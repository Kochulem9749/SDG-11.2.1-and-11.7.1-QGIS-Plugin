# -*- coding: utf-8 -*-
def classFactory(iface):
    from .transport_sa import TransportSAPlugin
    return TransportSAPlugin(iface)
