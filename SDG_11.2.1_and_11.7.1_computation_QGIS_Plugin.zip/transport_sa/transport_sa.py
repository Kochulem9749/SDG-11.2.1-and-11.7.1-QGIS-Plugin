# -*- coding: utf-8 -*-
import os
from qgis.PyQt.QtWidgets import QAction
from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtCore import QCoreApplication


class TransportSAPlugin:
    def __init__(self, iface):
        self.iface = iface
        self.action = None
        self.dialog = None

    def tr(self, message):
        return QCoreApplication.translate('TransportSA', message)

    def initGui(self):
        icon_path = os.path.join(os.path.dirname(__file__), 'icon.png')
        self.action = QAction(
            QIcon(icon_path) if os.path.exists(icon_path) else QIcon(),
            self.tr('SDG 11.2.1 & 11.7.1 Statistics Computation'),
            self.iface.mainWindow()
        )
        self.action.triggered.connect(self.run)
        self.iface.addToolBarIcon(self.action)
        self.iface.addPluginToVectorMenu(self.tr('&SDG 11.2.1 & 11.7.1'), self.action)

    def unload(self):
        self.iface.removePluginVectorMenu(self.tr('&SDG 11.2.1 & 11.7.1'), self.action)
        self.iface.removeToolBarIcon(self.action)
        if self.dialog:
            self.dialog.close()
            self.dialog = None

    def run(self):
        from .transport_sa_dialog import TransportSADialog
        if not self.dialog:
            self.dialog = TransportSADialog(self.iface)
        self.dialog.show()
        self.dialog.raise_()
        self.dialog.activateWindow()
