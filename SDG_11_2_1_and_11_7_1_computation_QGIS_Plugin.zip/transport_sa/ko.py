# -*- coding: utf-8 -*-
"""한국어."""

TEXT = {
    'win_title': 'SDG 11.2.1 및 11.7.1 통계 산출',
    'subtitle': '도시 지역으로 사전 자르기 -> 재투영 + 지오메트리 수정 -> 공공 오픈 '
                '스페이스 자르기 -> 경계점 -> 서비스 영역 -> 볼록 껍질 -> 자르기 -> '
                '디졸브 -> 서비스권 내 인구 -> 도로 폭 결합 -> 버퍼 -> 디졸브 -> '
                '자르기(도로 용지) -> 통계표',
    'language': '언어:',
    'tab_layers': '레이어',
    'tab_distances': '거리',
    'tab_output': '출력',
    'progress': '진행 상황',
    'btn_run': '분석 실행',
    'btn_cancel': '취소',
    'btn_reset': '로그 지우기',
    'btn_close': '닫기',
    'grp_streets': '도로',
    'note_streets': '네트워크 경로 탐색에 사용하는 도로 레이어',
    'grp_urban': '도시 경계',
    'note_urban': '도시 범위를 정의하는 폴리곤 레이어',
    'grp_pop_raster': '격자 인구(래스터)',
    'note_pop_raster': '격자 인구 데이터셋입니다. 이것 또는 아래의 가구 인구(포인트) 중 '
                       '하나를 지정하세요(둘 중 하나는 필수).',
    'grp_hh': '가구 인구(포인트)',
    'note_hh': '가구 단위 인구수를 담은 포인트 레이어입니다. 이것 또는 격자 인구 '
               '래스터 중 하나를 지정하세요(둘 중 하나는 필수). 둘 다 지정하면 가구 '
               '포인트를 사용합니다. 각 서비스권 인구 = 그 안에 있는 포인트의 선택한 '
               '필드 합계.',
    'lbl_pop_field': '총인구가 담긴 필드(가구 포인트별):',
    'grp_pos': '공공 오픈 스페이스(폴리곤)',
    'note_pos': '일반에 개방된 미개발지 또는 열린 토지를 나타내는 폴리곤 레이어로, '
                '주민에게 여가 공간을 제공하고 환경의 질을 높입니다. 예: 공원, 정원, '
                '놀이터, 공공 해변, 하천변, 수변 공간',
    'grp_bus': '저용량 대중교통 정류장(버스 정류장, 경전철 정류장)',
    'note_bus': '버스 정류장 / 경전철 정류장 위치 포인트 레이어',
    'grp_rail': '고용량 대중교통 역(철도역, 지하철역)',
    'note_rail': '철도역 / 지하철역 위치 포인트 레이어',
    'grp_ferry': '고용량 대중교통(여객선 터미널)',
    'note_ferry': '여객선 터미널 위치 포인트 레이어',
    'grp_widths': '실측 도로 폭(CSV 표)',
    'note_widths': '도로 용지 산출에 사용됩니다. 1열 = 도로 등급(아래에서 선택한 도로 '
                   '등급 필드와 대조), 2열 = 실측 폭(미터). CSV가 없고 도로 등급 필드도 '
                   '없으면 도로 용지 = 0입니다.',
    'btn_browse_csv': 'CSV 찾아보기...',
    'grp_catfield': '도로 등급 필드(도로 레이어)',
    'note_catfield': '도로 등급을 담은 도로 레이어의 필드로, 도로 폭 결합에 사용됩니다. '
                     '\'fclass\', \'highway\', \'type\'이 있으면 자동으로 선택되며, '
                     '없으면 여기서 필드를 선택하세요. 비워 두면 자동으로 감지합니다.',
    'grp_crs': '대상 좌표계(투영 좌표계, 미터 단위 - 예: 도시 지역의 UTM 존)',
    'dist_header': '네트워크 거리 임계값:',
    'dist_pos': '공공 오픈 스페이스',
    'spacing_header': '공공 오픈 스페이스 경계점 간격:',
    'spacing_note': '각 오픈 스페이스 외곽선을 따라 배치하는 시작점입니다. 표준은 100 m'
                    '입니다. 큰 공원이 많은 도시는 간격을 넓히면(예: 200 m) 더 빠르지만 '
                    '정확도는 약간 떨어집니다.',
    'perf_header': '성능:',
    'chk_preclip': '입력 데이터를 도시 지역으로 미리 자르기',
    'note_preclip': '권장. 도시 지역 탐색 범위 안의 도로, 정류장, 오픈 스페이스만 '
                    '유지합니다. 국가·지역 단위 데이터에서 훨씬 빠릅니다.',
    'chk_memory': '중간 레이어를 메모리에 유지',
    'note_memory': '더 빠릅니다. 컴퓨터 메모리가 부족할 때만 해제하세요.',
    'chk_native': 'QGIS 기본 서비스 영역 알고리즘 사용',
    'note_native': '검증용으로만 사용 - 시작점이 많으면 매우 느립니다. 기본값은 빠른 '
                   '제한 탐색입니다(결과 동일).',
    'grp_city': '도시 이름(팁: 특수 문자는 피하세요)',
    'city_placeholder': '예: Mombasa',
    'lbl_output_folder': '출력 폴더:',
    'btn_browse': '찾아보기...',
    'info_block':
        "보존되는 최종 파일:\n"
        "  자르기·디졸브한 서비스권:\n"
        "  SA_POS_dissolved.shp                공공 오픈 스페이스\n"
        "  SA_Bus_dissolved.shp                저용량 정류장\n"
        "  SA_Ferry_dissolved.shp              여객선 터미널\n"
        "  SA_Rail_dissolved.shp               철도역\n"
        "  SA_HighCapacity_dissolved.shp       고용량(철도 + 여객선)\n"
        "  SA_CombinedTransport_dissolved.shp  대중교통 전체\n"
        "  개별(정류장별) 서비스 영역:\n"
        "  SA_Bus_individual.shp / SA_Ferry_individual.shp / SA_Rail_individual.shp\n"
        "  ZonalStats_*.shp                    서비스권 + pop_sum 필드\n"
        "  LAS_streets_dissolved.shp           도로 용지\n"
        "  {city}_statistics_11.2.1_and_11.7.1.xlsx\n\n"
        "참고:\n"
        "  - 처리 전에 지오메트리를 자동으로 수정합니다.\n"
        "  - 인구: 가구 포인트가 있으면 인구 필드 합계,\n"
        "    없으면 격자 인구 래스터를 사용합니다.\n"
        "  - 공공 오픈 스페이스 면적은 도시 경계로 자른 뒤 측정합니다.\n"
        "  - 입력은 도시 지역 + 탐색 범위로 미리 자르고 중간 레이어는\n"
        "    메모리에 유지합니다(거리 탭에서 변경 가능).\n"
        "  - 대중교통 전체 = 저용량 정류장 + 여객선 + 철도\n"
        "    (공공 오픈 스페이스 제외).\n"
        "  - 도로 용지: 도로 폭에 따라 버퍼를 만들고 디졸브한 뒤\n"
        "    도시 범위로 자릅니다.\n"
        "  - 통계표는 선택한 언어로 작성됩니다.\n"
        "  - 실패 후에는 '로그 지우기'로 버튼을 다시 활성화하세요.",
    'msg_running_title': '실행 중',
    'msg_cannot_reset': '분석 실행 중에는 지울 수 없습니다. 먼저 취소하세요.',
    'msg_missing_layer': '레이어 없음',
    'msg_select_streets': '도로 레이어를 선택하세요.',
    'msg_select_urban': '도시 경계 레이어를 선택하세요.',
    'msg_missing_pop_title': '인구 데이터 없음',
    'msg_missing_pop': '격자 인구(래스터) 레이어 또는 가구 인구(포인트) 레이어를 '
                       '선택하세요(둘 중 하나는 필수).',
    'msg_missing_popfield_title': '인구 필드 없음',
    'msg_missing_popfield': '가구 인구(포인트) 레이어의 총인구 필드를 선택하세요.',
    'msg_missing_city_title': '도시 이름 없음',
    'msg_missing_city': '도시 이름을 입력하세요.',
    'msg_missing_output_title': '출력 폴더 없음',
    'msg_missing_output': '출력 폴더를 선택하세요.',
    'msg_invalid_crs_title': '잘못된 좌표계',
    'msg_invalid_crs': '올바른 대상 좌표계를 선택하세요.',
    'msg_no_transport_title': '교통 레이어 없음',
    'msg_no_transport': '공공 오픈 스페이스 / 저용량 / 여객선 / 철도 레이어가 선택되지 '
                        '않았습니다. 도시 지역과 도로만 처리합니다. 계속하시겠습니까?',
    'msg_complete': '완료',
    'msg_error': '오류',
    'msg_failed': '분석에 실패했습니다. 자세한 내용은 로그를 확인하세요.\n\n'
                  '\'로그 지우기\'를 누른 뒤 다시 실행하세요.',
    'msg_close_running': '분석이 아직 실행 중입니다. 취소하고 닫으시겠습니까?',
    'msg_cancel_requested': '취소를 요청했습니다...',
    'dlg_select_output': '출력 폴더 선택',
    'dlg_select_csv': '실측 도로 폭 CSV 선택',
    'csv_filter': 'CSV 파일 (*.csv *.txt);;모든 파일 (*)',
    'msg_invalid_csv_title': '잘못된 CSV',
    'msg_invalid_csv': '읽을 수 없습니다:',
    'msg_widths_title': '도로 폭 CSV',
    'msg_widths_cols': '도로 폭 표에는 최소 두 개의 열(도로 등급, 폭)이 필요합니다. 이 '
                       '표는 무시됩니다.',
    'res_done': '완료되었습니다!',
    'res_las': '도로 용지',
    'res_stats': '통계표(CSV)',
    'res_excel': '통계 통합 문서(Excel)',
    'res_roads': '도로 표',
    'res_folder': '폴더',
    'res_time': '소요 시간',
    'h_city': '도시',
    'h_urban_area': '도시 면적(km2)',
    'h_pos_area': '공공 오픈 스페이스 면적(km2)',
    'h_las': '도로 용지(km2)',
    'h_ops_las': '공공 오픈 스페이스 + 도로 용지(km2)',
    'h_prop_ops_las': '도시 면적 중 공공 오픈 스페이스 + 도로 용지 비율(%)',
    'h_total_pop': '도시 총인구',
    'h_pop_pos': '공공 오픈 스페이스 접근 가능 인구',
    'h_pop_bus': '저용량 대중교통 정류장(버스 정류장, 경전철 정류장) 접근 가능 인구',
    'h_pop_hc': '고용량 대중교통(철도 + 여객선) 접근 가능 인구',
    'h_pop_comb': '대중교통 전체 접근 가능 인구',
    'h_pct_pos': '공공 오픈 스페이스 접근 가능 인구 비율(%)',
    'h_pct_bus': '저용량 대중교통 정류장(버스 정류장, 경전철 정류장) 접근 가능 인구 '
                 '비율(%)',
    'h_pct_hc': '고용량 대중교통 접근 가능 인구 비율(%)',
    'h_pct_comb': '대중교통 전체 접근 가능 인구 비율(%)',
    'h_pop_source': '인구 데이터 출처',
    'src_household': '가구 포인트',
    'src_raster': '격자 래스터',
    'src_field': '필드',
}
