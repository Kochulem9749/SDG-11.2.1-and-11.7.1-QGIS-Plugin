# -*- coding: utf-8 -*-
"""Additional interface languages, one module per language (TEXT dict)."""
