# -*- coding: utf-8 -*-
"""Bahasa Indonesia."""

TEXT = {
    'win_title': 'Perhitungan Statistik SDG 11.2.1 dan 11.7.1',
    'subtitle': 'Pemotongan awal ke wilayah perkotaan -> Proyeksi ulang + perbaikan '
                'geometri -> Pemotongan ruang terbuka publik -> Titik batas -> Area '
                'layanan -> Selubung cembung -> Pemotongan -> Penggabungan -> '
                'Penduduk dalam area layanan -> Penggabungan lebar jalan -> Buffer -> '
                'Penggabungan -> Pemotongan (lahan untuk jalan) -> Tabel statistik',
    'language': 'Bahasa:',
    'tab_layers': 'Lapisan',
    'tab_distances': 'Jarak',
    'tab_output': 'Keluaran',
    'progress': 'Kemajuan',
    'btn_run': 'Jalankan analisis',
    'btn_cancel': 'Batal',
    'btn_reset': 'Hapus log',
    'btn_close': 'Tutup',
    'grp_streets': 'Jalan',
    'note_streets': 'Lapisan jalan yang digunakan untuk perutean jaringan',
    'grp_urban': 'Batas perkotaan',
    'note_urban': 'Lapisan poligon yang menentukan cakupan wilayah perkotaan',
    'grp_pop_raster': 'Penduduk berbasis grid (raster)',
    'note_pop_raster': 'Data penduduk berbasis grid. Berikan ini ATAU Penduduk rumah '
                       'tangga (titik) di bawah - salah satunya wajib.',
    'grp_hh': 'Penduduk rumah tangga (titik)',
    'note_hh': 'Lapisan titik dengan jumlah penduduk per rumah tangga. Berikan ini '
               'ATAU raster penduduk berbasis grid - salah satunya wajib. Jika '
               'keduanya diberikan, titik rumah tangga yang digunakan. Penduduk '
               'setiap area layanan = jumlah kolom terpilih dari titik-titik di '
               'dalamnya.',
    'lbl_pop_field': 'Kolom berisi total penduduk (per titik rumah tangga):',
    'grp_pos': 'Ruang terbuka publik (poligon)',
    'note_pos': 'Lapisan poligon berupa lahan tak terbangun atau terbuka yang dapat '
                'diakses publik, menyediakan area rekreasi bagi warga dan '
                'meningkatkan kualitas lingkungan. Contohnya taman, kebun, taman '
                'bermain, pantai umum, bantaran sungai, dan tepi air',
    'grp_bus': 'Halte angkutan berkapasitas rendah (halte bus, halte kereta '
               'ringan)',
    'note_bus': 'Lapisan titik lokasi halte bus / halte kereta ringan',
    'grp_rail': 'Halte angkutan berkapasitas tinggi (stasiun kereta, stasiun '
                'metro)',
    'note_rail': 'Lapisan titik lokasi stasiun kereta / metro',
    'grp_ferry': 'Halte angkutan berkapasitas tinggi (dermaga feri)',
    'note_ferry': 'Lapisan titik lokasi terminal feri',
    'grp_widths': 'Lebar jalan terukur (tabel CSV)',
    'note_widths': 'Digunakan untuk lahan untuk jalan. Kolom 1 = kategori jalan '
                   '(dicocokkan dengan kolom kategori jalan yang dipilih di bawah), '
                   'kolom 2 = lebar terukur dalam meter. Jika CSV tidak diberikan dan '
                   'tidak ada kolom kategori, lahan untuk jalan = 0.',
    'btn_browse_csv': 'Telusuri CSV...',
    'grp_catfield': 'Kolom kategori jalan (dari lapisan jalan)',
    'note_catfield': 'Kolom pada lapisan jalan yang berisi kategori jalan, digunakan '
                     'untuk menggabungkan lebar jalan. \'fclass\', \'highway\' atau '
                     '\'type\' dipilih otomatis jika ada; jika tidak, pilih kolom di '
                     'sini. Biarkan kosong untuk deteksi otomatis.',
    'grp_crs': 'Sistem referensi koordinat tujuan (terproyeksi, dalam meter - '
               'mis. UTM wilayah perkotaan)',
    'dist_header': 'Ambang jarak jaringan untuk:',
    'dist_pos': 'Ruang terbuka publik',
    'spacing_header': 'Jarak antar titik batas ruang terbuka publik:',
    'spacing_note': 'Titik awal yang ditempatkan di sepanjang garis tepi setiap ruang '
                    'terbuka. 100 m adalah standar; jarak lebih besar (mis. 200 m) '
                    'lebih cepat untuk kota dengan banyak taman besar, tetapi sedikit '
                    'kurang akurat.',
    'perf_header': 'Kinerja:',
    'chk_preclip': 'Potong data masukan terlebih dahulu ke wilayah perkotaan',
    'note_preclip': 'Disarankan. Hanya menyimpan jalan, halte, dan ruang terbuka di '
                    'dalam batas pencarian wilayah perkotaan - jauh lebih cepat untuk '
                    'data tingkat nasional atau regional.',
    'chk_memory': 'Simpan lapisan perantara di memori',
    'note_memory': 'Lebih cepat. Hapus centang hanya jika komputer kehabisan RAM.',
    'chk_native': 'Gunakan algoritma area layanan bawaan QGIS',
    'note_native': 'Hanya untuk pemeriksaan - sangat lambat dengan banyak titik awal. '
                   'Bawaan adalah pencarian terbatas yang cepat (hasil sama).',
    'grp_city': 'Nama kota (Tips: hindari karakter khusus)',
    'city_placeholder': 'mis. Mombasa',
    'lbl_output_folder': 'Folder keluaran:',
    'btn_browse': 'Telusuri...',
    'info_block':
        "Berkas akhir yang disimpan:\n"
        "  Area layanan yang dipotong dan digabungkan:\n"
        "  SA_POS_dissolved.shp                Ruang terbuka publik\n"
        "  SA_Bus_dissolved.shp                Halte kapasitas rendah\n"
        "  SA_Ferry_dissolved.shp              Dermaga feri\n"
        "  SA_Rail_dissolved.shp               Stasiun kereta\n"
        "  SA_HighCapacity_dissolved.shp       Kapasitas tinggi (kereta + feri)\n"
        "  SA_CombinedTransport_dissolved.shp  Angkutan umum gabungan\n"
        "  Area layanan individual (per halte):\n"
        "  SA_Bus_individual.shp / SA_Ferry_individual.shp / SA_Rail_individual.shp\n"
        "  ZonalStats_*.shp                    Area layanan + kolom pop_sum\n"
        "  LAS_streets_dissolved.shp           Lahan untuk jalan\n"
        "  {city}_statistics_11.2.1_and_11.7.1.xlsx\n\n"
        "CATATAN:\n"
        "  - Geometri diperbaiki otomatis sebelum pemrosesan.\n"
        "  - Penduduk: titik rumah tangga (jumlah kolom penduduk) jika diberikan,\n"
        "    jika tidak, raster penduduk berbasis grid.\n"
        "  - Luas ruang terbuka publik diukur setelah dipotong ke batas perkotaan.\n"
        "  - Data dipotong ke wilayah perkotaan + batas pencarian dan lapisan\n"
        "    perantara disimpan di memori (lihat tab Jarak).\n"
        "  - Angkutan gabungan = halte kapasitas rendah + feri + kereta\n"
        "    (ruang terbuka publik tidak termasuk).\n"
        "  - Lahan untuk jalan: buffer jalan sesuai lebarnya, digabungkan\n"
        "    dan dipotong ke cakupan perkotaan.\n"
        "  - Tabel statistik ditulis dalam bahasa yang dipilih.\n"
        "  - Gunakan 'Hapus log' untuk mengaktifkan kembali tombol setelah gagal.",
    'msg_running_title': 'Sedang berjalan',
    'msg_cannot_reset': 'Tidak dapat menghapus saat analisis berjalan. Batalkan '
                        'terlebih dahulu.',
    'msg_missing_layer': 'Lapisan tidak ada',
    'msg_select_streets': 'Silakan pilih lapisan jalan.',
    'msg_select_urban': 'Silakan pilih lapisan batas perkotaan.',
    'msg_missing_pop_title': 'Data penduduk tidak ada',
    'msg_missing_pop': 'Silakan pilih lapisan penduduk berbasis grid (raster) atau '
                       'lapisan penduduk rumah tangga (titik) - salah satunya wajib.',
    'msg_missing_popfield_title': 'Kolom penduduk tidak ada',
    'msg_missing_popfield': 'Silakan pilih kolom total penduduk untuk lapisan '
                            'penduduk rumah tangga (titik).',
    'msg_missing_city_title': 'Nama kota tidak ada',
    'msg_missing_city': 'Silakan masukkan nama kota.',
    'msg_missing_output_title': 'Folder keluaran tidak ada',
    'msg_missing_output': 'Silakan pilih folder keluaran.',
    'msg_invalid_crs_title': 'SRK tidak valid',
    'msg_invalid_crs': 'Silakan pilih SRK tujuan yang valid.',
    'msg_no_transport_title': 'Tidak ada lapisan transportasi',
    'msg_no_transport': 'Tidak ada lapisan ruang terbuka publik / kapasitas rendah / '
                        'feri / kereta yang dipilih. Hanya wilayah perkotaan dan '
                        'jalan yang akan diproses. Lanjutkan?',
    'msg_complete': 'Selesai',
    'msg_error': 'Galat',
    'msg_failed': 'Analisis gagal. Lihat log untuk detailnya.\n\n'
                  'Klik \'Hapus log\' lalu jalankan kembali.',
    'msg_close_running': 'Analisis masih berjalan. Batalkan dan tutup?',
    'msg_cancel_requested': 'Pembatalan diminta...',
    'dlg_select_output': 'Pilih folder keluaran',
    'dlg_select_csv': 'Pilih CSV lebar jalan terukur',
    'csv_filter': 'Berkas CSV (*.csv *.txt);;Semua berkas (*)',
    'msg_invalid_csv_title': 'CSV tidak valid',
    'msg_invalid_csv': 'Tidak dapat dibaca:',
    'msg_widths_title': 'CSV lebar jalan',
    'msg_widths_cols': 'Tabel lebar jalan memerlukan minimal dua kolom (kategori '
                       'jalan, lebar). Tabel ini akan diabaikan.',
    'res_done': 'Selesai!',
    'res_las': 'Lahan untuk jalan',
    'res_stats': 'Tabel statistik (CSV)',
    'res_excel': 'Buku kerja statistik (Excel)',
    'res_roads': 'Tabel jalan',
    'res_folder': 'Folder',
    'res_time': 'Waktu',
    'h_city': 'Kota',
    'h_urban_area': 'Luas wilayah perkotaan (km2)',
    'h_pos_area': 'Luas ruang terbuka publik (km2)',
    'h_las': 'Lahan untuk jalan (km2)',
    'h_ops_las': 'Ruang terbuka publik + lahan untuk jalan (km2)',
    'h_prop_ops_las': 'Proporsi wilayah perkotaan berupa ruang terbuka publik + '
                      'lahan untuk jalan (%)',
    'h_total_pop': 'Total penduduk perkotaan',
    'h_pop_pos': 'Penduduk dengan akses ke ruang terbuka publik',
    'h_pop_bus': 'Penduduk dengan akses ke halte angkutan berkapasitas rendah '
                 '(halte bus, halte kereta ringan)',
    'h_pop_hc': 'Penduduk dengan akses ke angkutan berkapasitas tinggi (kereta + '
                'feri)',
    'h_pop_comb': 'Penduduk dengan akses ke angkutan umum gabungan',
    'h_pct_pos': 'Persentase penduduk dengan akses ke ruang terbuka publik',
    'h_pct_bus': 'Persentase penduduk dengan akses ke halte angkutan berkapasitas '
                 'rendah (halte bus, halte kereta ringan)',
    'h_pct_hc': 'Persentase penduduk dengan akses ke angkutan berkapasitas tinggi',
    'h_pct_comb': 'Persentase penduduk dengan akses ke angkutan umum gabungan',
    'h_pop_source': 'Sumber data penduduk',
    'src_household': 'Titik rumah tangga',
    'src_raster': 'Raster grid',
    'src_field': 'kolom',
}
