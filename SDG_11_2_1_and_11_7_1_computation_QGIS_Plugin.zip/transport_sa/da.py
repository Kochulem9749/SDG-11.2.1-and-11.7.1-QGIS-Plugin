# -*- coding: utf-8 -*-
"""Dansk."""

TEXT = {
    'win_title': 'Beregning af statistik for SDG 11.2.1 og 11.7.1',
    'subtitle': 'Forudgående klipning til byområdet -> Omprojicering + '
                'geometrikorrektion -> Klipning af åbne offentlige rum -> '
                'Grænsepunkter -> Serviceområde -> Konveks hylster -> Klipning -> '
                'Sammenlægning -> Befolkning i oplande -> Sammenkædning af '
                'vejbredder -> Buffer -> Sammenlægning -> Klipning (areal afsat '
                'til gader) -> Statistiktabel',
    'language': 'Sprog:',
    'tab_layers': 'Lag',
    'tab_distances': 'Afstande',
    'tab_output': 'Output',
    'progress': 'Fremskridt',
    'btn_run': 'Kør analyse',
    'btn_cancel': 'Annuller',
    'btn_reset': 'Ryd log',
    'btn_close': 'Luk',
    'grp_streets': 'Gader',
    'note_streets': 'Gadelag, der bruges til ruteberegning i netværket',
    'grp_urban': 'Bygrænse',
    'note_urban': 'Polygonlag, der afgrænser byområdet',
    'grp_pop_raster': 'Gitterbaseret befolkning (raster)',
    'note_pop_raster': 'Gitterbaseret befolkningsdatasæt. Angiv dette ELLER '
                       'Husstandsbefolkning (punkter) nedenfor - et af dem er '
                       'påkrævet.',
    'grp_hh': 'Husstandsbefolkning (punkter)',
    'note_hh': 'Punktlag med antal indbyggere pr. husstand. Angiv dette ELLER '
               'befolkningsrasteret - et af dem er påkrævet. Hvis begge angives, '
               'bruges husstandspunkterne. Befolkning i hvert opland = summen af '
               'det valgte felt for punkterne inden for oplandet.',
    'lbl_pop_field': 'Felt med samlet befolkning (pr. husstandspunkt):',
    'grp_pos': 'Åbne offentlige rum (polygoner)',
    'note_pos': 'Polygonlag med ubebygget eller åbent areal, der er '
                'tilgængeligt for offentligheden, giver beboerne '
                'rekreative områder og forbedrer miljøkvaliteten. Eksempler: '
                'parker, haver, legepladser, offentlige strande, åbredder og '
                'havnefronter',
    'grp_bus': 'Stoppesteder for kollektiv trafik med lav kapacitet '
               '(busstoppesteder, letbanestop)',
    'note_bus': 'Punktlag med bus- / letbanestoppesteder',
    'grp_rail': 'Stoppesteder for kollektiv trafik med høj kapacitet '
                '(togstationer, metrostationer)',
    'note_rail': 'Punktlag med tog- / metrostationer',
    'grp_ferry': 'Stoppesteder for kollektiv trafik med høj kapacitet '
                 '(færgelejer)',
    'note_ferry': 'Punktlag med færgeterminaler',
    'grp_widths': 'Målte vejbredder (CSV-tabel)',
    'note_widths': 'Bruges til areal afsat til gader. Kolonne 1 = vejkategori '
                   '(matches med feltet for vejkategori, der vælges nedenfor), '
                   'kolonne 2 = målt vejbredde i meter. Hvis der ikke angives en '
                   'CSV, og der ikke findes et kategorifelt, er areal afsat til '
                   'gader = 0.',
    'btn_browse_csv': 'Gennemse CSV...',
    'grp_catfield': 'Felt for vejkategori (gadelag)',
    'note_catfield': 'Felt i gadelaget med vejkategorierne, bruges til at '
                     'sammenkæde vejbredderne. \'fclass\', \'highway\' eller '
                     '\'type\' vælges automatisk, hvis det findes; ellers vælges '
                     'feltet her. Lad feltet stå tomt for automatisk '
                     'genkendelse.',
    'grp_crs': 'Mål-koordinatsystem (projiceret, i meter - f.eks. UTM for '
               'byområdet)',
    'dist_header': 'Tærskel for netværksafstand for:',
    'dist_pos': 'Åbne offentlige rum',
    'spacing_header': 'Afstand mellem grænsepunkter for åbne offentlige rum:',
    'spacing_note': 'Startpunkter langs omridset af hvert åbent rum. 100 m er '
                    'standard; større afstand (f.eks. 200 m) er hurtigere for '
                    'byer med mange store parker, men lidt mindre præcis.',
    'perf_header': 'Ydeevne:',
    'chk_preclip': 'Klip inputdata til byområdet på forhånd',
    'note_preclip': 'Anbefales. Beholder kun gader, stoppesteder og åbne rum '
                    'inden for søgemarginen omkring byområdet - meget hurtigere '
                    'med data for hele landet eller regionen.',
    'chk_memory': 'Behold mellemliggende lag i hukommelsen',
    'note_memory': 'Hurtigere. Fjern kun markeringen, hvis computeren løber tør '
                   'for RAM.',
    'chk_native': 'Brug QGIS\' indbyggede algoritme til serviceområde',
    'note_native': 'Kun til kontrol - meget langsom med mange startpunkter. '
                   'Standard er den hurtige afgrænsede søgning (samme '
                   'resultater).',
    'grp_city': 'Byens navn (tip: undgå specialtegn)',
    'city_placeholder': 'f.eks. Mombasa',
    'lbl_output_folder': 'Outputmappe:',
    'btn_browse': 'Gennemse...',
    'info_block':
        "Endelige filer, der bevares:\n"
        "  Klippede og sammenlagte oplande:\n"
        "  SA_POS_dissolved.shp                Åbne offentlige rum\n"
        "  SA_Bus_dissolved.shp                Stoppesteder med lav kapacitet\n"
        "  SA_Ferry_dissolved.shp              Færgelejer\n"
        "  SA_Rail_dissolved.shp               Togstationer\n"
        "  SA_HighCapacity_dissolved.shp       Høj kapacitet (tog + færge)\n"
        "  SA_CombinedTransport_dissolved.shp  Kollektiv trafik samlet\n"
        "  Individuelle serviceområder (pr. stoppested):\n"
        "  SA_Bus_individual.shp / SA_Ferry_individual.shp / SA_Rail_individual.shp\n"
        "  ZonalStats_*.shp                    Opland + feltet pop_sum\n"
        "  LAS_streets_dissolved.shp           Areal afsat til gader\n"
        "  {city}_statistics_11.2.1_and_11.7.1.xlsx\n\n"
        "BEMÆRKNINGER:\n"
        "  - Geometrier korrigeres automatisk før behandlingen.\n"
        "  - Befolkning: husstandspunkter (summen af befolkningsfeltet), hvis\n"
        "    de angives, ellers befolkningsrasteret.\n"
        "  - Arealet af åbne offentlige rum måles efter klipning til bygrænsen.\n"
        "  - Inputdata klippes til byområdet + søgemargin, og mellemliggende\n"
        "    lag holdes i hukommelsen (se fanen Afstande).\n"
        "  - Kollektiv trafik samlet = lav kapacitet + færge + tog\n"
        "    (åbne offentlige rum indgår ikke).\n"
        "  - Areal afsat til gader: gader med buffer efter bredde, lagt sammen\n"
        "    og klippet til byområdet.\n"
        "  - Statistiktabellen skrives på det valgte sprog.\n"
        "  - Brug »Ryd log« for at aktivere knapperne igen efter en fejl.",
    'msg_running_title': 'Kører',
    'msg_cannot_reset': 'Kan ikke rydde, mens analysen kører. Annuller først.',
    'msg_missing_layer': 'Manglende lag',
    'msg_select_streets': 'Vælg et gadelag.',
    'msg_select_urban': 'Vælg et lag for bygrænsen.',
    'msg_missing_pop_title': 'Manglende befolkningsdata',
    'msg_missing_pop': 'Vælg et lag med gitterbaseret befolkning (raster) eller '
                       'husstandsbefolkning (punkter) - et af dem er påkrævet.',
    'msg_missing_popfield_title': 'Manglende befolkningsfelt',
    'msg_missing_popfield': 'Vælg feltet med samlet befolkning for laget med '
                            'husstandsbefolkning (punkter).',
    'msg_missing_city_title': 'Manglende bynavn',
    'msg_missing_city': 'Indtast byens navn.',
    'msg_missing_output_title': 'Manglende outputmappe',
    'msg_missing_output': 'Vælg en outputmappe.',
    'msg_invalid_crs_title': 'Ugyldigt koordinatsystem',
    'msg_invalid_crs': 'Vælg et gyldigt mål-koordinatsystem.',
    'msg_no_transport_title': 'Ingen trafiklag',
    'msg_no_transport': 'Der er ikke valgt lag for åbne offentlige rum / lav '
                        'kapacitet / færge / tog. Kun byområdet og gaderne '
                        'behandles. Fortsæt?',
    'msg_complete': 'Fuldført',
    'msg_error': 'Fejl',
    'msg_failed': 'Analysen mislykkedes. Se loggen for detaljer.\n\n'
                  'Klik på »Ryd log«, og kør igen.',
    'msg_close_running': 'Analysen kører stadig. Annuller og luk?',
    'msg_cancel_requested': 'Annullering anmodet...',
    'dlg_select_output': 'Vælg outputmappe',
    'dlg_select_csv': 'Vælg CSV med målte vejbredder',
    'csv_filter': 'CSV-filer (*.csv *.txt);;Alle filer (*)',
    'msg_invalid_csv_title': 'Ugyldig CSV',
    'msg_invalid_csv': 'Kunne ikke læses:',
    'msg_widths_title': 'CSV med vejbredder',
    'msg_widths_cols': 'Tabellen med vejbredder skal have mindst to kolonner '
                       '(vejkategori, bredde). Den ignoreres.',
    'res_done': 'Færdig!',
    'res_las': 'Areal afsat til gader',
    'res_stats': 'Statistiktabel (CSV)',
    'res_excel': 'Statistikprojektmappe (Excel)',
    'res_roads': 'Gadetabel',
    'res_folder': 'Mappe',
    'res_time': 'Tid',
    'h_city': 'By',
    'h_urban_area': 'Byareal (km2)',
    'h_pos_area': 'Areal af åbne offentlige rum (km2)',
    'h_las': 'Areal afsat til gader (km2)',
    'h_ops_las': 'Åbne offentlige rum + areal afsat til gader (km2)',
    'h_prop_ops_las': 'Andel af byarealet med åbne offentlige rum + areal afsat '
                      'til gader (%)',
    'h_total_pop': 'Samlet bybefolkning',
    'h_pop_pos': 'Befolkning med adgang til åbne offentlige rum',
    'h_pop_bus': 'Befolkning med adgang til stoppesteder for kollektiv trafik '
                 'med lav kapacitet (busstoppesteder, letbanestop)',
    'h_pop_hc': 'Befolkning med adgang til kollektiv trafik med høj kapacitet '
                '(tog + færge)',
    'h_pop_comb': 'Befolkning med adgang til kollektiv trafik samlet',
    'h_pct_pos': 'Andel af befolkningen med adgang til åbne offentlige rum (%)',
    'h_pct_bus': 'Andel af befolkningen med adgang til stoppesteder for '
                 'kollektiv trafik med lav kapacitet (busstoppesteder, '
                 'letbanestop) (%)',
    'h_pct_hc': 'Andel af befolkningen med adgang til kollektiv trafik med høj '
                'kapacitet (%)',
    'h_pct_comb': 'Andel af befolkningen med adgang til kollektiv trafik '
                  'samlet (%)',
    'h_pop_source': 'Kilde til befolkningsdata',
    'src_household': 'Husstandspunkter',
    'src_raster': 'Befolkningsraster',
    'src_field': 'felt',
}
