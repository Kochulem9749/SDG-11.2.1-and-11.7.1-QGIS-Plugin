# -*- coding: utf-8 -*-
"""Nederlands."""

TEXT = {
    'win_title': 'Berekening van statistieken voor SDG 11.2.1 en 11.7.1',
    'subtitle': 'Vooraf knippen tot het stedelijk gebied -> Herprojectie + '
                'geometrieherstel -> Knippen van open openbare ruimten -> Grenspunten '
                '-> Verzorgingsgebied -> Convex omhulsel -> Knippen -> Samenvoegen -> '
                'Bevolking in verzorgingsgebieden -> Koppeling van straatbreedtes -> '
                'Buffer -> Samenvoegen -> Knippen (grond bestemd voor straten) -> '
                'Statistiektabel',
    'language': 'Taal:',
    'tab_layers': 'Lagen',
    'tab_distances': 'Afstanden',
    'tab_output': 'Uitvoer',
    'progress': 'Voortgang',
    'btn_run': 'Analyse starten',
    'btn_cancel': 'Annuleren',
    'btn_reset': 'Logboek wissen',
    'btn_close': 'Sluiten',
    'grp_streets': 'Straten',
    'note_streets': 'Stratenlaag voor routeberekening over het netwerk',
    'grp_urban': 'Stedelijke grens',
    'note_urban': 'Polygoonlaag die de omvang van het stedelijk gebied bepaalt',
    'grp_pop_raster': 'Gerasterde bevolking (raster)',
    'note_pop_raster': 'Gerasterde bevolkingsdataset. Geef deze OF de '
                       'Huishoudbevolking (punten) hieronder op - één van beide is '
                       'verplicht.',
    'grp_hh': 'Huishoudbevolking (punten)',
    'note_hh': 'Puntenlaag met het aantal inwoners per huishouden. Geef deze OF het '
               'gerasterde bevolkingsraster op - één van beide is verplicht. Als beide '
               'zijn opgegeven, worden de huishoudpunten gebruikt. Bevolking per '
               'verzorgingsgebied = som van het gekozen veld over de punten erbinnen.',
    'lbl_pop_field': 'Veld met de totale bevolking (per huishoudpunt):',
    'grp_pos': 'Open openbare ruimten (polygonen)',
    'note_pos': 'Polygoonlagen met onbebouwde of open, publiek toegankelijke grond die '
                'bewoners recreatieruimte biedt en de milieukwaliteit verbetert. '
                'Voorbeelden: parken, tuinen, speeltuinen, openbare stranden, '
                'rivieroevers en waterkanten',
    'grp_bus': 'Haltes van vervoer met lage capaciteit (bushaltes, '
               'sneltram-/tramhaltes)',
    'note_bus': 'Puntenlaag met de locaties van bus- / tramhaltes',
    'grp_rail': 'Haltes van vervoer met hoge capaciteit (treinstations, '
                'metrostations)',
    'note_rail': 'Puntenlaag met de locaties van trein- / metrostations',
    'grp_ferry': 'Haltes van vervoer met hoge capaciteit (veersteigers)',
    'note_ferry': 'Puntenlaag met de locaties van veerterminals',
    'grp_widths': 'Gemeten straatbreedtes (CSV-tabel)',
    'note_widths': 'Gebruikt voor de grond bestemd voor straten. Kolom 1 = '
                   'wegcategorie (gekoppeld aan het hieronder gekozen veld voor de '
                   'wegcategorie), kolom 2 = gemeten breedte in meters. Zonder CSV en '
                   'zonder categorieveld is de grond bestemd voor straten = 0.',
    'btn_browse_csv': 'CSV bladeren...',
    'grp_catfield': 'Veld wegcategorie (uit de stratenlaag)',
    'note_catfield': 'Veld van de stratenlaag met de wegcategorieën, gebruikt om de '
                     'breedtes te koppelen. \'fclass\', \'highway\' of \'type\' wordt '
                     'automatisch gekozen als het bestaat; kies anders hier het veld. '
                     'Leeg laten voor automatische herkenning.',
    'grp_crs': 'Doel-coördinatenreferentiesysteem (geprojecteerd, in meters - bijv. '
               'UTM-zone van het stedelijk gebied)',
    'dist_header': 'Drempelwaarde netwerkafstand voor:',
    'dist_pos': 'Open openbare ruimten',
    'spacing_header': 'Afstand tussen grenspunten van open openbare ruimten:',
    'spacing_note': 'Startpunten langs de omtrek van elke open ruimte. 100 m is de '
                    'standaard; een grotere afstand (bijv. 200 m) is sneller voor '
                    'steden met veel grote parken, maar iets minder nauwkeurig.',
    'perf_header': 'Prestaties:',
    'chk_preclip': 'Invoer vooraf knippen tot het stedelijk gebied',
    'note_preclip': 'Aanbevolen. Behoudt alleen straten, haltes en open ruimten binnen '
                    'de zoekmarge rond het stedelijk gebied - veel sneller met '
                    'landelijke of regionale gegevens.',
    'chk_memory': 'Tussenlagen in het geheugen houden',
    'note_memory': 'Sneller. Alleen uitvinken als de computer te weinig RAM heeft.',
    'chk_native': 'Ingebouwd QGIS-algoritme voor verzorgingsgebieden gebruiken',
    'note_native': 'Alleen ter controle - zeer traag bij veel startpunten. Standaard '
                   'wordt de snelle begrensde zoekmethode gebruikt (zelfde '
                   'resultaten).',
    'grp_city': 'Naam van de stad (tip: vermijd speciale tekens)',
    'city_placeholder': 'bijv. Mombasa',
    'lbl_output_folder': 'Uitvoermap:',
    'btn_browse': 'Bladeren...',
    'info_block':
        "Bewaarde eindbestanden:\n"
        "  Geknipte en samengevoegde verzorgingsgebieden:\n"
        "  SA_POS_dissolved.shp                Open openbare ruimten\n"
        "  SA_Bus_dissolved.shp                Haltes met lage capaciteit\n"
        "  SA_Ferry_dissolved.shp              Veersteigers\n"
        "  SA_Rail_dissolved.shp               Treinstations\n"
        "  SA_HighCapacity_dissolved.shp       Hoge capaciteit (spoor + veer)\n"
        "  SA_CombinedTransport_dissolved.shp  Openbaar vervoer totaal\n"
        "  Afzonderlijke verzorgingsgebieden (per halte):\n"
        "  SA_Bus_individual.shp / SA_Ferry_individual.shp / SA_Rail_individual.shp\n"
        "  ZonalStats_*.shp                    Verzorgingsgebied + veld pop_sum\n"
        "  LAS_streets_dissolved.shp           Grond bestemd voor straten\n"
        "  {city}_statistics_11.2.1_and_11.7.1.xlsx\n\n"
        "OPMERKINGEN:\n"
        "  - Geometrieën worden vóór de verwerking automatisch hersteld.\n"
        "  - Bevolking: huishoudpunten (som van het bevolkingsveld) indien\n"
        "    opgegeven, anders het gerasterde bevolkingsraster.\n"
        "  - Oppervlakte van open openbare ruimten gemeten na knippen tot de stadsgrens.\n"
        "  - Invoer wordt geknipt tot stedelijk gebied + zoekmarge en tussenlagen\n"
        "    blijven in het geheugen (zie tabblad Afstanden).\n"
        "  - Openbaar vervoer totaal = lage capaciteit + veer + spoor\n"
        "    (zonder open openbare ruimten).\n"
        "  - Grond bestemd voor straten: straten gebufferd naar breedte,\n"
        "    samengevoegd en geknipt tot het stedelijk gebied.\n"
        "  - De statistiektabel wordt in de gekozen taal geschreven.\n"
        "  - Gebruik na een fout 'Logboek wissen' om de knoppen weer te activeren.",
    'msg_running_title': 'Bezig',
    'msg_cannot_reset': 'Wissen is niet mogelijk tijdens de analyse. Annuleer eerst.',
    'msg_missing_layer': 'Ontbrekende laag',
    'msg_select_streets': 'Selecteer een stratenlaag.',
    'msg_select_urban': 'Selecteer een laag met de stedelijke grens.',
    'msg_missing_pop_title': 'Ontbrekende bevolkingsgegevens',
    'msg_missing_pop': 'Selecteer een laag met gerasterde bevolking (raster) of '
                       'huishoudbevolking (punten) - één van beide is verplicht.',
    'msg_missing_popfield_title': 'Ontbrekend bevolkingsveld',
    'msg_missing_popfield': 'Selecteer het veld met de totale bevolking voor de laag '
                            'huishoudbevolking (punten).',
    'msg_missing_city_title': 'Ontbrekende stadsnaam',
    'msg_missing_city': 'Voer de naam van de stad in.',
    'msg_missing_output_title': 'Ontbrekende uitvoermap',
    'msg_missing_output': 'Selecteer een uitvoermap.',
    'msg_invalid_crs_title': 'Ongeldig CRS',
    'msg_invalid_crs': 'Selecteer een geldig doel-CRS.',
    'msg_no_transport_title': 'Geen vervoerslagen',
    'msg_no_transport': 'Er is geen laag voor open openbare ruimten / lage capaciteit / '
                        'veer / spoor gekozen. Alleen het stedelijk gebied en de straten '
                        'worden verwerkt. Doorgaan?',
    'msg_complete': 'Voltooid',
    'msg_error': 'Fout',
    'msg_failed': 'De analyse is mislukt. Zie het logboek voor details.\n\n'
                  'Klik op \'Logboek wissen\' en start opnieuw.',
    'msg_close_running': 'De analyse loopt nog. Annuleren en sluiten?',
    'msg_cancel_requested': 'Annulering aangevraagd...',
    'dlg_select_output': 'Uitvoermap selecteren',
    'dlg_select_csv': 'CSV met gemeten straatbreedtes selecteren',
    'csv_filter': 'CSV-bestanden (*.csv *.txt);;Alle bestanden (*)',
    'msg_invalid_csv_title': 'Ongeldige CSV',
    'msg_invalid_csv': 'Kon niet worden gelezen:',
    'msg_widths_title': 'CSV straatbreedtes',
    'msg_widths_cols': 'De tabel met straatbreedtes moet minstens twee kolommen hebben '
                       '(wegcategorie, breedte). Hij wordt genegeerd.',
    'res_done': 'Klaar!',
    'res_las': 'Grond bestemd voor straten',
    'res_stats': 'Statistiektabel (CSV)',
    'res_excel': 'Statistiekwerkmap (Excel)',
    'res_roads': 'Stratentabel',
    'res_folder': 'Map',
    'res_time': 'Duur',
    'h_city': 'Stad',
    'h_urban_area': 'Stedelijke oppervlakte (km2)',
    'h_pos_area': 'Oppervlakte open openbare ruimten (km2)',
    'h_las': 'Grond bestemd voor straten (km2)',
    'h_ops_las': 'Open openbare ruimten + grond bestemd voor straten (km2)',
    'h_prop_ops_las': 'Aandeel van de stedelijke oppervlakte in open openbare ruimten '
                      '+ grond bestemd voor straten (%)',
    'h_total_pop': 'Totale stedelijke bevolking',
    'h_pop_pos': 'Bevolking met toegang tot open openbare ruimten',
    'h_pop_bus': 'Bevolking met toegang tot haltes van vervoer met lage capaciteit '
                 '(bushaltes, sneltram-/tramhaltes)',
    'h_pop_hc': 'Bevolking met toegang tot vervoer met hoge capaciteit (spoor + veer)',
    'h_pop_comb': 'Bevolking met toegang tot openbaar vervoer totaal',
    'h_pct_pos': 'Percentage bevolking met toegang tot open openbare ruimten',
    'h_pct_bus': 'Percentage bevolking met toegang tot haltes van vervoer met lage '
                 'capaciteit (bushaltes, sneltram-/tramhaltes)',
    'h_pct_hc': 'Percentage bevolking met toegang tot vervoer met hoge capaciteit',
    'h_pct_comb': 'Percentage bevolking met toegang tot openbaar vervoer totaal',
    'h_pop_source': 'Bron van bevolkingsgegevens',
    'src_household': 'Huishoudpunten',
    'src_raster': 'Bevolkingsraster',
    'src_field': 'veld',
}
