# -*- coding: utf-8 -*-
"""Norsk (bokmål)."""

TEXT = {
    'win_title': 'Beregning av statistikk for SDG 11.2.1 og 11.7.1',
    'subtitle': 'Forhåndsklipping til tettstedsområdet -> Omprojisering + '
                'geometrikorrigering -> Klipping av åpne offentlige rom -> '
                'Grensepunkter -> Serviceområde -> Konveks innhylling -> Klipping '
                '-> Sammenslåing -> Befolkning i dekningsområder -> Kobling av '
                'gatebredder -> Buffer -> Sammenslåing -> Klipping (areal avsatt '
                'til gater) -> Statistikktabell',
    'language': 'Språk:',
    'tab_layers': 'Lag',
    'tab_distances': 'Avstander',
    'tab_output': 'Utdata',
    'progress': 'Fremdrift',
    'btn_run': 'Kjør analyse',
    'btn_cancel': 'Avbryt',
    'btn_reset': 'Tøm logg',
    'btn_close': 'Lukk',
    'grp_streets': 'Gater',
    'note_streets': 'Gatelag som brukes til ruteberegning i nettverket',
    'grp_urban': 'Tettstedsgrense',
    'note_urban': 'Polygonlag som avgrenser tettstedsområdet',
    'grp_pop_raster': 'Rutenettbefolkning (raster)',
    'note_pop_raster': 'Befolkningsdata i rutenett. Oppgi dette ELLER '
                       'Husholdningsbefolkning (punkter) nedenfor - ett av dem '
                       'er påkrevd.',
    'grp_hh': 'Husholdningsbefolkning (punkter)',
    'note_hh': 'Punktlag med antall innbyggere per husholdning. Oppgi dette '
               'ELLER befolkningsrasteret - ett av dem er påkrevd. Hvis begge '
               'oppgis, brukes husholdningspunktene. Befolkning i hvert '
               'dekningsområde = summen av det valgte feltet for punktene innenfor '
               'området.',
    'lbl_pop_field': 'Felt med total befolkning (per husholdningspunkt):',
    'grp_pos': 'Åpne offentlige rom (polygoner)',
    'note_pos': 'Polygonlag med ubebygd eller åpent areal som er tilgjengelig '
                'for allmennheten, gir innbyggerne rekreasjonsområder og bedrer '
                'miljøkvaliteten. Eksempler: parker, hager, lekeplasser, '
                'offentlige strender, elvebredder og havnepromenader',
    'grp_bus': 'Holdeplasser for kollektivtransport med lav kapasitet '
               '(bussholdeplasser, bybaneholdeplasser)',
    'note_bus': 'Punktlag med buss- / bybaneholdeplasser',
    'grp_rail': 'Holdeplasser for kollektivtransport med høy kapasitet '
                '(jernbanestasjoner, T-banestasjoner)',
    'note_rail': 'Punktlag med jernbane- / T-banestasjoner',
    'grp_ferry': 'Holdeplasser for kollektivtransport med høy kapasitet '
                 '(fergekaier)',
    'note_ferry': 'Punktlag med fergeterminaler',
    'grp_widths': 'Målte gatebredder (CSV-tabell)',
    'note_widths': 'Brukes for areal avsatt til gater. Kolonne 1 = vegkategori '
                   '(matches mot feltet for vegkategori som velges nedenfor), '
                   'kolonne 2 = målt gatebredde i meter. Hvis ingen CSV oppgis og '
                   'det ikke finnes noe kategorifelt, blir areal avsatt til '
                   'gater = 0.',
    'btn_browse_csv': 'Bla etter CSV...',
    'grp_catfield': 'Felt for vegkategori (gatelag)',
    'note_catfield': 'Felt i gatelaget med vegkategoriene, brukes til å koble '
                     'gatebreddene. \'fclass\', \'highway\' eller \'type\' velges '
                     'automatisk hvis det finnes; ellers velger du feltet her. La '
                     'stå tomt for automatisk gjenkjenning.',
    'grp_crs': 'Målkoordinatsystem (projisert, i meter - f.eks. UTM for '
               'tettstedsområdet)',
    'dist_header': 'Terskel for nettverksavstand for:',
    'dist_pos': 'Åpne offentlige rom',
    'spacing_header': 'Avstand mellom grensepunkter for åpne offentlige rom:',
    'spacing_note': 'Startpunkter langs omrisset av hvert åpent rom. 100 m er '
                    'standard; større avstand (f.eks. 200 m) går raskere for byer '
                    'med mange store parker, men blir litt mindre nøyaktig.',
    'perf_header': 'Ytelse:',
    'chk_preclip': 'Forhåndsklipp inndata til tettstedsområdet',
    'note_preclip': 'Anbefales. Beholder bare gater, holdeplasser og åpne rom '
                    'innenfor søkemarginen rundt tettstedsområdet - mye raskere '
                    'med data for hele landet eller regionen.',
    'chk_memory': 'Behold mellomlag i minnet',
    'note_memory': 'Raskere. Fjern avmerkingen bare hvis datamaskinen går tom '
                   'for RAM.',
    'chk_native': 'Bruk QGIS sin innebygde algoritme for serviceområde',
    'note_native': 'Bare for kontroll - svært tregt med mange startpunkter. '
                   'Standard er det raske avgrensede søket (samme resultater).',
    'grp_city': 'Byens navn (tips: unngå spesialtegn)',
    'city_placeholder': 'f.eks. Mombasa',
    'lbl_output_folder': 'Utdatamappe:',
    'btn_browse': 'Bla gjennom...',
    'info_block':
        "Endelige filer som beholdes:\n"
        "  Klippede og sammenslåtte dekningsområder:\n"
        "  SA_POS_dissolved.shp                Åpne offentlige rom\n"
        "  SA_Bus_dissolved.shp                Holdeplasser med lav kapasitet\n"
        "  SA_Ferry_dissolved.shp              Fergekaier\n"
        "  SA_Rail_dissolved.shp               Jernbanestasjoner\n"
        "  SA_HighCapacity_dissolved.shp       Høy kapasitet (jernbane + ferge)\n"
        "  SA_CombinedTransport_dissolved.shp  Kollektivtransport samlet\n"
        "  Enkeltvise serviceområder (per holdeplass):\n"
        "  SA_Bus_individual.shp / SA_Ferry_individual.shp / SA_Rail_individual.shp\n"
        "  ZonalStats_*.shp                    Dekningsområde + feltet pop_sum\n"
        "  LAS_streets_dissolved.shp           Areal avsatt til gater\n"
        "  {city}_statistics_11.2.1_and_11.7.1.xlsx\n\n"
        "MERKNADER:\n"
        "  - Geometrier korrigeres automatisk før behandlingen.\n"
        "  - Befolkning: husholdningspunkter (summen av befolkningsfeltet) hvis\n"
        "    de oppgis, ellers befolkningsrasteret.\n"
        "  - Arealet av åpne offentlige rom måles etter klipping mot tettstedsgrensen.\n"
        "  - Inndata forhåndsklippes til tettstedsområdet + søkemargin, og\n"
        "    mellomlag holdes i minnet (se fanen Avstander).\n"
        "  - Kollektivtransport samlet = lav kapasitet + ferge + jernbane\n"
        "    (åpne offentlige rom er ikke med).\n"
        "  - Areal avsatt til gater: gater bufret etter bredde, slått sammen\n"
        "    og klippet mot tettstedsområdet.\n"
        "  - Statistikktabellen skrives på det valgte språket.\n"
        "  - Bruk «Tøm logg» for å aktivere knappene igjen etter en feil.",
    'msg_running_title': 'Kjører',
    'msg_cannot_reset': 'Kan ikke tømme mens analysen kjører. Avbryt først.',
    'msg_missing_layer': 'Lag mangler',
    'msg_select_streets': 'Velg et gatelag.',
    'msg_select_urban': 'Velg et lag for tettstedsgrensen.',
    'msg_missing_pop_title': 'Befolkningsdata mangler',
    'msg_missing_pop': 'Velg et lag med rutenettbefolkning (raster) eller '
                       'husholdningsbefolkning (punkter) - ett av dem er '
                       'påkrevd.',
    'msg_missing_popfield_title': 'Befolkningsfelt mangler',
    'msg_missing_popfield': 'Velg feltet med total befolkning for laget med '
                            'husholdningsbefolkning (punkter).',
    'msg_missing_city_title': 'Byens navn mangler',
    'msg_missing_city': 'Skriv inn byens navn.',
    'msg_missing_output_title': 'Utdatamappe mangler',
    'msg_missing_output': 'Velg en utdatamappe.',
    'msg_invalid_crs_title': 'Ugyldig koordinatsystem',
    'msg_invalid_crs': 'Velg et gyldig målkoordinatsystem.',
    'msg_no_transport_title': 'Ingen transportlag',
    'msg_no_transport': 'Ingen lag for åpne offentlige rom / lav kapasitet / '
                        'ferge / jernbane er valgt. Bare tettstedsområdet og '
                        'gatene behandles. Fortsette?',
    'msg_complete': 'Fullført',
    'msg_error': 'Feil',
    'msg_failed': 'Analysen mislyktes. Se loggen for detaljer.\n\n'
                  'Klikk «Tøm logg» og kjør på nytt.',
    'msg_close_running': 'Analysen kjører fortsatt. Avbryte og lukke?',
    'msg_cancel_requested': 'Avbrudd forespurt...',
    'dlg_select_output': 'Velg utdatamappe',
    'dlg_select_csv': 'Velg CSV med målte gatebredder',
    'csv_filter': 'CSV-filer (*.csv *.txt);;Alle filer (*)',
    'msg_invalid_csv_title': 'Ugyldig CSV',
    'msg_invalid_csv': 'Kunne ikke leses:',
    'msg_widths_title': 'CSV med gatebredder',
    'msg_widths_cols': 'Tabellen med gatebredder må ha minst to kolonner '
                       '(vegkategori, bredde). Den blir ignorert.',
    'res_done': 'Ferdig!',
    'res_las': 'Areal avsatt til gater',
    'res_stats': 'Statistikktabell (CSV)',
    'res_excel': 'Statistikkarbeidsbok (Excel)',
    'res_roads': 'Gatetabell',
    'res_folder': 'Mappe',
    'res_time': 'Tid',
    'h_city': 'By',
    'h_urban_area': 'Tettstedsareal (km2)',
    'h_pos_area': 'Areal av åpne offentlige rom (km2)',
    'h_las': 'Areal avsatt til gater (km2)',
    'h_ops_las': 'Åpne offentlige rom + areal avsatt til gater (km2)',
    'h_prop_ops_las': 'Andel av tettstedsarealet med åpne offentlige rom + '
                      'areal avsatt til gater (%)',
    'h_total_pop': 'Total befolkning i tettstedet',
    'h_pop_pos': 'Befolkning med tilgang til åpne offentlige rom',
    'h_pop_bus': 'Befolkning med tilgang til holdeplasser for kollektivtransport '
                 'med lav kapasitet (bussholdeplasser, bybaneholdeplasser)',
    'h_pop_hc': 'Befolkning med tilgang til kollektivtransport med høy '
                'kapasitet (jernbane + ferge)',
    'h_pop_comb': 'Befolkning med tilgang til kollektivtransport samlet',
    'h_pct_pos': 'Andel av befolkningen med tilgang til åpne offentlige rom '
                 '(%)',
    'h_pct_bus': 'Andel av befolkningen med tilgang til holdeplasser for '
                 'kollektivtransport med lav kapasitet (bussholdeplasser, '
                 'bybaneholdeplasser) (%)',
    'h_pct_hc': 'Andel av befolkningen med tilgang til kollektivtransport med '
                'høy kapasitet (%)',
    'h_pct_comb': 'Andel av befolkningen med tilgang til kollektivtransport '
                  'samlet (%)',
    'h_pop_source': 'Kilde for befolkningsdata',
    'src_household': 'Husholdningspunkter',
    'src_raster': 'Befolkningsraster',
    'src_field': 'felt',
}
