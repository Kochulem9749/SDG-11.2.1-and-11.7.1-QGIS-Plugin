# -*- coding: utf-8 -*-
"""Deutsch."""

TEXT = {
    'win_title': 'Berechnung der Statistiken zu SDG 11.2.1 und 11.7.1',
    'subtitle': 'Vorab-Zuschnitt auf das Stadtgebiet -> Umprojektion + '
                'Geometriekorrektur -> Zuschnitt der öffentlichen Freiflächen '
                '-> Randpunkte -> Einzugsbereich -> Konvexe Hülle -> Zuschnitt '
                '-> Auflösen -> Bevölkerung in den Einzugsgebieten -> Verknüpfung '
                'der Straßenbreiten -> Puffer -> Auflösen -> Zuschnitt '
                '(Straßenfläche) -> Statistiktabelle',
    'language': 'Sprache:',
    'tab_layers': 'Layer',
    'tab_distances': 'Entfernungen',
    'tab_output': 'Ausgabe',
    'progress': 'Fortschritt',
    'btn_run': 'Analyse starten',
    'btn_cancel': 'Abbrechen',
    'btn_reset': 'Protokoll leeren',
    'btn_close': 'Schließen',
    'grp_streets': 'Straßen',
    'note_streets': 'Straßen-Layer für die Routenberechnung im Netz',
    'grp_urban': 'Stadtgrenze',
    'note_urban': 'Polygon-Layer, der die Ausdehnung des Stadtgebiets festlegt',
    'grp_pop_raster': 'Gerasterte Bevölkerung (Raster)',
    'note_pop_raster': 'Gerasterter Bevölkerungsdatensatz. Geben Sie diesen ODER '
                       'die Haushaltsbevölkerung (Punkte) unten an - eines von '
                       'beiden ist erforderlich.',
    'grp_hh': 'Haushaltsbevölkerung (Punkte)',
    'note_hh': 'Punkt-Layer mit Einwohnerzahlen auf Haushaltsebene. Geben Sie '
               'diesen ODER das gerasterte Bevölkerungsraster an - eines von '
               'beiden ist erforderlich. Sind beide angegeben, werden die '
               'Haushaltspunkte verwendet. Bevölkerung je Einzugsgebiet = Summe '
               'des gewählten Feldes über die darin liegenden Punkte.',
    'lbl_pop_field': 'Feld mit der Gesamtbevölkerung (je Haushaltspunkt):',
    'grp_pos': 'Öffentliche Freiflächen (Polygone)',
    'note_pos': 'Polygon-Layer mit unbebauten oder offenen, öffentlich '
                'zugänglichen Flächen, die den Bewohnern Erholungsräume bieten '
                'und die Umweltqualität verbessern. Beispiele: Parks, Gärten, '
                'Spielplätze, öffentliche Strände, Flussufer und Uferpromenaden',
    'grp_bus': 'Haltestellen des Verkehrs mit geringer Kapazität '
               '(Bushaltestellen, Stadtbahnhaltestellen)',
    'note_bus': 'Punkt-Layer der Bus- / Stadtbahnhaltestellen',
    'grp_rail': 'Haltestellen des Verkehrs mit hoher Kapazität (Bahnhöfe, '
                'U-Bahn-Stationen)',
    'note_rail': 'Punkt-Layer der Bahnhöfe / U-Bahn-Stationen',
    'grp_ferry': 'Haltestellen des Verkehrs mit hoher Kapazität (Fähranleger)',
    'note_ferry': 'Punkt-Layer der Fährterminals',
    'grp_widths': 'Gemessene Straßenbreiten (CSV-Tabelle)',
    'note_widths': 'Wird für die Straßenfläche verwendet. Spalte 1 = '
                   'Straßenkategorie (abgeglichen mit dem unten gewählten Feld '
                   'der Straßenkategorie), Spalte 2 = gemessene Straßenbreite in '
                   'Metern. Wird keine CSV angegeben und ist kein Kategoriefeld '
                   'vorhanden, ist die Straßenfläche = 0.',
    'btn_browse_csv': 'CSV durchsuchen...',
    'grp_catfield': 'Feld der Straßenkategorie (Straßen-Layer)',
    'note_catfield': 'Feld des Straßen-Layers mit den Straßenkategorien, '
                     'verwendet zur Verknüpfung der Straßenbreiten. \'fclass\', '
                     '\'highway\' oder \'type\' wird automatisch gewählt, falls '
                     'vorhanden; andernfalls hier das Feld auswählen. Leer lassen '
                     'für die automatische Erkennung.',
    'grp_crs': 'Ziel-Koordinatenbezugssystem (projiziert, in Metern - z. B. '
               'UTM des Stadtgebiets)',
    'dist_header': 'Schwellenwert der Netzentfernung für:',
    'dist_pos': 'Öffentliche Freiflächen',
    'spacing_header': 'Abstand der Randpunkte der öffentlichen Freiflächen:',
    'spacing_note': 'Startpunkte entlang des Umrisses jeder Freifläche. 100 m '
                    'ist der Standard; ein größerer Abstand (z. B. 200 m) ist '
                    'bei Städten mit vielen großen Parks schneller, aber etwas '
                    'ungenauer.',
    'perf_header': 'Leistung:',
    'chk_preclip': 'Eingabedaten vorab auf das Stadtgebiet zuschneiden',
    'note_preclip': 'Empfohlen. Behält nur Straßen, Haltestellen und '
                    'Freiflächen innerhalb des Suchrands um das Stadtgebiet - '
                    'deutlich schneller bei landes- oder regionsweiten Daten.',
    'chk_memory': 'Zwischen-Layer im Arbeitsspeicher halten',
    'note_memory': 'Schneller. Nur deaktivieren, wenn der Arbeitsspeicher des '
                   'Computers nicht ausreicht.',
    'chk_native': 'Native QGIS-Einzugsbereichsberechnung verwenden',
    'note_native': 'Nur zur Kontrolle - sehr langsam bei vielen Startpunkten. '
                   'Standard ist die schnelle begrenzte Suche (gleiche '
                   'Ergebnisse).',
    'grp_city': 'Name der Stadt (Hinweis: Sonderzeichen vermeiden)',
    'city_placeholder': 'z. B. Mombasa',
    'lbl_output_folder': 'Ausgabeordner:',
    'btn_browse': 'Durchsuchen...',
    'info_block':
        "Beibehaltene Ergebnisdateien:\n"
        "  Zugeschnittene und aufgelöste Einzugsgebiete:\n"
        "  SA_POS_dissolved.shp                Öffentliche Freiflächen\n"
        "  SA_Bus_dissolved.shp                Haltestellen mit geringer Kapazität\n"
        "  SA_Ferry_dissolved.shp              Fähranleger\n"
        "  SA_Rail_dissolved.shp               Bahnhöfe\n"
        "  SA_HighCapacity_dissolved.shp       Hohe Kapazität (Bahn + Fähre)\n"
        "  SA_CombinedTransport_dissolved.shp  Öffentlicher Verkehr gesamt\n"
        "  Einzelne Einzugsbereiche (je Haltestelle):\n"
        "  SA_Bus_individual.shp / SA_Ferry_individual.shp / SA_Rail_individual.shp\n"
        "  ZonalStats_*.shp                    Einzugsgebiet + Feld pop_sum\n"
        "  LAS_streets_dissolved.shp           Straßenfläche\n"
        "  {city}_statistics_11.2.1_and_11.7.1.xlsx\n\n"
        "HINWEISE:\n"
        "  - Geometrien werden vor der Verarbeitung automatisch korrigiert.\n"
        "  - Bevölkerung: Haushaltspunkte (Summe des Bevölkerungsfeldes),\n"
        "    falls angegeben, sonst das gerasterte Bevölkerungsraster.\n"
        "  - Fläche der Freiflächen nach Zuschnitt auf die Stadtgrenze gemessen.\n"
        "  - Eingabedaten werden auf Stadtgebiet + Suchrand zugeschnitten und\n"
        "    Zwischen-Layer im Speicher gehalten (siehe Reiter Entfernungen).\n"
        "  - Öffentlicher Verkehr gesamt = geringe Kapazität + Fähre + Bahn\n"
        "    (ohne öffentliche Freiflächen).\n"
        "  - Straßenfläche: Straßen nach Breite gepuffert, aufgelöst und\n"
        "    auf das Stadtgebiet zugeschnitten.\n"
        "  - Die Statistiktabelle wird in der gewählten Sprache geschrieben.\n"
        "  - Nach einem Fehler mit „Protokoll leeren“ die Schaltflächen reaktivieren.",
    'msg_running_title': 'Läuft',
    'msg_cannot_reset': 'Leeren nicht möglich, solange die Analyse läuft. '
                        'Bitte zuerst abbrechen.',
    'msg_missing_layer': 'Fehlender Layer',
    'msg_select_streets': 'Bitte einen Straßen-Layer auswählen.',
    'msg_select_urban': 'Bitte einen Layer der Stadtgrenze auswählen.',
    'msg_missing_pop_title': 'Fehlende Bevölkerungsdaten',
    'msg_missing_pop': 'Bitte einen Layer der gerasterten Bevölkerung (Raster) '
                       'oder der Haushaltsbevölkerung (Punkte) auswählen - einer '
                       'von beiden ist erforderlich.',
    'msg_missing_popfield_title': 'Fehlendes Bevölkerungsfeld',
    'msg_missing_popfield': 'Bitte das Feld mit der Gesamtbevölkerung für den '
                            'Layer der Haushaltsbevölkerung (Punkte) auswählen.',
    'msg_missing_city_title': 'Fehlender Stadtname',
    'msg_missing_city': 'Bitte einen Stadtnamen eingeben.',
    'msg_missing_output_title': 'Fehlender Ausgabeordner',
    'msg_missing_output': 'Bitte einen Ausgabeordner auswählen.',
    'msg_invalid_crs_title': 'Ungültiges KBS',
    'msg_invalid_crs': 'Bitte ein gültiges Ziel-KBS auswählen.',
    'msg_no_transport_title': 'Keine Verkehrs-Layer',
    'msg_no_transport': 'Kein Layer für öffentliche Freiflächen / geringe '
                        'Kapazität / Fähre / Bahn ausgewählt. Es werden nur '
                        'Stadtgebiet und Straßen verarbeitet. Fortfahren?',
    'msg_complete': 'Abgeschlossen',
    'msg_error': 'Fehler',
    'msg_failed': 'Die Analyse ist fehlgeschlagen. Details im Protokoll.'
                  '\n\nKlicken Sie auf „Protokoll leeren“ und starten Sie neu.',
    'msg_close_running': 'Die Analyse läuft noch. Abbrechen und schließen?',
    'msg_cancel_requested': 'Abbruch angefordert...',
    'dlg_select_output': 'Ausgabeordner auswählen',
    'dlg_select_csv': 'CSV mit gemessenen Straßenbreiten auswählen',
    'csv_filter': 'CSV-Dateien (*.csv *.txt);;Alle Dateien (*)',
    'msg_invalid_csv_title': 'Ungültige CSV',
    'msg_invalid_csv': 'Konnte nicht gelesen werden:',
    'msg_widths_title': 'CSV der Straßenbreiten',
    'msg_widths_cols': 'Die Tabelle der Straßenbreiten benötigt mindestens zwei '
                       'Spalten (Straßenkategorie, Breite). Sie wird ignoriert.',
    'res_done': 'Fertig!',
    'res_las': 'Straßenfläche',
    'res_stats': 'Statistiktabelle (CSV)',
    'res_excel': 'Statistik-Arbeitsmappe (Excel)',
    'res_roads': 'Straßentabelle',
    'res_folder': 'Ordner',
    'res_time': 'Dauer',
    'h_city': 'Stadt',
    'h_urban_area': 'Stadtfläche (km2)',
    'h_pos_area': 'Fläche der öffentlichen Freiflächen (km2)',
    'h_las': 'Straßenfläche (km2)',
    'h_ops_las': 'Öffentliche Freiflächen + Straßenfläche (km2)',
    'h_prop_ops_las': 'Anteil der Stadtfläche an öffentlichen Freiflächen + '
                      'Straßenfläche (%)',
    'h_total_pop': 'Städtische Gesamtbevölkerung',
    'h_pop_pos': 'Bevölkerung mit Zugang zu öffentlichen Freiflächen',
    'h_pop_bus': 'Bevölkerung mit Zugang zu Haltestellen des Verkehrs mit '
                 'geringer Kapazität (Bushaltestellen, Stadtbahnhaltestellen)',
    'h_pop_hc': 'Bevölkerung mit Zugang zu Verkehr mit hoher Kapazität (Bahn + '
                'Fähre)',
    'h_pop_comb': 'Bevölkerung mit Zugang zum öffentlichen Verkehr gesamt',
    'h_pct_pos': 'Anteil der Bevölkerung mit Zugang zu öffentlichen '
                 'Freiflächen (%)',
    'h_pct_bus': 'Anteil der Bevölkerung mit Zugang zu Haltestellen des '
                 'Verkehrs mit geringer Kapazität (Bushaltestellen, '
                 'Stadtbahnhaltestellen) (%)',
    'h_pct_hc': 'Anteil der Bevölkerung mit Zugang zu Verkehr mit hoher '
                'Kapazität (%)',
    'h_pct_comb': 'Anteil der Bevölkerung mit Zugang zum öffentlichen Verkehr '
                  'gesamt (%)',
    'h_pop_source': 'Quelle der Bevölkerungsdaten',
    'src_household': 'Haushaltspunkte',
    'src_raster': 'Bevölkerungsraster',
    'src_field': 'Feld',
}
