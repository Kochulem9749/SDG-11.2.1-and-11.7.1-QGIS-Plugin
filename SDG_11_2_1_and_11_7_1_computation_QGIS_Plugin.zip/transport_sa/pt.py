# -*- coding: utf-8 -*-
"""Português (European Portuguese spelling, as used in Mozambique, Angola,
Portugal)."""

TEXT = {
    'win_title': 'Cálculo das estatísticas dos ODS 11.2.1 e 11.7.1',
    'subtitle': 'Recorte prévio à área urbana -> Reprojeção + correção de '
                'geometrias -> Recorte dos espaços públicos abertos -> Pontos '
                'de contorno -> Área de serviço -> Envolvente convexa -> Recorte '
                '-> Dissolução -> População nas áreas de abrangência -> Junção '
                'das larguras das vias -> Buffer -> Dissolução -> Recorte (área '
                'destinada às ruas) -> Tabela estatística',
    'language': 'Idioma:',
    'tab_layers': 'Camadas',
    'tab_distances': 'Distâncias',
    'tab_output': 'Resultados',
    'progress': 'Progresso',
    'btn_run': 'Executar análise',
    'btn_cancel': 'Cancelar',
    'btn_reset': 'Limpar registo',
    'btn_close': 'Fechar',
    'grp_streets': 'Ruas',
    'note_streets': 'Camada de ruas utilizada para o cálculo de percursos na '
                    'rede',
    'grp_urban': 'Limite urbano',
    'note_urban': 'Camada de polígonos que define a extensão urbana',
    'grp_pop_raster': 'População em grelha (raster)',
    'note_pop_raster': 'Conjunto de dados de população em grelha. Forneça este '
                       'OU a População dos agregados familiares (pontos) abaixo '
                       '- um dos dois é obrigatório.',
    'grp_hh': 'População dos agregados familiares (pontos)',
    'note_hh': 'Camada de pontos com o número de habitantes por agregado '
               'familiar. Forneça esta camada OU o raster de população em '
               'grelha - um dos dois é obrigatório. Se forem fornecidos ambos, '
               'são usados os pontos dos agregados familiares. População de cada '
               'área de abrangência = soma do campo selecionado para os pontos '
               'situados no seu interior.',
    'lbl_pop_field': 'Campo com a população total (por ponto de agregado '
                     'familiar):',
    'grp_pos': 'Espaços públicos abertos (polígonos)',
    'note_pos': 'Camadas de polígonos que representam terrenos não edificados '
                'ou abertos acessíveis ao público, que proporcionam áreas de '
                'lazer aos residentes e melhoram a qualidade ambiental. Por '
                'exemplo: parques, jardins, parques infantis, praias públicas, '
                'margens de rios e frentes de água',
    'grp_bus': 'Paragens de transporte de baixa capacidade (paragens de '
               'autocarro, de metro ligeiro)',
    'note_bus': 'Camada de pontos com a localização das paragens de autocarro '
                '/ metro ligeiro',
    'grp_rail': 'Paragens de transporte de alta capacidade (estações '
                'ferroviárias, de metro)',
    'note_rail': 'Camada de pontos com a localização das estações '
                 'ferroviárias / de metro',
    'grp_ferry': 'Paragens de transporte de alta capacidade (cais de ferry)',
    'note_ferry': 'Camada de pontos com a localização dos terminais de ferry',
    'grp_widths': 'Larguras medidas das vias (tabela CSV)',
    'note_widths': 'Utilizado para a área destinada às ruas. Coluna 1 = '
                   'categoria da via (associada ao campo de categoria da via '
                   'selecionado abaixo), coluna 2 = largura medida em metros. '
                   'Se não for fornecido nenhum CSV e não existir campo de '
                   'categoria, a área destinada às ruas = 0.',
    'btn_browse_csv': 'Procurar CSV...',
    'grp_catfield': 'Campo de categoria da via (camada de ruas)',
    'note_catfield': 'Campo da camada de ruas que contém as categorias das '
                     'vias, utilizado para juntar as larguras. \'fclass\', '
                     '\'highway\' ou \'type\' é selecionado automaticamente se '
                     'existir; caso contrário, escolha o campo aqui. Deixe vazio '
                     'para deteção automática.',
    'grp_crs': 'Sistema de referência de coordenadas de destino (projetado, '
               'em metros - p. ex. UTM da área urbana)',
    'dist_header': 'Limiar de distância na rede para:',
    'dist_pos': 'Espaços públicos abertos',
    'spacing_header': 'Espaçamento dos pontos no contorno dos espaços públicos '
                      'abertos:',
    'spacing_note': 'Pontos de partida colocados ao longo do contorno de cada '
                    'espaço aberto. 100 m é o valor padrão; um espaçamento '
                    'maior (p. ex. 200 m) é mais rápido em cidades com muitos '
                    'parques grandes, mas ligeiramente menos preciso.',
    'perf_header': 'Desempenho:',
    'chk_preclip': 'Recortar previamente os dados à área urbana',
    'note_preclip': 'Recomendado. Mantém apenas as ruas, paragens e espaços '
                    'abertos dentro da margem de pesquisa da área urbana - muito '
                    'mais rápido com dados de âmbito nacional ou regional.',
    'chk_memory': 'Manter as camadas intermédias em memória',
    'note_memory': 'Mais rápido. Desmarque apenas se o computador ficar sem '
                   'memória RAM.',
    'chk_native': 'Utilizar o algoritmo nativo de área de serviço do QGIS',
    'note_native': 'Apenas para verificação - muito lento com muitos pontos de '
                   'partida. Por predefinição é usada a pesquisa limitada rápida '
                   '(mesmos resultados).',
    'grp_city': 'Nome da cidade (dica: evite caracteres especiais)',
    'city_placeholder': 'p. ex. Mombasa',
    'lbl_output_folder': 'Pasta de resultados:',
    'btn_browse': 'Procurar...',
    'info_block':
        "Ficheiros finais conservados:\n"
        "  Áreas de abrangência recortadas e dissolvidas:\n"
        "  SA_POS_dissolved.shp                Espaços públicos abertos\n"
        "  SA_Bus_dissolved.shp                Paragens de baixa capacidade\n"
        "  SA_Ferry_dissolved.shp              Cais de ferry\n"
        "  SA_Rail_dissolved.shp               Estações ferroviárias\n"
        "  SA_HighCapacity_dissolved.shp       Alta capacidade (ferrovia + ferry)\n"
        "  SA_CombinedTransport_dissolved.shp  Transporte público combinado\n"
        "  Áreas de serviço individuais (por paragem):\n"
        "  SA_Bus_individual.shp / SA_Ferry_individual.shp / SA_Rail_individual.shp\n"
        "  ZonalStats_*.shp                    Área de abrangência + campo pop_sum\n"
        "  LAS_streets_dissolved.shp           Área destinada às ruas\n"
        "  {city}_statistics_11.2.1_and_11.7.1.xlsx\n\n"
        "NOTAS:\n"
        "  - As geometrias são corrigidas automaticamente antes do processamento.\n"
        "  - População: pontos dos agregados familiares (soma do campo de população)\n"
        "    se fornecidos; caso contrário, o raster de população em grelha.\n"
        "  - Área dos espaços públicos abertos medida após recorte ao limite urbano.\n"
        "  - Os dados são recortados à área urbana + margem de pesquisa e as\n"
        "    camadas intermédias mantidas em memória (ver separador Distâncias).\n"
        "  - Transporte combinado = paragens de baixa capacidade + ferry + ferrovia\n"
        "    (espaços públicos abertos excluídos).\n"
        "  - Área destinada às ruas: buffer das ruas segundo a largura,\n"
        "    dissolvido e recortado à extensão urbana.\n"
        "  - A tabela estatística é escrita no idioma selecionado.\n"
        "  - Use «Limpar registo» para reativar os botões após um erro.",
    'msg_running_title': 'Em execução',
    'msg_cannot_reset': 'Não é possível limpar enquanto a análise está em '
                        'execução. Cancele primeiro.',
    'msg_missing_layer': 'Camada em falta',
    'msg_select_streets': 'Selecione uma camada de ruas.',
    'msg_select_urban': 'Selecione uma camada de limite urbano.',
    'msg_missing_pop_title': 'Dados de população em falta',
    'msg_missing_pop': 'Selecione uma camada de população em grelha (raster) '
                       'ou uma camada de população dos agregados familiares '
                       '(pontos) - uma das duas é obrigatória.',
    'msg_missing_popfield_title': 'Campo de população em falta',
    'msg_missing_popfield': 'Selecione o campo com a população total da camada '
                            'de população dos agregados familiares (pontos).',
    'msg_missing_city_title': 'Nome da cidade em falta',
    'msg_missing_city': 'Introduza o nome da cidade.',
    'msg_missing_output_title': 'Pasta de resultados em falta',
    'msg_missing_output': 'Selecione uma pasta de resultados.',
    'msg_invalid_crs_title': 'SRC inválido',
    'msg_invalid_crs': 'Selecione um SRC de destino válido.',
    'msg_no_transport_title': 'Sem camadas de transporte',
    'msg_no_transport': 'Não foi selecionada nenhuma camada de espaços públicos '
                        'abertos / baixa capacidade / ferry / ferrovia. Serão '
                        'processadas apenas a área urbana e as ruas. Continuar?',
    'msg_complete': 'Concluído',
    'msg_error': 'Erro',
    'msg_failed': 'A análise falhou. Consulte o registo para mais detalhes.'
                  '\n\nClique em «Limpar registo» para recomeçar.',
    'msg_close_running': 'A análise ainda está em execução. Cancelar e fechar?',
    'msg_cancel_requested': 'Cancelamento solicitado...',
    'dlg_select_output': 'Selecionar a pasta de resultados',
    'dlg_select_csv': 'Selecionar o CSV das larguras medidas das vias',
    'csv_filter': 'Ficheiros CSV (*.csv *.txt);;Todos os ficheiros (*)',
    'msg_invalid_csv_title': 'CSV inválido',
    'msg_invalid_csv': 'Não foi possível ler:',
    'msg_widths_title': 'CSV das larguras das vias',
    'msg_widths_cols': 'A tabela de larguras das vias precisa de pelo menos '
                       'duas colunas (categoria da via, largura). Será ignorada.',
    'res_done': 'Concluído!',
    'res_las': 'Área destinada às ruas',
    'res_stats': 'Tabela estatística (CSV)',
    'res_excel': 'Livro estatístico (Excel)',
    'res_roads': 'Tabela das ruas',
    'res_folder': 'Pasta',
    'res_time': 'Tempo',
    'h_city': 'Cidade',
    'h_urban_area': 'Área urbana (km2)',
    'h_pos_area': 'Área dos espaços públicos abertos (km2)',
    'h_las': 'Área destinada às ruas (km2)',
    'h_ops_las': 'Espaços públicos abertos + área destinada às ruas (km2)',
    'h_prop_ops_las': 'Proporção da área urbana em espaços públicos abertos + '
                      'área destinada às ruas (%)',
    'h_total_pop': 'População urbana total',
    'h_pop_pos': 'População com acesso a espaços públicos abertos',
    'h_pop_bus': 'População com acesso a paragens de transporte de baixa '
                 'capacidade (paragens de autocarro, de metro ligeiro)',
    'h_pop_hc': 'População com acesso a transporte de alta capacidade '
                '(ferrovia + ferry)',
    'h_pop_comb': 'População com acesso ao transporte público combinado',
    'h_pct_pos': 'Percentagem da população com acesso a espaços públicos '
                 'abertos',
    'h_pct_bus': 'Percentagem da população com acesso a paragens de transporte '
                 'de baixa capacidade (paragens de autocarro, de metro ligeiro)',
    'h_pct_hc': 'Percentagem da população com acesso a transporte de alta '
                'capacidade',
    'h_pct_comb': 'Percentagem da população com acesso ao transporte público '
                  'combinado',
    'h_pop_source': 'Fonte dos dados de população',
    'src_household': 'Pontos dos agregados familiares',
    'src_raster': 'Raster em grelha',
    'src_field': 'campo',
}
