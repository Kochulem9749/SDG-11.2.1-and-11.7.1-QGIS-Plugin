# -*- coding: utf-8 -*-
"""
Translations for the SDG 11.2.1 and 11.7.1 Statistics Computation plugin.

Languages: English (en), French (fr), Spanish (es), Italian (it),
Chinese - Simplified (zh), Arabic (ar) - in STRINGS below - plus 27 more
languages, one file each in translations/<code>.py: Portuguese, German,
Russian, Japanese, Swahili, Swedish, Norwegian (Bokmål), Danish, Hindi,
Bengali, Urdu, Punjabi, Marathi, Telugu, Tamil, Gujarati, Indonesian,
Turkish, Korean, Vietnamese, Persian, Thai, Polish, Dutch, Ukrainian,
Amharic and Hausa.

Every user-facing string of the dialog and the column headers of the output
statistics table live here or in translations/<code>.py. To correct a
translation, edit the text for that language. Missing texts fall back to
English.
"""

LANGUAGES = [
    ('en', 'English'),
    ('fr', 'Français'),
    ('es', 'Español'),
    ('it', 'Italiano'),
    ('zh', '中文'),
    ('ar', 'العربية'),
    ('pt', 'Português'),
    ('de', 'Deutsch'),
    ('ru', 'Русский'),
    ('ja', '日本語'),
    ('sw', 'Kiswahili'),
    ('sv', 'Svenska'),
    ('nb', 'Norsk (bokmål)'),
    ('da', 'Dansk'),
    ('hi', 'हिन्दी'),
    ('bn', 'বাংলা'),
    ('ur', 'اردو'),
    ('pa', 'ਪੰਜਾਬੀ'),
    ('mr', 'मराठी'),
    ('te', 'తెలుగు'),
    ('ta', 'தமிழ்'),
    ('gu', 'ગુજરાતી'),
    ('id', 'Bahasa Indonesia'),
    ('tr', 'Türkçe'),
    ('ko', '한국어'),
    ('vi', 'Tiếng Việt'),
    ('fa', 'فارسی'),
    ('th', 'ไทย'),
    ('pl', 'Polski'),
    ('nl', 'Nederlands'),
    ('uk', 'Українська'),
    ('am', 'አማርኛ'),
    ('ha', 'Hausa'),
]

# QGIS locale prefixes that map onto one of the languages above.
LOCALE_ALIASES = {'no': 'nb', 'nn': 'nb', 'in': 'id'}

RTL_LANGUAGES = {'ar', 'ur', 'fa'}

STRINGS = {
    # ------------------------------------------------------------------ window
    'win_title': {
        'en': 'SDG 11.2.1 and 11.7.1 Statistics Computation',
        'fr': 'Calcul des statistiques des ODD 11.2.1 et 11.7.1',
        'es': 'Cálculo de estadísticas de los ODS 11.2.1 y 11.7.1',
        'it': 'Calcolo delle statistiche degli SDG 11.2.1 e 11.7.1',
        'zh': '可持续发展目标 11.2.1 和 11.7.1 统计计算',
        'ar': 'حساب إحصاءات مؤشري أهداف التنمية المستدامة 11.2.1 و11.7.1',
    },
    'subtitle': {
        'en': 'Pre-clip to Urban Area -> Reproject + Fix Geometries -> Clip Open '
              'Public Spaces -> Boundary Points -> Service Area -> Convex Hull '
              '-> Clip -> Dissolve -> Population in Catchments -> Road Widths '
              'Join -> Buffer -> Dissolve -> Clip (Land Allocated to Streets) '
              '-> Statistics Table',
        'fr': 'Pré-découpage à la zone urbaine -> Reprojection + correction des '
              'géométries -> Découpage des espaces publics ouverts -> Points de '
              'contour -> Zone de desserte -> Enveloppe convexe -> Découpage -> '
              'Fusion -> Population des zones de desserte -> Jointure des '
              'largeurs de voirie -> Tampon -> Fusion -> Découpage (superficie '
              'consacrée aux rues) -> Tableau statistique',
        'es': 'Recorte previo al área urbana -> Reproyección + corrección de '
              'geometrías -> Recorte de espacios públicos abiertos -> Puntos de '
              'contorno -> Área de servicio -> Envolvente convexa -> Recorte -> '
              'Disolución -> Población en áreas de cobertura -> Unión de anchos '
              'de vía -> Búfer -> Disolución -> Recorte (superficie destinada a '
              'calles) -> Tabla estadística',
        'it': 'Ritaglio preliminare all\'area urbana -> Riproiezione + '
              'correzione geometrie -> Ritaglio degli spazi pubblici aperti -> '
              'Punti di contorno -> Area di servizio -> Inviluppo convesso -> '
              'Ritaglio -> Dissoluzione -> Popolazione nei bacini di utenza -> '
              'Unione larghezze stradali -> Buffer -> Dissoluzione -> Ritaglio '
              '(superficie destinata alle strade) -> Tabella statistica',
        'zh': '预裁剪至城市区域 -> 重投影并修复几何 -> 裁剪公共开放空间 -> 边界点 -> '
              '服务区 -> 凸包 -> 裁剪 -> 融合 -> 服务范围内人口 -> 连接道路宽度 -> '
              '缓冲区 -> 融合 -> 裁剪（街道用地） -> 统计表',
        'ar': 'القص المسبق للمنطقة الحضرية ← إعادة الإسقاط وإصلاح الأشكال '
              'الهندسية ← قص الأماكن العامة المفتوحة ← نقاط الحدود ← منطقة '
              'الخدمة ← الغلاف المحدب ← القص ← الدمج ← السكان ضمن مناطق '
              'الخدمة ← ربط عروض الطرق ← النطاق العازل ← الدمج ← القص '
              '(المساحة المخصصة للشوارع) ← جدول الإحصاءات',
    },
    'language': {
        'en': 'Language:', 'fr': 'Langue :', 'es': 'Idioma:',
        'it': 'Lingua:', 'zh': '语言：', 'ar': 'اللغة:',
    },
    'tab_layers': {
        'en': 'Layers', 'fr': 'Couches', 'es': 'Capas',
        'it': 'Layer', 'zh': '图层', 'ar': 'الطبقات',
    },
    'tab_distances': {
        'en': 'Distances', 'fr': 'Distances', 'es': 'Distancias',
        'it': 'Distanze', 'zh': '距离', 'ar': 'المسافات',
    },
    'tab_output': {
        'en': 'Output', 'fr': 'Sortie', 'es': 'Salida',
        'it': 'Output', 'zh': '输出', 'ar': 'المخرجات',
    },
    'progress': {
        'en': 'Progress', 'fr': 'Progression', 'es': 'Progreso',
        'it': 'Avanzamento', 'zh': '进度', 'ar': 'التقدم',
    },
    'btn_run': {
        'en': 'Run Analysis', 'fr': 'Lancer l\'analyse',
        'es': 'Ejecutar análisis', 'it': 'Avvia analisi',
        'zh': '运行分析', 'ar': 'تشغيل التحليل',
    },
    'btn_cancel': {
        'en': 'Cancel', 'fr': 'Annuler', 'es': 'Cancelar',
        'it': 'Annulla', 'zh': '取消', 'ar': 'إلغاء',
    },
    'btn_reset': {
        'en': 'Reset Log', 'fr': 'Effacer le journal',
        'es': 'Borrar registro', 'it': 'Azzera registro',
        'zh': '清空日志', 'ar': 'مسح السجل',
    },
    'btn_close': {
        'en': 'Close', 'fr': 'Fermer', 'es': 'Cerrar',
        'it': 'Chiudi', 'zh': '关闭', 'ar': 'إغلاق',
    },

    # ------------------------------------------------------------- layers tab
    'grp_streets': {
        'en': 'Streets', 'fr': 'Rues', 'es': 'Calles',
        'it': 'Strade', 'zh': '街道', 'ar': 'الشوارع',
    },
    'note_streets': {
        'en': 'Street layer used for network routing',
        'fr': 'Couche des rues utilisée pour le calcul d\'itinéraires sur le '
              'réseau',
        'es': 'Capa de calles utilizada para el enrutamiento en la red',
        'it': 'Layer delle strade utilizzato per il calcolo dei percorsi '
              'sulla rete',
        'zh': '用于网络路径分析的街道图层',
        'ar': 'طبقة الشوارع المستخدمة لتحليل المسارات على الشبكة',
    },
    'grp_urban': {
        'en': 'Urban Boundary', 'fr': 'Limite urbaine',
        'es': 'Límite urbano', 'it': 'Confine urbano',
        'zh': '城市边界', 'ar': 'الحدود الحضرية',
    },
    'note_urban': {
        'en': 'Polygon layer defining urban extent',
        'fr': 'Couche de polygones définissant l\'étendue urbaine',
        'es': 'Capa de polígonos que define la extensión urbana',
        'it': 'Layer poligonale che definisce l\'estensione urbana',
        'zh': '定义城市范围的面图层',
        'ar': 'طبقة مضلعات تحدد النطاق الحضري',
    },
    'grp_pop_raster': {
        'en': 'Gridded Population (Raster)',
        'fr': 'Population maillée (raster)',
        'es': 'Población en cuadrícula (ráster)',
        'it': 'Popolazione su griglia (raster)',
        'zh': '网格化人口（栅格）',
        'ar': 'بيانات السكان الشبكية (راستر)',
    },
    'note_pop_raster': {
        'en': 'Gridded population dataset. Provide this OR Household '
              'Population (Points) below - one of the two is required.',
        'fr': 'Jeu de données de population maillée. Fournissez ce jeu OU la '
              'Population des ménages (points) ci-dessous - l\'un des deux est '
              'obligatoire.',
        'es': 'Conjunto de datos de población en cuadrícula. Proporcione este '
              'O la Población de hogares (puntos) más abajo; uno de los dos es '
              'obligatorio.',
        'it': 'Dataset della popolazione su griglia. Fornire questo OPPURE la '
              'Popolazione delle famiglie (punti) qui sotto - uno dei due è '
              'obbligatorio.',
        'zh': '网格化人口数据集。请提供此数据或下方的“住户人口（点）”，二者必须提供其一。',
        'ar': 'مجموعة بيانات السكان الشبكية. قدّم هذه البيانات أو بيانات سكان '
              'الأسر (نقاط) أدناه - يلزم توفير أحدهما.',
    },
    'grp_hh': {
        'en': 'Household Population (Points)',
        'fr': 'Population des ménages (points)',
        'es': 'Población de hogares (puntos)',
        'it': 'Popolazione delle famiglie (punti)',
        'zh': '住户人口（点）',
        'ar': 'سكان الأسر (نقاط)',
    },
    'note_hh': {
        'en': 'Point layer with population counts at household level. '
              'Provide this OR the Gridded Population raster - one of the two '
              'is required. If both are given, the household points are used. '
              'Population within each catchment = sum of the selected field '
              'over the points inside it.',
        'fr': 'Couche de points contenant les effectifs de population au '
              'niveau des ménages. Fournissez cette couche OU le raster de '
              'population maillée - l\'un des deux est obligatoire. Si les deux '
              'sont fournis, les points des ménages sont utilisés. Population '
              'de chaque zone de desserte = somme du champ sélectionné pour les '
              'points situés à l\'intérieur.',
        'es': 'Capa de puntos con el número de habitantes por hogar. '
              'Proporcione esta capa O el ráster de población en cuadrícula; '
              'uno de los dos es obligatorio. Si se proporcionan ambos, se usan '
              'los puntos de hogares. Población en cada área de cobertura = '
              'suma del campo seleccionado de los puntos situados en su '
              'interior.',
        'it': 'Layer di punti con il numero di abitanti per famiglia. Fornire '
              'questo OPPURE il raster della popolazione su griglia - uno dei '
              'due è obbligatorio. Se vengono forniti entrambi, si usano i punti '
              'delle famiglie. Popolazione di ciascun bacino di utenza = somma '
              'del campo selezionato per i punti al suo interno.',
        'zh': '包含住户级人口数的点图层。请提供此图层或网格化人口栅格，二者必须提供其一。'
              '若两者均提供，则使用住户点。每个服务范围内的人口 = 其内部各点所选字段之和。',
        'ar': 'طبقة نقاط تتضمن أعداد السكان على مستوى الأسرة. قدّم هذه الطبقة أو '
              'راستر السكان الشبكي - يلزم توفير أحدهما. إذا توفر الاثنان، تُستخدم '
              'نقاط الأسر. السكان ضمن كل منطقة خدمة = مجموع الحقل المحدد للنقاط '
              'الواقعة داخلها.',
    },
    'lbl_pop_field': {
        'en': 'Field containing total population (per household point):',
        'fr': 'Champ contenant la population totale (par point de ménage) :',
        'es': 'Campo con la población total (por punto de hogar):',
        'it': 'Campo con la popolazione totale (per punto famiglia):',
        'zh': '包含总人口的字段（每个住户点）：',
        'ar': 'الحقل الذي يتضمن إجمالي السكان (لكل نقطة أسرة):',
    },
    'grp_pos': {
        'en': 'Open Public Spaces (Polygons)',
        'fr': 'Espaces publics ouverts (polygones)',
        'es': 'Espacios públicos abiertos (polígonos)',
        'it': 'Spazi pubblici aperti (poligoni)',
        'zh': '公共开放空间（面）',
        'ar': 'الأماكن العامة المفتوحة (مضلعات)',
    },
    'note_pos': {
        'en': 'Polygon layers representing undeveloped or open land that is '
              'accessible to the public, providing recreational areas for '
              'residents and enhancing environmental quality. Examples include '
              'parks, gardens, playgrounds, public beaches, riverbanks, and '
              'waterfronts',
        'fr': 'Couches de polygones représentant des terrains non bâtis ou '
              'ouverts accessibles au public, offrant des espaces de loisirs '
              'aux habitants et améliorant la qualité de l\'environnement. Par '
              'exemple : parcs, jardins, aires de jeux, plages publiques, berges '
              'et fronts d\'eau',
        'es': 'Capas de polígonos que representan terrenos no edificados o '
              'abiertos accesibles al público, que ofrecen zonas recreativas a '
              'los residentes y mejoran la calidad ambiental. Por ejemplo: '
              'parques, jardines, parques infantiles, playas públicas, riberas '
              'y frentes de agua',
        'it': 'Layer poligonali che rappresentano terreni non edificati o '
              'aperti accessibili al pubblico, che offrono aree ricreative ai '
              'residenti e migliorano la qualità ambientale. Ad esempio parchi, '
              'giardini, parchi giochi, spiagge pubbliche, sponde fluviali e '
              'lungomare',
        'zh': '表示向公众开放的未开发或开敞用地的面图层，为居民提供休闲场所并改善环境质量。'
              '例如公园、花园、儿童游乐场、公共海滩、河岸和滨水区',
        'ar': 'طبقات مضلعات تمثل الأراضي غير المبنية أو المفتوحة المتاحة للعموم، '
              'والتي توفر مساحات ترفيهية للسكان وتحسّن جودة البيئة. ومن أمثلتها '
              'الحدائق والمتنزهات وملاعب الأطفال والشواطئ العامة وضفاف الأنهار '
              'والواجهات المائية',
    },
    'grp_bus': {
        'en': 'Low Capacity Transport Stops (Bus Stops, Light Rail Stops)',
        'fr': 'Arrêts de transport à faible capacité (arrêts de bus, de '
              'tramway)',
        'es': 'Paradas de transporte de baja capacidad (paradas de autobús, '
              'de tren ligero)',
        'it': 'Fermate del trasporto a bassa capacità (fermate di autobus, di '
              'metropolitana leggera)',
        'zh': '低运量公共交通站点（公交车站、轻轨站）',
        'ar': 'محطات النقل منخفض السعة (مواقف الحافلات، محطات القطار الخفيف)',
    },
    'note_bus': {
        'en': 'Point layer of bus stop / light rail stop locations',
        'fr': 'Couche de points des arrêts de bus / de tramway',
        'es': 'Capa de puntos con la ubicación de paradas de autobús / tren '
              'ligero',
        'it': 'Layer di punti con le fermate di autobus / metropolitana '
              'leggera',
        'zh': '公交车站／轻轨站位置的点图层',
        'ar': 'طبقة نقاط لمواقع مواقف الحافلات / محطات القطار الخفيف',
    },
    'grp_rail': {
        'en': 'High Capacity Transport Stops (Railway Stops, Metro Stops)',
        'fr': 'Arrêts de transport à grande capacité (gares ferroviaires, '
              'stations de métro)',
        'es': 'Paradas de transporte de alta capacidad (estaciones de '
              'ferrocarril, de metro)',
        'it': 'Fermate del trasporto ad alta capacità (stazioni ferroviarie, '
              'della metropolitana)',
        'zh': '大运量公共交通站点（火车站、地铁站）',
        'ar': 'محطات النقل عالي السعة (محطات السكك الحديدية، محطات المترو)',
    },
    'note_rail': {
        'en': 'Point layer of railway/metro station locations',
        'fr': 'Couche de points des gares ferroviaires / stations de métro',
        'es': 'Capa de puntos con la ubicación de estaciones de ferrocarril / '
              'metro',
        'it': 'Layer di punti con le stazioni ferroviarie / della '
              'metropolitana',
        'zh': '火车站／地铁站位置的点图层',
        'ar': 'طبقة نقاط لمواقع محطات السكك الحديدية / المترو',
    },
    'grp_ferry': {
        'en': 'High Capacity Transport Stops (Ferry Stops)',
        'fr': 'Arrêts de transport à grande capacité (embarcadères de ferry)',
        'es': 'Paradas de transporte de alta capacidad (terminales de ferry)',
        'it': 'Fermate del trasporto ad alta capacità (approdi dei traghetti)',
        'zh': '大运量公共交通站点（渡轮码头）',
        'ar': 'محطات النقل عالي السعة (محطات العبّارات)',
    },
    'note_ferry': {
        'en': 'Point layer of ferry terminal locations',
        'fr': 'Couche de points des terminaux de ferry',
        'es': 'Capa de puntos con la ubicación de terminales de ferry',
        'it': 'Layer di punti con i terminal dei traghetti',
        'zh': '渡轮码头位置的点图层',
        'ar': 'طبقة نقاط لمواقع محطات العبّارات',
    },
    'grp_widths': {
        'en': 'Measured Road Widths (CSV table)',
        'fr': 'Largeurs de voirie mesurées (tableau CSV)',
        'es': 'Anchos de vía medidos (tabla CSV)',
        'it': 'Larghezze stradali misurate (tabella CSV)',
        'zh': '实测道路宽度（CSV 表）',
        'ar': 'عروض الطرق المقيسة (جدول CSV)',
    },
    'note_widths': {
        'en': 'Used for Land Allocated to Streets. Column 1 = road category '
              '(matched to the Road Category Field selected below), column 2 = '
              'measured road width in metres. If no CSV is given and no road '
              'category field is available, Land Allocated to Streets = 0.',
        'fr': 'Utilisé pour la superficie consacrée aux rues. Colonne 1 = '
              'catégorie de voie (associée au champ de catégorie de voie '
              'sélectionné ci-dessous), colonne 2 = largeur mesurée en mètres. '
              'Si aucun CSV n\'est fourni et qu\'aucun champ de catégorie n\'est '
              'disponible, la superficie consacrée aux rues = 0.',
        'es': 'Se utiliza para la superficie destinada a calles. Columna 1 = '
              'categoría de vía (vinculada al campo de categoría de vía '
              'seleccionado más abajo), columna 2 = ancho medido en metros. Si '
              'no se proporciona ningún CSV y no hay campo de categoría '
              'disponible, la superficie destinada a calles = 0.',
        'it': 'Utilizzato per la superficie destinata alle strade. Colonna 1 = '
              'categoria stradale (associata al campo della categoria stradale '
              'selezionato qui sotto), colonna 2 = larghezza misurata in metri. '
              'Se non viene fornito alcun CSV e non è disponibile un campo della '
              'categoria, la superficie destinata alle strade = 0.',
        'zh': '用于计算街道用地。第 1 列 = 道路类别（与下方所选的道路类别字段匹配），'
              '第 2 列 = 实测道路宽度（米）。若未提供 CSV 且无可用的道路类别字段，'
              '则街道用地 = 0。',
        'ar': 'يُستخدم لحساب المساحة المخصصة للشوارع. العمود 1 = فئة الطريق (تُطابق '
              'مع حقل فئة الطريق المحدد أدناه)، العمود 2 = عرض الطريق المقيس '
              'بالمتر. إذا لم يُقدَّم ملف CSV ولم يتوفر حقل لفئة الطريق، تكون '
              'المساحة المخصصة للشوارع = 0.',
    },
    'btn_browse_csv': {
        'en': 'Browse CSV...', 'fr': 'Parcourir CSV...',
        'es': 'Examinar CSV...', 'it': 'Sfoglia CSV...',
        'zh': '浏览 CSV...', 'ar': 'استعراض CSV...',
    },
    'grp_catfield': {
        'en': 'Road Category Field (from Streets layer)',
        'fr': 'Champ de catégorie de voie (couche des rues)',
        'es': 'Campo de categoría de vía (capa de calles)',
        'it': 'Campo della categoria stradale (layer delle strade)',
        'zh': '道路类别字段（来自街道图层）',
        'ar': 'حقل فئة الطريق (من طبقة الشوارع)',
    },
    'note_catfield': {
        'en': 'Field of the Streets layer holding the road categories, used to '
              'join the road widths. \'fclass\', \'highway\' or \'type\' is '
              'selected automatically when present; otherwise choose the field '
              'here. Leave empty to auto-detect.',
        'fr': 'Champ de la couche des rues contenant les catégories de voie, '
              'utilisé pour joindre les largeurs. \'fclass\', \'highway\' ou '
              '\'type\' est sélectionné automatiquement s\'il existe ; sinon, '
              'choisissez le champ ici. Laissez vide pour la détection '
              'automatique.',
        'es': 'Campo de la capa de calles que contiene las categorías de vía, '
              'utilizado para unir los anchos. Se selecciona automáticamente '
              '\'fclass\', \'highway\' o \'type\' si existe; de lo contrario, '
              'elija el campo aquí. Déjelo vacío para la detección automática.',
        'it': 'Campo del layer delle strade che contiene le categorie '
              'stradali, usato per unire le larghezze. \'fclass\', \'highway\' o '
              '\'type\' viene selezionato automaticamente se presente; '
              'altrimenti scegliere il campo qui. Lasciare vuoto per il '
              'rilevamento automatico.',
        'zh': '街道图层中保存道路类别的字段，用于连接道路宽度。若存在 “fclass”、'
              '“highway” 或 “type”，将自动选择；否则请在此选择字段。留空则自动识别。',
        'ar': 'حقل طبقة الشوارع الذي يتضمن فئات الطرق، ويُستخدم لربط عروض الطرق. '
              'يُحدَّد الحقل \'fclass\' أو \'highway\' أو \'type\' تلقائيًا عند '
              'وجوده؛ وإلا فاختر الحقل هنا. اتركه فارغًا للكشف التلقائي.',
    },
    'grp_crs': {
        'en': 'Target Coordinate Reference System (Projected, Meters - e.g. '
              'UTM for the urban area)',
        'fr': 'Système de coordonnées de référence cible (projeté, en mètres '
              '- p. ex. UTM de la zone urbaine)',
        'es': 'Sistema de referencia de coordenadas de destino (proyectado, '
              'en metros; p. ej. UTM del área urbana)',
        'it': 'Sistema di riferimento delle coordinate di destinazione '
              '(proiettato, in metri - ad es. UTM dell\'area urbana)',
        'zh': '目标坐标参考系（投影坐标，单位为米，例如城市所在的 UTM 分带）',
        'ar': 'نظام الإحداثيات المرجعي المستهدف (مُسقَط، بالمتر - مثل نطاق UTM '
              'للمنطقة الحضرية)',
    },

    # ---------------------------------------------------------- distances tab
    'dist_header': {
        'en': 'Network distance threshold for:',
        'fr': 'Seuil de distance sur le réseau pour :',
        'es': 'Umbral de distancia en la red para:',
        'it': 'Soglia di distanza sulla rete per:',
        'zh': '网络距离阈值：',
        'ar': 'حدّ المسافة على الشبكة لـ:',
    },
    'dist_pos': {
        'en': 'Open Public Spaces', 'fr': 'Espaces publics ouverts',
        'es': 'Espacios públicos abiertos', 'it': 'Spazi pubblici aperti',
        'zh': '公共开放空间', 'ar': 'الأماكن العامة المفتوحة',
    },
    'spacing_header': {
        'en': 'Open Public Spaces boundary point spacing:',
        'fr': 'Espacement des points sur le contour des espaces publics '
              'ouverts :',
        'es': 'Espaciado de puntos en el contorno de los espacios públicos '
              'abiertos:',
        'it': 'Spaziatura dei punti sul contorno degli spazi pubblici aperti:',
        'zh': '公共开放空间边界点间距：',
        'ar': 'المسافة بين نقاط حدود الأماكن العامة المفتوحة:',
    },
    'spacing_note': {
        'en': 'Start points placed along each open space outline. 100 m is the '
              'standard; larger spacing (e.g. 200 m) is faster for cities with '
              'many large parks but slightly less precise.',
        'fr': 'Points de départ placés le long du contour de chaque espace '
              'ouvert. 100 m est la norme ; un espacement plus grand (p. ex. '
              '200 m) est plus rapide pour les villes comptant de nombreux grands '
              'parcs, mais légèrement moins précis.',
        'es': 'Puntos de partida situados a lo largo del contorno de cada '
              'espacio abierto. 100 m es el valor estándar; un espaciado mayor '
              '(p. ej. 200 m) es más rápido en ciudades con muchos parques '
              'grandes, pero algo menos preciso.',
        'it': 'Punti di partenza posizionati lungo il contorno di ciascuno '
              'spazio aperto. 100 m è lo standard; una spaziatura maggiore (ad '
              'es. 200 m) è più veloce per le città con molti grandi parchi, ma '
              'leggermente meno precisa.',
        'zh': '沿每个开放空间轮廓布设的起点。标准间距为 100 米；对于大型公园较多的城市，'
              '较大间距（如 200 米）计算更快，但精度略低。',
        'ar': 'نقاط بداية توضع على امتداد حدود كل مساحة مفتوحة. القيمة القياسية '
              '100 م؛ والتباعد الأكبر (مثل 200 م) أسرع للمدن التي تضم حدائق كبيرة '
              'كثيرة، لكنه أقل دقة بقليل.',
    },
    'perf_header': {
        'en': 'Performance:', 'fr': 'Performances :', 'es': 'Rendimiento:',
        'it': 'Prestazioni:', 'zh': '性能：', 'ar': 'الأداء:',
    },
    'chk_preclip': {
        'en': 'Pre-clip inputs to the urban area',
        'fr': 'Pré-découper les données à la zone urbaine',
        'es': 'Recortar previamente los datos al área urbana',
        'it': 'Ritagliare preliminarmente i dati all\'area urbana',
        'zh': '将输入数据预裁剪至城市区域',
        'ar': 'القص المسبق للمدخلات وفق المنطقة الحضرية',
    },
    'note_preclip': {
        'en': 'Recommended. Keeps only streets, stops and open spaces within '
              'the search margin of the urban area - much faster with '
              'country/region-wide data.',
        'fr': 'Recommandé. Ne conserve que les rues, arrêts et espaces ouverts '
              'situés dans la marge de recherche autour de la zone urbaine - '
              'beaucoup plus rapide avec des données nationales ou régionales.',
        'es': 'Recomendado. Conserva solo las calles, paradas y espacios '
              'abiertos dentro del margen de búsqueda del área urbana; mucho más '
              'rápido con datos de alcance nacional o regional.',
        'it': 'Consigliato. Mantiene solo strade, fermate e spazi aperti entro '
              'il margine di ricerca dell\'area urbana - molto più veloce con '
              'dati nazionali o regionali.',
        'zh': '推荐。仅保留城市区域搜索范围内的街道、站点和开放空间——处理全国或区域范围数据时速度大幅提升。',
        'ar': 'موصى به. يحتفظ فقط بالشوارع والمحطات والمساحات المفتوحة الواقعة '
              'ضمن هامش البحث حول المنطقة الحضرية - أسرع بكثير مع بيانات على '
              'مستوى البلد أو الإقليم.',
    },
    'chk_memory': {
        'en': 'Keep intermediate layers in memory',
        'fr': 'Conserver les couches intermédiaires en mémoire',
        'es': 'Mantener las capas intermedias en memoria',
        'it': 'Mantenere i layer intermedi in memoria',
        'zh': '将中间图层保存在内存中',
        'ar': 'الاحتفاظ بالطبقات الوسيطة في الذاكرة',
    },
    'note_memory': {
        'en': 'Faster. Untick only if the computer runs out of RAM.',
        'fr': 'Plus rapide. Décochez uniquement si l\'ordinateur manque de '
              'mémoire vive.',
        'es': 'Más rápido. Desmárquelo solo si el equipo se queda sin memoria '
              'RAM.',
        'it': 'Più veloce. Deselezionare solo se il computer esaurisce la '
              'memoria RAM.',
        'zh': '速度更快。仅在计算机内存不足时取消勾选。',
        'ar': 'أسرع. ألغِ التحديد فقط إذا نفدت ذاكرة الحاسوب.',
    },
    'chk_native': {
        'en': 'Use QGIS native Service Area algorithm',
        'fr': 'Utiliser l\'algorithme natif de zone de desserte de QGIS',
        'es': 'Usar el algoritmo nativo de área de servicio de QGIS',
        'it': 'Usare l\'algoritmo nativo di area di servizio di QGIS',
        'zh': '使用 QGIS 原生服务区算法',
        'ar': 'استخدام خوارزمية منطقة الخدمة الأصلية في QGIS',
    },
    'note_native': {
        'en': 'For cross-checking only - very slow with many start points. '
              'Default is the fast bounded search (same results).',
        'fr': 'Pour vérification uniquement - très lent avec de nombreux points '
              'de départ. Par défaut : recherche bornée rapide (mêmes '
              'résultats).',
        'es': 'Solo para verificación; muy lento con muchos puntos de partida. '
              'Por defecto se usa la búsqueda acotada rápida (mismos '
              'resultados).',
        'it': 'Solo per verifica - molto lento con molti punti di partenza. '
              'L\'impostazione predefinita è la ricerca limitata veloce (stessi '
              'risultati).',
        'zh': '仅用于交叉核对——起点较多时速度很慢。默认使用快速有界搜索（结果相同）。',
        'ar': 'للتحقق فقط - بطيء جدًا مع كثرة نقاط البداية. الإعداد الافتراضي '
              'هو البحث المحدود السريع (النتائج نفسها).',
    },

    # ------------------------------------------------------------- output tab
    'grp_city': {
        'en': 'City Name (Hint: Avoid special characters)',
        'fr': 'Nom de la ville (conseil : évitez les caractères spéciaux)',
        'es': 'Nombre de la ciudad (consejo: evite caracteres especiales)',
        'it': 'Nome della città (suggerimento: evitare caratteri speciali)',
        'zh': '城市名称（提示：避免使用特殊字符）',
        'ar': 'اسم المدينة (تلميح: تجنّب الأحرف الخاصة)',
    },
    'city_placeholder': {
        'en': 'e.g. Mombasa', 'fr': 'p. ex. Mombasa', 'es': 'p. ej. Mombasa',
        'it': 'ad es. Mombasa', 'zh': '例如 Mombasa', 'ar': 'مثال: Mombasa',
    },
    'lbl_output_folder': {
        'en': 'Output folder:', 'fr': 'Dossier de sortie :',
        'es': 'Carpeta de salida:', 'it': 'Cartella di output:',
        'zh': '输出文件夹：', 'ar': 'مجلد المخرجات:',
    },
    'btn_browse': {
        'en': 'Browse...', 'fr': 'Parcourir...', 'es': 'Examinar...',
        'it': 'Sfoglia...', 'zh': '浏览...', 'ar': 'استعراض...',
    },
    'info_block': {
        'en': "Final files retained:\n"
              "  Clipped + dissolved catchments (service areas):\n"
              "  SA_POS_dissolved.shp                Open Public Spaces\n"
              "  SA_Bus_dissolved.shp                Low Capacity Transport Stops\n"
              "  SA_Ferry_dissolved.shp              Ferry stops\n"
              "  SA_Rail_dissolved.shp               Rail stops\n"
              "  SA_HighCapacity_dissolved.shp       High Capacity (Rail + Ferry)\n"
              "  SA_CombinedTransport_dissolved.shp  Combined Public Transport\n"
              "  Individual (per-stop) service areas:\n"
              "  SA_Bus_individual.shp / SA_Ferry_individual.shp / SA_Rail_individual.shp\n"
              "  ZonalStats_*.shp                    Catchment + pop_sum field\n"
              "  LAS_streets_dissolved.shp           Land Allocated to Streets\n"
              "  {city}_statistics_11.2.1_and_11.7.1.xlsx\n\n"
              "NOTES:\n"
              "  - Geometries are fixed automatically before processing.\n"
              "  - Population: household points (sum of the population field)\n"
              "    if given, otherwise the gridded population raster.\n"
              "  - Open Public Spaces area measured after clipping to urban boundary.\n"
              "  - Inputs are pre-clipped to the urban area + search margin and\n"
              "    intermediates kept in memory (see Distances tab to change).\n"
              "  - Combined transport = low capacity stops + ferry + rail\n"
              "    (Open Public Spaces excluded).\n"
              "  - Land Allocated to Streets: roads buffered by width, dissolved,\n"
              "    clipped to the urban extent.\n"
              "  - The statistics table is written in the selected language.\n"
              "  - Use 'Reset Log' to clear the log and re-enable buttons after a failure.",
        'fr': "Fichiers finaux conservés :\n"
              "  Zones de desserte découpées et fusionnées :\n"
              "  SA_POS_dissolved.shp                Espaces publics ouverts\n"
              "  SA_Bus_dissolved.shp                Arrêts de transport à faible capacité\n"
              "  SA_Ferry_dissolved.shp              Embarcadères de ferry\n"
              "  SA_Rail_dissolved.shp               Gares ferroviaires\n"
              "  SA_HighCapacity_dissolved.shp       Grande capacité (rail + ferry)\n"
              "  SA_CombinedTransport_dissolved.shp  Transports publics combinés\n"
              "  Zones de desserte individuelles (par arrêt) :\n"
              "  SA_Bus_individual.shp / SA_Ferry_individual.shp / SA_Rail_individual.shp\n"
              "  ZonalStats_*.shp                    Zone de desserte + champ pop_sum\n"
              "  LAS_streets_dissolved.shp           Superficie consacrée aux rues\n"
              "  {city}_statistics_11.2.1_and_11.7.1.xlsx\n\n"
              "REMARQUES :\n"
              "  - Les géométries sont corrigées automatiquement avant le traitement.\n"
              "  - Population : points des ménages (somme du champ de population)\n"
              "    s'ils sont fournis, sinon le raster de population maillée.\n"
              "  - Superficie des espaces publics ouverts mesurée après découpage à la limite urbaine.\n"
              "  - Les données sont pré-découpées à la zone urbaine + marge de recherche et\n"
              "    les couches intermédiaires gardées en mémoire (voir l'onglet Distances).\n"
              "  - Transports combinés = arrêts à faible capacité + ferry + rail\n"
              "    (espaces publics ouverts exclus).\n"
              "  - Superficie consacrée aux rues : rues tamponnées selon leur largeur,\n"
              "    fusionnées et découpées à l'étendue urbaine.\n"
              "  - Le tableau statistique est rédigé dans la langue sélectionnée.\n"
              "  - Utilisez « Effacer le journal » pour réactiver les boutons après un échec.",
        'es': "Archivos finales conservados:\n"
              "  Áreas de cobertura recortadas y disueltas:\n"
              "  SA_POS_dissolved.shp                Espacios públicos abiertos\n"
              "  SA_Bus_dissolved.shp                Paradas de transporte de baja capacidad\n"
              "  SA_Ferry_dissolved.shp              Terminales de ferry\n"
              "  SA_Rail_dissolved.shp               Estaciones de ferrocarril\n"
              "  SA_HighCapacity_dissolved.shp       Alta capacidad (ferrocarril + ferry)\n"
              "  SA_CombinedTransport_dissolved.shp  Transporte público combinado\n"
              "  Áreas de servicio individuales (por parada):\n"
              "  SA_Bus_individual.shp / SA_Ferry_individual.shp / SA_Rail_individual.shp\n"
              "  ZonalStats_*.shp                    Área de cobertura + campo pop_sum\n"
              "  LAS_streets_dissolved.shp           Superficie destinada a calles\n"
              "  {city}_statistics_11.2.1_and_11.7.1.xlsx\n\n"
              "NOTAS:\n"
              "  - Las geometrías se corrigen automáticamente antes del procesamiento.\n"
              "  - Población: puntos de hogares (suma del campo de población)\n"
              "    si se proporcionan; de lo contrario, el ráster de población en cuadrícula.\n"
              "  - Superficie de espacios públicos abiertos medida tras recortar al límite urbano.\n"
              "  - Los datos se recortan previamente al área urbana + margen de búsqueda y\n"
              "    las capas intermedias se mantienen en memoria (véase la pestaña Distancias).\n"
              "  - Transporte combinado = paradas de baja capacidad + ferry + ferrocarril\n"
              "    (espacios públicos abiertos excluidos).\n"
              "  - Superficie destinada a calles: calles con búfer según su ancho,\n"
              "    disueltas y recortadas a la extensión urbana.\n"
              "  - La tabla estadística se redacta en el idioma seleccionado.\n"
              "  - Use «Borrar registro» para reactivar los botones tras un error.",
        'it': "File finali conservati:\n"
              "  Bacini di utenza ritagliati e dissolti:\n"
              "  SA_POS_dissolved.shp                Spazi pubblici aperti\n"
              "  SA_Bus_dissolved.shp                Fermate del trasporto a bassa capacità\n"
              "  SA_Ferry_dissolved.shp              Approdi dei traghetti\n"
              "  SA_Rail_dissolved.shp               Stazioni ferroviarie\n"
              "  SA_HighCapacity_dissolved.shp       Alta capacità (ferrovia + traghetto)\n"
              "  SA_CombinedTransport_dissolved.shp  Trasporto pubblico combinato\n"
              "  Aree di servizio individuali (per fermata):\n"
              "  SA_Bus_individual.shp / SA_Ferry_individual.shp / SA_Rail_individual.shp\n"
              "  ZonalStats_*.shp                    Bacino di utenza + campo pop_sum\n"
              "  LAS_streets_dissolved.shp           Superficie destinata alle strade\n"
              "  {city}_statistics_11.2.1_and_11.7.1.xlsx\n\n"
              "NOTE:\n"
              "  - Le geometrie vengono corrette automaticamente prima dell'elaborazione.\n"
              "  - Popolazione: punti delle famiglie (somma del campo popolazione)\n"
              "    se forniti, altrimenti il raster della popolazione su griglia.\n"
              "  - Superficie degli spazi pubblici aperti misurata dopo il ritaglio al confine urbano.\n"
              "  - I dati sono ritagliati all'area urbana + margine di ricerca e\n"
              "    i layer intermedi tenuti in memoria (vedere la scheda Distanze).\n"
              "  - Trasporto combinato = fermate a bassa capacità + traghetto + ferrovia\n"
              "    (spazi pubblici aperti esclusi).\n"
              "  - Superficie destinata alle strade: strade con buffer secondo la larghezza,\n"
              "    dissolte e ritagliate all'estensione urbana.\n"
              "  - La tabella statistica è redatta nella lingua selezionata.\n"
              "  - Usare «Azzera registro» per riattivare i pulsanti dopo un errore.",
        'zh': "保留的最终文件：\n"
              "  裁剪并融合后的服务范围：\n"
              "  SA_POS_dissolved.shp                公共开放空间\n"
              "  SA_Bus_dissolved.shp                低运量公共交通站点\n"
              "  SA_Ferry_dissolved.shp              渡轮码头\n"
              "  SA_Rail_dissolved.shp               火车站\n"
              "  SA_HighCapacity_dissolved.shp       大运量（铁路 + 渡轮）\n"
              "  SA_CombinedTransport_dissolved.shp  综合公共交通\n"
              "  单个站点的服务区：\n"
              "  SA_Bus_individual.shp / SA_Ferry_individual.shp / SA_Rail_individual.shp\n"
              "  ZonalStats_*.shp                    服务范围 + pop_sum 字段\n"
              "  LAS_streets_dissolved.shp           街道用地\n"
              "  {city}_statistics_11.2.1_and_11.7.1.xlsx\n\n"
              "说明：\n"
              "  - 处理前会自动修复几何。\n"
              "  - 人口：若提供住户点则使用住户点（人口字段之和），\n"
              "    否则使用网格化人口栅格。\n"
              "  - 公共开放空间面积在裁剪至城市边界后计算。\n"
              "  - 输入数据预裁剪至城市区域 + 搜索范围，\n"
              "    中间图层保存在内存中（可在“距离”选项卡中更改）。\n"
              "  - 综合公共交通 = 低运量站点 + 渡轮 + 铁路（不含公共开放空间）。\n"
              "  - 街道用地：按道路宽度生成缓冲区，融合后裁剪至城市范围。\n"
              "  - 统计表以所选语言输出。\n"
              "  - 运行失败后，使用“清空日志”重新启用按钮。",
        'ar': "الملفات النهائية المحفوظة:\n"
              "  مناطق الخدمة بعد القص والدمج:\n"
              "  SA_POS_dissolved.shp                الأماكن العامة المفتوحة\n"
              "  SA_Bus_dissolved.shp                محطات النقل منخفض السعة\n"
              "  SA_Ferry_dissolved.shp              محطات العبّارات\n"
              "  SA_Rail_dissolved.shp               محطات السكك الحديدية\n"
              "  SA_HighCapacity_dissolved.shp       النقل عالي السعة (السكك الحديدية + العبّارات)\n"
              "  SA_CombinedTransport_dissolved.shp  النقل العام المجمّع\n"
              "  مناطق الخدمة الفردية (لكل محطة):\n"
              "  SA_Bus_individual.shp / SA_Ferry_individual.shp / SA_Rail_individual.shp\n"
              "  ZonalStats_*.shp                    منطقة الخدمة + الحقل pop_sum\n"
              "  LAS_streets_dissolved.shp           المساحة المخصصة للشوارع\n"
              "  {city}_statistics_11.2.1_and_11.7.1.xlsx\n\n"
              "ملاحظات:\n"
              "  - تُصلَح الأشكال الهندسية تلقائيًا قبل المعالجة.\n"
              "  - السكان: نقاط الأسر (مجموع حقل السكان) إن توفرت،\n"
              "    وإلا فراستر السكان الشبكي.\n"
              "  - تُقاس مساحة الأماكن العامة المفتوحة بعد قصها وفق الحدود الحضرية.\n"
              "  - تُقص المدخلات مسبقًا وفق المنطقة الحضرية مع هامش البحث،\n"
              "    وتُحفظ الطبقات الوسيطة في الذاكرة (انظر تبويب المسافات).\n"
              "  - النقل المجمّع = محطات النقل منخفض السعة + العبّارات + السكك الحديدية\n"
              "    (باستثناء الأماكن العامة المفتوحة).\n"
              "  - المساحة المخصصة للشوارع: نطاقات عازلة للطرق حسب عرضها،\n"
              "    تُدمج وتُقص وفق النطاق الحضري.\n"
              "  - يُكتب جدول الإحصاءات باللغة المحددة.\n"
              "  - استخدم «مسح السجل» لإعادة تفعيل الأزرار بعد حدوث خطأ.",
    },

    # --------------------------------------------------------------- messages
    'msg_running_title': {
        'en': 'Running', 'fr': 'En cours', 'es': 'En ejecución',
        'it': 'In esecuzione', 'zh': '正在运行', 'ar': 'قيد التشغيل',
    },
    'msg_cannot_reset': {
        'en': 'Cannot reset while analysis is running. Cancel first.',
        'fr': 'Impossible d\'effacer pendant l\'analyse. Annulez d\'abord.',
        'es': 'No se puede borrar mientras se ejecuta el análisis. Cancele '
              'primero.',
        'it': 'Impossibile azzerare durante l\'analisi. Annullare prima.',
        'zh': '分析运行期间无法清空。请先取消。',
        'ar': 'لا يمكن المسح أثناء تشغيل التحليل. ألغِ التحليل أولًا.',
    },
    'msg_missing_layer': {
        'en': 'Missing Layer', 'fr': 'Couche manquante',
        'es': 'Falta una capa', 'it': 'Layer mancante',
        'zh': '缺少图层', 'ar': 'طبقة مفقودة',
    },
    'msg_select_streets': {
        'en': 'Please select a Streets layer.',
        'fr': 'Veuillez sélectionner une couche de rues.',
        'es': 'Seleccione una capa de calles.',
        'it': 'Selezionare un layer delle strade.',
        'zh': '请选择街道图层。',
        'ar': 'يرجى اختيار طبقة الشوارع.',
    },
    'msg_select_urban': {
        'en': 'Please select an Urban Boundary layer.',
        'fr': 'Veuillez sélectionner une couche de limite urbaine.',
        'es': 'Seleccione una capa de límite urbano.',
        'it': 'Selezionare un layer del confine urbano.',
        'zh': '请选择城市边界图层。',
        'ar': 'يرجى اختيار طبقة الحدود الحضرية.',
    },
    'msg_missing_pop_title': {
        'en': 'Missing Population Data',
        'fr': 'Données de population manquantes',
        'es': 'Faltan datos de población',
        'it': 'Dati di popolazione mancanti',
        'zh': '缺少人口数据',
        'ar': 'بيانات السكان مفقودة',
    },
    'msg_missing_pop': {
        'en': 'Please select a Gridded Population (Raster) layer or a '
              'Household Population (Points) layer - one of the two is '
              'required.',
        'fr': 'Veuillez sélectionner une couche de population maillée '
              '(raster) ou une couche de population des ménages (points) - '
              'l\'une des deux est obligatoire.',
        'es': 'Seleccione una capa de población en cuadrícula (ráster) o una '
              'capa de población de hogares (puntos); una de las dos es '
              'obligatoria.',
        'it': 'Selezionare un layer della popolazione su griglia (raster) o '
              'un layer della popolazione delle famiglie (punti) - uno dei due '
              'è obbligatorio.',
        'zh': '请选择网格化人口（栅格）图层或住户人口（点）图层，二者必须选择其一。',
        'ar': 'يرجى اختيار طبقة بيانات السكان الشبكية (راستر) أو طبقة سكان الأسر '
              '(نقاط) - يلزم اختيار إحداهما.',
    },
    'msg_missing_popfield_title': {
        'en': 'Missing Population Field',
        'fr': 'Champ de population manquant',
        'es': 'Falta el campo de población',
        'it': 'Campo della popolazione mancante',
        'zh': '缺少人口字段',
        'ar': 'حقل السكان مفقود',
    },
    'msg_missing_popfield': {
        'en': 'Please select the field containing total population for the '
              'Household Population (Points) layer.',
        'fr': 'Veuillez sélectionner le champ contenant la population totale '
              'de la couche de population des ménages (points).',
        'es': 'Seleccione el campo con la población total de la capa de '
              'población de hogares (puntos).',
        'it': 'Selezionare il campo con la popolazione totale del layer della '
              'popolazione delle famiglie (punti).',
        'zh': '请为住户人口（点）图层选择包含总人口的字段。',
        'ar': 'يرجى اختيار الحقل الذي يتضمن إجمالي السكان لطبقة سكان الأسر '
              '(نقاط).',
    },
    'msg_missing_city_title': {
        'en': 'Missing City Name', 'fr': 'Nom de ville manquant',
        'es': 'Falta el nombre de la ciudad',
        'it': 'Nome della città mancante',
        'zh': '缺少城市名称', 'ar': 'اسم المدينة مفقود',
    },
    'msg_missing_city': {
        'en': 'Please enter a city name.',
        'fr': 'Veuillez saisir un nom de ville.',
        'es': 'Introduzca el nombre de la ciudad.',
        'it': 'Inserire il nome della città.',
        'zh': '请输入城市名称。',
        'ar': 'يرجى إدخال اسم المدينة.',
    },
    'msg_missing_output_title': {
        'en': 'Missing Output', 'fr': 'Sortie manquante',
        'es': 'Falta la salida', 'it': 'Output mancante',
        'zh': '缺少输出位置', 'ar': 'المخرجات مفقودة',
    },
    'msg_missing_output': {
        'en': 'Please select an output folder.',
        'fr': 'Veuillez sélectionner un dossier de sortie.',
        'es': 'Seleccione una carpeta de salida.',
        'it': 'Selezionare una cartella di output.',
        'zh': '请选择输出文件夹。',
        'ar': 'يرجى اختيار مجلد للمخرجات.',
    },
    'msg_invalid_crs_title': {
        'en': 'Invalid CRS', 'fr': 'SCR non valide', 'es': 'SRC no válido',
        'it': 'SR non valido', 'zh': '坐标参考系无效',
        'ar': 'نظام إحداثيات غير صالح',
    },
    'msg_invalid_crs': {
        'en': 'Please select a valid target CRS.',
        'fr': 'Veuillez sélectionner un SCR cible valide.',
        'es': 'Seleccione un SRC de destino válido.',
        'it': 'Selezionare un SR di destinazione valido.',
        'zh': '请选择有效的目标坐标参考系。',
        'ar': 'يرجى اختيار نظام إحداثيات مستهدف صالح.',
    },
    'msg_no_transport_title': {
        'en': 'No Transport Layers', 'fr': 'Aucune couche de transport',
        'es': 'Sin capas de transporte', 'it': 'Nessun layer di trasporto',
        'zh': '无交通图层', 'ar': 'لا توجد طبقات للنقل',
    },
    'msg_no_transport': {
        'en': 'No Open Public Spaces / Low Capacity / Ferry / Rail layers '
              'selected. Only the urban area and streets will be processed. '
              'Continue?',
        'fr': 'Aucune couche d\'espaces publics ouverts / de faible capacité / '
              'de ferry / de rail sélectionnée. Seules la zone urbaine et les '
              'rues seront traitées. Continuer ?',
        'es': 'No se ha seleccionado ninguna capa de espacios públicos '
              'abiertos / baja capacidad / ferry / ferrocarril. Solo se '
              'procesarán el área urbana y las calles. ¿Continuar?',
        'it': 'Nessun layer di spazi pubblici aperti / bassa capacità / '
              'traghetti / ferrovia selezionato. Verranno elaborati solo l\'area '
              'urbana e le strade. Continuare?',
        'zh': '未选择公共开放空间／低运量／渡轮／铁路图层。将仅处理城市区域和街道。是否继续？',
        'ar': 'لم تُحدَّد طبقات الأماكن العامة المفتوحة / النقل منخفض السعة / '
              'العبّارات / السكك الحديدية. ستُعالَج المنطقة الحضرية والشوارع فقط. '
              'هل تريد المتابعة؟',
    },
    'msg_complete': {
        'en': 'Complete', 'fr': 'Terminé', 'es': 'Completado',
        'it': 'Completato', 'zh': '完成', 'ar': 'اكتمل',
    },
    'msg_error': {
        'en': 'Error', 'fr': 'Erreur', 'es': 'Error',
        'it': 'Errore', 'zh': '错误', 'ar': 'خطأ',
    },
    'msg_failed': {
        'en': 'Analysis failed. See log for details.\n\nClick \'Reset Log\' to '
              'clear and run again.',
        'fr': 'L\'analyse a échoué. Consultez le journal pour plus de détails.'
              '\n\nCliquez sur « Effacer le journal » pour recommencer.',
        'es': 'El análisis ha fallado. Consulte el registro para más '
              'detalles.\n\nHaga clic en «Borrar registro» para volver a '
              'empezar.',
        'it': 'Analisi non riuscita. Consultare il registro per i dettagli.'
              '\n\nFare clic su «Azzera registro» per ricominciare.',
        'zh': '分析失败。详情请查看日志。\n\n点击“清空日志”后重新运行。',
        'ar': 'فشل التحليل. راجع السجل للاطلاع على التفاصيل.\n\nانقر على «مسح '
              'السجل» ثم أعد التشغيل.',
    },
    'msg_close_running': {
        'en': 'Analysis is still running. Cancel and close?',
        'fr': 'L\'analyse est toujours en cours. Annuler et fermer ?',
        'es': 'El análisis sigue en ejecución. ¿Cancelar y cerrar?',
        'it': 'L\'analisi è ancora in corso. Annullare e chiudere?',
        'zh': '分析仍在运行。是否取消并关闭？',
        'ar': 'لا يزال التحليل قيد التشغيل. هل تريد الإلغاء والإغلاق؟',
    },
    'msg_cancel_requested': {
        'en': 'Cancellation requested...', 'fr': 'Annulation demandée...',
        'es': 'Cancelación solicitada...', 'it': 'Annullamento richiesto...',
        'zh': '已请求取消……', 'ar': 'تم طلب الإلغاء...',
    },
    'dlg_select_output': {
        'en': 'Select Output Folder',
        'fr': 'Sélectionner le dossier de sortie',
        'es': 'Seleccionar carpeta de salida',
        'it': 'Seleziona cartella di output',
        'zh': '选择输出文件夹', 'ar': 'اختر مجلد المخرجات',
    },
    'dlg_select_csv': {
        'en': 'Select Measured Road Widths CSV',
        'fr': 'Sélectionner le CSV des largeurs de voirie mesurées',
        'es': 'Seleccionar el CSV de anchos de vía medidos',
        'it': 'Seleziona il CSV delle larghezze stradali misurate',
        'zh': '选择实测道路宽度 CSV',
        'ar': 'اختر ملف CSV لعروض الطرق المقيسة',
    },
    'csv_filter': {
        'en': 'CSV files (*.csv *.txt);;All files (*)',
        'fr': 'Fichiers CSV (*.csv *.txt);;Tous les fichiers (*)',
        'es': 'Archivos CSV (*.csv *.txt);;Todos los archivos (*)',
        'it': 'File CSV (*.csv *.txt);;Tutti i file (*)',
        'zh': 'CSV 文件 (*.csv *.txt);;所有文件 (*)',
        'ar': 'ملفات CSV (*.csv *.txt);;جميع الملفات (*)',
    },
    'msg_invalid_csv_title': {
        'en': 'Invalid CSV', 'fr': 'CSV non valide', 'es': 'CSV no válido',
        'it': 'CSV non valido', 'zh': 'CSV 无效', 'ar': 'ملف CSV غير صالح',
    },
    'msg_invalid_csv': {
        'en': 'Could not read:', 'fr': 'Lecture impossible :',
        'es': 'No se pudo leer:', 'it': 'Impossibile leggere:',
        'zh': '无法读取：', 'ar': 'تعذّرت القراءة:',
    },
    'msg_widths_title': {
        'en': 'Road Widths CSV', 'fr': 'CSV des largeurs de voirie',
        'es': 'CSV de anchos de vía', 'it': 'CSV delle larghezze stradali',
        'zh': '道路宽度 CSV', 'ar': 'ملف CSV لعروض الطرق',
    },
    'msg_widths_cols': {
        'en': 'The road widths table needs at least two columns (road '
              'category, width). It will be ignored.',
        'fr': 'Le tableau des largeurs doit comporter au moins deux colonnes '
              '(catégorie de voie, largeur). Il sera ignoré.',
        'es': 'La tabla de anchos de vía necesita al menos dos columnas '
              '(categoría de vía, ancho). Se ignorará.',
        'it': 'La tabella delle larghezze richiede almeno due colonne '
              '(categoria stradale, larghezza). Verrà ignorata.',
        'zh': '道路宽度表至少需要两列（道路类别、宽度）。将忽略该表。',
        'ar': 'يجب أن يتضمن جدول عروض الطرق عمودين على الأقل (فئة الطريق، '
              'العرض). سيتم تجاهله.',
    },

    # ------------------------------------------------- end-of-run summary
    'res_done': {
        'en': 'Done!', 'fr': 'Terminé !', 'es': '¡Completado!',
        'it': 'Completato!', 'zh': '完成！', 'ar': 'اكتمل!',
    },
    'res_las': {
        'en': 'Land Allocated to Streets', 'fr': 'Superficie consacrée aux rues',
        'es': 'Superficie destinada a calles',
        'it': 'Superficie destinata alle strade',
        'zh': '街道用地', 'ar': 'المساحة المخصصة للشوارع',
    },
    'res_stats': {
        'en': 'Statistics table (CSV)', 'fr': 'Tableau statistique (CSV)',
        'es': 'Tabla estadística (CSV)', 'it': 'Tabella statistica (CSV)',
        'zh': '统计表（CSV）', 'ar': 'جدول الإحصاءات (CSV)',
    },
    'res_excel': {
        'en': 'Statistics workbook (Excel)',
        'fr': 'Classeur statistique (Excel)',
        'es': 'Libro estadístico (Excel)',
        'it': 'Cartella di lavoro statistica (Excel)',
        'zh': '统计工作簿（Excel）',
        'ar': 'مصنف الإحصاءات (Excel)',
    },
    'res_roads': {
        'en': 'Roads table', 'fr': 'Tableau des rues',
        'es': 'Tabla de calles', 'it': 'Tabella delle strade',
        'zh': '道路表', 'ar': 'جدول الطرق',
    },
    'res_folder': {
        'en': 'Folder', 'fr': 'Dossier', 'es': 'Carpeta',
        'it': 'Cartella', 'zh': '文件夹', 'ar': 'المجلد',
    },
    'res_time': {
        'en': 'Time', 'fr': 'Durée', 'es': 'Tiempo',
        'it': 'Tempo', 'zh': '用时', 'ar': 'المدة',
    },

    # ---------------------------------------- statistics table (CSV / Excel)
    'h_city': {
        'en': 'City', 'fr': 'Ville', 'es': 'Ciudad',
        'it': 'Città', 'zh': '城市', 'ar': 'المدينة',
    },
    'h_urban_area': {
        'en': 'Urban Area (km2)', 'fr': 'Superficie urbaine (km2)',
        'es': 'Superficie urbana (km2)', 'it': 'Superficie urbana (km2)',
        'zh': '城市面积（平方公里）', 'ar': 'المساحة الحضرية (كم2)',
    },
    'h_pos_area': {
        'en': 'Open Public Spaces Area (km2)',
        'fr': 'Superficie des espaces publics ouverts (km2)',
        'es': 'Superficie de espacios públicos abiertos (km2)',
        'it': 'Superficie degli spazi pubblici aperti (km2)',
        'zh': '公共开放空间面积（平方公里）',
        'ar': 'مساحة الأماكن العامة المفتوحة (كم2)',
    },
    'h_las': {
        'en': 'Land Allocated to Streets (km2)',
        'fr': 'Superficie consacrée aux rues (km2)',
        'es': 'Superficie destinada a calles (km2)',
        'it': 'Superficie destinata alle strade (km2)',
        'zh': '街道用地（平方公里）',
        'ar': 'المساحة المخصصة للشوارع (كم2)',
    },
    'h_ops_las': {
        'en': 'Open Public Space + Land Allocated to Streets (km2)',
        'fr': 'Espaces publics ouverts + superficie consacrée aux rues (km2)',
        'es': 'Espacios públicos abiertos + superficie destinada a calles '
              '(km2)',
        'it': 'Spazi pubblici aperti + superficie destinata alle strade (km2)',
        'zh': '公共开放空间 + 街道用地（平方公里）',
        'ar': 'الأماكن العامة المفتوحة + المساحة المخصصة للشوارع (كم2)',
    },
    'h_prop_ops_las': {
        'en': 'Proportion of Urban Area with Open Public Space + Land '
              'Allocated to Streets (%)',
        'fr': 'Part de la superficie urbaine en espaces publics ouverts + '
              'superficie consacrée aux rues (%)',
        'es': 'Proporción de la superficie urbana con espacios públicos '
              'abiertos + superficie destinada a calles (%)',
        'it': 'Quota della superficie urbana con spazi pubblici aperti + '
              'superficie destinata alle strade (%)',
        'zh': '城市面积中公共开放空间 + 街道用地所占比例（%）',
        'ar': 'نسبة المساحة الحضرية المخصصة للأماكن العامة المفتوحة + الشوارع '
              '(%)',
    },
    'h_total_pop': {
        'en': 'Total Urban Population', 'fr': 'Population urbaine totale',
        'es': 'Población urbana total', 'it': 'Popolazione urbana totale',
        'zh': '城市总人口', 'ar': 'إجمالي السكان الحضريين',
    },
    'h_pop_pos': {
        'en': 'Population with Access to Open Public Spaces',
        'fr': 'Population ayant accès aux espaces publics ouverts',
        'es': 'Población con acceso a espacios públicos abiertos',
        'it': 'Popolazione con accesso agli spazi pubblici aperti',
        'zh': '可便捷到达公共开放空间的人口',
        'ar': 'السكان الذين يمكنهم الوصول إلى الأماكن العامة المفتوحة',
    },
    'h_pop_bus': {
        'en': 'Population with Access to Low Capacity Transport Stops (Bus '
              'Stops, Light Rail Stops)',
        'fr': 'Population ayant accès aux arrêts de transport à faible '
              'capacité (arrêts de bus, de tramway)',
        'es': 'Población con acceso a paradas de transporte de baja capacidad '
              '(paradas de autobús, de tren ligero)',
        'it': 'Popolazione con accesso alle fermate del trasporto a bassa '
              'capacità (fermate di autobus, di metropolitana leggera)',
        'zh': '可便捷到达低运量公共交通站点（公交车站、轻轨站）的人口',
        'ar': 'السكان الذين يمكنهم الوصول إلى محطات النقل منخفض السعة (مواقف '
              'الحافلات، محطات القطار الخفيف)',
    },
    'h_pop_hc': {
        'en': 'Population with Access to High Capacity Transport (Rail + '
              'Ferry)',
        'fr': 'Population ayant accès aux transports à grande capacité (rail '
              '+ ferry)',
        'es': 'Población con acceso a transporte de alta capacidad '
              '(ferrocarril + ferry)',
        'it': 'Popolazione con accesso al trasporto ad alta capacità '
              '(ferrovia + traghetto)',
        'zh': '可便捷到达大运量公共交通（铁路 + 渡轮）的人口',
        'ar': 'السكان الذين يمكنهم الوصول إلى النقل عالي السعة (السكك '
              'الحديدية + العبّارات)',
    },
    'h_pop_comb': {
        'en': 'Population with Access to Combined Public Transport',
        'fr': 'Population ayant accès aux transports publics combinés',
        'es': 'Población con acceso al transporte público combinado',
        'it': 'Popolazione con accesso al trasporto pubblico combinato',
        'zh': '可便捷到达综合公共交通的人口',
        'ar': 'السكان الذين يمكنهم الوصول إلى النقل العام المجمّع',
    },
    'h_pct_pos': {
        'en': 'Percentage Population with Access to Open Public Spaces',
        'fr': 'Pourcentage de la population ayant accès aux espaces publics '
              'ouverts',
        'es': 'Porcentaje de población con acceso a espacios públicos '
              'abiertos',
        'it': 'Percentuale di popolazione con accesso agli spazi pubblici '
              'aperti',
        'zh': '可便捷到达公共开放空间的人口比例（%）',
        'ar': 'النسبة المئوية للسكان الذين يمكنهم الوصول إلى الأماكن العامة '
              'المفتوحة',
    },
    'h_pct_bus': {
        'en': 'Percentage Population with Access to Low Capacity Transport '
              'Stops (Bus Stops, Light Rail Stops)',
        'fr': 'Pourcentage de la population ayant accès aux arrêts de '
              'transport à faible capacité (arrêts de bus, de tramway)',
        'es': 'Porcentaje de población con acceso a paradas de transporte de '
              'baja capacidad (paradas de autobús, de tren ligero)',
        'it': 'Percentuale di popolazione con accesso alle fermate del '
              'trasporto a bassa capacità (fermate di autobus, di '
              'metropolitana leggera)',
        'zh': '可便捷到达低运量公共交通站点（公交车站、轻轨站）的人口比例（%）',
        'ar': 'النسبة المئوية للسكان الذين يمكنهم الوصول إلى محطات النقل منخفض '
              'السعة (مواقف الحافلات، محطات القطار الخفيف)',
    },
    'h_pct_hc': {
        'en': 'Percentage Population with Access to High Capacity Transport',
        'fr': 'Pourcentage de la population ayant accès aux transports à '
              'grande capacité',
        'es': 'Porcentaje de población con acceso a transporte de alta '
              'capacidad',
        'it': 'Percentuale di popolazione con accesso al trasporto ad alta '
              'capacità',
        'zh': '可便捷到达大运量公共交通的人口比例（%）',
        'ar': 'النسبة المئوية للسكان الذين يمكنهم الوصول إلى النقل عالي السعة',
    },
    'h_pct_comb': {
        'en': 'Percentage Population with Access to Combined Public Transport',
        'fr': 'Pourcentage de la population ayant accès aux transports publics '
              'combinés',
        'es': 'Porcentaje de población con acceso al transporte público '
              'combinado',
        'it': 'Percentuale di popolazione con accesso al trasporto pubblico '
              'combinato',
        'zh': '可便捷到达综合公共交通的人口比例（%）',
        'ar': 'النسبة المئوية للسكان الذين يمكنهم الوصول إلى النقل العام '
              'المجمّع',
    },
    'h_pop_source': {
        'en': 'Population Data Source', 'fr': 'Source des données de '
              'population',
        'es': 'Fuente de los datos de población',
        'it': 'Fonte dei dati di popolazione',
        'zh': '人口数据来源', 'ar': 'مصدر بيانات السكان',
    },
    'src_household': {
        'en': 'Household points', 'fr': 'Points des ménages',
        'es': 'Puntos de hogares', 'it': 'Punti delle famiglie',
        'zh': '住户点', 'ar': 'نقاط الأسر',
    },
    'src_raster': {
        'en': 'Gridded raster', 'fr': 'Raster maillé',
        'es': 'Ráster en cuadrícula', 'it': 'Raster su griglia',
        'zh': '网格化栅格', 'ar': 'راستر شبكي',
    },
    'src_field': {
        'en': 'field', 'fr': 'champ', 'es': 'campo',
        'it': 'campo', 'zh': '字段', 'ar': 'الحقل',
    },
}



def _load_extra_languages():
    """Merge translations/<code>.py (TEXT dicts) into STRINGS."""
    import importlib
    base = {'en', 'fr', 'es', 'it', 'zh', 'ar'}
    for code in [c for c, _ in LANGUAGES if c not in base]:
        try:
            mod = importlib.import_module(
                '.translations.' + code, __package__)
        except (ImportError, TypeError):
            continue
        for key, text in getattr(mod, 'TEXT', {}).items():
            if key in STRINGS:
                STRINGS[key][code] = text


_load_extra_languages()

SUPPORTED = [code for code, _ in LANGUAGES]


def tr(key, lang='en'):
    """Text for `key` in `lang`; falls back to English, then to the key."""
    entry = STRINGS.get(key)
    if entry is None:
        return key
    return entry.get(lang) or entry.get('en') or key


def default_language():
    """The user's saved choice, else the QGIS interface language, else
    English."""
    try:
        from qgis.PyQt.QtCore import QSettings
        s = QSettings()
        saved = s.value('transport_sa/language', '', type=str)
        if saved in SUPPORTED:
            return saved
        loc = s.value('locale/userLocale', '', type=str) or ''
        code = loc[:2].lower()
        code = LOCALE_ALIASES.get(code, code)
        if code in SUPPORTED:
            return code
    except (ImportError, TypeError):
        return 'en'
    return 'en'


def save_language(lang):
    from qgis.PyQt.QtCore import QSettings
    QSettings().setValue('transport_sa/language', lang)
