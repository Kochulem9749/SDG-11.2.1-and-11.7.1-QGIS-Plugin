# -*- coding: utf-8 -*-
"""
Translations for the SDG 11.2.1 and 11.7.1 Statistics Computation plugin.

Languages: English (en), French (fr), Spanish (es), Italian (it),
Chinese - Simplified (zh), Arabic (ar) - in STRINGS below - plus 27 more
languages, one block each in _EXTRA_TEXT further down: Portuguese, German,
Russian, Japanese, Swahili, Swedish, Norwegian (Bokmål), Danish, Hindi,
Bengali, Urdu, Punjabi, Marathi, Telugu, Tamil, Gujarati, Indonesian,
Turkish, Korean, Vietnamese, Persian, Thai, Polish, Dutch, Ukrainian,
Amharic and Hausa.

Every user-facing string of the dialog and the column headers of the output
statistics table live in this file. To correct a
translation, edit the text for that language. Missing texts fall back to
English.
"""

LANGUAGES = [
    ('en', 'English'),
    ('fr', 'Français'),
    ('es', 'Español'),
    ('it', 'Italiano'),
    ('zh', '中文'),
    ('ar', 'العربية'),
    ('pt', 'Português'),
    ('de', 'Deutsch'),
    ('ru', 'Русский'),
    ('ja', '日本語'),
    ('sw', 'Kiswahili'),
    ('sv', 'Svenska'),
    ('nb', 'Norsk (bokmål)'),
    ('da', 'Dansk'),
    ('hi', 'हिन्दी'),
    ('bn', 'বাংলা'),
    ('ur', 'اردو'),
    ('pa', 'ਪੰਜਾਬੀ'),
    ('mr', 'मराठी'),
    ('te', 'తెలుగు'),
    ('ta', 'தமிழ்'),
    ('gu', 'ગુજરાતી'),
    ('id', 'Bahasa Indonesia'),
    ('tr', 'Türkçe'),
    ('ko', '한국어'),
    ('vi', 'Tiếng Việt'),
    ('fa', 'فارسی'),
    ('th', 'ไทย'),
    ('pl', 'Polski'),
    ('nl', 'Nederlands'),
    ('uk', 'Українська'),
    ('am', 'አማርኛ'),
    ('ha', 'Hausa'),
]

# QGIS locale prefixes that map onto one of the languages above.
LOCALE_ALIASES = {'no': 'nb', 'nn': 'nb', 'in': 'id'}

RTL_LANGUAGES = {'ar', 'ur', 'fa'}

STRINGS = {
    # ------------------------------------------------------------------ window
    'win_title': {
        'en': 'SDG 11.2.1 and 11.7.1 Statistics Computation',
        'fr': 'Calcul des statistiques des ODD 11.2.1 et 11.7.1',
        'es': 'Cálculo de estadísticas de los ODS 11.2.1 y 11.7.1',
        'it': 'Calcolo delle statistiche degli SDG 11.2.1 e 11.7.1',
        'zh': '可持续发展目标 11.2.1 和 11.7.1 统计计算',
        'ar': 'حساب إحصاءات مؤشري أهداف التنمية المستدامة 11.2.1 و11.7.1',
    },
    'subtitle': {
        'en': 'Pre-clip to Urban Area -> Reproject + Fix Geometries -> Clip Open '
              'Public Spaces -> Boundary Points -> Service Area -> Convex Hull '
              '-> Clip -> Dissolve -> Population in Catchments -> Road Widths '
              'Join -> Buffer -> Dissolve -> Clip (Land Allocated to Streets) '
              '-> Statistics Table',
        'fr': 'Pré-découpage à la zone urbaine -> Reprojection + correction des '
              'géométries -> Découpage des espaces publics ouverts -> Points de '
              'contour -> Zone de desserte -> Enveloppe convexe -> Découpage -> '
              'Fusion -> Population des zones de desserte -> Jointure des '
              'largeurs de voirie -> Tampon -> Fusion -> Découpage (superficie '
              'consacrée aux rues) -> Tableau statistique',
        'es': 'Recorte previo al área urbana -> Reproyección + corrección de '
              'geometrías -> Recorte de espacios públicos abiertos -> Puntos de '
              'contorno -> Área de servicio -> Envolvente convexa -> Recorte -> '
              'Disolución -> Población en áreas de cobertura -> Unión de anchos '
              'de vía -> Búfer -> Disolución -> Recorte (superficie destinada a '
              'calles) -> Tabla estadística',
        'it': 'Ritaglio preliminare all\'area urbana -> Riproiezione + '
              'correzione geometrie -> Ritaglio degli spazi pubblici aperti -> '
              'Punti di contorno -> Area di servizio -> Inviluppo convesso -> '
              'Ritaglio -> Dissoluzione -> Popolazione nei bacini di utenza -> '
              'Unione larghezze stradali -> Buffer -> Dissoluzione -> Ritaglio '
              '(superficie destinata alle strade) -> Tabella statistica',
        'zh': '预裁剪至城市区域 -> 重投影并修复几何 -> 裁剪公共开放空间 -> 边界点 -> '
              '服务区 -> 凸包 -> 裁剪 -> 融合 -> 服务范围内人口 -> 连接道路宽度 -> '
              '缓冲区 -> 融合 -> 裁剪（街道用地） -> 统计表',
        'ar': 'القص المسبق للمنطقة الحضرية ← إعادة الإسقاط وإصلاح الأشكال '
              'الهندسية ← قص الأماكن العامة المفتوحة ← نقاط الحدود ← منطقة '
              'الخدمة ← الغلاف المحدب ← القص ← الدمج ← السكان ضمن مناطق '
              'الخدمة ← ربط عروض الطرق ← النطاق العازل ← الدمج ← القص '
              '(المساحة المخصصة للشوارع) ← جدول الإحصاءات',
    },
    'language': {
        'en': 'Language:', 'fr': 'Langue :', 'es': 'Idioma:',
        'it': 'Lingua:', 'zh': '语言：', 'ar': 'اللغة:',
    },
    'tab_layers': {
        'en': 'Layers', 'fr': 'Couches', 'es': 'Capas',
        'it': 'Layer', 'zh': '图层', 'ar': 'الطبقات',
    },
    'tab_distances': {
        'en': 'Distances', 'fr': 'Distances', 'es': 'Distancias',
        'it': 'Distanze', 'zh': '距离', 'ar': 'المسافات',
    },
    'tab_output': {
        'en': 'Output', 'fr': 'Sortie', 'es': 'Salida',
        'it': 'Output', 'zh': '输出', 'ar': 'المخرجات',
    },
    'progress': {
        'en': 'Progress', 'fr': 'Progression', 'es': 'Progreso',
        'it': 'Avanzamento', 'zh': '进度', 'ar': 'التقدم',
    },
    'btn_run': {
        'en': 'Run Analysis', 'fr': 'Lancer l\'analyse',
        'es': 'Ejecutar análisis', 'it': 'Avvia analisi',
        'zh': '运行分析', 'ar': 'تشغيل التحليل',
    },
    'btn_cancel': {
        'en': 'Cancel', 'fr': 'Annuler', 'es': 'Cancelar',
        'it': 'Annulla', 'zh': '取消', 'ar': 'إلغاء',
    },
    'btn_reset': {
        'en': 'Reset Log', 'fr': 'Effacer le journal',
        'es': 'Borrar registro', 'it': 'Azzera registro',
        'zh': '清空日志', 'ar': 'مسح السجل',
    },
    'btn_close': {
        'en': 'Close', 'fr': 'Fermer', 'es': 'Cerrar',
        'it': 'Chiudi', 'zh': '关闭', 'ar': 'إغلاق',
    },

    # ------------------------------------------------------------- layers tab
    'grp_streets': {
        'en': 'Streets', 'fr': 'Rues', 'es': 'Calles',
        'it': 'Strade', 'zh': '街道', 'ar': 'الشوارع',
    },
    'note_streets': {
        'en': 'Street layer used for network routing',
        'fr': 'Couche des rues utilisée pour le calcul d\'itinéraires sur le '
              'réseau',
        'es': 'Capa de calles utilizada para el enrutamiento en la red',
        'it': 'Layer delle strade utilizzato per il calcolo dei percorsi '
              'sulla rete',
        'zh': '用于网络路径分析的街道图层',
        'ar': 'طبقة الشوارع المستخدمة لتحليل المسارات على الشبكة',
    },
    'grp_urban': {
        'en': 'Urban Boundary', 'fr': 'Limite urbaine',
        'es': 'Límite urbano', 'it': 'Confine urbano',
        'zh': '城市边界', 'ar': 'الحدود الحضرية',
    },
    'note_urban': {
        'en': 'Polygon layer defining urban extent',
        'fr': 'Couche de polygones définissant l\'étendue urbaine',
        'es': 'Capa de polígonos que define la extensión urbana',
        'it': 'Layer poligonale che definisce l\'estensione urbana',
        'zh': '定义城市范围的面图层',
        'ar': 'طبقة مضلعات تحدد النطاق الحضري',
    },
    'grp_pop_raster': {
        'en': 'Gridded Population (Raster)',
        'fr': 'Population maillée (raster)',
        'es': 'Población en cuadrícula (ráster)',
        'it': 'Popolazione su griglia (raster)',
        'zh': '网格化人口（栅格）',
        'ar': 'بيانات السكان الشبكية (راستر)',
    },
    'note_pop_raster': {
        'en': 'Gridded population dataset. Provide this OR Household '
              'Population (Points) below - one of the two is required.',
        'fr': 'Jeu de données de population maillée. Fournissez ce jeu OU la '
              'Population des ménages (points) ci-dessous - l\'un des deux est '
              'obligatoire.',
        'es': 'Conjunto de datos de población en cuadrícula. Proporcione este '
              'O la Población de hogares (puntos) más abajo; uno de los dos es '
              'obligatorio.',
        'it': 'Dataset della popolazione su griglia. Fornire questo OPPURE la '
              'Popolazione delle famiglie (punti) qui sotto - uno dei due è '
              'obbligatorio.',
        'zh': '网格化人口数据集。请提供此数据或下方的“住户人口（点）”，二者必须提供其一。',
        'ar': 'مجموعة بيانات السكان الشبكية. قدّم هذه البيانات أو بيانات سكان '
              'الأسر (نقاط) أدناه - يلزم توفير أحدهما.',
    },
    'grp_hh': {
        'en': 'Household Population (Points)',
        'fr': 'Population des ménages (points)',
        'es': 'Población de hogares (puntos)',
        'it': 'Popolazione delle famiglie (punti)',
        'zh': '住户人口（点）',
        'ar': 'سكان الأسر (نقاط)',
    },
    'note_hh': {
        'en': 'Point layer with population counts at household level. '
              'Provide this OR the Gridded Population raster - one of the two '
              'is required. If both are given, the household points are used. '
              'Population within each catchment = sum of the selected field '
              'over the points inside it.',
        'fr': 'Couche de points contenant les effectifs de population au '
              'niveau des ménages. Fournissez cette couche OU le raster de '
              'population maillée - l\'un des deux est obligatoire. Si les deux '
              'sont fournis, les points des ménages sont utilisés. Population '
              'de chaque zone de desserte = somme du champ sélectionné pour les '
              'points situés à l\'intérieur.',
        'es': 'Capa de puntos con el número de habitantes por hogar. '
              'Proporcione esta capa O el ráster de población en cuadrícula; '
              'uno de los dos es obligatorio. Si se proporcionan ambos, se usan '
              'los puntos de hogares. Población en cada área de cobertura = '
              'suma del campo seleccionado de los puntos situados en su '
              'interior.',
        'it': 'Layer di punti con il numero di abitanti per famiglia. Fornire '
              'questo OPPURE il raster della popolazione su griglia - uno dei '
              'due è obbligatorio. Se vengono forniti entrambi, si usano i punti '
              'delle famiglie. Popolazione di ciascun bacino di utenza = somma '
              'del campo selezionato per i punti al suo interno.',
        'zh': '包含住户级人口数的点图层。请提供此图层或网格化人口栅格，二者必须提供其一。'
              '若两者均提供，则使用住户点。每个服务范围内的人口 = 其内部各点所选字段之和。',
        'ar': 'طبقة نقاط تتضمن أعداد السكان على مستوى الأسرة. قدّم هذه الطبقة أو '
              'راستر السكان الشبكي - يلزم توفير أحدهما. إذا توفر الاثنان، تُستخدم '
              'نقاط الأسر. السكان ضمن كل منطقة خدمة = مجموع الحقل المحدد للنقاط '
              'الواقعة داخلها.',
    },
    'lbl_pop_field': {
        'en': 'Field containing total population (per household point):',
        'fr': 'Champ contenant la population totale (par point de ménage) :',
        'es': 'Campo con la población total (por punto de hogar):',
        'it': 'Campo con la popolazione totale (per punto famiglia):',
        'zh': '包含总人口的字段（每个住户点）：',
        'ar': 'الحقل الذي يتضمن إجمالي السكان (لكل نقطة أسرة):',
    },
    'grp_pos': {
        'en': 'Open Public Spaces (Polygons)',
        'fr': 'Espaces publics ouverts (polygones)',
        'es': 'Espacios públicos abiertos (polígonos)',
        'it': 'Spazi pubblici aperti (poligoni)',
        'zh': '公共开放空间（面）',
        'ar': 'الأماكن العامة المفتوحة (مضلعات)',
    },
    'note_pos': {
        'en': 'Polygon layers representing undeveloped or open land that is '
              'accessible to the public, providing recreational areas for '
              'residents and enhancing environmental quality. Examples include '
              'parks, gardens, playgrounds, public beaches, riverbanks, and '
              'waterfronts',
        'fr': 'Couches de polygones représentant des terrains non bâtis ou '
              'ouverts accessibles au public, offrant des espaces de loisirs '
              'aux habitants et améliorant la qualité de l\'environnement. Par '
              'exemple : parcs, jardins, aires de jeux, plages publiques, berges '
              'et fronts d\'eau',
        'es': 'Capas de polígonos que representan terrenos no edificados o '
              'abiertos accesibles al público, que ofrecen zonas recreativas a '
              'los residentes y mejoran la calidad ambiental. Por ejemplo: '
              'parques, jardines, parques infantiles, playas públicas, riberas '
              'y frentes de agua',
        'it': 'Layer poligonali che rappresentano terreni non edificati o '
              'aperti accessibili al pubblico, che offrono aree ricreative ai '
              'residenti e migliorano la qualità ambientale. Ad esempio parchi, '
              'giardini, parchi giochi, spiagge pubbliche, sponde fluviali e '
              'lungomare',
        'zh': '表示向公众开放的未开发或开敞用地的面图层，为居民提供休闲场所并改善环境质量。'
              '例如公园、花园、儿童游乐场、公共海滩、河岸和滨水区',
        'ar': 'طبقات مضلعات تمثل الأراضي غير المبنية أو المفتوحة المتاحة للعموم، '
              'والتي توفر مساحات ترفيهية للسكان وتحسّن جودة البيئة. ومن أمثلتها '
              'الحدائق والمتنزهات وملاعب الأطفال والشواطئ العامة وضفاف الأنهار '
              'والواجهات المائية',
    },
    'grp_bus': {
        'en': 'Low Capacity Transport Stops (Bus Stops, Light Rail Stops)',
        'fr': 'Arrêts de transport à faible capacité (arrêts de bus, de '
              'tramway)',
        'es': 'Paradas de transporte de baja capacidad (paradas de autobús, '
              'de tren ligero)',
        'it': 'Fermate del trasporto a bassa capacità (fermate di autobus, di '
              'metropolitana leggera)',
        'zh': '低运量公共交通站点（公交车站、轻轨站）',
        'ar': 'محطات النقل منخفض السعة (مواقف الحافلات، محطات القطار الخفيف)',
    },
    'note_bus': {
        'en': 'Point layer of bus stop / light rail stop locations',
        'fr': 'Couche de points des arrêts de bus / de tramway',
        'es': 'Capa de puntos con la ubicación de paradas de autobús / tren '
              'ligero',
        'it': 'Layer di punti con le fermate di autobus / metropolitana '
              'leggera',
        'zh': '公交车站／轻轨站位置的点图层',
        'ar': 'طبقة نقاط لمواقع مواقف الحافلات / محطات القطار الخفيف',
    },
    'grp_rail': {
        'en': 'High Capacity Transport Stops (Railway Stops, Metro Stops)',
        'fr': 'Arrêts de transport à grande capacité (gares ferroviaires, '
              'stations de métro)',
        'es': 'Paradas de transporte de alta capacidad (estaciones de '
              'ferrocarril, de metro)',
        'it': 'Fermate del trasporto ad alta capacità (stazioni ferroviarie, '
              'della metropolitana)',
        'zh': '大运量公共交通站点（火车站、地铁站）',
        'ar': 'محطات النقل عالي السعة (محطات السكك الحديدية، محطات المترو)',
    },
    'note_rail': {
        'en': 'Point layer of railway/metro station locations',
        'fr': 'Couche de points des gares ferroviaires / stations de métro',
        'es': 'Capa de puntos con la ubicación de estaciones de ferrocarril / '
              'metro',
        'it': 'Layer di punti con le stazioni ferroviarie / della '
              'metropolitana',
        'zh': '火车站／地铁站位置的点图层',
        'ar': 'طبقة نقاط لمواقع محطات السكك الحديدية / المترو',
    },
    'grp_ferry': {
        'en': 'High Capacity Transport Stops (Ferry Stops)',
        'fr': 'Arrêts de transport à grande capacité (embarcadères de ferry)',
        'es': 'Paradas de transporte de alta capacidad (terminales de ferry)',
        'it': 'Fermate del trasporto ad alta capacità (approdi dei traghetti)',
        'zh': '大运量公共交通站点（渡轮码头）',
        'ar': 'محطات النقل عالي السعة (محطات العبّارات)',
    },
    'note_ferry': {
        'en': 'Point layer of ferry terminal locations',
        'fr': 'Couche de points des terminaux de ferry',
        'es': 'Capa de puntos con la ubicación de terminales de ferry',
        'it': 'Layer di punti con i terminal dei traghetti',
        'zh': '渡轮码头位置的点图层',
        'ar': 'طبقة نقاط لمواقع محطات العبّارات',
    },
    'grp_widths': {
        'en': 'Measured Road Widths (CSV table)',
        'fr': 'Largeurs de voirie mesurées (tableau CSV)',
        'es': 'Anchos de vía medidos (tabla CSV)',
        'it': 'Larghezze stradali misurate (tabella CSV)',
        'zh': '实测道路宽度（CSV 表）',
        'ar': 'عروض الطرق المقيسة (جدول CSV)',
    },
    'note_widths': {
        'en': 'Used for Land Allocated to Streets. Column 1 = road category '
              '(matched to the Road Category Field selected below), column 2 = '
              'measured road width in metres. If no CSV is given and no road '
              'category field is available, Land Allocated to Streets = 0.',
        'fr': 'Utilisé pour la superficie consacrée aux rues. Colonne 1 = '
              'catégorie de voie (associée au champ de catégorie de voie '
              'sélectionné ci-dessous), colonne 2 = largeur mesurée en mètres. '
              'Si aucun CSV n\'est fourni et qu\'aucun champ de catégorie n\'est '
              'disponible, la superficie consacrée aux rues = 0.',
        'es': 'Se utiliza para la superficie destinada a calles. Columna 1 = '
              'categoría de vía (vinculada al campo de categoría de vía '
              'seleccionado más abajo), columna 2 = ancho medido en metros. Si '
              'no se proporciona ningún CSV y no hay campo de categoría '
              'disponible, la superficie destinada a calles = 0.',
        'it': 'Utilizzato per la superficie destinata alle strade. Colonna 1 = '
              'categoria stradale (associata al campo della categoria stradale '
              'selezionato qui sotto), colonna 2 = larghezza misurata in metri. '
              'Se non viene fornito alcun CSV e non è disponibile un campo della '
              'categoria, la superficie destinata alle strade = 0.',
        'zh': '用于计算街道用地。第 1 列 = 道路类别（与下方所选的道路类别字段匹配），'
              '第 2 列 = 实测道路宽度（米）。若未提供 CSV 且无可用的道路类别字段，'
              '则街道用地 = 0。',
        'ar': 'يُستخدم لحساب المساحة المخصصة للشوارع. العمود 1 = فئة الطريق (تُطابق '
              'مع حقل فئة الطريق المحدد أدناه)، العمود 2 = عرض الطريق المقيس '
              'بالمتر. إذا لم يُقدَّم ملف CSV ولم يتوفر حقل لفئة الطريق، تكون '
              'المساحة المخصصة للشوارع = 0.',
    },
    'btn_browse_csv': {
        'en': 'Browse CSV...', 'fr': 'Parcourir CSV...',
        'es': 'Examinar CSV...', 'it': 'Sfoglia CSV...',
        'zh': '浏览 CSV...', 'ar': 'استعراض CSV...',
    },
    'grp_catfield': {
        'en': 'Road Category Field (from Streets layer)',
        'fr': 'Champ de catégorie de voie (couche des rues)',
        'es': 'Campo de categoría de vía (capa de calles)',
        'it': 'Campo della categoria stradale (layer delle strade)',
        'zh': '道路类别字段（来自街道图层）',
        'ar': 'حقل فئة الطريق (من طبقة الشوارع)',
    },
    'note_catfield': {
        'en': 'Field of the Streets layer holding the road categories, used to '
              'join the road widths. \'fclass\', \'highway\' or \'type\' is '
              'selected automatically when present; otherwise choose the field '
              'here. Leave empty to auto-detect.',
        'fr': 'Champ de la couche des rues contenant les catégories de voie, '
              'utilisé pour joindre les largeurs. \'fclass\', \'highway\' ou '
              '\'type\' est sélectionné automatiquement s\'il existe ; sinon, '
              'choisissez le champ ici. Laissez vide pour la détection '
              'automatique.',
        'es': 'Campo de la capa de calles que contiene las categorías de vía, '
              'utilizado para unir los anchos. Se selecciona automáticamente '
              '\'fclass\', \'highway\' o \'type\' si existe; de lo contrario, '
              'elija el campo aquí. Déjelo vacío para la detección automática.',
        'it': 'Campo del layer delle strade che contiene le categorie '
              'stradali, usato per unire le larghezze. \'fclass\', \'highway\' o '
              '\'type\' viene selezionato automaticamente se presente; '
              'altrimenti scegliere il campo qui. Lasciare vuoto per il '
              'rilevamento automatico.',
        'zh': '街道图层中保存道路类别的字段，用于连接道路宽度。若存在 “fclass”、'
              '“highway” 或 “type”，将自动选择；否则请在此选择字段。留空则自动识别。',
        'ar': 'حقل طبقة الشوارع الذي يتضمن فئات الطرق، ويُستخدم لربط عروض الطرق. '
              'يُحدَّد الحقل \'fclass\' أو \'highway\' أو \'type\' تلقائيًا عند '
              'وجوده؛ وإلا فاختر الحقل هنا. اتركه فارغًا للكشف التلقائي.',
    },
    'grp_crs': {
        'en': 'Target Coordinate Reference System (Projected, Meters - e.g. '
              'UTM for the urban area)',
        'fr': 'Système de coordonnées de référence cible (projeté, en mètres '
              '- p. ex. UTM de la zone urbaine)',
        'es': 'Sistema de referencia de coordenadas de destino (proyectado, '
              'en metros; p. ej. UTM del área urbana)',
        'it': 'Sistema di riferimento delle coordinate di destinazione '
              '(proiettato, in metri - ad es. UTM dell\'area urbana)',
        'zh': '目标坐标参考系（投影坐标，单位为米，例如城市所在的 UTM 分带）',
        'ar': 'نظام الإحداثيات المرجعي المستهدف (مُسقَط، بالمتر - مثل نطاق UTM '
              'للمنطقة الحضرية)',
    },

    # ---------------------------------------------------------- distances tab
    'dist_header': {
        'en': 'Network distance threshold for:',
        'fr': 'Seuil de distance sur le réseau pour :',
        'es': 'Umbral de distancia en la red para:',
        'it': 'Soglia di distanza sulla rete per:',
        'zh': '网络距离阈值：',
        'ar': 'حدّ المسافة على الشبكة لـ:',
    },
    'dist_pos': {
        'en': 'Open Public Spaces', 'fr': 'Espaces publics ouverts',
        'es': 'Espacios públicos abiertos', 'it': 'Spazi pubblici aperti',
        'zh': '公共开放空间', 'ar': 'الأماكن العامة المفتوحة',
    },
    'spacing_header': {
        'en': 'Open Public Spaces boundary point spacing:',
        'fr': 'Espacement des points sur le contour des espaces publics '
              'ouverts :',
        'es': 'Espaciado de puntos en el contorno de los espacios públicos '
              'abiertos:',
        'it': 'Spaziatura dei punti sul contorno degli spazi pubblici aperti:',
        'zh': '公共开放空间边界点间距：',
        'ar': 'المسافة بين نقاط حدود الأماكن العامة المفتوحة:',
    },
    'spacing_note': {
        'en': 'Start points placed along each open space outline. 100 m is the '
              'standard; larger spacing (e.g. 200 m) is faster for cities with '
              'many large parks but slightly less precise.',
        'fr': 'Points de départ placés le long du contour de chaque espace '
              'ouvert. 100 m est la norme ; un espacement plus grand (p. ex. '
              '200 m) est plus rapide pour les villes comptant de nombreux grands '
              'parcs, mais légèrement moins précis.',
        'es': 'Puntos de partida situados a lo largo del contorno de cada '
              'espacio abierto. 100 m es el valor estándar; un espaciado mayor '
              '(p. ej. 200 m) es más rápido en ciudades con muchos parques '
              'grandes, pero algo menos preciso.',
        'it': 'Punti di partenza posizionati lungo il contorno di ciascuno '
              'spazio aperto. 100 m è lo standard; una spaziatura maggiore (ad '
              'es. 200 m) è più veloce per le città con molti grandi parchi, ma '
              'leggermente meno precisa.',
        'zh': '沿每个开放空间轮廓布设的起点。标准间距为 100 米；对于大型公园较多的城市，'
              '较大间距（如 200 米）计算更快，但精度略低。',
        'ar': 'نقاط بداية توضع على امتداد حدود كل مساحة مفتوحة. القيمة القياسية '
              '100 م؛ والتباعد الأكبر (مثل 200 م) أسرع للمدن التي تضم حدائق كبيرة '
              'كثيرة، لكنه أقل دقة بقليل.',
    },
    'perf_header': {
        'en': 'Performance:', 'fr': 'Performances :', 'es': 'Rendimiento:',
        'it': 'Prestazioni:', 'zh': '性能：', 'ar': 'الأداء:',
    },
    'chk_preclip': {
        'en': 'Pre-clip inputs to the urban area',
        'fr': 'Pré-découper les données à la zone urbaine',
        'es': 'Recortar previamente los datos al área urbana',
        'it': 'Ritagliare preliminarmente i dati all\'area urbana',
        'zh': '将输入数据预裁剪至城市区域',
        'ar': 'القص المسبق للمدخلات وفق المنطقة الحضرية',
    },
    'note_preclip': {
        'en': 'Recommended. Keeps only streets, stops and open spaces within '
              'the search margin of the urban area - much faster with '
              'country/region-wide data.',
        'fr': 'Recommandé. Ne conserve que les rues, arrêts et espaces ouverts '
              'situés dans la marge de recherche autour de la zone urbaine - '
              'beaucoup plus rapide avec des données nationales ou régionales.',
        'es': 'Recomendado. Conserva solo las calles, paradas y espacios '
              'abiertos dentro del margen de búsqueda del área urbana; mucho más '
              'rápido con datos de alcance nacional o regional.',
        'it': 'Consigliato. Mantiene solo strade, fermate e spazi aperti entro '
              'il margine di ricerca dell\'area urbana - molto più veloce con '
              'dati nazionali o regionali.',
        'zh': '推荐。仅保留城市区域搜索范围内的街道、站点和开放空间——处理全国或区域范围数据时速度大幅提升。',
        'ar': 'موصى به. يحتفظ فقط بالشوارع والمحطات والمساحات المفتوحة الواقعة '
              'ضمن هامش البحث حول المنطقة الحضرية - أسرع بكثير مع بيانات على '
              'مستوى البلد أو الإقليم.',
    },
    'chk_memory': {
        'en': 'Keep intermediate layers in memory',
        'fr': 'Conserver les couches intermédiaires en mémoire',
        'es': 'Mantener las capas intermedias en memoria',
        'it': 'Mantenere i layer intermedi in memoria',
        'zh': '将中间图层保存在内存中',
        'ar': 'الاحتفاظ بالطبقات الوسيطة في الذاكرة',
    },
    'note_memory': {
        'en': 'Faster. Untick only if the computer runs out of RAM.',
        'fr': 'Plus rapide. Décochez uniquement si l\'ordinateur manque de '
              'mémoire vive.',
        'es': 'Más rápido. Desmárquelo solo si el equipo se queda sin memoria '
              'RAM.',
        'it': 'Più veloce. Deselezionare solo se il computer esaurisce la '
              'memoria RAM.',
        'zh': '速度更快。仅在计算机内存不足时取消勾选。',
        'ar': 'أسرع. ألغِ التحديد فقط إذا نفدت ذاكرة الحاسوب.',
    },
    'chk_native': {
        'en': 'Use QGIS native Service Area algorithm',
        'fr': 'Utiliser l\'algorithme natif de zone de desserte de QGIS',
        'es': 'Usar el algoritmo nativo de área de servicio de QGIS',
        'it': 'Usare l\'algoritmo nativo di area di servizio di QGIS',
        'zh': '使用 QGIS 原生服务区算法',
        'ar': 'استخدام خوارزمية منطقة الخدمة الأصلية في QGIS',
    },
    'note_native': {
        'en': 'For cross-checking only - very slow with many start points. '
              'Default is the fast bounded search (same results).',
        'fr': 'Pour vérification uniquement - très lent avec de nombreux points '
              'de départ. Par défaut : recherche bornée rapide (mêmes '
              'résultats).',
        'es': 'Solo para verificación; muy lento con muchos puntos de partida. '
              'Por defecto se usa la búsqueda acotada rápida (mismos '
              'resultados).',
        'it': 'Solo per verifica - molto lento con molti punti di partenza. '
              'L\'impostazione predefinita è la ricerca limitata veloce (stessi '
              'risultati).',
        'zh': '仅用于交叉核对——起点较多时速度很慢。默认使用快速有界搜索（结果相同）。',
        'ar': 'للتحقق فقط - بطيء جدًا مع كثرة نقاط البداية. الإعداد الافتراضي '
              'هو البحث المحدود السريع (النتائج نفسها).',
    },

    # ------------------------------------------------------------- output tab
    'grp_city': {
        'en': 'City Name (Hint: Avoid special characters)',
        'fr': 'Nom de la ville (conseil : évitez les caractères spéciaux)',
        'es': 'Nombre de la ciudad (consejo: evite caracteres especiales)',
        'it': 'Nome della città (suggerimento: evitare caratteri speciali)',
        'zh': '城市名称（提示：避免使用特殊字符）',
        'ar': 'اسم المدينة (تلميح: تجنّب الأحرف الخاصة)',
    },
    'city_placeholder': {
        'en': 'e.g. Mombasa', 'fr': 'p. ex. Mombasa', 'es': 'p. ej. Mombasa',
        'it': 'ad es. Mombasa', 'zh': '例如 Mombasa', 'ar': 'مثال: Mombasa',
    },
    'lbl_output_folder': {
        'en': 'Output folder:', 'fr': 'Dossier de sortie :',
        'es': 'Carpeta de salida:', 'it': 'Cartella di output:',
        'zh': '输出文件夹：', 'ar': 'مجلد المخرجات:',
    },
    'btn_browse': {
        'en': 'Browse...', 'fr': 'Parcourir...', 'es': 'Examinar...',
        'it': 'Sfoglia...', 'zh': '浏览...', 'ar': 'استعراض...',
    },
    'info_block': {
        'en': "Final files retained:\n"
              "  Clipped + dissolved catchments (service areas):\n"
              "  SA_POS_dissolved.shp                Open Public Spaces\n"
              "  SA_Bus_dissolved.shp                Low Capacity Transport Stops\n"
              "  SA_Ferry_dissolved.shp              Ferry stops\n"
              "  SA_Rail_dissolved.shp               Rail stops\n"
              "  SA_HighCapacity_dissolved.shp       High Capacity (Rail + Ferry)\n"
              "  SA_CombinedTransport_dissolved.shp  Combined Public Transport\n"
              "  Individual (per-stop) service areas:\n"
              "  SA_Bus_individual.shp / SA_Ferry_individual.shp / SA_Rail_individual.shp\n"
              "  ZonalStats_*.shp                    Catchment + pop_sum field\n"
              "  LAS_streets_dissolved.shp           Land Allocated to Streets\n"
              "  {city}_statistics_11.2.1_and_11.7.1.xlsx\n\n"
              "NOTES:\n"
              "  - Geometries are fixed automatically before processing.\n"
              "  - Population: household points (sum of the population field)\n"
              "    if given, otherwise the gridded population raster.\n"
              "  - Open Public Spaces area measured after clipping to urban boundary.\n"
              "  - Inputs are pre-clipped to the urban area + search margin and\n"
              "    intermediates kept in memory (see Distances tab to change).\n"
              "  - Combined transport = low capacity stops + ferry + rail\n"
              "    (Open Public Spaces excluded).\n"
              "  - Land Allocated to Streets: roads buffered by width, dissolved,\n"
              "    clipped to the urban extent.\n"
              "  - The statistics table is written in the selected language.\n"
              "  - Use 'Reset Log' to clear the log and re-enable buttons after a failure.",
        'fr': "Fichiers finaux conservés :\n"
              "  Zones de desserte découpées et fusionnées :\n"
              "  SA_POS_dissolved.shp                Espaces publics ouverts\n"
              "  SA_Bus_dissolved.shp                Arrêts de transport à faible capacité\n"
              "  SA_Ferry_dissolved.shp              Embarcadères de ferry\n"
              "  SA_Rail_dissolved.shp               Gares ferroviaires\n"
              "  SA_HighCapacity_dissolved.shp       Grande capacité (rail + ferry)\n"
              "  SA_CombinedTransport_dissolved.shp  Transports publics combinés\n"
              "  Zones de desserte individuelles (par arrêt) :\n"
              "  SA_Bus_individual.shp / SA_Ferry_individual.shp / SA_Rail_individual.shp\n"
              "  ZonalStats_*.shp                    Zone de desserte + champ pop_sum\n"
              "  LAS_streets_dissolved.shp           Superficie consacrée aux rues\n"
              "  {city}_statistics_11.2.1_and_11.7.1.xlsx\n\n"
              "REMARQUES :\n"
              "  - Les géométries sont corrigées automatiquement avant le traitement.\n"
              "  - Population : points des ménages (somme du champ de population)\n"
              "    s'ils sont fournis, sinon le raster de population maillée.\n"
              "  - Superficie des espaces publics ouverts mesurée après découpage à la limite urbaine.\n"
              "  - Les données sont pré-découpées à la zone urbaine + marge de recherche et\n"
              "    les couches intermédiaires gardées en mémoire (voir l'onglet Distances).\n"
              "  - Transports combinés = arrêts à faible capacité + ferry + rail\n"
              "    (espaces publics ouverts exclus).\n"
              "  - Superficie consacrée aux rues : rues tamponnées selon leur largeur,\n"
              "    fusionnées et découpées à l'étendue urbaine.\n"
              "  - Le tableau statistique est rédigé dans la langue sélectionnée.\n"
              "  - Utilisez « Effacer le journal » pour réactiver les boutons après un échec.",
        'es': "Archivos finales conservados:\n"
              "  Áreas de cobertura recortadas y disueltas:\n"
              "  SA_POS_dissolved.shp                Espacios públicos abiertos\n"
              "  SA_Bus_dissolved.shp                Paradas de transporte de baja capacidad\n"
              "  SA_Ferry_dissolved.shp              Terminales de ferry\n"
              "  SA_Rail_dissolved.shp               Estaciones de ferrocarril\n"
              "  SA_HighCapacity_dissolved.shp       Alta capacidad (ferrocarril + ferry)\n"
              "  SA_CombinedTransport_dissolved.shp  Transporte público combinado\n"
              "  Áreas de servicio individuales (por parada):\n"
              "  SA_Bus_individual.shp / SA_Ferry_individual.shp / SA_Rail_individual.shp\n"
              "  ZonalStats_*.shp                    Área de cobertura + campo pop_sum\n"
              "  LAS_streets_dissolved.shp           Superficie destinada a calles\n"
              "  {city}_statistics_11.2.1_and_11.7.1.xlsx\n\n"
              "NOTAS:\n"
              "  - Las geometrías se corrigen automáticamente antes del procesamiento.\n"
              "  - Población: puntos de hogares (suma del campo de población)\n"
              "    si se proporcionan; de lo contrario, el ráster de población en cuadrícula.\n"
              "  - Superficie de espacios públicos abiertos medida tras recortar al límite urbano.\n"
              "  - Los datos se recortan previamente al área urbana + margen de búsqueda y\n"
              "    las capas intermedias se mantienen en memoria (véase la pestaña Distancias).\n"
              "  - Transporte combinado = paradas de baja capacidad + ferry + ferrocarril\n"
              "    (espacios públicos abiertos excluidos).\n"
              "  - Superficie destinada a calles: calles con búfer según su ancho,\n"
              "    disueltas y recortadas a la extensión urbana.\n"
              "  - La tabla estadística se redacta en el idioma seleccionado.\n"
              "  - Use «Borrar registro» para reactivar los botones tras un error.",
        'it': "File finali conservati:\n"
              "  Bacini di utenza ritagliati e dissolti:\n"
              "  SA_POS_dissolved.shp                Spazi pubblici aperti\n"
              "  SA_Bus_dissolved.shp                Fermate del trasporto a bassa capacità\n"
              "  SA_Ferry_dissolved.shp              Approdi dei traghetti\n"
              "  SA_Rail_dissolved.shp               Stazioni ferroviarie\n"
              "  SA_HighCapacity_dissolved.shp       Alta capacità (ferrovia + traghetto)\n"
              "  SA_CombinedTransport_dissolved.shp  Trasporto pubblico combinato\n"
              "  Aree di servizio individuali (per fermata):\n"
              "  SA_Bus_individual.shp / SA_Ferry_individual.shp / SA_Rail_individual.shp\n"
              "  ZonalStats_*.shp                    Bacino di utenza + campo pop_sum\n"
              "  LAS_streets_dissolved.shp           Superficie destinata alle strade\n"
              "  {city}_statistics_11.2.1_and_11.7.1.xlsx\n\n"
              "NOTE:\n"
              "  - Le geometrie vengono corrette automaticamente prima dell'elaborazione.\n"
              "  - Popolazione: punti delle famiglie (somma del campo popolazione)\n"
              "    se forniti, altrimenti il raster della popolazione su griglia.\n"
              "  - Superficie degli spazi pubblici aperti misurata dopo il ritaglio al confine urbano.\n"
              "  - I dati sono ritagliati all'area urbana + margine di ricerca e\n"
              "    i layer intermedi tenuti in memoria (vedere la scheda Distanze).\n"
              "  - Trasporto combinato = fermate a bassa capacità + traghetto + ferrovia\n"
              "    (spazi pubblici aperti esclusi).\n"
              "  - Superficie destinata alle strade: strade con buffer secondo la larghezza,\n"
              "    dissolte e ritagliate all'estensione urbana.\n"
              "  - La tabella statistica è redatta nella lingua selezionata.\n"
              "  - Usare «Azzera registro» per riattivare i pulsanti dopo un errore.",
        'zh': "保留的最终文件：\n"
              "  裁剪并融合后的服务范围：\n"
              "  SA_POS_dissolved.shp                公共开放空间\n"
              "  SA_Bus_dissolved.shp                低运量公共交通站点\n"
              "  SA_Ferry_dissolved.shp              渡轮码头\n"
              "  SA_Rail_dissolved.shp               火车站\n"
              "  SA_HighCapacity_dissolved.shp       大运量（铁路 + 渡轮）\n"
              "  SA_CombinedTransport_dissolved.shp  综合公共交通\n"
              "  单个站点的服务区：\n"
              "  SA_Bus_individual.shp / SA_Ferry_individual.shp / SA_Rail_individual.shp\n"
              "  ZonalStats_*.shp                    服务范围 + pop_sum 字段\n"
              "  LAS_streets_dissolved.shp           街道用地\n"
              "  {city}_statistics_11.2.1_and_11.7.1.xlsx\n\n"
              "说明：\n"
              "  - 处理前会自动修复几何。\n"
              "  - 人口：若提供住户点则使用住户点（人口字段之和），\n"
              "    否则使用网格化人口栅格。\n"
              "  - 公共开放空间面积在裁剪至城市边界后计算。\n"
              "  - 输入数据预裁剪至城市区域 + 搜索范围，\n"
              "    中间图层保存在内存中（可在“距离”选项卡中更改）。\n"
              "  - 综合公共交通 = 低运量站点 + 渡轮 + 铁路（不含公共开放空间）。\n"
              "  - 街道用地：按道路宽度生成缓冲区，融合后裁剪至城市范围。\n"
              "  - 统计表以所选语言输出。\n"
              "  - 运行失败后，使用“清空日志”重新启用按钮。",
        'ar': "الملفات النهائية المحفوظة:\n"
              "  مناطق الخدمة بعد القص والدمج:\n"
              "  SA_POS_dissolved.shp                الأماكن العامة المفتوحة\n"
              "  SA_Bus_dissolved.shp                محطات النقل منخفض السعة\n"
              "  SA_Ferry_dissolved.shp              محطات العبّارات\n"
              "  SA_Rail_dissolved.shp               محطات السكك الحديدية\n"
              "  SA_HighCapacity_dissolved.shp       النقل عالي السعة (السكك الحديدية + العبّارات)\n"
              "  SA_CombinedTransport_dissolved.shp  النقل العام المجمّع\n"
              "  مناطق الخدمة الفردية (لكل محطة):\n"
              "  SA_Bus_individual.shp / SA_Ferry_individual.shp / SA_Rail_individual.shp\n"
              "  ZonalStats_*.shp                    منطقة الخدمة + الحقل pop_sum\n"
              "  LAS_streets_dissolved.shp           المساحة المخصصة للشوارع\n"
              "  {city}_statistics_11.2.1_and_11.7.1.xlsx\n\n"
              "ملاحظات:\n"
              "  - تُصلَح الأشكال الهندسية تلقائيًا قبل المعالجة.\n"
              "  - السكان: نقاط الأسر (مجموع حقل السكان) إن توفرت،\n"
              "    وإلا فراستر السكان الشبكي.\n"
              "  - تُقاس مساحة الأماكن العامة المفتوحة بعد قصها وفق الحدود الحضرية.\n"
              "  - تُقص المدخلات مسبقًا وفق المنطقة الحضرية مع هامش البحث،\n"
              "    وتُحفظ الطبقات الوسيطة في الذاكرة (انظر تبويب المسافات).\n"
              "  - النقل المجمّع = محطات النقل منخفض السعة + العبّارات + السكك الحديدية\n"
              "    (باستثناء الأماكن العامة المفتوحة).\n"
              "  - المساحة المخصصة للشوارع: نطاقات عازلة للطرق حسب عرضها،\n"
              "    تُدمج وتُقص وفق النطاق الحضري.\n"
              "  - يُكتب جدول الإحصاءات باللغة المحددة.\n"
              "  - استخدم «مسح السجل» لإعادة تفعيل الأزرار بعد حدوث خطأ.",
    },

    # --------------------------------------------------------------- messages
    'msg_running_title': {
        'en': 'Running', 'fr': 'En cours', 'es': 'En ejecución',
        'it': 'In esecuzione', 'zh': '正在运行', 'ar': 'قيد التشغيل',
    },
    'msg_cannot_reset': {
        'en': 'Cannot reset while analysis is running. Cancel first.',
        'fr': 'Impossible d\'effacer pendant l\'analyse. Annulez d\'abord.',
        'es': 'No se puede borrar mientras se ejecuta el análisis. Cancele '
              'primero.',
        'it': 'Impossibile azzerare durante l\'analisi. Annullare prima.',
        'zh': '分析运行期间无法清空。请先取消。',
        'ar': 'لا يمكن المسح أثناء تشغيل التحليل. ألغِ التحليل أولًا.',
    },
    'msg_missing_layer': {
        'en': 'Missing Layer', 'fr': 'Couche manquante',
        'es': 'Falta una capa', 'it': 'Layer mancante',
        'zh': '缺少图层', 'ar': 'طبقة مفقودة',
    },
    'msg_select_streets': {
        'en': 'Please select a Streets layer.',
        'fr': 'Veuillez sélectionner une couche de rues.',
        'es': 'Seleccione una capa de calles.',
        'it': 'Selezionare un layer delle strade.',
        'zh': '请选择街道图层。',
        'ar': 'يرجى اختيار طبقة الشوارع.',
    },
    'msg_select_urban': {
        'en': 'Please select an Urban Boundary layer.',
        'fr': 'Veuillez sélectionner une couche de limite urbaine.',
        'es': 'Seleccione una capa de límite urbano.',
        'it': 'Selezionare un layer del confine urbano.',
        'zh': '请选择城市边界图层。',
        'ar': 'يرجى اختيار طبقة الحدود الحضرية.',
    },
    'msg_missing_pop_title': {
        'en': 'Missing Population Data',
        'fr': 'Données de population manquantes',
        'es': 'Faltan datos de población',
        'it': 'Dati di popolazione mancanti',
        'zh': '缺少人口数据',
        'ar': 'بيانات السكان مفقودة',
    },
    'msg_missing_pop': {
        'en': 'Please select a Gridded Population (Raster) layer or a '
              'Household Population (Points) layer - one of the two is '
              'required.',
        'fr': 'Veuillez sélectionner une couche de population maillée '
              '(raster) ou une couche de population des ménages (points) - '
              'l\'une des deux est obligatoire.',
        'es': 'Seleccione una capa de población en cuadrícula (ráster) o una '
              'capa de población de hogares (puntos); una de las dos es '
              'obligatoria.',
        'it': 'Selezionare un layer della popolazione su griglia (raster) o '
              'un layer della popolazione delle famiglie (punti) - uno dei due '
              'è obbligatorio.',
        'zh': '请选择网格化人口（栅格）图层或住户人口（点）图层，二者必须选择其一。',
        'ar': 'يرجى اختيار طبقة بيانات السكان الشبكية (راستر) أو طبقة سكان الأسر '
              '(نقاط) - يلزم اختيار إحداهما.',
    },
    'msg_missing_popfield_title': {
        'en': 'Missing Population Field',
        'fr': 'Champ de population manquant',
        'es': 'Falta el campo de población',
        'it': 'Campo della popolazione mancante',
        'zh': '缺少人口字段',
        'ar': 'حقل السكان مفقود',
    },
    'msg_missing_popfield': {
        'en': 'Please select the field containing total population for the '
              'Household Population (Points) layer.',
        'fr': 'Veuillez sélectionner le champ contenant la population totale '
              'de la couche de population des ménages (points).',
        'es': 'Seleccione el campo con la población total de la capa de '
              'población de hogares (puntos).',
        'it': 'Selezionare il campo con la popolazione totale del layer della '
              'popolazione delle famiglie (punti).',
        'zh': '请为住户人口（点）图层选择包含总人口的字段。',
        'ar': 'يرجى اختيار الحقل الذي يتضمن إجمالي السكان لطبقة سكان الأسر '
              '(نقاط).',
    },
    'msg_missing_city_title': {
        'en': 'Missing City Name', 'fr': 'Nom de ville manquant',
        'es': 'Falta el nombre de la ciudad',
        'it': 'Nome della città mancante',
        'zh': '缺少城市名称', 'ar': 'اسم المدينة مفقود',
    },
    'msg_missing_city': {
        'en': 'Please enter a city name.',
        'fr': 'Veuillez saisir un nom de ville.',
        'es': 'Introduzca el nombre de la ciudad.',
        'it': 'Inserire il nome della città.',
        'zh': '请输入城市名称。',
        'ar': 'يرجى إدخال اسم المدينة.',
    },
    'msg_missing_output_title': {
        'en': 'Missing Output', 'fr': 'Sortie manquante',
        'es': 'Falta la salida', 'it': 'Output mancante',
        'zh': '缺少输出位置', 'ar': 'المخرجات مفقودة',
    },
    'msg_missing_output': {
        'en': 'Please select an output folder.',
        'fr': 'Veuillez sélectionner un dossier de sortie.',
        'es': 'Seleccione una carpeta de salida.',
        'it': 'Selezionare una cartella di output.',
        'zh': '请选择输出文件夹。',
        'ar': 'يرجى اختيار مجلد للمخرجات.',
    },
    'msg_invalid_crs_title': {
        'en': 'Invalid CRS', 'fr': 'SCR non valide', 'es': 'SRC no válido',
        'it': 'SR non valido', 'zh': '坐标参考系无效',
        'ar': 'نظام إحداثيات غير صالح',
    },
    'msg_invalid_crs': {
        'en': 'Please select a valid target CRS.',
        'fr': 'Veuillez sélectionner un SCR cible valide.',
        'es': 'Seleccione un SRC de destino válido.',
        'it': 'Selezionare un SR di destinazione valido.',
        'zh': '请选择有效的目标坐标参考系。',
        'ar': 'يرجى اختيار نظام إحداثيات مستهدف صالح.',
    },
    'msg_no_transport_title': {
        'en': 'No Transport Layers', 'fr': 'Aucune couche de transport',
        'es': 'Sin capas de transporte', 'it': 'Nessun layer di trasporto',
        'zh': '无交通图层', 'ar': 'لا توجد طبقات للنقل',
    },
    'msg_no_transport': {
        'en': 'No Open Public Spaces / Low Capacity / Ferry / Rail layers '
              'selected. Only the urban area and streets will be processed. '
              'Continue?',
        'fr': 'Aucune couche d\'espaces publics ouverts / de faible capacité / '
              'de ferry / de rail sélectionnée. Seules la zone urbaine et les '
              'rues seront traitées. Continuer ?',
        'es': 'No se ha seleccionado ninguna capa de espacios públicos '
              'abiertos / baja capacidad / ferry / ferrocarril. Solo se '
              'procesarán el área urbana y las calles. ¿Continuar?',
        'it': 'Nessun layer di spazi pubblici aperti / bassa capacità / '
              'traghetti / ferrovia selezionato. Verranno elaborati solo l\'area '
              'urbana e le strade. Continuare?',
        'zh': '未选择公共开放空间／低运量／渡轮／铁路图层。将仅处理城市区域和街道。是否继续？',
        'ar': 'لم تُحدَّد طبقات الأماكن العامة المفتوحة / النقل منخفض السعة / '
              'العبّارات / السكك الحديدية. ستُعالَج المنطقة الحضرية والشوارع فقط. '
              'هل تريد المتابعة؟',
    },
    'msg_complete': {
        'en': 'Complete', 'fr': 'Terminé', 'es': 'Completado',
        'it': 'Completato', 'zh': '完成', 'ar': 'اكتمل',
    },
    'msg_error': {
        'en': 'Error', 'fr': 'Erreur', 'es': 'Error',
        'it': 'Errore', 'zh': '错误', 'ar': 'خطأ',
    },
    'msg_failed': {
        'en': 'Analysis failed. See log for details.\n\nClick \'Reset Log\' to '
              'clear and run again.',
        'fr': 'L\'analyse a échoué. Consultez le journal pour plus de détails.'
              '\n\nCliquez sur « Effacer le journal » pour recommencer.',
        'es': 'El análisis ha fallado. Consulte el registro para más '
              'detalles.\n\nHaga clic en «Borrar registro» para volver a '
              'empezar.',
        'it': 'Analisi non riuscita. Consultare il registro per i dettagli.'
              '\n\nFare clic su «Azzera registro» per ricominciare.',
        'zh': '分析失败。详情请查看日志。\n\n点击“清空日志”后重新运行。',
        'ar': 'فشل التحليل. راجع السجل للاطلاع على التفاصيل.\n\nانقر على «مسح '
              'السجل» ثم أعد التشغيل.',
    },
    'msg_close_running': {
        'en': 'Analysis is still running. Cancel and close?',
        'fr': 'L\'analyse est toujours en cours. Annuler et fermer ?',
        'es': 'El análisis sigue en ejecución. ¿Cancelar y cerrar?',
        'it': 'L\'analisi è ancora in corso. Annullare e chiudere?',
        'zh': '分析仍在运行。是否取消并关闭？',
        'ar': 'لا يزال التحليل قيد التشغيل. هل تريد الإلغاء والإغلاق؟',
    },
    'msg_cancel_requested': {
        'en': 'Cancellation requested...', 'fr': 'Annulation demandée...',
        'es': 'Cancelación solicitada...', 'it': 'Annullamento richiesto...',
        'zh': '已请求取消……', 'ar': 'تم طلب الإلغاء...',
    },
    'dlg_select_output': {
        'en': 'Select Output Folder',
        'fr': 'Sélectionner le dossier de sortie',
        'es': 'Seleccionar carpeta de salida',
        'it': 'Seleziona cartella di output',
        'zh': '选择输出文件夹', 'ar': 'اختر مجلد المخرجات',
    },
    'dlg_select_csv': {
        'en': 'Select Measured Road Widths CSV',
        'fr': 'Sélectionner le CSV des largeurs de voirie mesurées',
        'es': 'Seleccionar el CSV de anchos de vía medidos',
        'it': 'Seleziona il CSV delle larghezze stradali misurate',
        'zh': '选择实测道路宽度 CSV',
        'ar': 'اختر ملف CSV لعروض الطرق المقيسة',
    },
    'csv_filter': {
        'en': 'CSV files (*.csv *.txt);;All files (*)',
        'fr': 'Fichiers CSV (*.csv *.txt);;Tous les fichiers (*)',
        'es': 'Archivos CSV (*.csv *.txt);;Todos los archivos (*)',
        'it': 'File CSV (*.csv *.txt);;Tutti i file (*)',
        'zh': 'CSV 文件 (*.csv *.txt);;所有文件 (*)',
        'ar': 'ملفات CSV (*.csv *.txt);;جميع الملفات (*)',
    },
    'msg_invalid_csv_title': {
        'en': 'Invalid CSV', 'fr': 'CSV non valide', 'es': 'CSV no válido',
        'it': 'CSV non valido', 'zh': 'CSV 无效', 'ar': 'ملف CSV غير صالح',
    },
    'msg_invalid_csv': {
        'en': 'Could not read:', 'fr': 'Lecture impossible :',
        'es': 'No se pudo leer:', 'it': 'Impossibile leggere:',
        'zh': '无法读取：', 'ar': 'تعذّرت القراءة:',
    },
    'msg_widths_title': {
        'en': 'Road Widths CSV', 'fr': 'CSV des largeurs de voirie',
        'es': 'CSV de anchos de vía', 'it': 'CSV delle larghezze stradali',
        'zh': '道路宽度 CSV', 'ar': 'ملف CSV لعروض الطرق',
    },
    'msg_widths_cols': {
        'en': 'The road widths table needs at least two columns (road '
              'category, width). It will be ignored.',
        'fr': 'Le tableau des largeurs doit comporter au moins deux colonnes '
              '(catégorie de voie, largeur). Il sera ignoré.',
        'es': 'La tabla de anchos de vía necesita al menos dos columnas '
              '(categoría de vía, ancho). Se ignorará.',
        'it': 'La tabella delle larghezze richiede almeno due colonne '
              '(categoria stradale, larghezza). Verrà ignorata.',
        'zh': '道路宽度表至少需要两列（道路类别、宽度）。将忽略该表。',
        'ar': 'يجب أن يتضمن جدول عروض الطرق عمودين على الأقل (فئة الطريق، '
              'العرض). سيتم تجاهله.',
    },

    # ------------------------------------------------- end-of-run summary
    'res_done': {
        'en': 'Done!', 'fr': 'Terminé !', 'es': '¡Completado!',
        'it': 'Completato!', 'zh': '完成！', 'ar': 'اكتمل!',
    },
    'res_las': {
        'en': 'Land Allocated to Streets', 'fr': 'Superficie consacrée aux rues',
        'es': 'Superficie destinada a calles',
        'it': 'Superficie destinata alle strade',
        'zh': '街道用地', 'ar': 'المساحة المخصصة للشوارع',
    },
    'res_stats': {
        'en': 'Statistics table (CSV)', 'fr': 'Tableau statistique (CSV)',
        'es': 'Tabla estadística (CSV)', 'it': 'Tabella statistica (CSV)',
        'zh': '统计表（CSV）', 'ar': 'جدول الإحصاءات (CSV)',
    },
    'res_excel': {
        'en': 'Statistics workbook (Excel)',
        'fr': 'Classeur statistique (Excel)',
        'es': 'Libro estadístico (Excel)',
        'it': 'Cartella di lavoro statistica (Excel)',
        'zh': '统计工作簿（Excel）',
        'ar': 'مصنف الإحصاءات (Excel)',
    },
    'res_roads': {
        'en': 'Roads table', 'fr': 'Tableau des rues',
        'es': 'Tabla de calles', 'it': 'Tabella delle strade',
        'zh': '道路表', 'ar': 'جدول الطرق',
    },
    'res_folder': {
        'en': 'Folder', 'fr': 'Dossier', 'es': 'Carpeta',
        'it': 'Cartella', 'zh': '文件夹', 'ar': 'المجلد',
    },
    'res_time': {
        'en': 'Time', 'fr': 'Durée', 'es': 'Tiempo',
        'it': 'Tempo', 'zh': '用时', 'ar': 'المدة',
    },

    # ---------------------------------------- statistics table (CSV / Excel)
    'h_city': {
        'en': 'City', 'fr': 'Ville', 'es': 'Ciudad',
        'it': 'Città', 'zh': '城市', 'ar': 'المدينة',
    },
    'h_urban_area': {
        'en': 'Urban Area (km2)', 'fr': 'Superficie urbaine (km2)',
        'es': 'Superficie urbana (km2)', 'it': 'Superficie urbana (km2)',
        'zh': '城市面积（平方公里）', 'ar': 'المساحة الحضرية (كم2)',
    },
    'h_pos_area': {
        'en': 'Open Public Spaces Area (km2)',
        'fr': 'Superficie des espaces publics ouverts (km2)',
        'es': 'Superficie de espacios públicos abiertos (km2)',
        'it': 'Superficie degli spazi pubblici aperti (km2)',
        'zh': '公共开放空间面积（平方公里）',
        'ar': 'مساحة الأماكن العامة المفتوحة (كم2)',
    },
    'h_las': {
        'en': 'Land Allocated to Streets (km2)',
        'fr': 'Superficie consacrée aux rues (km2)',
        'es': 'Superficie destinada a calles (km2)',
        'it': 'Superficie destinata alle strade (km2)',
        'zh': '街道用地（平方公里）',
        'ar': 'المساحة المخصصة للشوارع (كم2)',
    },
    'h_ops_las': {
        'en': 'Open Public Space + Land Allocated to Streets (km2)',
        'fr': 'Espaces publics ouverts + superficie consacrée aux rues (km2)',
        'es': 'Espacios públicos abiertos + superficie destinada a calles '
              '(km2)',
        'it': 'Spazi pubblici aperti + superficie destinata alle strade (km2)',
        'zh': '公共开放空间 + 街道用地（平方公里）',
        'ar': 'الأماكن العامة المفتوحة + المساحة المخصصة للشوارع (كم2)',
    },
    'h_prop_ops_las': {
        'en': 'Proportion of Urban Area with Open Public Space + Land '
              'Allocated to Streets (%)',
        'fr': 'Part de la superficie urbaine en espaces publics ouverts + '
              'superficie consacrée aux rues (%)',
        'es': 'Proporción de la superficie urbana con espacios públicos '
              'abiertos + superficie destinada a calles (%)',
        'it': 'Quota della superficie urbana con spazi pubblici aperti + '
              'superficie destinata alle strade (%)',
        'zh': '城市面积中公共开放空间 + 街道用地所占比例（%）',
        'ar': 'نسبة المساحة الحضرية المخصصة للأماكن العامة المفتوحة + الشوارع '
              '(%)',
    },
    'h_total_pop': {
        'en': 'Total Urban Population', 'fr': 'Population urbaine totale',
        'es': 'Población urbana total', 'it': 'Popolazione urbana totale',
        'zh': '城市总人口', 'ar': 'إجمالي السكان الحضريين',
    },
    'h_pop_pos': {
        'en': 'Population with Access to Open Public Spaces',
        'fr': 'Population ayant accès aux espaces publics ouverts',
        'es': 'Población con acceso a espacios públicos abiertos',
        'it': 'Popolazione con accesso agli spazi pubblici aperti',
        'zh': '可便捷到达公共开放空间的人口',
        'ar': 'السكان الذين يمكنهم الوصول إلى الأماكن العامة المفتوحة',
    },
    'h_pop_bus': {
        'en': 'Population with Access to Low Capacity Transport Stops (Bus '
              'Stops, Light Rail Stops)',
        'fr': 'Population ayant accès aux arrêts de transport à faible '
              'capacité (arrêts de bus, de tramway)',
        'es': 'Población con acceso a paradas de transporte de baja capacidad '
              '(paradas de autobús, de tren ligero)',
        'it': 'Popolazione con accesso alle fermate del trasporto a bassa '
              'capacità (fermate di autobus, di metropolitana leggera)',
        'zh': '可便捷到达低运量公共交通站点（公交车站、轻轨站）的人口',
        'ar': 'السكان الذين يمكنهم الوصول إلى محطات النقل منخفض السعة (مواقف '
              'الحافلات، محطات القطار الخفيف)',
    },
    'h_pop_hc': {
        'en': 'Population with Access to High Capacity Transport (Rail + '
              'Ferry)',
        'fr': 'Population ayant accès aux transports à grande capacité (rail '
              '+ ferry)',
        'es': 'Población con acceso a transporte de alta capacidad '
              '(ferrocarril + ferry)',
        'it': 'Popolazione con accesso al trasporto ad alta capacità '
              '(ferrovia + traghetto)',
        'zh': '可便捷到达大运量公共交通（铁路 + 渡轮）的人口',
        'ar': 'السكان الذين يمكنهم الوصول إلى النقل عالي السعة (السكك '
              'الحديدية + العبّارات)',
    },
    'h_pop_comb': {
        'en': 'Population with Access to Combined Public Transport',
        'fr': 'Population ayant accès aux transports publics combinés',
        'es': 'Población con acceso al transporte público combinado',
        'it': 'Popolazione con accesso al trasporto pubblico combinato',
        'zh': '可便捷到达综合公共交通的人口',
        'ar': 'السكان الذين يمكنهم الوصول إلى النقل العام المجمّع',
    },
    'h_pct_pos': {
        'en': 'Percentage Population with Access to Open Public Spaces',
        'fr': 'Pourcentage de la population ayant accès aux espaces publics '
              'ouverts',
        'es': 'Porcentaje de población con acceso a espacios públicos '
              'abiertos',
        'it': 'Percentuale di popolazione con accesso agli spazi pubblici '
              'aperti',
        'zh': '可便捷到达公共开放空间的人口比例（%）',
        'ar': 'النسبة المئوية للسكان الذين يمكنهم الوصول إلى الأماكن العامة '
              'المفتوحة',
    },
    'h_pct_bus': {
        'en': 'Percentage Population with Access to Low Capacity Transport '
              'Stops (Bus Stops, Light Rail Stops)',
        'fr': 'Pourcentage de la population ayant accès aux arrêts de '
              'transport à faible capacité (arrêts de bus, de tramway)',
        'es': 'Porcentaje de población con acceso a paradas de transporte de '
              'baja capacidad (paradas de autobús, de tren ligero)',
        'it': 'Percentuale di popolazione con accesso alle fermate del '
              'trasporto a bassa capacità (fermate di autobus, di '
              'metropolitana leggera)',
        'zh': '可便捷到达低运量公共交通站点（公交车站、轻轨站）的人口比例（%）',
        'ar': 'النسبة المئوية للسكان الذين يمكنهم الوصول إلى محطات النقل منخفض '
              'السعة (مواقف الحافلات، محطات القطار الخفيف)',
    },
    'h_pct_hc': {
        'en': 'Percentage Population with Access to High Capacity Transport',
        'fr': 'Pourcentage de la population ayant accès aux transports à '
              'grande capacité',
        'es': 'Porcentaje de población con acceso a transporte de alta '
              'capacidad',
        'it': 'Percentuale di popolazione con accesso al trasporto ad alta '
              'capacità',
        'zh': '可便捷到达大运量公共交通的人口比例（%）',
        'ar': 'النسبة المئوية للسكان الذين يمكنهم الوصول إلى النقل عالي السعة',
    },
    'h_pct_comb': {
        'en': 'Percentage Population with Access to Combined Public Transport',
        'fr': 'Pourcentage de la population ayant accès aux transports publics '
              'combinés',
        'es': 'Porcentaje de población con acceso al transporte público '
              'combinado',
        'it': 'Percentuale di popolazione con accesso al trasporto pubblico '
              'combinato',
        'zh': '可便捷到达综合公共交通的人口比例（%）',
        'ar': 'النسبة المئوية للسكان الذين يمكنهم الوصول إلى النقل العام '
              'المجمّع',
    },
    'h_pop_source': {
        'en': 'Population Data Source', 'fr': 'Source des données de '
              'population',
        'es': 'Fuente de los datos de población',
        'it': 'Fonte dei dati di popolazione',
        'zh': '人口数据来源', 'ar': 'مصدر بيانات السكان',
    },
    'src_household': {
        'en': 'Household points', 'fr': 'Points des ménages',
        'es': 'Puntos de hogares', 'it': 'Punti delle famiglie',
        'zh': '住户点', 'ar': 'نقاط الأسر',
    },
    'src_raster': {
        'en': 'Gridded raster', 'fr': 'Raster maillé',
        'es': 'Ráster en cuadrícula', 'it': 'Raster su griglia',
        'zh': '网格化栅格', 'ar': 'راستر شبكي',
    },
    'src_field': {
        'en': 'field', 'fr': 'champ', 'es': 'campo',
        'it': 'campo', 'zh': '字段', 'ar': 'الحقل',
    },
}



# ==========================================================================
# MORE LANGUAGES - one block per language. To correct a translation, edit
# the text in that language's block. Keys left out fall back to English.
# A file translations/<code>.py with a TEXT dict, if present, overrides
# the block below for that language.
# ==========================================================================

_EXTRA_TEXT = {}

# ---------------------------------------------------------- pt: Português
_EXTRA_TEXT['pt'] = {
    'win_title': 'Cálculo das estatísticas dos ODS 11.2.1 e 11.7.1',
    'subtitle': 'Recorte prévio à área urbana -> Reprojeção + correção de '
                'geometrias -> Recorte dos espaços públicos abertos -> Pontos '
                'de contorno -> Área de serviço -> Envolvente convexa -> Recorte '
                '-> Dissolução -> População nas áreas de abrangência -> Junção '
                'das larguras das vias -> Buffer -> Dissolução -> Recorte (área '
                'destinada às ruas) -> Tabela estatística',
    'language': 'Idioma:',
    'tab_layers': 'Camadas',
    'tab_distances': 'Distâncias',
    'tab_output': 'Resultados',
    'progress': 'Progresso',
    'btn_run': 'Executar análise',
    'btn_cancel': 'Cancelar',
    'btn_reset': 'Limpar registo',
    'btn_close': 'Fechar',
    'grp_streets': 'Ruas',
    'note_streets': 'Camada de ruas utilizada para o cálculo de percursos na '
                    'rede',
    'grp_urban': 'Limite urbano',
    'note_urban': 'Camada de polígonos que define a extensão urbana',
    'grp_pop_raster': 'População em grelha (raster)',
    'note_pop_raster': 'Conjunto de dados de população em grelha. Forneça este '
                       'OU a População dos agregados familiares (pontos) abaixo '
                       '- um dos dois é obrigatório.',
    'grp_hh': 'População dos agregados familiares (pontos)',
    'note_hh': 'Camada de pontos com o número de habitantes por agregado '
               'familiar. Forneça esta camada OU o raster de população em '
               'grelha - um dos dois é obrigatório. Se forem fornecidos ambos, '
               'são usados os pontos dos agregados familiares. População de cada '
               'área de abrangência = soma do campo selecionado para os pontos '
               'situados no seu interior.',
    'lbl_pop_field': 'Campo com a população total (por ponto de agregado '
                     'familiar):',
    'grp_pos': 'Espaços públicos abertos (polígonos)',
    'note_pos': 'Camadas de polígonos que representam terrenos não edificados '
                'ou abertos acessíveis ao público, que proporcionam áreas de '
                'lazer aos residentes e melhoram a qualidade ambiental. Por '
                'exemplo: parques, jardins, parques infantis, praias públicas, '
                'margens de rios e frentes de água',
    'grp_bus': 'Paragens de transporte de baixa capacidade (paragens de '
               'autocarro, de metro ligeiro)',
    'note_bus': 'Camada de pontos com a localização das paragens de autocarro '
                '/ metro ligeiro',
    'grp_rail': 'Paragens de transporte de alta capacidade (estações '
                'ferroviárias, de metro)',
    'note_rail': 'Camada de pontos com a localização das estações '
                 'ferroviárias / de metro',
    'grp_ferry': 'Paragens de transporte de alta capacidade (cais de ferry)',
    'note_ferry': 'Camada de pontos com a localização dos terminais de ferry',
    'grp_widths': 'Larguras medidas das vias (tabela CSV)',
    'note_widths': 'Utilizado para a área destinada às ruas. Coluna 1 = '
                   'categoria da via (associada ao campo de categoria da via '
                   'selecionado abaixo), coluna 2 = largura medida em metros. '
                   'Se não for fornecido nenhum CSV e não existir campo de '
                   'categoria, a área destinada às ruas = 0.',
    'btn_browse_csv': 'Procurar CSV...',
    'grp_catfield': 'Campo de categoria da via (camada de ruas)',
    'note_catfield': 'Campo da camada de ruas que contém as categorias das '
                     'vias, utilizado para juntar as larguras. \'fclass\', '
                     '\'highway\' ou \'type\' é selecionado automaticamente se '
                     'existir; caso contrário, escolha o campo aqui. Deixe vazio '
                     'para deteção automática.',
    'grp_crs': 'Sistema de referência de coordenadas de destino (projetado, '
               'em metros - p. ex. UTM da área urbana)',
    'dist_header': 'Limiar de distância na rede para:',
    'dist_pos': 'Espaços públicos abertos',
    'spacing_header': 'Espaçamento dos pontos no contorno dos espaços públicos '
                      'abertos:',
    'spacing_note': 'Pontos de partida colocados ao longo do contorno de cada '
                    'espaço aberto. 100 m é o valor padrão; um espaçamento '
                    'maior (p. ex. 200 m) é mais rápido em cidades com muitos '
                    'parques grandes, mas ligeiramente menos preciso.',
    'perf_header': 'Desempenho:',
    'chk_preclip': 'Recortar previamente os dados à área urbana',
    'note_preclip': 'Recomendado. Mantém apenas as ruas, paragens e espaços '
                    'abertos dentro da margem de pesquisa da área urbana - muito '
                    'mais rápido com dados de âmbito nacional ou regional.',
    'chk_memory': 'Manter as camadas intermédias em memória',
    'note_memory': 'Mais rápido. Desmarque apenas se o computador ficar sem '
                   'memória RAM.',
    'chk_native': 'Utilizar o algoritmo nativo de área de serviço do QGIS',
    'note_native': 'Apenas para verificação - muito lento com muitos pontos de '
                   'partida. Por predefinição é usada a pesquisa limitada rápida '
                   '(mesmos resultados).',
    'grp_city': 'Nome da cidade (dica: evite caracteres especiais)',
    'city_placeholder': 'p. ex. Mombasa',
    'lbl_output_folder': 'Pasta de resultados:',
    'btn_browse': 'Procurar...',
    'info_block':
        "Ficheiros finais conservados:\n"
        "  Áreas de abrangência recortadas e dissolvidas:\n"
        "  SA_POS_dissolved.shp                Espaços públicos abertos\n"
        "  SA_Bus_dissolved.shp                Paragens de baixa capacidade\n"
        "  SA_Ferry_dissolved.shp              Cais de ferry\n"
        "  SA_Rail_dissolved.shp               Estações ferroviárias\n"
        "  SA_HighCapacity_dissolved.shp       Alta capacidade (ferrovia + ferry)\n"
        "  SA_CombinedTransport_dissolved.shp  Transporte público combinado\n"
        "  Áreas de serviço individuais (por paragem):\n"
        "  SA_Bus_individual.shp / SA_Ferry_individual.shp / SA_Rail_individual.shp\n"
        "  ZonalStats_*.shp                    Área de abrangência + campo pop_sum\n"
        "  LAS_streets_dissolved.shp           Área destinada às ruas\n"
        "  {city}_statistics_11.2.1_and_11.7.1.xlsx\n\n"
        "NOTAS:\n"
        "  - As geometrias são corrigidas automaticamente antes do processamento.\n"
        "  - População: pontos dos agregados familiares (soma do campo de população)\n"
        "    se fornecidos; caso contrário, o raster de população em grelha.\n"
        "  - Área dos espaços públicos abertos medida após recorte ao limite urbano.\n"
        "  - Os dados são recortados à área urbana + margem de pesquisa e as\n"
        "    camadas intermédias mantidas em memória (ver separador Distâncias).\n"
        "  - Transporte combinado = paragens de baixa capacidade + ferry + ferrovia\n"
        "    (espaços públicos abertos excluídos).\n"
        "  - Área destinada às ruas: buffer das ruas segundo a largura,\n"
        "    dissolvido e recortado à extensão urbana.\n"
        "  - A tabela estatística é escrita no idioma selecionado.\n"
        "  - Use «Limpar registo» para reativar os botões após um erro.",
    'msg_running_title': 'Em execução',
    'msg_cannot_reset': 'Não é possível limpar enquanto a análise está em '
                        'execução. Cancele primeiro.',
    'msg_missing_layer': 'Camada em falta',
    'msg_select_streets': 'Selecione uma camada de ruas.',
    'msg_select_urban': 'Selecione uma camada de limite urbano.',
    'msg_missing_pop_title': 'Dados de população em falta',
    'msg_missing_pop': 'Selecione uma camada de população em grelha (raster) '
                       'ou uma camada de população dos agregados familiares '
                       '(pontos) - uma das duas é obrigatória.',
    'msg_missing_popfield_title': 'Campo de população em falta',
    'msg_missing_popfield': 'Selecione o campo com a população total da camada '
                            'de população dos agregados familiares (pontos).',
    'msg_missing_city_title': 'Nome da cidade em falta',
    'msg_missing_city': 'Introduza o nome da cidade.',
    'msg_missing_output_title': 'Pasta de resultados em falta',
    'msg_missing_output': 'Selecione uma pasta de resultados.',
    'msg_invalid_crs_title': 'SRC inválido',
    'msg_invalid_crs': 'Selecione um SRC de destino válido.',
    'msg_no_transport_title': 'Sem camadas de transporte',
    'msg_no_transport': 'Não foi selecionada nenhuma camada de espaços públicos '
                        'abertos / baixa capacidade / ferry / ferrovia. Serão '
                        'processadas apenas a área urbana e as ruas. Continuar?',
    'msg_complete': 'Concluído',
    'msg_error': 'Erro',
    'msg_failed': 'A análise falhou. Consulte o registo para mais detalhes.'
                  '\n\nClique em «Limpar registo» para recomeçar.',
    'msg_close_running': 'A análise ainda está em execução. Cancelar e fechar?',
    'msg_cancel_requested': 'Cancelamento solicitado...',
    'dlg_select_output': 'Selecionar a pasta de resultados',
    'dlg_select_csv': 'Selecionar o CSV das larguras medidas das vias',
    'csv_filter': 'Ficheiros CSV (*.csv *.txt);;Todos os ficheiros (*)',
    'msg_invalid_csv_title': 'CSV inválido',
    'msg_invalid_csv': 'Não foi possível ler:',
    'msg_widths_title': 'CSV das larguras das vias',
    'msg_widths_cols': 'A tabela de larguras das vias precisa de pelo menos '
                       'duas colunas (categoria da via, largura). Será ignorada.',
    'res_done': 'Concluído!',
    'res_las': 'Área destinada às ruas',
    'res_stats': 'Tabela estatística (CSV)',
    'res_excel': 'Livro estatístico (Excel)',
    'res_roads': 'Tabela das ruas',
    'res_folder': 'Pasta',
    'res_time': 'Tempo',
    'h_city': 'Cidade',
    'h_urban_area': 'Área urbana (km2)',
    'h_pos_area': 'Área dos espaços públicos abertos (km2)',
    'h_las': 'Área destinada às ruas (km2)',
    'h_ops_las': 'Espaços públicos abertos + área destinada às ruas (km2)',
    'h_prop_ops_las': 'Proporção da área urbana em espaços públicos abertos + '
                      'área destinada às ruas (%)',
    'h_total_pop': 'População urbana total',
    'h_pop_pos': 'População com acesso a espaços públicos abertos',
    'h_pop_bus': 'População com acesso a paragens de transporte de baixa '
                 'capacidade (paragens de autocarro, de metro ligeiro)',
    'h_pop_hc': 'População com acesso a transporte de alta capacidade '
                '(ferrovia + ferry)',
    'h_pop_comb': 'População com acesso ao transporte público combinado',
    'h_pct_pos': 'Percentagem da população com acesso a espaços públicos '
                 'abertos',
    'h_pct_bus': 'Percentagem da população com acesso a paragens de transporte '
                 'de baixa capacidade (paragens de autocarro, de metro ligeiro)',
    'h_pct_hc': 'Percentagem da população com acesso a transporte de alta '
                'capacidade',
    'h_pct_comb': 'Percentagem da população com acesso ao transporte público '
                  'combinado',
    'h_pop_source': 'Fonte dos dados de população',
    'src_household': 'Pontos dos agregados familiares',
    'src_raster': 'Raster em grelha',
    'src_field': 'campo',
}


# ---------------------------------------------------------- de: Deutsch
_EXTRA_TEXT['de'] = {
    'win_title': 'Berechnung der Statistiken zu SDG 11.2.1 und 11.7.1',
    'subtitle': 'Vorab-Zuschnitt auf das Stadtgebiet -> Umprojektion + '
                'Geometriekorrektur -> Zuschnitt der öffentlichen Freiflächen '
                '-> Randpunkte -> Einzugsbereich -> Konvexe Hülle -> Zuschnitt '
                '-> Auflösen -> Bevölkerung in den Einzugsgebieten -> Verknüpfung '
                'der Straßenbreiten -> Puffer -> Auflösen -> Zuschnitt '
                '(Straßenfläche) -> Statistiktabelle',
    'language': 'Sprache:',
    'tab_layers': 'Layer',
    'tab_distances': 'Entfernungen',
    'tab_output': 'Ausgabe',
    'progress': 'Fortschritt',
    'btn_run': 'Analyse starten',
    'btn_cancel': 'Abbrechen',
    'btn_reset': 'Protokoll leeren',
    'btn_close': 'Schließen',
    'grp_streets': 'Straßen',
    'note_streets': 'Straßen-Layer für die Routenberechnung im Netz',
    'grp_urban': 'Stadtgrenze',
    'note_urban': 'Polygon-Layer, der die Ausdehnung des Stadtgebiets festlegt',
    'grp_pop_raster': 'Gerasterte Bevölkerung (Raster)',
    'note_pop_raster': 'Gerasterter Bevölkerungsdatensatz. Geben Sie diesen ODER '
                       'die Haushaltsbevölkerung (Punkte) unten an - eines von '
                       'beiden ist erforderlich.',
    'grp_hh': 'Haushaltsbevölkerung (Punkte)',
    'note_hh': 'Punkt-Layer mit Einwohnerzahlen auf Haushaltsebene. Geben Sie '
               'diesen ODER das gerasterte Bevölkerungsraster an - eines von '
               'beiden ist erforderlich. Sind beide angegeben, werden die '
               'Haushaltspunkte verwendet. Bevölkerung je Einzugsgebiet = Summe '
               'des gewählten Feldes über die darin liegenden Punkte.',
    'lbl_pop_field': 'Feld mit der Gesamtbevölkerung (je Haushaltspunkt):',
    'grp_pos': 'Öffentliche Freiflächen (Polygone)',
    'note_pos': 'Polygon-Layer mit unbebauten oder offenen, öffentlich '
                'zugänglichen Flächen, die den Bewohnern Erholungsräume bieten '
                'und die Umweltqualität verbessern. Beispiele: Parks, Gärten, '
                'Spielplätze, öffentliche Strände, Flussufer und Uferpromenaden',
    'grp_bus': 'Haltestellen des Verkehrs mit geringer Kapazität '
               '(Bushaltestellen, Stadtbahnhaltestellen)',
    'note_bus': 'Punkt-Layer der Bus- / Stadtbahnhaltestellen',
    'grp_rail': 'Haltestellen des Verkehrs mit hoher Kapazität (Bahnhöfe, '
                'U-Bahn-Stationen)',
    'note_rail': 'Punkt-Layer der Bahnhöfe / U-Bahn-Stationen',
    'grp_ferry': 'Haltestellen des Verkehrs mit hoher Kapazität (Fähranleger)',
    'note_ferry': 'Punkt-Layer der Fährterminals',
    'grp_widths': 'Gemessene Straßenbreiten (CSV-Tabelle)',
    'note_widths': 'Wird für die Straßenfläche verwendet. Spalte 1 = '
                   'Straßenkategorie (abgeglichen mit dem unten gewählten Feld '
                   'der Straßenkategorie), Spalte 2 = gemessene Straßenbreite in '
                   'Metern. Wird keine CSV angegeben und ist kein Kategoriefeld '
                   'vorhanden, ist die Straßenfläche = 0.',
    'btn_browse_csv': 'CSV durchsuchen...',
    'grp_catfield': 'Feld der Straßenkategorie (Straßen-Layer)',
    'note_catfield': 'Feld des Straßen-Layers mit den Straßenkategorien, '
                     'verwendet zur Verknüpfung der Straßenbreiten. \'fclass\', '
                     '\'highway\' oder \'type\' wird automatisch gewählt, falls '
                     'vorhanden; andernfalls hier das Feld auswählen. Leer lassen '
                     'für die automatische Erkennung.',
    'grp_crs': 'Ziel-Koordinatenbezugssystem (projiziert, in Metern - z. B. '
               'UTM des Stadtgebiets)',
    'dist_header': 'Schwellenwert der Netzentfernung für:',
    'dist_pos': 'Öffentliche Freiflächen',
    'spacing_header': 'Abstand der Randpunkte der öffentlichen Freiflächen:',
    'spacing_note': 'Startpunkte entlang des Umrisses jeder Freifläche. 100 m '
                    'ist der Standard; ein größerer Abstand (z. B. 200 m) ist '
                    'bei Städten mit vielen großen Parks schneller, aber etwas '
                    'ungenauer.',
    'perf_header': 'Leistung:',
    'chk_preclip': 'Eingabedaten vorab auf das Stadtgebiet zuschneiden',
    'note_preclip': 'Empfohlen. Behält nur Straßen, Haltestellen und '
                    'Freiflächen innerhalb des Suchrands um das Stadtgebiet - '
                    'deutlich schneller bei landes- oder regionsweiten Daten.',
    'chk_memory': 'Zwischen-Layer im Arbeitsspeicher halten',
    'note_memory': 'Schneller. Nur deaktivieren, wenn der Arbeitsspeicher des '
                   'Computers nicht ausreicht.',
    'chk_native': 'Native QGIS-Einzugsbereichsberechnung verwenden',
    'note_native': 'Nur zur Kontrolle - sehr langsam bei vielen Startpunkten. '
                   'Standard ist die schnelle begrenzte Suche (gleiche '
                   'Ergebnisse).',
    'grp_city': 'Name der Stadt (Hinweis: Sonderzeichen vermeiden)',
    'city_placeholder': 'z. B. Mombasa',
    'lbl_output_folder': 'Ausgabeordner:',
    'btn_browse': 'Durchsuchen...',
    'info_block':
        "Beibehaltene Ergebnisdateien:\n"
        "  Zugeschnittene und aufgelöste Einzugsgebiete:\n"
        "  SA_POS_dissolved.shp                Öffentliche Freiflächen\n"
        "  SA_Bus_dissolved.shp                Haltestellen mit geringer Kapazität\n"
        "  SA_Ferry_dissolved.shp              Fähranleger\n"
        "  SA_Rail_dissolved.shp               Bahnhöfe\n"
        "  SA_HighCapacity_dissolved.shp       Hohe Kapazität (Bahn + Fähre)\n"
        "  SA_CombinedTransport_dissolved.shp  Öffentlicher Verkehr gesamt\n"
        "  Einzelne Einzugsbereiche (je Haltestelle):\n"
        "  SA_Bus_individual.shp / SA_Ferry_individual.shp / SA_Rail_individual.shp\n"
        "  ZonalStats_*.shp                    Einzugsgebiet + Feld pop_sum\n"
        "  LAS_streets_dissolved.shp           Straßenfläche\n"
        "  {city}_statistics_11.2.1_and_11.7.1.xlsx\n\n"
        "HINWEISE:\n"
        "  - Geometrien werden vor der Verarbeitung automatisch korrigiert.\n"
        "  - Bevölkerung: Haushaltspunkte (Summe des Bevölkerungsfeldes),\n"
        "    falls angegeben, sonst das gerasterte Bevölkerungsraster.\n"
        "  - Fläche der Freiflächen nach Zuschnitt auf die Stadtgrenze gemessen.\n"
        "  - Eingabedaten werden auf Stadtgebiet + Suchrand zugeschnitten und\n"
        "    Zwischen-Layer im Speicher gehalten (siehe Reiter Entfernungen).\n"
        "  - Öffentlicher Verkehr gesamt = geringe Kapazität + Fähre + Bahn\n"
        "    (ohne öffentliche Freiflächen).\n"
        "  - Straßenfläche: Straßen nach Breite gepuffert, aufgelöst und\n"
        "    auf das Stadtgebiet zugeschnitten.\n"
        "  - Die Statistiktabelle wird in der gewählten Sprache geschrieben.\n"
        "  - Nach einem Fehler mit „Protokoll leeren“ die Schaltflächen reaktivieren.",
    'msg_running_title': 'Läuft',
    'msg_cannot_reset': 'Leeren nicht möglich, solange die Analyse läuft. '
                        'Bitte zuerst abbrechen.',
    'msg_missing_layer': 'Fehlender Layer',
    'msg_select_streets': 'Bitte einen Straßen-Layer auswählen.',
    'msg_select_urban': 'Bitte einen Layer der Stadtgrenze auswählen.',
    'msg_missing_pop_title': 'Fehlende Bevölkerungsdaten',
    'msg_missing_pop': 'Bitte einen Layer der gerasterten Bevölkerung (Raster) '
                       'oder der Haushaltsbevölkerung (Punkte) auswählen - einer '
                       'von beiden ist erforderlich.',
    'msg_missing_popfield_title': 'Fehlendes Bevölkerungsfeld',
    'msg_missing_popfield': 'Bitte das Feld mit der Gesamtbevölkerung für den '
                            'Layer der Haushaltsbevölkerung (Punkte) auswählen.',
    'msg_missing_city_title': 'Fehlender Stadtname',
    'msg_missing_city': 'Bitte einen Stadtnamen eingeben.',
    'msg_missing_output_title': 'Fehlender Ausgabeordner',
    'msg_missing_output': 'Bitte einen Ausgabeordner auswählen.',
    'msg_invalid_crs_title': 'Ungültiges KBS',
    'msg_invalid_crs': 'Bitte ein gültiges Ziel-KBS auswählen.',
    'msg_no_transport_title': 'Keine Verkehrs-Layer',
    'msg_no_transport': 'Kein Layer für öffentliche Freiflächen / geringe '
                        'Kapazität / Fähre / Bahn ausgewählt. Es werden nur '
                        'Stadtgebiet und Straßen verarbeitet. Fortfahren?',
    'msg_complete': 'Abgeschlossen',
    'msg_error': 'Fehler',
    'msg_failed': 'Die Analyse ist fehlgeschlagen. Details im Protokoll.'
                  '\n\nKlicken Sie auf „Protokoll leeren“ und starten Sie neu.',
    'msg_close_running': 'Die Analyse läuft noch. Abbrechen und schließen?',
    'msg_cancel_requested': 'Abbruch angefordert...',
    'dlg_select_output': 'Ausgabeordner auswählen',
    'dlg_select_csv': 'CSV mit gemessenen Straßenbreiten auswählen',
    'csv_filter': 'CSV-Dateien (*.csv *.txt);;Alle Dateien (*)',
    'msg_invalid_csv_title': 'Ungültige CSV',
    'msg_invalid_csv': 'Konnte nicht gelesen werden:',
    'msg_widths_title': 'CSV der Straßenbreiten',
    'msg_widths_cols': 'Die Tabelle der Straßenbreiten benötigt mindestens zwei '
                       'Spalten (Straßenkategorie, Breite). Sie wird ignoriert.',
    'res_done': 'Fertig!',
    'res_las': 'Straßenfläche',
    'res_stats': 'Statistiktabelle (CSV)',
    'res_excel': 'Statistik-Arbeitsmappe (Excel)',
    'res_roads': 'Straßentabelle',
    'res_folder': 'Ordner',
    'res_time': 'Dauer',
    'h_city': 'Stadt',
    'h_urban_area': 'Stadtfläche (km2)',
    'h_pos_area': 'Fläche der öffentlichen Freiflächen (km2)',
    'h_las': 'Straßenfläche (km2)',
    'h_ops_las': 'Öffentliche Freiflächen + Straßenfläche (km2)',
    'h_prop_ops_las': 'Anteil der Stadtfläche an öffentlichen Freiflächen + '
                      'Straßenfläche (%)',
    'h_total_pop': 'Städtische Gesamtbevölkerung',
    'h_pop_pos': 'Bevölkerung mit Zugang zu öffentlichen Freiflächen',
    'h_pop_bus': 'Bevölkerung mit Zugang zu Haltestellen des Verkehrs mit '
                 'geringer Kapazität (Bushaltestellen, Stadtbahnhaltestellen)',
    'h_pop_hc': 'Bevölkerung mit Zugang zu Verkehr mit hoher Kapazität (Bahn + '
                'Fähre)',
    'h_pop_comb': 'Bevölkerung mit Zugang zum öffentlichen Verkehr gesamt',
    'h_pct_pos': 'Anteil der Bevölkerung mit Zugang zu öffentlichen '
                 'Freiflächen (%)',
    'h_pct_bus': 'Anteil der Bevölkerung mit Zugang zu Haltestellen des '
                 'Verkehrs mit geringer Kapazität (Bushaltestellen, '
                 'Stadtbahnhaltestellen) (%)',
    'h_pct_hc': 'Anteil der Bevölkerung mit Zugang zu Verkehr mit hoher '
                'Kapazität (%)',
    'h_pct_comb': 'Anteil der Bevölkerung mit Zugang zum öffentlichen Verkehr '
                  'gesamt (%)',
    'h_pop_source': 'Quelle der Bevölkerungsdaten',
    'src_household': 'Haushaltspunkte',
    'src_raster': 'Bevölkerungsraster',
    'src_field': 'Feld',
}


# ---------------------------------------------------------- ru: Русский
_EXTRA_TEXT['ru'] = {
    'win_title': 'Расчёт статистики ЦУР 11.2.1 и 11.7.1',
    'subtitle': 'Предварительная обрезка по городской территории -> '
                'Перепроецирование + исправление геометрии -> Обрезка открытых '
                'общественных пространств -> Точки контура -> Зона обслуживания '
                '-> Выпуклая оболочка -> Обрезка -> Слияние -> Население зон '
                'доступности -> Присоединение ширины улиц -> Буфер -> Слияние -> '
                'Обрезка (территория под улицами) -> Статистическая таблица',
    'language': 'Язык:',
    'tab_layers': 'Слои',
    'tab_distances': 'Расстояния',
    'tab_output': 'Результаты',
    'progress': 'Ход выполнения',
    'btn_run': 'Запустить анализ',
    'btn_cancel': 'Отмена',
    'btn_reset': 'Очистить журнал',
    'btn_close': 'Закрыть',
    'grp_streets': 'Улицы',
    'note_streets': 'Слой улиц для построения маршрутов по сети',
    'grp_urban': 'Граница города',
    'note_urban': 'Полигональный слой, задающий границы городской территории',
    'grp_pop_raster': 'Сеточные данные о населении (растр)',
    'note_pop_raster': 'Сеточный набор данных о населении. Укажите его ИЛИ '
                       'население домохозяйств (точки) ниже - одно из двух '
                       'обязательно.',
    'grp_hh': 'Население домохозяйств (точки)',
    'note_hh': 'Точечный слой с численностью населения на уровне домохозяйств. '
               'Укажите его ИЛИ растр сеточного населения - одно из двух '
               'обязательно. Если указаны оба, используются точки '
               'домохозяйств. Население каждой зоны доступности = сумма '
               'выбранного поля по точкам внутри неё.',
    'lbl_pop_field': 'Поле с общей численностью населения (для каждой точки '
                     'домохозяйства):',
    'grp_pos': 'Открытые общественные пространства (полигоны)',
    'note_pos': 'Полигональные слои незастроенных или открытых территорий, '
                'доступных для всех, которые служат местами отдыха жителей и '
                'улучшают качество окружающей среды. Например: парки, сады, '
                'детские площадки, общественные пляжи, берега рек и набережные',
    'grp_bus': 'Остановки транспорта малой вместимости (автобусные остановки, '
               'остановки лёгкого рельсового транспорта)',
    'note_bus': 'Точечный слой автобусных остановок / остановок лёгкого '
                'рельсового транспорта',
    'grp_rail': 'Остановки транспорта большой вместимости (железнодорожные '
                'станции, станции метро)',
    'note_rail': 'Точечный слой железнодорожных станций / станций метро',
    'grp_ferry': 'Остановки транспорта большой вместимости (паромные причалы)',
    'note_ferry': 'Точечный слой паромных терминалов',
    'grp_widths': 'Измеренная ширина улиц (таблица CSV)',
    'note_widths': 'Используется для расчёта территории под улицами. Столбец 1 '
                   '= категория дороги (сопоставляется с выбранным ниже полем '
                   'категории дороги), столбец 2 = измеренная ширина в метрах. '
                   'Если CSV не указан и поле категории отсутствует, территория '
                   'под улицами = 0.',
    'btn_browse_csv': 'Выбрать CSV...',
    'grp_catfield': 'Поле категории дороги (слой улиц)',
    'note_catfield': 'Поле слоя улиц с категориями дорог, используемое для '
                     'присоединения ширины. Поле \'fclass\', \'highway\' или '
                     '\'type\' выбирается автоматически при наличии; иначе '
                     'выберите поле здесь. Оставьте пустым для автоопределения.',
    'grp_crs': 'Целевая система координат (проекционная, в метрах - например, '
               'зона UTM городской территории)',
    'dist_header': 'Пороговое сетевое расстояние для:',
    'dist_pos': 'Открытые общественные пространства',
    'spacing_header': 'Шаг точек по контуру открытых общественных пространств:',
    'spacing_note': 'Начальные точки, размещаемые вдоль контура каждого '
                    'открытого пространства. Стандартное значение - 100 м; '
                    'больший шаг (например, 200 м) ускоряет расчёт для городов '
                    'с большим числом крупных парков, но немного снижает '
                    'точность.',
    'perf_header': 'Производительность:',
    'chk_preclip': 'Предварительно обрезать данные по городской территории',
    'note_preclip': 'Рекомендуется. Сохраняются только улицы, остановки и '
                    'открытые пространства в пределах зоны поиска вокруг города '
                    '- намного быстрее при работе с данными на уровне страны '
                    'или региона.',
    'chk_memory': 'Хранить промежуточные слои в памяти',
    'note_memory': 'Быстрее. Снимите флажок, только если компьютеру не хватает '
                   'оперативной памяти.',
    'chk_native': 'Использовать встроенный алгоритм зоны обслуживания QGIS',
    'note_native': 'Только для проверки - очень медленно при большом числе '
                   'начальных точек. По умолчанию используется быстрый '
                   'ограниченный поиск (те же результаты).',
    'grp_city': 'Название города (совет: избегайте специальных символов)',
    'city_placeholder': 'например, Mombasa',
    'lbl_output_folder': 'Папка результатов:',
    'btn_browse': 'Обзор...',
    'info_block':
        "Сохраняемые итоговые файлы:\n"
        "  Обрезанные и объединённые зоны доступности:\n"
        "  SA_POS_dissolved.shp                Открытые общественные пространства\n"
        "  SA_Bus_dissolved.shp                Остановки малой вместимости\n"
        "  SA_Ferry_dissolved.shp              Паромные причалы\n"
        "  SA_Rail_dissolved.shp               Железнодорожные станции\n"
        "  SA_HighCapacity_dissolved.shp       Большая вместимость (ж/д + паром)\n"
        "  SA_CombinedTransport_dissolved.shp  Общественный транспорт в целом\n"
        "  Отдельные зоны обслуживания (по остановкам):\n"
        "  SA_Bus_individual.shp / SA_Ferry_individual.shp / SA_Rail_individual.shp\n"
        "  ZonalStats_*.shp                    Зона доступности + поле pop_sum\n"
        "  LAS_streets_dissolved.shp           Территория под улицами\n"
        "  {city}_statistics_11.2.1_and_11.7.1.xlsx\n\n"
        "ПРИМЕЧАНИЯ:\n"
        "  - Геометрия автоматически исправляется перед обработкой.\n"
        "  - Население: точки домохозяйств (сумма поля населения), если указаны,\n"
        "    иначе растр сеточного населения.\n"
        "  - Площадь открытых пространств измеряется после обрезки по границе города.\n"
        "  - Данные обрезаются по городу + зоне поиска, промежуточные слои\n"
        "    хранятся в памяти (см. вкладку «Расстояния»).\n"
        "  - Общественный транспорт в целом = малая вместимость + паром + ж/д\n"
        "    (без открытых общественных пространств).\n"
        "  - Территория под улицами: буфер улиц по их ширине, объединённый\n"
        "    и обрезанный по городской территории.\n"
        "  - Статистическая таблица создаётся на выбранном языке.\n"
        "  - После ошибки нажмите «Очистить журнал», чтобы снова включить кнопки.",
    'msg_running_title': 'Выполняется',
    'msg_cannot_reset': 'Невозможно очистить во время анализа. Сначала '
                        'отмените его.',
    'msg_missing_layer': 'Отсутствует слой',
    'msg_select_streets': 'Выберите слой улиц.',
    'msg_select_urban': 'Выберите слой границы города.',
    'msg_missing_pop_title': 'Отсутствуют данные о населении',
    'msg_missing_pop': 'Выберите слой сеточного населения (растр) или слой '
                       'населения домохозяйств (точки) - один из них '
                       'обязателен.',
    'msg_missing_popfield_title': 'Отсутствует поле населения',
    'msg_missing_popfield': 'Выберите поле с общей численностью населения для '
                            'слоя населения домохозяйств (точки).',
    'msg_missing_city_title': 'Не указано название города',
    'msg_missing_city': 'Введите название города.',
    'msg_missing_output_title': 'Не указана папка результатов',
    'msg_missing_output': 'Выберите папку для результатов.',
    'msg_invalid_crs_title': 'Недопустимая система координат',
    'msg_invalid_crs': 'Выберите допустимую целевую систему координат.',
    'msg_no_transport_title': 'Нет транспортных слоёв',
    'msg_no_transport': 'Не выбраны слои открытых общественных пространств / '
                        'малой вместимости / паромов / железной дороги. Будут '
                        'обработаны только городская территория и улицы. '
                        'Продолжить?',
    'msg_complete': 'Готово',
    'msg_error': 'Ошибка',
    'msg_failed': 'Анализ завершился с ошибкой. Подробности в журнале.'
                  '\n\nНажмите «Очистить журнал» и запустите снова.',
    'msg_close_running': 'Анализ ещё выполняется. Отменить и закрыть?',
    'msg_cancel_requested': 'Запрошена отмена...',
    'dlg_select_output': 'Выберите папку результатов',
    'dlg_select_csv': 'Выберите CSV с измеренной шириной улиц',
    'csv_filter': 'Файлы CSV (*.csv *.txt);;Все файлы (*)',
    'msg_invalid_csv_title': 'Недопустимый CSV',
    'msg_invalid_csv': 'Не удалось прочитать:',
    'msg_widths_title': 'CSV ширины улиц',
    'msg_widths_cols': 'Таблица ширины улиц должна содержать не менее двух '
                       'столбцов (категория дороги, ширина). Она будет '
                       'проигнорирована.',
    'res_done': 'Готово!',
    'res_las': 'Территория под улицами',
    'res_stats': 'Статистическая таблица (CSV)',
    'res_excel': 'Статистическая книга (Excel)',
    'res_roads': 'Таблица улиц',
    'res_folder': 'Папка',
    'res_time': 'Время',
    'h_city': 'Город',
    'h_urban_area': 'Площадь городской территории (км2)',
    'h_pos_area': 'Площадь открытых общественных пространств (км2)',
    'h_las': 'Территория под улицами (км2)',
    'h_ops_las': 'Открытые общественные пространства + территория под улицами '
                 '(км2)',
    'h_prop_ops_las': 'Доля городской территории, занятая открытыми '
                      'общественными пространствами и улицами (%)',
    'h_total_pop': 'Общая численность городского населения',
    'h_pop_pos': 'Население с доступом к открытым общественным пространствам',
    'h_pop_bus': 'Население с доступом к остановкам транспорта малой '
                 'вместимости (автобусные остановки, остановки лёгкого '
                 'рельсового транспорта)',
    'h_pop_hc': 'Население с доступом к транспорту большой вместимости (ж/д + '
                'паром)',
    'h_pop_comb': 'Население с доступом к общественному транспорту в целом',
    'h_pct_pos': 'Доля населения с доступом к открытым общественным '
                 'пространствам (%)',
    'h_pct_bus': 'Доля населения с доступом к остановкам транспорта малой '
                 'вместимости (автобусные остановки, остановки лёгкого '
                 'рельсового транспорта) (%)',
    'h_pct_hc': 'Доля населения с доступом к транспорту большой вместимости '
                '(%)',
    'h_pct_comb': 'Доля населения с доступом к общественному транспорту в '
                  'целом (%)',
    'h_pop_source': 'Источник данных о населении',
    'src_household': 'Точки домохозяйств',
    'src_raster': 'Сеточный растр',
    'src_field': 'поле',
}


# ---------------------------------------------------------- ja: 日本語
_EXTRA_TEXT['ja'] = {
    'win_title': 'SDG 11.2.1 および 11.7.1 統計計算',
    'subtitle': '市街地への事前クリップ -> 再投影 + ジオメトリ修正 -> 公共オープン'
                'スペースのクリップ -> 境界ポイント -> サービスエリア -> 凸包 -> '
                'クリップ -> ディゾルブ -> 圏域内人口 -> 道路幅員の結合 -> バッファ '
                '-> ディゾルブ -> クリップ（道路用地） -> 統計表',
    'language': '言語：',
    'tab_layers': 'レイヤ',
    'tab_distances': '距離',
    'tab_output': '出力',
    'progress': '進行状況',
    'btn_run': '解析を実行',
    'btn_cancel': 'キャンセル',
    'btn_reset': 'ログを消去',
    'btn_close': '閉じる',
    'grp_streets': '道路',
    'note_streets': 'ネットワーク経路探索に使用する道路レイヤ',
    'grp_urban': '市街地境界',
    'note_urban': '市街地の範囲を定めるポリゴンレイヤ',
    'grp_pop_raster': 'グリッド人口（ラスタ）',
    'note_pop_raster': 'グリッド人口データセット。これか下の「世帯人口（ポイント）」の'
                       'いずれかを指定してください（どちらか一方が必須）。',
    'grp_hh': '世帯人口（ポイント）',
    'note_hh': '世帯単位の人口を持つポイントレイヤ。これかグリッド人口ラスタのいずれか'
               'を指定してください（どちらか一方が必須）。両方を指定した場合は世帯'
               'ポイントを使用します。各圏域の人口 = 圏域内ポイントの選択フィールドの'
               '合計。',
    'lbl_pop_field': '総人口を格納したフィールド（世帯ポイントごと）：',
    'grp_pos': '公共オープンスペース（ポリゴン）',
    'note_pos': '一般に開放された未開発地またはオープンな土地を表すポリゴンレイヤ。'
                '住民に憩いの場を提供し、環境の質を高めます。例：公園、庭園、遊び場、'
                '公共の海岸、河川敷、水辺空間',
    'grp_bus': '低輸送力の公共交通停留所（バス停、ライトレール停留所）',
    'note_bus': 'バス停／ライトレール停留所の位置を示すポイントレイヤ',
    'grp_rail': '高輸送力の公共交通駅（鉄道駅、地下鉄駅）',
    'note_rail': '鉄道駅／地下鉄駅の位置を示すポイントレイヤ',
    'grp_ferry': '高輸送力の公共交通（フェリー乗り場）',
    'note_ferry': 'フェリーターミナルの位置を示すポイントレイヤ',
    'grp_widths': '実測道路幅員（CSV 表）',
    'note_widths': '道路用地の計算に使用します。1 列目 = 道路種別（下で選択する道路'
                   '種別フィールドと照合）、2 列目 = 実測幅員（メートル）。CSV が'
                   '指定されず道路種別フィールドもない場合、道路用地 = 0。',
    'btn_browse_csv': 'CSV を参照...',
    'grp_catfield': '道路種別フィールド（道路レイヤ）',
    'note_catfield': '道路種別を格納した道路レイヤのフィールドで、幅員の結合に使用'
                     'します。「fclass」「highway」「type」があれば自動で選択されます。'
                     'ない場合はここで選択してください。空欄のままにすると自動検出します。',
    'grp_crs': '出力座標参照系（投影座標系、単位メートル。例：市街地の UTM 帯）',
    'dist_header': 'ネットワーク距離のしきい値：',
    'dist_pos': '公共オープンスペース',
    'spacing_header': '公共オープンスペース境界ポイントの間隔：',
    'spacing_note': '各オープンスペースの輪郭に沿って配置する起点。標準は 100 m です。'
                    '大きな公園が多い都市では間隔を広げる（例：200 m）と速くなりますが、'
                    '精度はやや下がります。',
    'perf_header': 'パフォーマンス：',
    'chk_preclip': '入力データを市街地へ事前にクリップする',
    'note_preclip': '推奨。市街地の探索範囲内にある道路・停留所・オープンスペースのみを'
                    '残します。国・地域単位のデータでは大幅に高速になります。',
    'chk_memory': '中間レイヤをメモリに保持する',
    'note_memory': '高速です。コンピュータのメモリが不足する場合のみオフにしてください。',
    'chk_native': 'QGIS 標準のサービスエリアアルゴリズムを使用する',
    'note_native': '検証用のみ。起点が多いと非常に遅くなります。既定は高速な範囲限定'
                   '探索です（結果は同じ）。',
    'grp_city': '都市名（ヒント：特殊文字は避けてください）',
    'city_placeholder': '例：Mombasa',
    'lbl_output_folder': '出力フォルダ：',
    'btn_browse': '参照...',
    'info_block':
        "保存される最終ファイル：\n"
        "  クリップ・ディゾルブ済みの圏域：\n"
        "  SA_POS_dissolved.shp                公共オープンスペース\n"
        "  SA_Bus_dissolved.shp                低輸送力の停留所\n"
        "  SA_Ferry_dissolved.shp              フェリー乗り場\n"
        "  SA_Rail_dissolved.shp               鉄道駅\n"
        "  SA_HighCapacity_dissolved.shp       高輸送力（鉄道 + フェリー）\n"
        "  SA_CombinedTransport_dissolved.shp  公共交通全体\n"
        "  個別（停留所ごと）のサービスエリア：\n"
        "  SA_Bus_individual.shp / SA_Ferry_individual.shp / SA_Rail_individual.shp\n"
        "  ZonalStats_*.shp                    圏域 + pop_sum フィールド\n"
        "  LAS_streets_dissolved.shp           道路用地\n"
        "  {city}_statistics_11.2.1_and_11.7.1.xlsx\n\n"
        "注記：\n"
        "  - 処理前にジオメトリを自動修正します。\n"
        "  - 人口：世帯ポイントがあればその人口フィールドの合計、\n"
        "    なければグリッド人口ラスタを使用します。\n"
        "  - 公共オープンスペースの面積は市街地境界でクリップした後に計測します。\n"
        "  - 入力は市街地 + 探索範囲へ事前クリップし、中間レイヤは\n"
        "    メモリに保持します（「距離」タブで変更可）。\n"
        "  - 公共交通全体 = 低輸送力の停留所 + フェリー + 鉄道\n"
        "    （公共オープンスペースは含まない）。\n"
        "  - 道路用地：幅員に応じて道路にバッファを作成し、ディゾルブして\n"
        "    市街地範囲でクリップします。\n"
        "  - 統計表は選択した言語で出力されます。\n"
        "  - 失敗した場合は「ログを消去」でボタンを再度有効にします。",
    'msg_running_title': '実行中',
    'msg_cannot_reset': '解析の実行中は消去できません。先にキャンセルしてください。',
    'msg_missing_layer': 'レイヤがありません',
    'msg_select_streets': '道路レイヤを選択してください。',
    'msg_select_urban': '市街地境界レイヤを選択してください。',
    'msg_missing_pop_title': '人口データがありません',
    'msg_missing_pop': 'グリッド人口（ラスタ）レイヤまたは世帯人口（ポイント）レイヤを'
                       '選択してください（どちらか一方が必須）。',
    'msg_missing_popfield_title': '人口フィールドがありません',
    'msg_missing_popfield': '世帯人口（ポイント）レイヤの総人口フィールドを選択して'
                            'ください。',
    'msg_missing_city_title': '都市名がありません',
    'msg_missing_city': '都市名を入力してください。',
    'msg_missing_output_title': '出力先がありません',
    'msg_missing_output': '出力フォルダを選択してください。',
    'msg_invalid_crs_title': '座標参照系が無効です',
    'msg_invalid_crs': '有効な出力座標参照系を選択してください。',
    'msg_no_transport_title': '交通レイヤがありません',
    'msg_no_transport': '公共オープンスペース／低輸送力／フェリー／鉄道のレイヤが選択'
                        'されていません。市街地と道路のみを処理します。続行しますか？',
    'msg_complete': '完了',
    'msg_error': 'エラー',
    'msg_failed': '解析に失敗しました。詳細はログを確認してください。\n\n'
                  '「ログを消去」をクリックしてから再実行してください。',
    'msg_close_running': '解析はまだ実行中です。キャンセルして閉じますか？',
    'msg_cancel_requested': 'キャンセルを要求しました...',
    'dlg_select_output': '出力フォルダを選択',
    'dlg_select_csv': '実測道路幅員の CSV を選択',
    'csv_filter': 'CSV ファイル (*.csv *.txt);;すべてのファイル (*)',
    'msg_invalid_csv_title': 'CSV が無効です',
    'msg_invalid_csv': '読み込めませんでした：',
    'msg_widths_title': '道路幅員 CSV',
    'msg_widths_cols': '道路幅員の表には少なくとも 2 列（道路種別、幅員）が必要です。'
                       'この表は無視されます。',
    'res_done': '完了しました！',
    'res_las': '道路用地',
    'res_stats': '統計表（CSV）',
    'res_excel': '統計ブック（Excel）',
    'res_roads': '道路表',
    'res_folder': 'フォルダ',
    'res_time': '所要時間',
    'h_city': '都市',
    'h_urban_area': '市街地面積（km2）',
    'h_pos_area': '公共オープンスペース面積（km2）',
    'h_las': '道路用地（km2）',
    'h_ops_las': '公共オープンスペース + 道路用地（km2）',
    'h_prop_ops_las': '市街地面積に占める公共オープンスペース + 道路用地の割合（%）',
    'h_total_pop': '都市総人口',
    'h_pop_pos': '公共オープンスペースにアクセスできる人口',
    'h_pop_bus': '低輸送力の公共交通停留所（バス停、ライトレール停留所）にアクセス'
                 'できる人口',
    'h_pop_hc': '高輸送力の公共交通（鉄道 + フェリー）にアクセスできる人口',
    'h_pop_comb': '公共交通全体にアクセスできる人口',
    'h_pct_pos': '公共オープンスペースにアクセスできる人口の割合（%）',
    'h_pct_bus': '低輸送力の公共交通停留所（バス停、ライトレール停留所）にアクセス'
                 'できる人口の割合（%）',
    'h_pct_hc': '高輸送力の公共交通にアクセスできる人口の割合（%）',
    'h_pct_comb': '公共交通全体にアクセスできる人口の割合（%）',
    'h_pop_source': '人口データの出典',
    'src_household': '世帯ポイント',
    'src_raster': 'グリッドラスタ',
    'src_field': 'フィールド',
}


# ---------------------------------------------------------- sw: Kiswahili
_EXTRA_TEXT['sw'] = {
    'win_title': 'Ukokotoaji wa Takwimu za SDG 11.2.1 na 11.7.1',
    'subtitle': 'Kukata awali kwa Eneo la Mjini -> Kubadilisha mfumo wa ramani + '
                'Kurekebisha jiometri -> Kukata Maeneo ya Wazi ya Umma -> Nukta za '
                'Mipaka -> Eneo la Huduma -> Ganda Mbonyeo -> Kukata -> Kuunganisha '
                '-> Idadi ya Watu katika Maeneo ya Huduma -> Kuunganisha Upana wa '
                'Barabara -> Bafa -> Kuunganisha -> Kukata (Ardhi Iliyotengwa kwa '
                'Barabara) -> Jedwali la Takwimu',
    'language': 'Lugha:',
    'tab_layers': 'Tabaka',
    'tab_distances': 'Umbali',
    'tab_output': 'Matokeo',
    'progress': 'Maendeleo',
    'btn_run': 'Endesha Uchambuzi',
    'btn_cancel': 'Ghairi',
    'btn_reset': 'Futa Kumbukumbu',
    'btn_close': 'Funga',
    'grp_streets': 'Barabara',
    'note_streets': 'Tabaka la barabara linalotumika kutafuta njia kwenye mtandao',
    'grp_urban': 'Mpaka wa Mji',
    'note_urban': 'Tabaka la poligoni linaloonyesha ukubwa wa eneo la mjini',
    'grp_pop_raster': 'Idadi ya Watu kwa Gridi (Rasta)',
    'note_pop_raster': 'Seti ya data ya idadi ya watu kwa gridi. Toa hii AU Idadi ya '
                       'Watu wa Kaya (Nukta) hapa chini - mojawapo inahitajika.',
    'grp_hh': 'Idadi ya Watu wa Kaya (Nukta)',
    'note_hh': 'Tabaka la nukta lenye idadi ya watu katika ngazi ya kaya. Toa hii AU '
               'rasta ya Idadi ya Watu kwa Gridi - mojawapo inahitajika. Zikitolewa '
               'zote mbili, nukta za kaya zitatumika. Idadi ya watu katika kila eneo '
               'la huduma = jumla ya sehemu iliyochaguliwa kwa nukta zilizo ndani '
               'yake.',
    'lbl_pop_field': 'Sehemu yenye jumla ya idadi ya watu (kwa kila nukta ya kaya):',
    'grp_pos': 'Maeneo ya Wazi ya Umma (Poligoni)',
    'note_pos': 'Tabaka za poligoni zinazowakilisha ardhi isiyoendelezwa au ya wazi '
                'inayofikiwa na umma, inayotoa maeneo ya burudani kwa wakazi na '
                'kuboresha ubora wa mazingira. Mifano ni pamoja na bustani za umma, '
                'bustani, viwanja vya michezo ya watoto, fukwe za umma, kingo za mito '
                'na kando za maji',
    'grp_bus': 'Vituo vya Usafiri vya Uwezo Mdogo (Vituo vya Basi, Vituo vya Reli '
               'Nyepesi)',
    'note_bus': 'Tabaka la nukta la mahali vilipo vituo vya basi / reli nyepesi',
    'grp_rail': 'Vituo vya Usafiri vya Uwezo Mkubwa (Vituo vya Reli, Vituo vya Metro)',
    'note_rail': 'Tabaka la nukta la mahali vilipo vituo vya reli/metro',
    'grp_ferry': 'Vituo vya Usafiri vya Uwezo Mkubwa (Vituo vya Vivuko)',
    'note_ferry': 'Tabaka la nukta la mahali vilipo vituo vya vivuko',
    'grp_widths': 'Upana wa Barabara Uliopimwa (jedwali la CSV)',
    'note_widths': 'Hutumika kwa Ardhi Iliyotengwa kwa Barabara. Safu ya 1 = aina ya '
                   'barabara (inalinganishwa na Sehemu ya Aina ya Barabara '
                   'iliyochaguliwa hapa chini), safu ya 2 = upana wa barabara '
                   'uliopimwa kwa mita. Ikiwa hakuna CSV na hakuna sehemu ya aina ya '
                   'barabara, Ardhi Iliyotengwa kwa Barabara = 0.',
    'btn_browse_csv': 'Chagua CSV...',
    'grp_catfield': 'Sehemu ya Aina ya Barabara (kutoka tabaka la Barabara)',
    'note_catfield': "Sehemu ya tabaka la Barabara yenye aina za barabara, "
                     "inayotumika kuunganisha upana wa barabara. 'fclass', "
                     "'highway' au 'type' huchaguliwa kiotomatiki ikiwepo; vinginevyo "
                     "chagua sehemu hapa. Acha wazi ili itambuliwe kiotomatiki.",
    'grp_crs': 'Mfumo Lengwa wa Marejeleo ya Kuratibu (Uliopangwa, Mita - mf. UTM '
               'kwa eneo la mjini)',
    'dist_header': 'Kiwango cha umbali wa mtandao kwa:',
    'dist_pos': 'Maeneo ya Wazi ya Umma',
    'spacing_header': 'Nafasi kati ya nukta za mpaka wa Maeneo ya Wazi ya Umma:',
    'spacing_note': 'Nukta za kuanzia zinazowekwa kando ya mpaka wa kila eneo la wazi. '
                    'Mita 100 ndicho kiwango cha kawaida; nafasi kubwa zaidi (mf. '
                    'mita 200) ni ya haraka zaidi kwa miji yenye bustani nyingi '
                    'kubwa lakini haina usahihi sana.',
    'perf_header': 'Utendaji:',
    'chk_preclip': 'Kata awali data ya kuingiza kwa eneo la mjini',
    'note_preclip': 'Inapendekezwa. Huhifadhi barabara, vituo na maeneo ya wazi '
                    'yaliyo ndani ya ukingo wa utafutaji wa eneo la mjini tu - ni '
                    'haraka zaidi kwa data ya nchi nzima au kanda nzima.',
    'chk_memory': 'Hifadhi tabaka za kati kwenye kumbukumbu',
    'note_memory': 'Ni haraka zaidi. Ondoa alama tu ikiwa kompyuta inaishiwa na RAM.',
    'chk_native': 'Tumia algoriti asilia ya QGIS ya Eneo la Huduma',
    'note_native': 'Kwa ukaguzi linganishi tu - ni polepole sana kwa nukta nyingi za '
                   'kuanzia. Chaguo-msingi ni utafutaji wa haraka wenye mipaka '
                   '(matokeo sawa).',
    'grp_city': 'Jina la Mji (Kidokezo: Epuka herufi maalum)',
    'city_placeholder': 'mf. Mombasa',
    'lbl_output_folder': 'Folda ya matokeo:',
    'btn_browse': 'Chagua...',
    'info_block':
        "Faili za mwisho zinazohifadhiwa:\n"
        "  Maeneo ya huduma yaliyokatwa + kuunganishwa:\n"
        "  SA_POS_dissolved.shp                Maeneo ya Wazi ya Umma\n"
        "  SA_Bus_dissolved.shp                Vituo vya Usafiri vya Uwezo Mdogo\n"
        "  SA_Ferry_dissolved.shp              Vituo vya vivuko\n"
        "  SA_Rail_dissolved.shp               Vituo vya reli\n"
        "  SA_HighCapacity_dissolved.shp       Uwezo Mkubwa (Reli + Kivuko)\n"
        "  SA_CombinedTransport_dissolved.shp  Usafiri wa Umma kwa Jumla\n"
        "  Maeneo ya huduma ya kila kituo:\n"
        "  SA_Bus_individual.shp / SA_Ferry_individual.shp / SA_Rail_individual.shp\n"
        "  ZonalStats_*.shp                    Eneo la huduma + sehemu ya pop_sum\n"
        "  LAS_streets_dissolved.shp           Ardhi Iliyotengwa kwa Barabara\n"
        "  {city}_statistics_11.2.1_and_11.7.1.xlsx\n\n"
        "MAELEZO:\n"
        "  - Jiometri hurekebishwa kiotomatiki kabla ya uchakataji.\n"
        "  - Idadi ya watu: nukta za kaya (jumla ya sehemu ya idadi ya watu)\n"
        "    zikitolewa, vinginevyo rasta ya idadi ya watu kwa gridi.\n"
        "  - Eneo la Maeneo ya Wazi ya Umma hupimwa baada ya kukatwa kwa mpaka wa mji.\n"
        "  - Data ya kuingiza hukatwa awali kwa eneo la mjini + ukingo wa utafutaji\n"
        "    na tabaka za kati huhifadhiwa kwenye kumbukumbu (angalia kichupo cha Umbali).\n"
        "  - Usafiri kwa jumla = vituo vya uwezo mdogo + kivuko + reli\n"
        "    (bila Maeneo ya Wazi ya Umma).\n"
        "  - Ardhi Iliyotengwa kwa Barabara: barabara zimewekewa bafa kwa upana,\n"
        "    kuunganishwa na kukatwa kwa eneo la mjini.\n"
        "  - Jedwali la takwimu huandikwa kwa lugha iliyochaguliwa.\n"
        "  - Tumia 'Futa Kumbukumbu' kufuta kumbukumbu na kuwezesha vitufe baada ya hitilafu.",
    'msg_running_title': 'Inaendelea',
    'msg_cannot_reset': 'Haiwezekani kufuta wakati uchambuzi unaendelea. Ghairi kwanza.',
    'msg_missing_layer': 'Tabaka Halipo',
    'msg_select_streets': 'Tafadhali chagua tabaka la Barabara.',
    'msg_select_urban': 'Tafadhali chagua tabaka la Mpaka wa Mji.',
    'msg_missing_pop_title': 'Data ya Idadi ya Watu Haipo',
    'msg_missing_pop': 'Tafadhali chagua tabaka la Idadi ya Watu kwa Gridi (Rasta) au '
                       'tabaka la Idadi ya Watu wa Kaya (Nukta) - mojawapo inahitajika.',
    'msg_missing_popfield_title': 'Sehemu ya Idadi ya Watu Haipo',
    'msg_missing_popfield': 'Tafadhali chagua sehemu yenye jumla ya idadi ya watu kwa '
                            'tabaka la Idadi ya Watu wa Kaya (Nukta).',
    'msg_missing_city_title': 'Jina la Mji Halipo',
    'msg_missing_city': 'Tafadhali weka jina la mji.',
    'msg_missing_output_title': 'Matokeo Hayapo',
    'msg_missing_output': 'Tafadhali chagua folda ya matokeo.',
    'msg_invalid_crs_title': 'CRS Batili',
    'msg_invalid_crs': 'Tafadhali chagua CRS lengwa sahihi.',
    'msg_no_transport_title': 'Hakuna Tabaka za Usafiri',
    'msg_no_transport': 'Hakuna tabaka za Maeneo ya Wazi ya Umma / Uwezo Mdogo / Kivuko '
                        '/ Reli zilizochaguliwa. Eneo la mjini na barabara tu ndizo '
                        'zitachakatwa. Endelea?',
    'msg_complete': 'Imekamilika',
    'msg_error': 'Hitilafu',
    'msg_failed': "Uchambuzi umeshindwa. Angalia kumbukumbu kwa maelezo.\n\n"
                  "Bofya 'Futa Kumbukumbu' ili kufuta na kuendesha tena.",
    'msg_close_running': 'Uchambuzi bado unaendelea. Ghairi na ufunge?',
    'msg_cancel_requested': 'Ombi la kughairi limetumwa...',
    'dlg_select_output': 'Chagua Folda ya Matokeo',
    'dlg_select_csv': 'Chagua CSV ya Upana wa Barabara Uliopimwa',
    'csv_filter': 'Faili za CSV (*.csv *.txt);;Faili zote (*)',
    'msg_invalid_csv_title': 'CSV Batili',
    'msg_invalid_csv': 'Haikuweza kusoma:',
    'msg_widths_title': 'CSV ya Upana wa Barabara',
    'msg_widths_cols': 'Jedwali la upana wa barabara linahitaji angalau safu mbili '
                       '(aina ya barabara, upana). Litapuuzwa.',
    'res_done': 'Imekamilika!',
    'res_las': 'Ardhi Iliyotengwa kwa Barabara',
    'res_stats': 'Jedwali la takwimu (CSV)',
    'res_excel': 'Kitabu cha takwimu (Excel)',
    'res_roads': 'Jedwali la barabara',
    'res_folder': 'Folda',
    'res_time': 'Muda',
    'h_city': 'Mji',
    'h_urban_area': 'Eneo la Mjini (km2)',
    'h_pos_area': 'Eneo la Maeneo ya Wazi ya Umma (km2)',
    'h_las': 'Ardhi Iliyotengwa kwa Barabara (km2)',
    'h_ops_las': 'Maeneo ya Wazi ya Umma + Ardhi Iliyotengwa kwa Barabara (km2)',
    'h_prop_ops_las': 'Uwiano wa Eneo la Mjini lenye Maeneo ya Wazi ya Umma + Ardhi '
                      'Iliyotengwa kwa Barabara (%)',
    'h_total_pop': 'Jumla ya Idadi ya Watu wa Mjini',
    'h_pop_pos': 'Idadi ya Watu Wanaofikia Maeneo ya Wazi ya Umma',
    'h_pop_bus': 'Idadi ya Watu Wanaofikia Vituo vya Usafiri vya Uwezo Mdogo (Vituo '
                 'vya Basi, Vituo vya Reli Nyepesi)',
    'h_pop_hc': 'Idadi ya Watu Wanaofikia Usafiri wa Uwezo Mkubwa (Reli + Kivuko)',
    'h_pop_comb': 'Idadi ya Watu Wanaofikia Usafiri wa Umma kwa Jumla',
    'h_pct_pos': 'Asilimia ya Watu Wanaofikia Maeneo ya Wazi ya Umma',
    'h_pct_bus': 'Asilimia ya Watu Wanaofikia Vituo vya Usafiri vya Uwezo Mdogo '
                 '(Vituo vya Basi, Vituo vya Reli Nyepesi)',
    'h_pct_hc': 'Asilimia ya Watu Wanaofikia Usafiri wa Uwezo Mkubwa',
    'h_pct_comb': 'Asilimia ya Watu Wanaofikia Usafiri wa Umma kwa Jumla',
    'h_pop_source': 'Chanzo cha Data ya Idadi ya Watu',
    'src_household': 'Nukta za kaya',
    'src_raster': 'Rasta ya gridi',
    'src_field': 'sehemu',
}


# ---------------------------------------------------------- sv: Svenska
_EXTRA_TEXT['sv'] = {
    'win_title': 'Beräkning av statistik för SDG 11.2.1 och 11.7.1',
    'subtitle': 'Förklippning till tätortsområdet -> Omprojicering + '
                'geometrikorrigering -> Klippning av öppna offentliga platser -> '
                'Gränspunkter -> Serviceområde -> Konvext hölje -> Klippning -> '
                'Sammanslagning -> Befolkning i upptagningsområden -> Koppling av '
                'gatubredder -> Buffert -> Sammanslagning -> Klippning (mark '
                'avsatt för gator) -> Statistiktabell',
    'language': 'Språk:',
    'tab_layers': 'Lager',
    'tab_distances': 'Avstånd',
    'tab_output': 'Utdata',
    'progress': 'Förlopp',
    'btn_run': 'Kör analys',
    'btn_cancel': 'Avbryt',
    'btn_reset': 'Rensa logg',
    'btn_close': 'Stäng',
    'grp_streets': 'Gator',
    'note_streets': 'Gatulager som används för ruttberäkning i nätverket',
    'grp_urban': 'Tätortsgräns',
    'note_urban': 'Polygonlager som avgränsar tätortsområdet',
    'grp_pop_raster': 'Rutnätsbefolkning (raster)',
    'note_pop_raster': 'Befolkningsdata i rutnät. Ange detta ELLER '
                       'Hushållsbefolkning (punkter) nedan - ett av dem krävs.',
    'grp_hh': 'Hushållsbefolkning (punkter)',
    'note_hh': 'Punktlager med antal invånare per hushåll. Ange detta ELLER '
               'befolkningsrastret - ett av dem krävs. Om båda anges används '
               'hushållspunkterna. Befolkning i varje upptagningsområde = summan '
               'av det valda fältet för punkterna inom området.',
    'lbl_pop_field': 'Fält med total befolkning (per hushållspunkt):',
    'grp_pos': 'Öppna offentliga platser (polygoner)',
    'note_pos': 'Polygonlager med obebyggd eller öppen mark som är tillgänglig '
                'för allmänheten, ger invånarna rekreationsytor och förbättrar '
                'miljökvaliteten. Exempel: parker, trädgårdar, lekplatser, '
                'allmänna stränder, åstränder och strandpromenader',
    'grp_bus': 'Hållplatser för kollektivtrafik med låg kapacitet '
               '(busshållplatser, spårvägshållplatser)',
    'note_bus': 'Punktlager med buss- / spårvägshållplatser',
    'grp_rail': 'Hållplatser för kollektivtrafik med hög kapacitet '
                '(järnvägsstationer, tunnelbanestationer)',
    'note_rail': 'Punktlager med järnvägs- / tunnelbanestationer',
    'grp_ferry': 'Hållplatser för kollektivtrafik med hög kapacitet '
                 '(färjelägen)',
    'note_ferry': 'Punktlager med färjeterminaler',
    'grp_widths': 'Uppmätta gatubredder (CSV-tabell)',
    'note_widths': 'Används för mark avsatt för gator. Kolumn 1 = vägkategori '
                   '(matchas mot fältet för vägkategori som väljs nedan), '
                   'kolumn 2 = uppmätt gatubredd i meter. Om ingen CSV anges och '
                   'inget kategorifält finns blir mark avsatt för gator = 0.',
    'btn_browse_csv': 'Bläddra CSV...',
    'grp_catfield': 'Fält för vägkategori (gatulager)',
    'note_catfield': 'Fält i gatulagret med vägkategorierna, används för att '
                     'koppla gatubredderna. \'fclass\', \'highway\' eller '
                     '\'type\' väljs automatiskt om det finns; annars väljer du '
                     'fältet här. Lämna tomt för automatisk identifiering.',
    'grp_crs': 'Målkoordinatsystem (projicerat, i meter - t.ex. UTM för '
               'tätortsområdet)',
    'dist_header': 'Tröskelvärde för nätverksavstånd för:',
    'dist_pos': 'Öppna offentliga platser',
    'spacing_header': 'Avstånd mellan gränspunkter för öppna offentliga '
                      'platser:',
    'spacing_note': 'Startpunkter längs varje öppen plats kontur. 100 m är '
                    'standard; större avstånd (t.ex. 200 m) går snabbare för '
                    'städer med många stora parker men blir något mindre '
                    'exakt.',
    'perf_header': 'Prestanda:',
    'chk_preclip': 'Förklipp indata till tätortsområdet',
    'note_preclip': 'Rekommenderas. Behåller bara gator, hållplatser och öppna '
                    'platser inom sökmarginalen kring tätortsområdet - mycket '
                    'snabbare med data för hela landet eller regionen.',
    'chk_memory': 'Behåll mellanlager i minnet',
    'note_memory': 'Snabbare. Avmarkera bara om datorn får slut på RAM-minne.',
    'chk_native': 'Använd QGIS inbyggda algoritm för serviceområde',
    'note_native': 'Endast för kontroll - mycket långsamt med många '
                   'startpunkter. Standard är den snabba begränsade sökningen '
                   '(samma resultat).',
    'grp_city': 'Stadens namn (tips: undvik specialtecken)',
    'city_placeholder': 't.ex. Mombasa',
    'lbl_output_folder': 'Utdatamapp:',
    'btn_browse': 'Bläddra...',
    'info_block':
        "Slutliga filer som sparas:\n"
        "  Klippta och sammanslagna upptagningsområden:\n"
        "  SA_POS_dissolved.shp                Öppna offentliga platser\n"
        "  SA_Bus_dissolved.shp                Hållplatser med låg kapacitet\n"
        "  SA_Ferry_dissolved.shp              Färjelägen\n"
        "  SA_Rail_dissolved.shp               Järnvägsstationer\n"
        "  SA_HighCapacity_dissolved.shp       Hög kapacitet (järnväg + färja)\n"
        "  SA_CombinedTransport_dissolved.shp  Kollektivtrafik totalt\n"
        "  Enskilda serviceområden (per hållplats):\n"
        "  SA_Bus_individual.shp / SA_Ferry_individual.shp / SA_Rail_individual.shp\n"
        "  ZonalStats_*.shp                    Upptagningsområde + fältet pop_sum\n"
        "  LAS_streets_dissolved.shp           Mark avsatt för gator\n"
        "  {city}_statistics_11.2.1_and_11.7.1.xlsx\n\n"
        "ANMÄRKNINGAR:\n"
        "  - Geometrier korrigeras automatiskt före bearbetningen.\n"
        "  - Befolkning: hushållspunkter (summan av befolkningsfältet) om de\n"
        "    anges, annars befolkningsrastret.\n"
        "  - Ytan för öppna offentliga platser mäts efter klippning mot tätortsgränsen.\n"
        "  - Indata förklipps till tätortsområdet + sökmarginal och mellanlager\n"
        "    hålls i minnet (se fliken Avstånd).\n"
        "  - Kollektivtrafik totalt = låg kapacitet + färja + järnväg\n"
        "    (öppna offentliga platser ingår inte).\n"
        "  - Mark avsatt för gator: gator buffrade efter bredd, sammanslagna\n"
        "    och klippta mot tätortsområdet.\n"
        "  - Statistiktabellen skrivs på det valda språket.\n"
        "  - Använd ”Rensa logg” för att aktivera knapparna igen efter ett fel.",
    'msg_running_title': 'Körs',
    'msg_cannot_reset': 'Det går inte att rensa medan analysen körs. Avbryt '
                        'först.',
    'msg_missing_layer': 'Lager saknas',
    'msg_select_streets': 'Välj ett gatulager.',
    'msg_select_urban': 'Välj ett lager för tätortsgränsen.',
    'msg_missing_pop_title': 'Befolkningsdata saknas',
    'msg_missing_pop': 'Välj ett lager med rutnätsbefolkning (raster) eller '
                       'hushållsbefolkning (punkter) - ett av dem krävs.',
    'msg_missing_popfield_title': 'Befolkningsfält saknas',
    'msg_missing_popfield': 'Välj fältet med total befolkning för lagret med '
                            'hushållsbefolkning (punkter).',
    'msg_missing_city_title': 'Stadens namn saknas',
    'msg_missing_city': 'Ange stadens namn.',
    'msg_missing_output_title': 'Utdatamapp saknas',
    'msg_missing_output': 'Välj en utdatamapp.',
    'msg_invalid_crs_title': 'Ogiltigt koordinatsystem',
    'msg_invalid_crs': 'Välj ett giltigt målkoordinatsystem.',
    'msg_no_transport_title': 'Inga trafiklager',
    'msg_no_transport': 'Inget lager för öppna offentliga platser / låg '
                        'kapacitet / färja / järnväg har valts. Endast '
                        'tätortsområdet och gatorna bearbetas. Fortsätta?',
    'msg_complete': 'Klart',
    'msg_error': 'Fel',
    'msg_failed': 'Analysen misslyckades. Se loggen för detaljer.\n\n'
                  'Klicka på ”Rensa logg” och kör igen.',
    'msg_close_running': 'Analysen körs fortfarande. Avbryta och stänga?',
    'msg_cancel_requested': 'Avbrott begärt...',
    'dlg_select_output': 'Välj utdatamapp',
    'dlg_select_csv': 'Välj CSV med uppmätta gatubredder',
    'csv_filter': 'CSV-filer (*.csv *.txt);;Alla filer (*)',
    'msg_invalid_csv_title': 'Ogiltig CSV',
    'msg_invalid_csv': 'Kunde inte läsas:',
    'msg_widths_title': 'CSV med gatubredder',
    'msg_widths_cols': 'Tabellen med gatubredder måste ha minst två kolumner '
                       '(vägkategori, bredd). Den ignoreras.',
    'res_done': 'Klart!',
    'res_las': 'Mark avsatt för gator',
    'res_stats': 'Statistiktabell (CSV)',
    'res_excel': 'Statistikarbetsbok (Excel)',
    'res_roads': 'Gatutabell',
    'res_folder': 'Mapp',
    'res_time': 'Tid',
    'h_city': 'Stad',
    'h_urban_area': 'Tätortsyta (km2)',
    'h_pos_area': 'Yta för öppna offentliga platser (km2)',
    'h_las': 'Mark avsatt för gator (km2)',
    'h_ops_las': 'Öppna offentliga platser + mark avsatt för gator (km2)',
    'h_prop_ops_las': 'Andel av tätortsytan med öppna offentliga platser + '
                      'mark avsatt för gator (%)',
    'h_total_pop': 'Total befolkning i tätorten',
    'h_pop_pos': 'Befolkning med tillgång till öppna offentliga platser',
    'h_pop_bus': 'Befolkning med tillgång till hållplatser för kollektivtrafik '
                 'med låg kapacitet (busshållplatser, spårvägshållplatser)',
    'h_pop_hc': 'Befolkning med tillgång till kollektivtrafik med hög '
                'kapacitet (järnväg + färja)',
    'h_pop_comb': 'Befolkning med tillgång till kollektivtrafik totalt',
    'h_pct_pos': 'Andel av befolkningen med tillgång till öppna offentliga '
                 'platser (%)',
    'h_pct_bus': 'Andel av befolkningen med tillgång till hållplatser för '
                 'kollektivtrafik med låg kapacitet (busshållplatser, '
                 'spårvägshållplatser) (%)',
    'h_pct_hc': 'Andel av befolkningen med tillgång till kollektivtrafik med '
                'hög kapacitet (%)',
    'h_pct_comb': 'Andel av befolkningen med tillgång till kollektivtrafik '
                  'totalt (%)',
    'h_pop_source': 'Källa för befolkningsdata',
    'src_household': 'Hushållspunkter',
    'src_raster': 'Befolkningsraster',
    'src_field': 'fält',
}


# ---------------------------------------------------------- nb: Norsk (bokmål)
_EXTRA_TEXT['nb'] = {
    'win_title': 'Beregning av statistikk for SDG 11.2.1 og 11.7.1',
    'subtitle': 'Forhåndsklipping til tettstedsområdet -> Omprojisering + '
                'geometrikorrigering -> Klipping av åpne offentlige rom -> '
                'Grensepunkter -> Serviceområde -> Konveks innhylling -> Klipping '
                '-> Sammenslåing -> Befolkning i dekningsområder -> Kobling av '
                'gatebredder -> Buffer -> Sammenslåing -> Klipping (areal avsatt '
                'til gater) -> Statistikktabell',
    'language': 'Språk:',
    'tab_layers': 'Lag',
    'tab_distances': 'Avstander',
    'tab_output': 'Utdata',
    'progress': 'Fremdrift',
    'btn_run': 'Kjør analyse',
    'btn_cancel': 'Avbryt',
    'btn_reset': 'Tøm logg',
    'btn_close': 'Lukk',
    'grp_streets': 'Gater',
    'note_streets': 'Gatelag som brukes til ruteberegning i nettverket',
    'grp_urban': 'Tettstedsgrense',
    'note_urban': 'Polygonlag som avgrenser tettstedsområdet',
    'grp_pop_raster': 'Rutenettbefolkning (raster)',
    'note_pop_raster': 'Befolkningsdata i rutenett. Oppgi dette ELLER '
                       'Husholdningsbefolkning (punkter) nedenfor - ett av dem '
                       'er påkrevd.',
    'grp_hh': 'Husholdningsbefolkning (punkter)',
    'note_hh': 'Punktlag med antall innbyggere per husholdning. Oppgi dette '
               'ELLER befolkningsrasteret - ett av dem er påkrevd. Hvis begge '
               'oppgis, brukes husholdningspunktene. Befolkning i hvert '
               'dekningsområde = summen av det valgte feltet for punktene innenfor '
               'området.',
    'lbl_pop_field': 'Felt med total befolkning (per husholdningspunkt):',
    'grp_pos': 'Åpne offentlige rom (polygoner)',
    'note_pos': 'Polygonlag med ubebygd eller åpent areal som er tilgjengelig '
                'for allmennheten, gir innbyggerne rekreasjonsområder og bedrer '
                'miljøkvaliteten. Eksempler: parker, hager, lekeplasser, '
                'offentlige strender, elvebredder og havnepromenader',
    'grp_bus': 'Holdeplasser for kollektivtransport med lav kapasitet '
               '(bussholdeplasser, bybaneholdeplasser)',
    'note_bus': 'Punktlag med buss- / bybaneholdeplasser',
    'grp_rail': 'Holdeplasser for kollektivtransport med høy kapasitet '
                '(jernbanestasjoner, T-banestasjoner)',
    'note_rail': 'Punktlag med jernbane- / T-banestasjoner',
    'grp_ferry': 'Holdeplasser for kollektivtransport med høy kapasitet '
                 '(fergekaier)',
    'note_ferry': 'Punktlag med fergeterminaler',
    'grp_widths': 'Målte gatebredder (CSV-tabell)',
    'note_widths': 'Brukes for areal avsatt til gater. Kolonne 1 = vegkategori '
                   '(matches mot feltet for vegkategori som velges nedenfor), '
                   'kolonne 2 = målt gatebredde i meter. Hvis ingen CSV oppgis og '
                   'det ikke finnes noe kategorifelt, blir areal avsatt til '
                   'gater = 0.',
    'btn_browse_csv': 'Bla etter CSV...',
    'grp_catfield': 'Felt for vegkategori (gatelag)',
    'note_catfield': 'Felt i gatelaget med vegkategoriene, brukes til å koble '
                     'gatebreddene. \'fclass\', \'highway\' eller \'type\' velges '
                     'automatisk hvis det finnes; ellers velger du feltet her. La '
                     'stå tomt for automatisk gjenkjenning.',
    'grp_crs': 'Målkoordinatsystem (projisert, i meter - f.eks. UTM for '
               'tettstedsområdet)',
    'dist_header': 'Terskel for nettverksavstand for:',
    'dist_pos': 'Åpne offentlige rom',
    'spacing_header': 'Avstand mellom grensepunkter for åpne offentlige rom:',
    'spacing_note': 'Startpunkter langs omrisset av hvert åpent rom. 100 m er '
                    'standard; større avstand (f.eks. 200 m) går raskere for byer '
                    'med mange store parker, men blir litt mindre nøyaktig.',
    'perf_header': 'Ytelse:',
    'chk_preclip': 'Forhåndsklipp inndata til tettstedsområdet',
    'note_preclip': 'Anbefales. Beholder bare gater, holdeplasser og åpne rom '
                    'innenfor søkemarginen rundt tettstedsområdet - mye raskere '
                    'med data for hele landet eller regionen.',
    'chk_memory': 'Behold mellomlag i minnet',
    'note_memory': 'Raskere. Fjern avmerkingen bare hvis datamaskinen går tom '
                   'for RAM.',
    'chk_native': 'Bruk QGIS sin innebygde algoritme for serviceområde',
    'note_native': 'Bare for kontroll - svært tregt med mange startpunkter. '
                   'Standard er det raske avgrensede søket (samme resultater).',
    'grp_city': 'Byens navn (tips: unngå spesialtegn)',
    'city_placeholder': 'f.eks. Mombasa',
    'lbl_output_folder': 'Utdatamappe:',
    'btn_browse': 'Bla gjennom...',
    'info_block':
        "Endelige filer som beholdes:\n"
        "  Klippede og sammenslåtte dekningsområder:\n"
        "  SA_POS_dissolved.shp                Åpne offentlige rom\n"
        "  SA_Bus_dissolved.shp                Holdeplasser med lav kapasitet\n"
        "  SA_Ferry_dissolved.shp              Fergekaier\n"
        "  SA_Rail_dissolved.shp               Jernbanestasjoner\n"
        "  SA_HighCapacity_dissolved.shp       Høy kapasitet (jernbane + ferge)\n"
        "  SA_CombinedTransport_dissolved.shp  Kollektivtransport samlet\n"
        "  Enkeltvise serviceområder (per holdeplass):\n"
        "  SA_Bus_individual.shp / SA_Ferry_individual.shp / SA_Rail_individual.shp\n"
        "  ZonalStats_*.shp                    Dekningsområde + feltet pop_sum\n"
        "  LAS_streets_dissolved.shp           Areal avsatt til gater\n"
        "  {city}_statistics_11.2.1_and_11.7.1.xlsx\n\n"
        "MERKNADER:\n"
        "  - Geometrier korrigeres automatisk før behandlingen.\n"
        "  - Befolkning: husholdningspunkter (summen av befolkningsfeltet) hvis\n"
        "    de oppgis, ellers befolkningsrasteret.\n"
        "  - Arealet av åpne offentlige rom måles etter klipping mot tettstedsgrensen.\n"
        "  - Inndata forhåndsklippes til tettstedsområdet + søkemargin, og\n"
        "    mellomlag holdes i minnet (se fanen Avstander).\n"
        "  - Kollektivtransport samlet = lav kapasitet + ferge + jernbane\n"
        "    (åpne offentlige rom er ikke med).\n"
        "  - Areal avsatt til gater: gater bufret etter bredde, slått sammen\n"
        "    og klippet mot tettstedsområdet.\n"
        "  - Statistikktabellen skrives på det valgte språket.\n"
        "  - Bruk «Tøm logg» for å aktivere knappene igjen etter en feil.",
    'msg_running_title': 'Kjører',
    'msg_cannot_reset': 'Kan ikke tømme mens analysen kjører. Avbryt først.',
    'msg_missing_layer': 'Lag mangler',
    'msg_select_streets': 'Velg et gatelag.',
    'msg_select_urban': 'Velg et lag for tettstedsgrensen.',
    'msg_missing_pop_title': 'Befolkningsdata mangler',
    'msg_missing_pop': 'Velg et lag med rutenettbefolkning (raster) eller '
                       'husholdningsbefolkning (punkter) - ett av dem er '
                       'påkrevd.',
    'msg_missing_popfield_title': 'Befolkningsfelt mangler',
    'msg_missing_popfield': 'Velg feltet med total befolkning for laget med '
                            'husholdningsbefolkning (punkter).',
    'msg_missing_city_title': 'Byens navn mangler',
    'msg_missing_city': 'Skriv inn byens navn.',
    'msg_missing_output_title': 'Utdatamappe mangler',
    'msg_missing_output': 'Velg en utdatamappe.',
    'msg_invalid_crs_title': 'Ugyldig koordinatsystem',
    'msg_invalid_crs': 'Velg et gyldig målkoordinatsystem.',
    'msg_no_transport_title': 'Ingen transportlag',
    'msg_no_transport': 'Ingen lag for åpne offentlige rom / lav kapasitet / '
                        'ferge / jernbane er valgt. Bare tettstedsområdet og '
                        'gatene behandles. Fortsette?',
    'msg_complete': 'Fullført',
    'msg_error': 'Feil',
    'msg_failed': 'Analysen mislyktes. Se loggen for detaljer.\n\n'
                  'Klikk «Tøm logg» og kjør på nytt.',
    'msg_close_running': 'Analysen kjører fortsatt. Avbryte og lukke?',
    'msg_cancel_requested': 'Avbrudd forespurt...',
    'dlg_select_output': 'Velg utdatamappe',
    'dlg_select_csv': 'Velg CSV med målte gatebredder',
    'csv_filter': 'CSV-filer (*.csv *.txt);;Alle filer (*)',
    'msg_invalid_csv_title': 'Ugyldig CSV',
    'msg_invalid_csv': 'Kunne ikke leses:',
    'msg_widths_title': 'CSV med gatebredder',
    'msg_widths_cols': 'Tabellen med gatebredder må ha minst to kolonner '
                       '(vegkategori, bredde). Den blir ignorert.',
    'res_done': 'Ferdig!',
    'res_las': 'Areal avsatt til gater',
    'res_stats': 'Statistikktabell (CSV)',
    'res_excel': 'Statistikkarbeidsbok (Excel)',
    'res_roads': 'Gatetabell',
    'res_folder': 'Mappe',
    'res_time': 'Tid',
    'h_city': 'By',
    'h_urban_area': 'Tettstedsareal (km2)',
    'h_pos_area': 'Areal av åpne offentlige rom (km2)',
    'h_las': 'Areal avsatt til gater (km2)',
    'h_ops_las': 'Åpne offentlige rom + areal avsatt til gater (km2)',
    'h_prop_ops_las': 'Andel av tettstedsarealet med åpne offentlige rom + '
                      'areal avsatt til gater (%)',
    'h_total_pop': 'Total befolkning i tettstedet',
    'h_pop_pos': 'Befolkning med tilgang til åpne offentlige rom',
    'h_pop_bus': 'Befolkning med tilgang til holdeplasser for kollektivtransport '
                 'med lav kapasitet (bussholdeplasser, bybaneholdeplasser)',
    'h_pop_hc': 'Befolkning med tilgang til kollektivtransport med høy '
                'kapasitet (jernbane + ferge)',
    'h_pop_comb': 'Befolkning med tilgang til kollektivtransport samlet',
    'h_pct_pos': 'Andel av befolkningen med tilgang til åpne offentlige rom '
                 '(%)',
    'h_pct_bus': 'Andel av befolkningen med tilgang til holdeplasser for '
                 'kollektivtransport med lav kapasitet (bussholdeplasser, '
                 'bybaneholdeplasser) (%)',
    'h_pct_hc': 'Andel av befolkningen med tilgang til kollektivtransport med '
                'høy kapasitet (%)',
    'h_pct_comb': 'Andel av befolkningen med tilgang til kollektivtransport '
                  'samlet (%)',
    'h_pop_source': 'Kilde for befolkningsdata',
    'src_household': 'Husholdningspunkter',
    'src_raster': 'Befolkningsraster',
    'src_field': 'felt',
}


# ---------------------------------------------------------- da: Dansk
_EXTRA_TEXT['da'] = {
    'win_title': 'Beregning af statistik for SDG 11.2.1 og 11.7.1',
    'subtitle': 'Forudgående klipning til byområdet -> Omprojicering + '
                'geometrikorrektion -> Klipning af åbne offentlige rum -> '
                'Grænsepunkter -> Serviceområde -> Konveks hylster -> Klipning -> '
                'Sammenlægning -> Befolkning i oplande -> Sammenkædning af '
                'vejbredder -> Buffer -> Sammenlægning -> Klipning (areal afsat '
                'til gader) -> Statistiktabel',
    'language': 'Sprog:',
    'tab_layers': 'Lag',
    'tab_distances': 'Afstande',
    'tab_output': 'Output',
    'progress': 'Fremskridt',
    'btn_run': 'Kør analyse',
    'btn_cancel': 'Annuller',
    'btn_reset': 'Ryd log',
    'btn_close': 'Luk',
    'grp_streets': 'Gader',
    'note_streets': 'Gadelag, der bruges til ruteberegning i netværket',
    'grp_urban': 'Bygrænse',
    'note_urban': 'Polygonlag, der afgrænser byområdet',
    'grp_pop_raster': 'Gitterbaseret befolkning (raster)',
    'note_pop_raster': 'Gitterbaseret befolkningsdatasæt. Angiv dette ELLER '
                       'Husstandsbefolkning (punkter) nedenfor - et af dem er '
                       'påkrævet.',
    'grp_hh': 'Husstandsbefolkning (punkter)',
    'note_hh': 'Punktlag med antal indbyggere pr. husstand. Angiv dette ELLER '
               'befolkningsrasteret - et af dem er påkrævet. Hvis begge angives, '
               'bruges husstandspunkterne. Befolkning i hvert opland = summen af '
               'det valgte felt for punkterne inden for oplandet.',
    'lbl_pop_field': 'Felt med samlet befolkning (pr. husstandspunkt):',
    'grp_pos': 'Åbne offentlige rum (polygoner)',
    'note_pos': 'Polygonlag med ubebygget eller åbent areal, der er '
                'tilgængeligt for offentligheden, giver beboerne '
                'rekreative områder og forbedrer miljøkvaliteten. Eksempler: '
                'parker, haver, legepladser, offentlige strande, åbredder og '
                'havnefronter',
    'grp_bus': 'Stoppesteder for kollektiv trafik med lav kapacitet '
               '(busstoppesteder, letbanestop)',
    'note_bus': 'Punktlag med bus- / letbanestoppesteder',
    'grp_rail': 'Stoppesteder for kollektiv trafik med høj kapacitet '
                '(togstationer, metrostationer)',
    'note_rail': 'Punktlag med tog- / metrostationer',
    'grp_ferry': 'Stoppesteder for kollektiv trafik med høj kapacitet '
                 '(færgelejer)',
    'note_ferry': 'Punktlag med færgeterminaler',
    'grp_widths': 'Målte vejbredder (CSV-tabel)',
    'note_widths': 'Bruges til areal afsat til gader. Kolonne 1 = vejkategori '
                   '(matches med feltet for vejkategori, der vælges nedenfor), '
                   'kolonne 2 = målt vejbredde i meter. Hvis der ikke angives en '
                   'CSV, og der ikke findes et kategorifelt, er areal afsat til '
                   'gader = 0.',
    'btn_browse_csv': 'Gennemse CSV...',
    'grp_catfield': 'Felt for vejkategori (gadelag)',
    'note_catfield': 'Felt i gadelaget med vejkategorierne, bruges til at '
                     'sammenkæde vejbredderne. \'fclass\', \'highway\' eller '
                     '\'type\' vælges automatisk, hvis det findes; ellers vælges '
                     'feltet her. Lad feltet stå tomt for automatisk '
                     'genkendelse.',
    'grp_crs': 'Mål-koordinatsystem (projiceret, i meter - f.eks. UTM for '
               'byområdet)',
    'dist_header': 'Tærskel for netværksafstand for:',
    'dist_pos': 'Åbne offentlige rum',
    'spacing_header': 'Afstand mellem grænsepunkter for åbne offentlige rum:',
    'spacing_note': 'Startpunkter langs omridset af hvert åbent rum. 100 m er '
                    'standard; større afstand (f.eks. 200 m) er hurtigere for '
                    'byer med mange store parker, men lidt mindre præcis.',
    'perf_header': 'Ydeevne:',
    'chk_preclip': 'Klip inputdata til byområdet på forhånd',
    'note_preclip': 'Anbefales. Beholder kun gader, stoppesteder og åbne rum '
                    'inden for søgemarginen omkring byområdet - meget hurtigere '
                    'med data for hele landet eller regionen.',
    'chk_memory': 'Behold mellemliggende lag i hukommelsen',
    'note_memory': 'Hurtigere. Fjern kun markeringen, hvis computeren løber tør '
                   'for RAM.',
    'chk_native': 'Brug QGIS\' indbyggede algoritme til serviceområde',
    'note_native': 'Kun til kontrol - meget langsom med mange startpunkter. '
                   'Standard er den hurtige afgrænsede søgning (samme '
                   'resultater).',
    'grp_city': 'Byens navn (tip: undgå specialtegn)',
    'city_placeholder': 'f.eks. Mombasa',
    'lbl_output_folder': 'Outputmappe:',
    'btn_browse': 'Gennemse...',
    'info_block':
        "Endelige filer, der bevares:\n"
        "  Klippede og sammenlagte oplande:\n"
        "  SA_POS_dissolved.shp                Åbne offentlige rum\n"
        "  SA_Bus_dissolved.shp                Stoppesteder med lav kapacitet\n"
        "  SA_Ferry_dissolved.shp              Færgelejer\n"
        "  SA_Rail_dissolved.shp               Togstationer\n"
        "  SA_HighCapacity_dissolved.shp       Høj kapacitet (tog + færge)\n"
        "  SA_CombinedTransport_dissolved.shp  Kollektiv trafik samlet\n"
        "  Individuelle serviceområder (pr. stoppested):\n"
        "  SA_Bus_individual.shp / SA_Ferry_individual.shp / SA_Rail_individual.shp\n"
        "  ZonalStats_*.shp                    Opland + feltet pop_sum\n"
        "  LAS_streets_dissolved.shp           Areal afsat til gader\n"
        "  {city}_statistics_11.2.1_and_11.7.1.xlsx\n\n"
        "BEMÆRKNINGER:\n"
        "  - Geometrier korrigeres automatisk før behandlingen.\n"
        "  - Befolkning: husstandspunkter (summen af befolkningsfeltet), hvis\n"
        "    de angives, ellers befolkningsrasteret.\n"
        "  - Arealet af åbne offentlige rum måles efter klipning til bygrænsen.\n"
        "  - Inputdata klippes til byområdet + søgemargin, og mellemliggende\n"
        "    lag holdes i hukommelsen (se fanen Afstande).\n"
        "  - Kollektiv trafik samlet = lav kapacitet + færge + tog\n"
        "    (åbne offentlige rum indgår ikke).\n"
        "  - Areal afsat til gader: gader med buffer efter bredde, lagt sammen\n"
        "    og klippet til byområdet.\n"
        "  - Statistiktabellen skrives på det valgte sprog.\n"
        "  - Brug »Ryd log« for at aktivere knapperne igen efter en fejl.",
    'msg_running_title': 'Kører',
    'msg_cannot_reset': 'Kan ikke rydde, mens analysen kører. Annuller først.',
    'msg_missing_layer': 'Manglende lag',
    'msg_select_streets': 'Vælg et gadelag.',
    'msg_select_urban': 'Vælg et lag for bygrænsen.',
    'msg_missing_pop_title': 'Manglende befolkningsdata',
    'msg_missing_pop': 'Vælg et lag med gitterbaseret befolkning (raster) eller '
                       'husstandsbefolkning (punkter) - et af dem er påkrævet.',
    'msg_missing_popfield_title': 'Manglende befolkningsfelt',
    'msg_missing_popfield': 'Vælg feltet med samlet befolkning for laget med '
                            'husstandsbefolkning (punkter).',
    'msg_missing_city_title': 'Manglende bynavn',
    'msg_missing_city': 'Indtast byens navn.',
    'msg_missing_output_title': 'Manglende outputmappe',
    'msg_missing_output': 'Vælg en outputmappe.',
    'msg_invalid_crs_title': 'Ugyldigt koordinatsystem',
    'msg_invalid_crs': 'Vælg et gyldigt mål-koordinatsystem.',
    'msg_no_transport_title': 'Ingen trafiklag',
    'msg_no_transport': 'Der er ikke valgt lag for åbne offentlige rum / lav '
                        'kapacitet / færge / tog. Kun byområdet og gaderne '
                        'behandles. Fortsæt?',
    'msg_complete': 'Fuldført',
    'msg_error': 'Fejl',
    'msg_failed': 'Analysen mislykkedes. Se loggen for detaljer.\n\n'
                  'Klik på »Ryd log«, og kør igen.',
    'msg_close_running': 'Analysen kører stadig. Annuller og luk?',
    'msg_cancel_requested': 'Annullering anmodet...',
    'dlg_select_output': 'Vælg outputmappe',
    'dlg_select_csv': 'Vælg CSV med målte vejbredder',
    'csv_filter': 'CSV-filer (*.csv *.txt);;Alle filer (*)',
    'msg_invalid_csv_title': 'Ugyldig CSV',
    'msg_invalid_csv': 'Kunne ikke læses:',
    'msg_widths_title': 'CSV med vejbredder',
    'msg_widths_cols': 'Tabellen med vejbredder skal have mindst to kolonner '
                       '(vejkategori, bredde). Den ignoreres.',
    'res_done': 'Færdig!',
    'res_las': 'Areal afsat til gader',
    'res_stats': 'Statistiktabel (CSV)',
    'res_excel': 'Statistikprojektmappe (Excel)',
    'res_roads': 'Gadetabel',
    'res_folder': 'Mappe',
    'res_time': 'Tid',
    'h_city': 'By',
    'h_urban_area': 'Byareal (km2)',
    'h_pos_area': 'Areal af åbne offentlige rum (km2)',
    'h_las': 'Areal afsat til gader (km2)',
    'h_ops_las': 'Åbne offentlige rum + areal afsat til gader (km2)',
    'h_prop_ops_las': 'Andel af byarealet med åbne offentlige rum + areal afsat '
                      'til gader (%)',
    'h_total_pop': 'Samlet bybefolkning',
    'h_pop_pos': 'Befolkning med adgang til åbne offentlige rum',
    'h_pop_bus': 'Befolkning med adgang til stoppesteder for kollektiv trafik '
                 'med lav kapacitet (busstoppesteder, letbanestop)',
    'h_pop_hc': 'Befolkning med adgang til kollektiv trafik med høj kapacitet '
                '(tog + færge)',
    'h_pop_comb': 'Befolkning med adgang til kollektiv trafik samlet',
    'h_pct_pos': 'Andel af befolkningen med adgang til åbne offentlige rum (%)',
    'h_pct_bus': 'Andel af befolkningen med adgang til stoppesteder for '
                 'kollektiv trafik med lav kapacitet (busstoppesteder, '
                 'letbanestop) (%)',
    'h_pct_hc': 'Andel af befolkningen med adgang til kollektiv trafik med høj '
                'kapacitet (%)',
    'h_pct_comb': 'Andel af befolkningen med adgang til kollektiv trafik '
                  'samlet (%)',
    'h_pop_source': 'Kilde til befolkningsdata',
    'src_household': 'Husstandspunkter',
    'src_raster': 'Befolkningsraster',
    'src_field': 'felt',
}


# ---------------------------------------------------------- hi: हिन्दी
_EXTRA_TEXT['hi'] = {
    'win_title': 'SDG 11.2.1 और 11.7.1 सांख्यिकी गणना',
    'subtitle': 'शहरी क्षेत्र तक पूर्व-क्लिप -> पुनःप्रक्षेपण + ज्यामिति सुधार -> '
                'सार्वजनिक खुले स्थानों की क्लिपिंग -> सीमा बिंदु -> सेवा क्षेत्र '
                '-> उत्तल आवरण -> क्लिप -> विलय -> सेवा क्षेत्रों में जनसंख्या -> '
                'सड़क चौड़ाई जोड़ना -> बफ़र -> विलय -> क्लिप (सड़कों हेतु आवंटित '
                'भूमि) -> सांख्यिकी तालिका',
    'language': 'भाषा:',
    'tab_layers': 'परतें',
    'tab_distances': 'दूरियाँ',
    'tab_output': 'आउटपुट',
    'progress': 'प्रगति',
    'btn_run': 'विश्लेषण चलाएँ',
    'btn_cancel': 'रद्द करें',
    'btn_reset': 'लॉग साफ़ करें',
    'btn_close': 'बंद करें',
    'grp_streets': 'सड़कें',
    'note_streets': 'नेटवर्क मार्ग-निर्धारण के लिए उपयोग की जाने वाली सड़क परत',
    'grp_urban': 'शहरी सीमा',
    'note_urban': 'शहरी विस्तार को परिभाषित करने वाली बहुभुज परत',
    'grp_pop_raster': 'ग्रिड आधारित जनसंख्या (रास्टर)',
    'note_pop_raster': 'ग्रिड आधारित जनसंख्या डेटासेट। यह या नीचे दी गई घरेलू '
                       'जनसंख्या (बिंदु) प्रदान करें - दोनों में से एक आवश्यक है।',
    'grp_hh': 'घरेलू जनसंख्या (बिंदु)',
    'note_hh': 'परिवार स्तर पर जनसंख्या गणना वाली बिंदु परत। यह या ग्रिड आधारित '
               'जनसंख्या रास्टर प्रदान करें - दोनों में से एक आवश्यक है। दोनों दिए '
               'जाने पर घरेलू बिंदुओं का उपयोग होगा। प्रत्येक सेवा क्षेत्र की '
               'जनसंख्या = उसके भीतर के बिंदुओं के चयनित फ़ील्ड का योग।',
    'lbl_pop_field': 'कुल जनसंख्या वाला फ़ील्ड (प्रति घरेलू बिंदु):',
    'grp_pos': 'सार्वजनिक खुले स्थान (बहुभुज)',
    'note_pos': 'जनता के लिए सुलभ अविकसित या खुली भूमि दर्शाने वाली बहुभुज परतें, '
                'जो निवासियों को मनोरंजन स्थल प्रदान करती हैं और पर्यावरण की '
                'गुणवत्ता बढ़ाती हैं। उदाहरण: पार्क, उद्यान, खेल के मैदान, सार्वजनिक '
                'समुद्र तट, नदी तट और जलाग्र क्षेत्र',
    'grp_bus': 'कम क्षमता वाले परिवहन स्टॉप (बस स्टॉप, लाइट रेल स्टॉप)',
    'note_bus': 'बस स्टॉप / लाइट रेल स्टॉप के स्थानों की बिंदु परत',
    'grp_rail': 'उच्च क्षमता वाले परिवहन स्टॉप (रेलवे स्टेशन, मेट्रो स्टेशन)',
    'note_rail': 'रेलवे / मेट्रो स्टेशनों के स्थानों की बिंदु परत',
    'grp_ferry': 'उच्च क्षमता वाले परिवहन स्टॉप (फ़ेरी घाट)',
    'note_ferry': 'फ़ेरी टर्मिनलों के स्थानों की बिंदु परत',
    'grp_widths': 'मापी गई सड़क चौड़ाई (CSV तालिका)',
    'note_widths': 'सड़कों हेतु आवंटित भूमि की गणना में उपयोग। कॉलम 1 = सड़क श्रेणी '
                   '(नीचे चुने गए सड़क श्रेणी फ़ील्ड से मिलाई जाती है), कॉलम 2 = '
                   'मीटर में मापी गई चौड़ाई। यदि CSV नहीं दी गई और कोई श्रेणी फ़ील्ड '
                   'उपलब्ध नहीं है, तो सड़कों हेतु आवंटित भूमि = 0।',
    'btn_browse_csv': 'CSV चुनें...',
    'grp_catfield': 'सड़क श्रेणी फ़ील्ड (सड़क परत से)',
    'note_catfield': 'सड़क परत का वह फ़ील्ड जिसमें सड़क श्रेणियाँ हैं, जिसका उपयोग '
                     'चौड़ाई जोड़ने के लिए होता है। \'fclass\', \'highway\' या '
                     '\'type\' मौजूद होने पर स्वतः चुना जाता है; अन्यथा यहाँ फ़ील्ड '
                     'चुनें। स्वतः पहचान के लिए खाली छोड़ें।',
    'grp_crs': 'लक्ष्य निर्देशांक संदर्भ प्रणाली (प्रक्षेपित, मीटर में - जैसे शहरी '
               'क्षेत्र का UTM क्षेत्र)',
    'dist_header': 'नेटवर्क दूरी सीमा:',
    'dist_pos': 'सार्वजनिक खुले स्थान',
    'spacing_header': 'सार्वजनिक खुले स्थानों के सीमा बिंदुओं के बीच दूरी:',
    'spacing_note': 'प्रत्येक खुले स्थान की रूपरेखा पर रखे गए प्रारंभिक बिंदु। 100 मीटर '
                    'मानक है; अधिक दूरी (जैसे 200 मीटर) कई बड़े पार्कों वाले शहरों '
                    'के लिए तेज़ है, पर थोड़ी कम सटीक।',
    'perf_header': 'प्रदर्शन:',
    'chk_preclip': 'इनपुट को पहले शहरी क्षेत्र तक क्लिप करें',
    'note_preclip': 'अनुशंसित। केवल शहरी क्षेत्र की खोज सीमा के भीतर की सड़कें, स्टॉप '
                    'और खुले स्थान रखता है - राष्ट्रीय/क्षेत्रीय डेटा के साथ बहुत '
                    'तेज़।',
    'chk_memory': 'मध्यवर्ती परतों को मेमोरी में रखें',
    'note_memory': 'तेज़। केवल तभी अनचेक करें जब कंप्यूटर की RAM कम पड़ जाए।',
    'chk_native': 'QGIS का मूल सेवा क्षेत्र एल्गोरिद्म उपयोग करें',
    'note_native': 'केवल जाँच के लिए - अधिक प्रारंभिक बिंदुओं पर बहुत धीमा। '
                   'डिफ़ॉल्ट तेज़ सीमित खोज है (परिणाम समान)।',
    'grp_city': 'शहर का नाम (सुझाव: विशेष वर्णों से बचें)',
    'city_placeholder': 'जैसे Mombasa',
    'lbl_output_folder': 'आउटपुट फ़ोल्डर:',
    'btn_browse': 'चुनें...',
    'info_block':
        "रखी जाने वाली अंतिम फ़ाइलें:\n"
        "  क्लिप और विलय किए गए सेवा क्षेत्र:\n"
        "  SA_POS_dissolved.shp                सार्वजनिक खुले स्थान\n"
        "  SA_Bus_dissolved.shp                कम क्षमता वाले स्टॉप\n"
        "  SA_Ferry_dissolved.shp              फ़ेरी घाट\n"
        "  SA_Rail_dissolved.shp               रेलवे स्टेशन\n"
        "  SA_HighCapacity_dissolved.shp       उच्च क्षमता (रेल + फ़ेरी)\n"
        "  SA_CombinedTransport_dissolved.shp  संयुक्त सार्वजनिक परिवहन\n"
        "  अलग-अलग (प्रति स्टॉप) सेवा क्षेत्र:\n"
        "  SA_Bus_individual.shp / SA_Ferry_individual.shp / SA_Rail_individual.shp\n"
        "  ZonalStats_*.shp                    सेवा क्षेत्र + pop_sum फ़ील्ड\n"
        "  LAS_streets_dissolved.shp           सड़कों हेतु आवंटित भूमि\n"
        "  {city}_statistics_11.2.1_and_11.7.1.xlsx\n\n"
        "टिप्पणियाँ:\n"
        "  - प्रसंस्करण से पहले ज्यामिति स्वतः सुधारी जाती है।\n"
        "  - जनसंख्या: घरेलू बिंदु (जनसंख्या फ़ील्ड का योग) यदि दिए गए हों,\n"
        "    अन्यथा ग्रिड आधारित जनसंख्या रास्टर।\n"
        "  - सार्वजनिक खुले स्थानों का क्षेत्रफल शहरी सीमा पर क्लिप करने के बाद मापा जाता है।\n"
        "  - इनपुट को शहरी क्षेत्र + खोज सीमा तक क्लिप किया जाता है और\n"
        "    मध्यवर्ती परतें मेमोरी में रखी जाती हैं (दूरियाँ टैब देखें)।\n"
        "  - संयुक्त परिवहन = कम क्षमता वाले स्टॉप + फ़ेरी + रेल\n"
        "    (सार्वजनिक खुले स्थान शामिल नहीं)।\n"
        "  - सड़कों हेतु आवंटित भूमि: चौड़ाई के अनुसार सड़कों का बफ़र,\n"
        "    विलय और शहरी विस्तार तक क्लिप।\n"
        "  - सांख्यिकी तालिका चयनित भाषा में लिखी जाती है।\n"
        "  - त्रुटि के बाद बटन फिर सक्रिय करने के लिए 'लॉग साफ़ करें' उपयोग करें।",
    'msg_running_title': 'चल रहा है',
    'msg_cannot_reset': 'विश्लेषण चलते समय साफ़ नहीं किया जा सकता। पहले रद्द करें।',
    'msg_missing_layer': 'परत अनुपलब्ध',
    'msg_select_streets': 'कृपया सड़क परत चुनें।',
    'msg_select_urban': 'कृपया शहरी सीमा परत चुनें।',
    'msg_missing_pop_title': 'जनसंख्या डेटा अनुपलब्ध',
    'msg_missing_pop': 'कृपया ग्रिड आधारित जनसंख्या (रास्टर) परत या घरेलू जनसंख्या '
                       '(बिंदु) परत चुनें - दोनों में से एक आवश्यक है।',
    'msg_missing_popfield_title': 'जनसंख्या फ़ील्ड अनुपलब्ध',
    'msg_missing_popfield': 'कृपया घरेलू जनसंख्या (बिंदु) परत के लिए कुल जनसंख्या '
                            'वाला फ़ील्ड चुनें।',
    'msg_missing_city_title': 'शहर का नाम अनुपलब्ध',
    'msg_missing_city': 'कृपया शहर का नाम दर्ज करें।',
    'msg_missing_output_title': 'आउटपुट अनुपलब्ध',
    'msg_missing_output': 'कृपया आउटपुट फ़ोल्डर चुनें।',
    'msg_invalid_crs_title': 'अमान्य CRS',
    'msg_invalid_crs': 'कृपया मान्य लक्ष्य CRS चुनें।',
    'msg_no_transport_title': 'कोई परिवहन परत नहीं',
    'msg_no_transport': 'सार्वजनिक खुले स्थान / कम क्षमता / फ़ेरी / रेल की कोई परत '
                        'नहीं चुनी गई। केवल शहरी क्षेत्र और सड़कों का प्रसंस्करण '
                        'होगा। जारी रखें?',
    'msg_complete': 'पूर्ण',
    'msg_error': 'त्रुटि',
    'msg_failed': 'विश्लेषण विफल रहा। विवरण के लिए लॉग देखें।\n\n'
                  '\'लॉग साफ़ करें\' पर क्लिक करके फिर से चलाएँ।',
    'msg_close_running': 'विश्लेषण अभी चल रहा है। रद्द करके बंद करें?',
    'msg_cancel_requested': 'रद्द करने का अनुरोध किया गया...',
    'dlg_select_output': 'आउटपुट फ़ोल्डर चुनें',
    'dlg_select_csv': 'मापी गई सड़क चौड़ाई की CSV चुनें',
    'csv_filter': 'CSV फ़ाइलें (*.csv *.txt);;सभी फ़ाइलें (*)',
    'msg_invalid_csv_title': 'अमान्य CSV',
    'msg_invalid_csv': 'पढ़ा नहीं जा सका:',
    'msg_widths_title': 'सड़क चौड़ाई CSV',
    'msg_widths_cols': 'सड़क चौड़ाई तालिका में कम से कम दो कॉलम (सड़क श्रेणी, चौड़ाई) '
                       'होने चाहिए। इसे अनदेखा किया जाएगा।',
    'res_done': 'पूर्ण!',
    'res_las': 'सड़कों हेतु आवंटित भूमि',
    'res_stats': 'सांख्यिकी तालिका (CSV)',
    'res_excel': 'सांख्यिकी वर्कबुक (Excel)',
    'res_roads': 'सड़क तालिका',
    'res_folder': 'फ़ोल्डर',
    'res_time': 'समय',
    'h_city': 'शहर',
    'h_urban_area': 'शहरी क्षेत्रफल (वर्ग किमी)',
    'h_pos_area': 'सार्वजनिक खुले स्थानों का क्षेत्रफल (वर्ग किमी)',
    'h_las': 'सड़कों हेतु आवंटित भूमि (वर्ग किमी)',
    'h_ops_las': 'सार्वजनिक खुले स्थान + सड़कों हेतु आवंटित भूमि (वर्ग किमी)',
    'h_prop_ops_las': 'शहरी क्षेत्रफल में सार्वजनिक खुले स्थानों + सड़कों हेतु आवंटित '
                      'भूमि का अनुपात (%)',
    'h_total_pop': 'कुल शहरी जनसंख्या',
    'h_pop_pos': 'सार्वजनिक खुले स्थानों तक पहुँच वाली जनसंख्या',
    'h_pop_bus': 'कम क्षमता वाले परिवहन स्टॉप (बस स्टॉप, लाइट रेल स्टॉप) तक पहुँच '
                 'वाली जनसंख्या',
    'h_pop_hc': 'उच्च क्षमता वाले परिवहन (रेल + फ़ेरी) तक पहुँच वाली जनसंख्या',
    'h_pop_comb': 'संयुक्त सार्वजनिक परिवहन तक पहुँच वाली जनसंख्या',
    'h_pct_pos': 'सार्वजनिक खुले स्थानों तक पहुँच वाली जनसंख्या का प्रतिशत',
    'h_pct_bus': 'कम क्षमता वाले परिवहन स्टॉप (बस स्टॉप, लाइट रेल स्टॉप) तक पहुँच '
                 'वाली जनसंख्या का प्रतिशत',
    'h_pct_hc': 'उच्च क्षमता वाले परिवहन तक पहुँच वाली जनसंख्या का प्रतिशत',
    'h_pct_comb': 'संयुक्त सार्वजनिक परिवहन तक पहुँच वाली जनसंख्या का प्रतिशत',
    'h_pop_source': 'जनसंख्या डेटा स्रोत',
    'src_household': 'घरेलू बिंदु',
    'src_raster': 'ग्रिड रास्टर',
    'src_field': 'फ़ील्ड',
}


# ---------------------------------------------------------- bn: বাংলা
_EXTRA_TEXT['bn'] = {
    'win_title': 'SDG 11.2.1 ও 11.7.1 পরিসংখ্যান গণনা',
    'subtitle': 'নগর এলাকায় প্রাক-ক্লিপ -> পুনঃপ্রক্ষেপণ + জ্যামিতি সংশোধন -> '
                'উন্মুক্ত জনপরিসর ক্লিপ -> সীমানা বিন্দু -> সেবা এলাকা -> উত্তল '
                'আবরণ -> ক্লিপ -> একীভবন -> সেবা এলাকার জনসংখ্যা -> রাস্তার প্রস্থ '
                'যুক্তকরণ -> বাফার -> একীভবন -> ক্লিপ (রাস্তার জন্য বরাদ্দ জমি) -> '
                'পরিসংখ্যান সারণি',
    'language': 'ভাষা:',
    'tab_layers': 'স্তর',
    'tab_distances': 'দূরত্ব',
    'tab_output': 'আউটপুট',
    'progress': 'অগ্রগতি',
    'btn_run': 'বিশ্লেষণ চালান',
    'btn_cancel': 'বাতিল',
    'btn_reset': 'লগ মুছুন',
    'btn_close': 'বন্ধ করুন',
    'grp_streets': 'রাস্তা',
    'note_streets': 'নেটওয়ার্কে পথ নির্ধারণের জন্য ব্যবহৃত রাস্তার স্তর',
    'grp_urban': 'নগর সীমানা',
    'note_urban': 'নগরের বিস্তার নির্ধারণকারী বহুভুজ স্তর',
    'grp_pop_raster': 'গ্রিডভিত্তিক জনসংখ্যা (রাস্টার)',
    'note_pop_raster': 'গ্রিডভিত্তিক জনসংখ্যা ডেটাসেট। এটি অথবা নিচের খানার জনসংখ্যা '
                       '(বিন্দু) দিন - দুটির একটি আবশ্যক।',
    'grp_hh': 'খানার জনসংখ্যা (বিন্দু)',
    'note_hh': 'খানা পর্যায়ের জনসংখ্যা সংবলিত বিন্দু স্তর। এটি অথবা গ্রিডভিত্তিক '
               'জনসংখ্যা রাস্টার দিন - দুটির একটি আবশ্যক। দুটিই দেওয়া হলে খানার '
               'বিন্দু ব্যবহৃত হবে। প্রতিটি সেবা এলাকার জনসংখ্যা = এর ভেতরের '
               'বিন্দুগুলোর নির্বাচিত ফিল্ডের যোগফল।',
    'lbl_pop_field': 'মোট জনসংখ্যার ফিল্ড (প্রতি খানা বিন্দু):',
    'grp_pos': 'উন্মুক্ত জনপরিসর (বহুভুজ)',
    'note_pos': 'জনসাধারণের জন্য উন্মুক্ত অনুন্নত বা খোলা জমির বহুভুজ স্তর, যা '
                'বাসিন্দাদের বিনোদনের স্থান দেয় এবং পরিবেশের মান বাড়ায়। যেমন: '
                'পার্ক, বাগান, খেলার মাঠ, সরকারি সৈকত, নদীতীর ও জলাধারের পাড়',
    'grp_bus': 'স্বল্প ধারণক্ষমতার পরিবহন স্টপ (বাস স্টপ, লাইট রেল স্টপ)',
    'note_bus': 'বাস স্টপ / লাইট রেল স্টপের অবস্থানের বিন্দু স্তর',
    'grp_rail': 'উচ্চ ধারণক্ষমতার পরিবহন স্টপ (রেলস্টেশন, মেট্রো স্টেশন)',
    'note_rail': 'রেলস্টেশন / মেট্রো স্টেশনের অবস্থানের বিন্দু স্তর',
    'grp_ferry': 'উচ্চ ধারণক্ষমতার পরিবহন স্টপ (ফেরিঘাট)',
    'note_ferry': 'ফেরি টার্মিনালের অবস্থানের বিন্দু স্তর',
    'grp_widths': 'পরিমাপকৃত রাস্তার প্রস্থ (CSV সারণি)',
    'note_widths': 'রাস্তার জন্য বরাদ্দ জমি গণনায় ব্যবহৃত। কলাম 1 = রাস্তার শ্রেণি '
                   '(নিচে নির্বাচিত রাস্তার শ্রেণি ফিল্ডের সাথে মেলানো হয়), কলাম 2 = '
                   'মিটারে পরিমাপকৃত প্রস্থ। CSV না দিলে এবং শ্রেণি ফিল্ড না থাকলে, '
                   'রাস্তার জন্য বরাদ্দ জমি = 0।',
    'btn_browse_csv': 'CSV নির্বাচন...',
    'grp_catfield': 'রাস্তার শ্রেণি ফিল্ড (রাস্তার স্তর থেকে)',
    'note_catfield': 'রাস্তার স্তরের যে ফিল্ডে রাস্তার শ্রেণি আছে, প্রস্থ যুক্ত করতে '
                     'ব্যবহৃত হয়। \'fclass\', \'highway\' বা \'type\' থাকলে '
                     'স্বয়ংক্রিয়ভাবে নির্বাচিত হয়; না থাকলে এখানে ফিল্ড বেছে নিন। '
                     'স্বয়ংক্রিয় শনাক্তকরণের জন্য ফাঁকা রাখুন।',
    'grp_crs': 'লক্ষ্য স্থানাঙ্ক রেফারেন্স ব্যবস্থা (প্রক্ষিপ্ত, মিটারে - যেমন নগর '
               'এলাকার UTM অঞ্চল)',
    'dist_header': 'নেটওয়ার্ক দূরত্বের সীমা:',
    'dist_pos': 'উন্মুক্ত জনপরিসর',
    'spacing_header': 'উন্মুক্ত জনপরিসরের সীমানা বিন্দুর ব্যবধান:',
    'spacing_note': 'প্রতিটি উন্মুক্ত স্থানের রূপরেখা বরাবর স্থাপিত সূচনা বিন্দু। 100 '
                    'মিটার মানক; বেশি ব্যবধান (যেমন 200 মিটার) অনেক বড় পার্কের শহরে '
                    'দ্রুততর, তবে কিছুটা কম নির্ভুল।',
    'perf_header': 'কার্যক্ষমতা:',
    'chk_preclip': 'ইনপুট আগে থেকেই নগর এলাকায় ক্লিপ করুন',
    'note_preclip': 'সুপারিশকৃত। কেবল নগর এলাকার অনুসন্ধান সীমার ভেতরের রাস্তা, স্টপ ও '
                    'খোলা জায়গা রাখে - জাতীয়/আঞ্চলিক ডেটায় অনেক দ্রুত।',
    'chk_memory': 'অন্তর্বর্তী স্তর মেমরিতে রাখুন',
    'note_memory': 'দ্রুততর। কম্পিউটারের RAM ফুরিয়ে গেলে তবেই টিক তুলে দিন।',
    'chk_native': 'QGIS-এর নিজস্ব সেবা এলাকা অ্যালগরিদম ব্যবহার করুন',
    'note_native': 'কেবল যাচাইয়ের জন্য - অনেক সূচনা বিন্দু থাকলে খুব ধীর। '
                   'ডিফল্ট হলো দ্রুত সীমিত অনুসন্ধান (একই ফলাফল)।',
    'grp_city': 'শহরের নাম (পরামর্শ: বিশেষ অক্ষর এড়িয়ে চলুন)',
    'city_placeholder': 'যেমন Mombasa',
    'lbl_output_folder': 'আউটপুট ফোল্ডার:',
    'btn_browse': 'নির্বাচন...',
    'info_block':
        "সংরক্ষিত চূড়ান্ত ফাইল:\n"
        "  ক্লিপ ও একীভূত সেবা এলাকা:\n"
        "  SA_POS_dissolved.shp                উন্মুক্ত জনপরিসর\n"
        "  SA_Bus_dissolved.shp                স্বল্প ধারণক্ষমতার স্টপ\n"
        "  SA_Ferry_dissolved.shp              ফেরিঘাট\n"
        "  SA_Rail_dissolved.shp               রেলস্টেশন\n"
        "  SA_HighCapacity_dissolved.shp       উচ্চ ধারণক্ষমতা (রেল + ফেরি)\n"
        "  SA_CombinedTransport_dissolved.shp  সমন্বিত গণপরিবহন\n"
        "  পৃথক (প্রতি স্টপ) সেবা এলাকা:\n"
        "  SA_Bus_individual.shp / SA_Ferry_individual.shp / SA_Rail_individual.shp\n"
        "  ZonalStats_*.shp                    সেবা এলাকা + pop_sum ফিল্ড\n"
        "  LAS_streets_dissolved.shp           রাস্তার জন্য বরাদ্দ জমি\n"
        "  {city}_statistics_11.2.1_and_11.7.1.xlsx\n\n"
        "টীকা:\n"
        "  - প্রক্রিয়াকরণের আগে জ্যামিতি স্বয়ংক্রিয়ভাবে সংশোধিত হয়।\n"
        "  - জনসংখ্যা: খানার বিন্দু (জনসংখ্যা ফিল্ডের যোগফল) দেওয়া থাকলে,\n"
        "    নইলে গ্রিডভিত্তিক জনসংখ্যা রাস্টার।\n"
        "  - উন্মুক্ত জনপরিসরের ক্ষেত্রফল নগর সীমানায় ক্লিপের পর মাপা হয়।\n"
        "  - ইনপুট নগর এলাকা + অনুসন্ধান সীমায় ক্লিপ হয় এবং অন্তর্বর্তী\n"
        "    স্তর মেমরিতে থাকে (দূরত্ব ট্যাব দেখুন)।\n"
        "  - সমন্বিত পরিবহন = স্বল্প ধারণক্ষমতার স্টপ + ফেরি + রেল\n"
        "    (উন্মুক্ত জনপরিসর বাদে)।\n"
        "  - রাস্তার জন্য বরাদ্দ জমি: প্রস্থ অনুযায়ী রাস্তার বাফার,\n"
        "    একীভূত করে নগর বিস্তারে ক্লিপ।\n"
        "  - পরিসংখ্যান সারণি নির্বাচিত ভাষায় লেখা হয়।\n"
        "  - ত্রুটির পর বোতাম আবার চালু করতে 'লগ মুছুন' ব্যবহার করুন।",
    'msg_running_title': 'চলছে',
    'msg_cannot_reset': 'বিশ্লেষণ চলাকালীন মোছা যাবে না। আগে বাতিল করুন।',
    'msg_missing_layer': 'স্তর অনুপস্থিত',
    'msg_select_streets': 'অনুগ্রহ করে একটি রাস্তার স্তর নির্বাচন করুন।',
    'msg_select_urban': 'অনুগ্রহ করে একটি নগর সীমানা স্তর নির্বাচন করুন।',
    'msg_missing_pop_title': 'জনসংখ্যা ডেটা অনুপস্থিত',
    'msg_missing_pop': 'অনুগ্রহ করে গ্রিডভিত্তিক জনসংখ্যা (রাস্টার) স্তর বা খানার '
                       'জনসংখ্যা (বিন্দু) স্তর নির্বাচন করুন - দুটির একটি আবশ্যক।',
    'msg_missing_popfield_title': 'জনসংখ্যা ফিল্ড অনুপস্থিত',
    'msg_missing_popfield': 'অনুগ্রহ করে খানার জনসংখ্যা (বিন্দু) স্তরের মোট জনসংখ্যার '
                            'ফিল্ড নির্বাচন করুন।',
    'msg_missing_city_title': 'শহরের নাম অনুপস্থিত',
    'msg_missing_city': 'অনুগ্রহ করে শহরের নাম লিখুন।',
    'msg_missing_output_title': 'আউটপুট অনুপস্থিত',
    'msg_missing_output': 'অনুগ্রহ করে একটি আউটপুট ফোল্ডার নির্বাচন করুন।',
    'msg_invalid_crs_title': 'অবৈধ CRS',
    'msg_invalid_crs': 'অনুগ্রহ করে একটি বৈধ লক্ষ্য CRS নির্বাচন করুন।',
    'msg_no_transport_title': 'কোনো পরিবহন স্তর নেই',
    'msg_no_transport': 'উন্মুক্ত জনপরিসর / স্বল্প ধারণক্ষমতা / ফেরি / রেলের কোনো স্তর '
                        'নির্বাচিত হয়নি। কেবল নগর এলাকা ও রাস্তা প্রক্রিয়া করা হবে। '
                        'চালিয়ে যাবেন?',
    'msg_complete': 'সম্পন্ন',
    'msg_error': 'ত্রুটি',
    'msg_failed': 'বিশ্লেষণ ব্যর্থ হয়েছে। বিস্তারিত জানতে লগ দেখুন।\n\n'
                  '\'লগ মুছুন\' ক্লিক করে আবার চালান।',
    'msg_close_running': 'বিশ্লেষণ এখনো চলছে। বাতিল করে বন্ধ করবেন?',
    'msg_cancel_requested': 'বাতিলের অনুরোধ করা হয়েছে...',
    'dlg_select_output': 'আউটপুট ফোল্ডার নির্বাচন করুন',
    'dlg_select_csv': 'পরিমাপকৃত রাস্তার প্রস্থের CSV নির্বাচন করুন',
    'csv_filter': 'CSV ফাইল (*.csv *.txt);;সব ফাইল (*)',
    'msg_invalid_csv_title': 'অবৈধ CSV',
    'msg_invalid_csv': 'পড়া যায়নি:',
    'msg_widths_title': 'রাস্তার প্রস্থ CSV',
    'msg_widths_cols': 'রাস্তার প্রস্থ সারণিতে অন্তত দুটি কলাম (রাস্তার শ্রেণি, প্রস্থ) '
                       'থাকতে হবে। এটি উপেক্ষা করা হবে।',
    'res_done': 'সম্পন্ন!',
    'res_las': 'রাস্তার জন্য বরাদ্দ জমি',
    'res_stats': 'পরিসংখ্যান সারণি (CSV)',
    'res_excel': 'পরিসংখ্যান ওয়ার্কবুক (Excel)',
    'res_roads': 'রাস্তার সারণি',
    'res_folder': 'ফোল্ডার',
    'res_time': 'সময়',
    'h_city': 'শহর',
    'h_urban_area': 'নগর এলাকার ক্ষেত্রফল (বর্গ কিমি)',
    'h_pos_area': 'উন্মুক্ত জনপরিসরের ক্ষেত্রফল (বর্গ কিমি)',
    'h_las': 'রাস্তার জন্য বরাদ্দ জমি (বর্গ কিমি)',
    'h_ops_las': 'উন্মুক্ত জনপরিসর + রাস্তার জন্য বরাদ্দ জমি (বর্গ কিমি)',
    'h_prop_ops_las': 'নগর এলাকায় উন্মুক্ত জনপরিসর + রাস্তার জন্য বরাদ্দ জমির অনুপাত '
                      '(%)',
    'h_total_pop': 'মোট নগর জনসংখ্যা',
    'h_pop_pos': 'উন্মুক্ত জনপরিসরে প্রবেশাধিকারসম্পন্ন জনসংখ্যা',
    'h_pop_bus': 'স্বল্প ধারণক্ষমতার পরিবহন স্টপে (বাস স্টপ, লাইট রেল স্টপ) '
                 'প্রবেশাধিকারসম্পন্ন জনসংখ্যা',
    'h_pop_hc': 'উচ্চ ধারণক্ষমতার পরিবহনে (রেল + ফেরি) প্রবেশাধিকারসম্পন্ন জনসংখ্যা',
    'h_pop_comb': 'সমন্বিত গণপরিবহনে প্রবেশাধিকারসম্পন্ন জনসংখ্যা',
    'h_pct_pos': 'উন্মুক্ত জনপরিসরে প্রবেশাধিকারসম্পন্ন জনসংখ্যার শতাংশ',
    'h_pct_bus': 'স্বল্প ধারণক্ষমতার পরিবহন স্টপে (বাস স্টপ, লাইট রেল স্টপ) '
                 'প্রবেশাধিকারসম্পন্ন জনসংখ্যার শতাংশ',
    'h_pct_hc': 'উচ্চ ধারণক্ষমতার পরিবহনে প্রবেশাধিকারসম্পন্ন জনসংখ্যার শতাংশ',
    'h_pct_comb': 'সমন্বিত গণপরিবহনে প্রবেশাধিকারসম্পন্ন জনসংখ্যার শতাংশ',
    'h_pop_source': 'জনসংখ্যা ডেটার উৎস',
    'src_household': 'খানার বিন্দু',
    'src_raster': 'গ্রিড রাস্টার',
    'src_field': 'ফিল্ড',
}


# ---------------------------------------------------------- ur: اردو
_EXTRA_TEXT['ur'] = {
    'win_title': 'ایس ڈی جی 11.2.1 اور 11.7.1 کے اعداد و شمار کا حساب',
    'subtitle': 'شہری علاقے تک ابتدائی کلپ -> دوبارہ پروجیکشن + جیومیٹری درستی -> '
                'عوامی کھلی جگہوں کا کلپ -> سرحدی نقاط -> سروس ایریا -> محدب احاطہ '
                '-> کلپ -> ضم -> سروس ایریاز میں آبادی -> سڑکوں کی چوڑائی کا جوڑ '
                '-> بفر -> ضم -> کلپ (سڑکوں کے لیے مختص زمین) -> اعداد و شمار کا '
                'جدول',
    'language': 'زبان:',
    'tab_layers': 'پرتیں',
    'tab_distances': 'فاصلے',
    'tab_output': 'نتائج',
    'progress': 'پیش رفت',
    'btn_run': 'تجزیہ چلائیں',
    'btn_cancel': 'منسوخ کریں',
    'btn_reset': 'لاگ صاف کریں',
    'btn_close': 'بند کریں',
    'grp_streets': 'سڑکیں',
    'note_streets': 'نیٹ ورک پر راستہ تلاش کرنے کے لیے سڑکوں کی پرت',
    'grp_urban': 'شہری حد',
    'note_urban': 'شہری علاقے کی حدود متعین کرنے والی کثیرالاضلاع پرت',
    'grp_pop_raster': 'گرڈ شدہ آبادی (راسٹر)',
    'note_pop_raster': 'گرڈ شدہ آبادی کا ڈیٹا سیٹ۔ یہ یا نیچے گھرانوں کی آبادی '
                       '(نقاط) فراہم کریں - دونوں میں سے ایک لازمی ہے۔',
    'grp_hh': 'گھرانوں کی آبادی (نقاط)',
    'note_hh': 'گھرانے کی سطح پر آبادی کی تعداد والی نقاط کی پرت۔ یہ یا گرڈ شدہ '
               'آبادی کا راسٹر فراہم کریں - دونوں میں سے ایک لازمی ہے۔ اگر دونوں '
               'دیے جائیں تو گھرانوں کے نقاط استعمال ہوں گے۔ ہر سروس ایریا کی آبادی '
               '= اس کے اندر موجود نقاط پر منتخب فیلڈ کا مجموعہ۔',
    'lbl_pop_field': 'کل آبادی والا فیلڈ (ہر گھرانے کے نقطے کے لیے):',
    'grp_pos': 'عوامی کھلی جگہیں (کثیرالاضلاع)',
    'note_pos': 'کثیرالاضلاع پرتیں جو عوام کے لیے قابل رسائی غیر ترقی یافتہ یا کھلی '
                'زمین کو ظاہر کرتی ہیں، رہائشیوں کو تفریحی مقامات فراہم کرتی ہیں اور '
                'ماحولیاتی معیار بہتر بناتی ہیں۔ مثالیں: پارک، باغات، کھیل کے میدان، '
                'عوامی ساحل، دریا کے کنارے اور واٹر فرنٹ',
    'grp_bus': 'کم گنجائش والے ٹرانسپورٹ اسٹاپ (بس اسٹاپ، لائٹ ریل اسٹاپ)',
    'note_bus': 'بس اسٹاپ / لائٹ ریل اسٹاپ کے مقامات کی نقاط کی پرت',
    'grp_rail': 'زیادہ گنجائش والے ٹرانسپورٹ اسٹاپ (ریلوے اسٹیشن، میٹرو اسٹیشن)',
    'note_rail': 'ریلوے/میٹرو اسٹیشنوں کے مقامات کی نقاط کی پرت',
    'grp_ferry': 'زیادہ گنجائش والے ٹرانسپورٹ اسٹاپ (فیری اسٹاپ)',
    'note_ferry': 'فیری ٹرمینلز کے مقامات کی نقاط کی پرت',
    'grp_widths': 'سڑکوں کی ناپی گئی چوڑائی (CSV جدول)',
    'note_widths': 'سڑکوں کے لیے مختص زمین کے لیے استعمال ہوتا ہے۔ کالم 1 = سڑک کی '
                   'قسم (نیچے منتخب کردہ سڑک کی قسم کے فیلڈ سے ملائی جاتی ہے)، کالم 2 '
                   '= میٹر میں ناپی گئی سڑک کی چوڑائی۔ اگر CSV نہ دیا جائے اور سڑک کی '
                   'قسم کا فیلڈ دستیاب نہ ہو تو سڑکوں کے لیے مختص زمین = 0۔',
    'btn_browse_csv': 'CSV منتخب کریں...',
    'grp_catfield': 'سڑک کی قسم کا فیلڈ (سڑکوں کی پرت سے)',
    'note_catfield': "سڑکوں کی پرت کا وہ فیلڈ جس میں سڑک کی اقسام ہیں، جو سڑکوں کی "
                     "چوڑائی جوڑنے کے لیے استعمال ہوتا ہے۔ 'fclass'، 'highway' یا "
                     "'type' موجود ہو تو خودکار طور پر منتخب ہوتا ہے؛ ورنہ یہاں فیلڈ "
                     "منتخب کریں۔ خودکار شناخت کے لیے خالی چھوڑ دیں۔",
    'grp_crs': 'ہدف کوآرڈینیٹ ریفرنس سسٹم (پروجیکٹڈ، میٹر - مثلاً شہری علاقے کے لیے '
               'UTM)',
    'dist_header': 'نیٹ ورک فاصلے کی حد برائے:',
    'dist_pos': 'عوامی کھلی جگہیں',
    'spacing_header': 'عوامی کھلی جگہوں کے سرحدی نقاط کا درمیانی فاصلہ:',
    'spacing_note': 'ہر کھلی جگہ کی بیرونی حد کے ساتھ رکھے گئے آغاز کے نقاط۔ 100 میٹر '
                    'معیاری ہے؛ زیادہ فاصلہ (مثلاً 200 میٹر) بہت سے بڑے پارکوں والے '
                    'شہروں کے لیے تیز ہے مگر قدرے کم درست ہے۔',
    'perf_header': 'کارکردگی:',
    'chk_preclip': 'ان پٹ کو شہری علاقے تک پہلے سے کلپ کریں',
    'note_preclip': 'تجویز کردہ۔ صرف شہری علاقے کے تلاشی حاشیے کے اندر موجود سڑکیں، '
                    'اسٹاپ اور کھلی جگہیں رکھتا ہے - ملکی/علاقائی سطح کے ڈیٹا کے ساتھ '
                    'کہیں زیادہ تیز۔',
    'chk_memory': 'درمیانی پرتیں میموری میں رکھیں',
    'note_memory': 'زیادہ تیز۔ نشان صرف تب ہٹائیں جب کمپیوٹر کی RAM کم پڑ جائے۔',
    'chk_native': 'QGIS کا اصل سروس ایریا الگورتھم استعمال کریں',
    'note_native': 'صرف تقابلی جانچ کے لیے - بہت سے آغاز کے نقاط کے ساتھ بہت سست۔ '
                   'طے شدہ تیز محدود تلاش ہے (یکساں نتائج)۔',
    'grp_city': 'شہر کا نام (اشارہ: خاص حروف سے گریز کریں)',
    'city_placeholder': 'مثلاً Mombasa',
    'lbl_output_folder': 'نتائج کا فولڈر:',
    'btn_browse': 'براؤز کریں...',
    'info_block':
        "محفوظ رکھی جانے والی حتمی فائلیں:\n"
        "  کلپ + ضم شدہ سروس ایریاز:\n"
        "  SA_POS_dissolved.shp                عوامی کھلی جگہیں\n"
        "  SA_Bus_dissolved.shp                کم گنجائش والے ٹرانسپورٹ اسٹاپ\n"
        "  SA_Ferry_dissolved.shp              فیری اسٹاپ\n"
        "  SA_Rail_dissolved.shp               ریل اسٹاپ\n"
        "  SA_HighCapacity_dissolved.shp       زیادہ گنجائش (ریل + فیری)\n"
        "  SA_CombinedTransport_dissolved.shp  مجموعی عوامی ٹرانسپورٹ\n"
        "  انفرادی (ہر اسٹاپ کے) سروس ایریاز:\n"
        "  SA_Bus_individual.shp / SA_Ferry_individual.shp / SA_Rail_individual.shp\n"
        "  ZonalStats_*.shp                    سروس ایریا + pop_sum فیلڈ\n"
        "  LAS_streets_dissolved.shp           سڑکوں کے لیے مختص زمین\n"
        "  {city}_statistics_11.2.1_and_11.7.1.xlsx\n\n"
        "نوٹس:\n"
        "  - پروسیسنگ سے پہلے جیومیٹری خودکار طور پر درست کی جاتی ہے۔\n"
        "  - آبادی: اگر دیے گئے ہوں تو گھرانوں کے نقاط (آبادی فیلڈ کا مجموعہ)،\n"
        "    ورنہ گرڈ شدہ آبادی کا راسٹر۔\n"
        "  - عوامی کھلی جگہوں کا رقبہ شہری حد تک کلپ کرنے کے بعد ناپا جاتا ہے۔\n"
        "  - ان پٹ شہری علاقے + تلاشی حاشیے تک پہلے سے کلپ ہوتے ہیں اور\n"
        "    درمیانی پرتیں میموری میں رکھی جاتی ہیں (تبدیلی کے لیے فاصلے ٹیب دیکھیں)۔\n"
        "  - مجموعی ٹرانسپورٹ = کم گنجائش والے اسٹاپ + فیری + ریل\n"
        "    (عوامی کھلی جگہیں شامل نہیں)۔\n"
        "  - سڑکوں کے لیے مختص زمین: سڑکوں پر چوڑائی کے مطابق بفر، ضم،\n"
        "    اور شہری حد تک کلپ۔\n"
        "  - اعداد و شمار کا جدول منتخب زبان میں لکھا جاتا ہے۔\n"
        "  - خرابی کے بعد لاگ صاف کرنے اور بٹن دوبارہ فعال کرنے کے لیے 'لاگ صاف کریں' استعمال کریں۔",
    'msg_running_title': 'جاری ہے',
    'msg_cannot_reset': 'تجزیہ جاری ہونے کے دوران صاف نہیں کیا جا سکتا۔ پہلے منسوخ '
                        'کریں۔',
    'msg_missing_layer': 'پرت موجود نہیں',
    'msg_select_streets': 'براہ کرم سڑکوں کی پرت منتخب کریں۔',
    'msg_select_urban': 'براہ کرم شہری حد کی پرت منتخب کریں۔',
    'msg_missing_pop_title': 'آبادی کا ڈیٹا موجود نہیں',
    'msg_missing_pop': 'براہ کرم گرڈ شدہ آبادی (راسٹر) کی پرت یا گھرانوں کی آبادی '
                       '(نقاط) کی پرت منتخب کریں - دونوں میں سے ایک لازمی ہے۔',
    'msg_missing_popfield_title': 'آبادی کا فیلڈ موجود نہیں',
    'msg_missing_popfield': 'براہ کرم گھرانوں کی آبادی (نقاط) کی پرت کے لیے کل آبادی '
                            'والا فیلڈ منتخب کریں۔',
    'msg_missing_city_title': 'شہر کا نام موجود نہیں',
    'msg_missing_city': 'براہ کرم شہر کا نام درج کریں۔',
    'msg_missing_output_title': 'نتائج کا فولڈر موجود نہیں',
    'msg_missing_output': 'براہ کرم نتائج کا فولڈر منتخب کریں۔',
    'msg_invalid_crs_title': 'غلط CRS',
    'msg_invalid_crs': 'براہ کرم درست ہدف CRS منتخب کریں۔',
    'msg_no_transport_title': 'کوئی ٹرانسپورٹ پرت نہیں',
    'msg_no_transport': 'عوامی کھلی جگہوں / کم گنجائش / فیری / ریل کی کوئی پرت منتخب '
                        'نہیں کی گئی۔ صرف شہری علاقے اور سڑکوں پر کارروائی ہوگی۔ '
                        'جاری رکھیں؟',
    'msg_complete': 'مکمل',
    'msg_error': 'خرابی',
    'msg_failed': "تجزیہ ناکام ہو گیا۔ تفصیلات کے لیے لاگ دیکھیں۔\n\n"
                  "صاف کر کے دوبارہ چلانے کے لیے 'لاگ صاف کریں' پر کلک کریں۔",
    'msg_close_running': 'تجزیہ ابھی جاری ہے۔ منسوخ کر کے بند کریں؟',
    'msg_cancel_requested': 'منسوخی کی درخواست کی گئی...',
    'dlg_select_output': 'نتائج کا فولڈر منتخب کریں',
    'dlg_select_csv': 'سڑکوں کی ناپی گئی چوڑائی کی CSV منتخب کریں',
    'csv_filter': 'CSV فائلیں (*.csv *.txt);;تمام فائلیں (*)',
    'msg_invalid_csv_title': 'غلط CSV',
    'msg_invalid_csv': 'پڑھا نہیں جا سکا:',
    'msg_widths_title': 'سڑکوں کی چوڑائی کی CSV',
    'msg_widths_cols': 'سڑکوں کی چوڑائی کے جدول میں کم از کم دو کالم (سڑک کی قسم، '
                       'چوڑائی) درکار ہیں۔ اسے نظر انداز کیا جائے گا۔',
    'res_done': 'مکمل!',
    'res_las': 'سڑکوں کے لیے مختص زمین',
    'res_stats': 'اعداد و شمار کا جدول (CSV)',
    'res_excel': 'اعداد و شمار کی ورک بک (Excel)',
    'res_roads': 'سڑکوں کا جدول',
    'res_folder': 'فولڈر',
    'res_time': 'وقت',
    'h_city': 'شہر',
    'h_urban_area': 'شہری رقبہ (km2)',
    'h_pos_area': 'عوامی کھلی جگہوں کا رقبہ (km2)',
    'h_las': 'سڑکوں کے لیے مختص زمین (km2)',
    'h_ops_las': 'عوامی کھلی جگہ + سڑکوں کے لیے مختص زمین (km2)',
    'h_prop_ops_las': 'عوامی کھلی جگہ + سڑکوں کے لیے مختص زمین والے شہری رقبے کا '
                      'تناسب (%)',
    'h_total_pop': 'کل شہری آبادی',
    'h_pop_pos': 'عوامی کھلی جگہوں تک رسائی والی آبادی',
    'h_pop_bus': 'کم گنجائش والے ٹرانسپورٹ اسٹاپ (بس اسٹاپ، لائٹ ریل اسٹاپ) تک '
                 'رسائی والی آبادی',
    'h_pop_hc': 'زیادہ گنجائش والے ٹرانسپورٹ (ریل + فیری) تک رسائی والی آبادی',
    'h_pop_comb': 'مجموعی عوامی ٹرانسپورٹ تک رسائی والی آبادی',
    'h_pct_pos': 'عوامی کھلی جگہوں تک رسائی والی آبادی کا فیصد',
    'h_pct_bus': 'کم گنجائش والے ٹرانسپورٹ اسٹاپ (بس اسٹاپ، لائٹ ریل اسٹاپ) تک '
                 'رسائی والی آبادی کا فیصد',
    'h_pct_hc': 'زیادہ گنجائش والے ٹرانسپورٹ تک رسائی والی آبادی کا فیصد',
    'h_pct_comb': 'مجموعی عوامی ٹرانسپورٹ تک رسائی والی آبادی کا فیصد',
    'h_pop_source': 'آبادی کے ڈیٹا کا ماخذ',
    'src_household': 'گھرانوں کے نقاط',
    'src_raster': 'گرڈ شدہ راسٹر',
    'src_field': 'فیلڈ',
}


# ---------------------------------------------------------- pa: ਪੰਜਾਬੀ
_EXTRA_TEXT['pa'] = {
    'win_title': 'SDG 11.2.1 ਅਤੇ 11.7.1 ਅੰਕੜਿਆਂ ਦੀ ਗਣਨਾ',
    'subtitle': 'ਸ਼ਹਿਰੀ ਖੇਤਰ ਤੱਕ ਪਹਿਲਾਂ ਕਲਿੱਪ -> ਮੁੜ-ਪ੍ਰੋਜੈਕਸ਼ਨ + ਜਿਓਮੈਟਰੀ ਸੁਧਾਰ -> '
                'ਜਨਤਕ ਖੁੱਲ੍ਹੀਆਂ ਥਾਵਾਂ ਕਲਿੱਪ -> ਹੱਦ ਬਿੰਦੂ -> ਸੇਵਾ ਖੇਤਰ -> ਉੱਤਲ ਘੇਰਾ -> '
                'ਕਲਿੱਪ -> ਰਲੇਵਾਂ -> ਸੇਵਾ ਖੇਤਰਾਂ ਵਿੱਚ ਆਬਾਦੀ -> ਸੜਕ ਦੀ ਚੌੜਾਈ ਜੋੜਨਾ -> '
                'ਬਫ਼ਰ -> ਰਲੇਵਾਂ -> ਕਲਿੱਪ (ਸੜਕਾਂ ਲਈ ਨਿਰਧਾਰਿਤ ਜ਼ਮੀਨ) -> ਅੰਕੜਾ ਸਾਰਣੀ',
    'language': 'ਭਾਸ਼ਾ:',
    'tab_layers': 'ਪਰਤਾਂ',
    'tab_distances': 'ਦੂਰੀਆਂ',
    'tab_output': 'ਨਤੀਜੇ',
    'progress': 'ਪ੍ਰਗਤੀ',
    'btn_run': 'ਵਿਸ਼ਲੇਸ਼ਣ ਚਲਾਓ',
    'btn_cancel': 'ਰੱਦ ਕਰੋ',
    'btn_reset': 'ਲੌਗ ਸਾਫ਼ ਕਰੋ',
    'btn_close': 'ਬੰਦ ਕਰੋ',
    'grp_streets': 'ਸੜਕਾਂ',
    'note_streets': 'ਨੈੱਟਵਰਕ ਰੂਟਿੰਗ ਲਈ ਵਰਤੀ ਜਾਂਦੀ ਸੜਕਾਂ ਦੀ ਪਰਤ',
    'grp_urban': 'ਸ਼ਹਿਰੀ ਹੱਦ',
    'note_urban': 'ਸ਼ਹਿਰੀ ਫੈਲਾਅ ਨੂੰ ਪਰਿਭਾਸ਼ਿਤ ਕਰਨ ਵਾਲੀ ਬਹੁਭੁਜ ਪਰਤ',
    'grp_pop_raster': 'ਗਰਿੱਡ ਅਧਾਰਿਤ ਆਬਾਦੀ (ਰਾਸਟਰ)',
    'note_pop_raster': 'ਗਰਿੱਡ ਅਧਾਰਿਤ ਆਬਾਦੀ ਡੇਟਾਸੈੱਟ। ਇਹ ਜਾਂ ਹੇਠਾਂ ਘਰੇਲੂ ਆਬਾਦੀ '
                       '(ਬਿੰਦੂ) ਦਿਓ - ਦੋਵਾਂ ਵਿੱਚੋਂ ਇੱਕ ਲਾਜ਼ਮੀ ਹੈ।',
    'grp_hh': 'ਘਰੇਲੂ ਆਬਾਦੀ (ਬਿੰਦੂ)',
    'note_hh': 'ਘਰ ਪੱਧਰ ਦੀ ਆਬਾਦੀ ਗਿਣਤੀ ਵਾਲੀ ਬਿੰਦੂ ਪਰਤ। ਇਹ ਜਾਂ ਗਰਿੱਡ ਅਧਾਰਿਤ ਆਬਾਦੀ '
               'ਰਾਸਟਰ ਦਿਓ - ਦੋਵਾਂ ਵਿੱਚੋਂ ਇੱਕ ਲਾਜ਼ਮੀ ਹੈ। ਦੋਵੇਂ ਦੇਣ ਤੇ ਘਰੇਲੂ ਬਿੰਦੂ '
               'ਵਰਤੇ ਜਾਣਗੇ। ਹਰ ਸੇਵਾ ਖੇਤਰ ਦੀ ਆਬਾਦੀ = ਇਸਦੇ ਅੰਦਰਲੇ ਬਿੰਦੂਆਂ ਦੇ ਚੁਣੇ '
               'ਖੇਤਰ ਦਾ ਜੋੜ।',
    'lbl_pop_field': 'ਕੁੱਲ ਆਬਾਦੀ ਵਾਲਾ ਖੇਤਰ (ਹਰ ਘਰੇਲੂ ਬਿੰਦੂ ਲਈ):',
    'grp_pos': 'ਜਨਤਕ ਖੁੱਲ੍ਹੀਆਂ ਥਾਵਾਂ (ਬਹੁਭੁਜ)',
    'note_pos': 'ਜਨਤਾ ਲਈ ਪਹੁੰਚਯੋਗ ਅਣਵਿਕਸਿਤ ਜਾਂ ਖੁੱਲ੍ਹੀ ਜ਼ਮੀਨ ਦੀਆਂ ਬਹੁਭੁਜ ਪਰਤਾਂ, ਜੋ '
                'ਵਸਨੀਕਾਂ ਨੂੰ ਮਨੋਰੰਜਨ ਥਾਵਾਂ ਦਿੰਦੀਆਂ ਅਤੇ ਵਾਤਾਵਰਣ ਦੀ ਗੁਣਵੱਤਾ ਵਧਾਉਂਦੀਆਂ '
                'ਹਨ। ਜਿਵੇਂ: ਪਾਰਕ, ਬਾਗ਼, ਖੇਡ ਮੈਦਾਨ, ਜਨਤਕ ਤੱਟ, ਦਰਿਆ ਕਿਨਾਰੇ ਅਤੇ ਜਲ-ਤਟ',
    'grp_bus': 'ਘੱਟ ਸਮਰੱਥਾ ਵਾਲੇ ਆਵਾਜਾਈ ਸਟਾਪ (ਬੱਸ ਸਟਾਪ, ਲਾਈਟ ਰੇਲ ਸਟਾਪ)',
    'note_bus': 'ਬੱਸ ਸਟਾਪ / ਲਾਈਟ ਰੇਲ ਸਟਾਪ ਦੀਆਂ ਥਾਵਾਂ ਦੀ ਬਿੰਦੂ ਪਰਤ',
    'grp_rail': 'ਉੱਚ ਸਮਰੱਥਾ ਵਾਲੇ ਆਵਾਜਾਈ ਸਟਾਪ (ਰੇਲਵੇ ਸਟੇਸ਼ਨ, ਮੈਟਰੋ ਸਟੇਸ਼ਨ)',
    'note_rail': 'ਰੇਲਵੇ / ਮੈਟਰੋ ਸਟੇਸ਼ਨਾਂ ਦੀਆਂ ਥਾਵਾਂ ਦੀ ਬਿੰਦੂ ਪਰਤ',
    'grp_ferry': 'ਉੱਚ ਸਮਰੱਥਾ ਵਾਲੇ ਆਵਾਜਾਈ ਸਟਾਪ (ਫੈਰੀ ਘਾਟ)',
    'note_ferry': 'ਫੈਰੀ ਟਰਮੀਨਲਾਂ ਦੀਆਂ ਥਾਵਾਂ ਦੀ ਬਿੰਦੂ ਪਰਤ',
    'grp_widths': 'ਮਾਪੀ ਗਈ ਸੜਕ ਚੌੜਾਈ (CSV ਸਾਰਣੀ)',
    'note_widths': 'ਸੜਕਾਂ ਲਈ ਨਿਰਧਾਰਿਤ ਜ਼ਮੀਨ ਦੀ ਗਣਨਾ ਵਿੱਚ ਵਰਤੀ ਜਾਂਦੀ ਹੈ। ਕਾਲਮ 1 = '
                   'ਸੜਕ ਸ਼੍ਰੇਣੀ (ਹੇਠਾਂ ਚੁਣੇ ਸੜਕ ਸ਼੍ਰੇਣੀ ਖੇਤਰ ਨਾਲ ਮਿਲਾਈ ਜਾਂਦੀ ਹੈ), ਕਾਲਮ '
                   '2 = ਮੀਟਰਾਂ ਵਿੱਚ ਮਾਪੀ ਚੌੜਾਈ। ਜੇ CSV ਨਾ ਦਿੱਤੀ ਜਾਵੇ ਅਤੇ ਸ਼੍ਰੇਣੀ ਖੇਤਰ '
                   'ਨਾ ਹੋਵੇ, ਤਾਂ ਸੜਕਾਂ ਲਈ ਨਿਰਧਾਰਿਤ ਜ਼ਮੀਨ = 0।',
    'btn_browse_csv': 'CSV ਚੁਣੋ...',
    'grp_catfield': 'ਸੜਕ ਸ਼੍ਰੇਣੀ ਖੇਤਰ (ਸੜਕਾਂ ਦੀ ਪਰਤ ਤੋਂ)',
    'note_catfield': 'ਸੜਕਾਂ ਦੀ ਪਰਤ ਦਾ ਉਹ ਖੇਤਰ ਜਿਸ ਵਿੱਚ ਸੜਕ ਸ਼੍ਰੇਣੀਆਂ ਹਨ, ਚੌੜਾਈ ਜੋੜਨ '
                     'ਲਈ ਵਰਤਿਆ ਜਾਂਦਾ ਹੈ। \'fclass\', \'highway\' ਜਾਂ \'type\' '
                     'ਮੌਜੂਦ ਹੋਵੇ ਤਾਂ ਆਪਣੇ-ਆਪ ਚੁਣਿਆ ਜਾਂਦਾ ਹੈ; ਨਹੀਂ ਤਾਂ ਇੱਥੇ ਖੇਤਰ ਚੁਣੋ। '
                     'ਆਪਣੇ-ਆਪ ਪਛਾਣ ਲਈ ਖਾਲੀ ਛੱਡੋ।',
    'grp_crs': 'ਟੀਚਾ ਕੋਆਰਡੀਨੇਟ ਹਵਾਲਾ ਪ੍ਰਣਾਲੀ (ਪ੍ਰੋਜੈਕਟਿਡ, ਮੀਟਰਾਂ ਵਿੱਚ - ਜਿਵੇਂ ਸ਼ਹਿਰੀ '
               'ਖੇਤਰ ਦਾ UTM ਜ਼ੋਨ)',
    'dist_header': 'ਨੈੱਟਵਰਕ ਦੂਰੀ ਸੀਮਾ:',
    'dist_pos': 'ਜਨਤਕ ਖੁੱਲ੍ਹੀਆਂ ਥਾਵਾਂ',
    'spacing_header': 'ਜਨਤਕ ਖੁੱਲ੍ਹੀਆਂ ਥਾਵਾਂ ਦੇ ਹੱਦ ਬਿੰਦੂਆਂ ਵਿਚਕਾਰ ਦੂਰੀ:',
    'spacing_note': 'ਹਰ ਖੁੱਲ੍ਹੀ ਥਾਂ ਦੀ ਰੂਪਰੇਖਾ ਨਾਲ ਰੱਖੇ ਸ਼ੁਰੂਆਤੀ ਬਿੰਦੂ। 100 ਮੀਟਰ ਮਿਆਰੀ '
                    'ਹੈ; ਵੱਧ ਦੂਰੀ (ਜਿਵੇਂ 200 ਮੀਟਰ) ਬਹੁਤ ਸਾਰੇ ਵੱਡੇ ਪਾਰਕਾਂ ਵਾਲੇ ਸ਼ਹਿਰਾਂ '
                    'ਲਈ ਤੇਜ਼ ਹੈ ਪਰ ਥੋੜ੍ਹੀ ਘੱਟ ਸਹੀ।',
    'perf_header': 'ਕਾਰਗੁਜ਼ਾਰੀ:',
    'chk_preclip': 'ਇਨਪੁੱਟ ਨੂੰ ਪਹਿਲਾਂ ਸ਼ਹਿਰੀ ਖੇਤਰ ਤੱਕ ਕਲਿੱਪ ਕਰੋ',
    'note_preclip': 'ਸਿਫ਼ਾਰਸ਼ੀ। ਸਿਰਫ਼ ਸ਼ਹਿਰੀ ਖੇਤਰ ਦੀ ਖੋਜ ਸੀਮਾ ਅੰਦਰਲੀਆਂ ਸੜਕਾਂ, ਸਟਾਪ ਅਤੇ '
                    'ਖੁੱਲ੍ਹੀਆਂ ਥਾਵਾਂ ਰੱਖਦਾ ਹੈ - ਕੌਮੀ/ਖੇਤਰੀ ਡੇਟਾ ਨਾਲ ਬਹੁਤ ਤੇਜ਼।',
    'chk_memory': 'ਵਿਚਕਾਰਲੀਆਂ ਪਰਤਾਂ ਮੈਮਰੀ ਵਿੱਚ ਰੱਖੋ',
    'note_memory': 'ਤੇਜ਼। ਸਿਰਫ਼ ਤਾਂ ਹੀ ਨਿਸ਼ਾਨ ਹਟਾਓ ਜੇ ਕੰਪਿਊਟਰ ਦੀ RAM ਘੱਟ ਪੈ ਜਾਵੇ।',
    'chk_native': 'QGIS ਦਾ ਮੂਲ ਸੇਵਾ ਖੇਤਰ ਐਲਗੋਰਿਦਮ ਵਰਤੋ',
    'note_native': 'ਸਿਰਫ਼ ਜਾਂਚ ਲਈ - ਬਹੁਤ ਸਾਰੇ ਸ਼ੁਰੂਆਤੀ ਬਿੰਦੂਆਂ ਨਾਲ ਬਹੁਤ ਹੌਲੀ। '
                   'ਡਿਫ਼ਾਲਟ ਤੇਜ਼ ਸੀਮਤ ਖੋਜ ਹੈ (ਨਤੀਜੇ ਇੱਕੋ ਜਿਹੇ)।',
    'grp_city': 'ਸ਼ਹਿਰ ਦਾ ਨਾਮ (ਸੁਝਾਅ: ਵਿਸ਼ੇਸ਼ ਅੱਖਰਾਂ ਤੋਂ ਬਚੋ)',
    'city_placeholder': 'ਜਿਵੇਂ Mombasa',
    'lbl_output_folder': 'ਨਤੀਜਾ ਫੋਲਡਰ:',
    'btn_browse': 'ਚੁਣੋ...',
    'info_block':
        "ਰੱਖੀਆਂ ਜਾਣ ਵਾਲੀਆਂ ਅੰਤਿਮ ਫ਼ਾਈਲਾਂ:\n"
        "  ਕਲਿੱਪ ਅਤੇ ਰਲੇਵੇਂ ਵਾਲੇ ਸੇਵਾ ਖੇਤਰ:\n"
        "  SA_POS_dissolved.shp                ਜਨਤਕ ਖੁੱਲ੍ਹੀਆਂ ਥਾਵਾਂ\n"
        "  SA_Bus_dissolved.shp                ਘੱਟ ਸਮਰੱਥਾ ਵਾਲੇ ਸਟਾਪ\n"
        "  SA_Ferry_dissolved.shp              ਫੈਰੀ ਘਾਟ\n"
        "  SA_Rail_dissolved.shp               ਰੇਲਵੇ ਸਟੇਸ਼ਨ\n"
        "  SA_HighCapacity_dissolved.shp       ਉੱਚ ਸਮਰੱਥਾ (ਰੇਲ + ਫੈਰੀ)\n"
        "  SA_CombinedTransport_dissolved.shp  ਸੰਯੁਕਤ ਜਨਤਕ ਆਵਾਜਾਈ\n"
        "  ਵੱਖਰੇ (ਹਰ ਸਟਾਪ ਦੇ) ਸੇਵਾ ਖੇਤਰ:\n"
        "  SA_Bus_individual.shp / SA_Ferry_individual.shp / SA_Rail_individual.shp\n"
        "  ZonalStats_*.shp                    ਸੇਵਾ ਖੇਤਰ + pop_sum ਖੇਤਰ\n"
        "  LAS_streets_dissolved.shp           ਸੜਕਾਂ ਲਈ ਨਿਰਧਾਰਿਤ ਜ਼ਮੀਨ\n"
        "  {city}_statistics_11.2.1_and_11.7.1.xlsx\n\n"
        "ਨੋਟ:\n"
        "  - ਪ੍ਰੋਸੈਸਿੰਗ ਤੋਂ ਪਹਿਲਾਂ ਜਿਓਮੈਟਰੀ ਆਪਣੇ-ਆਪ ਸੁਧਾਰੀ ਜਾਂਦੀ ਹੈ।\n"
        "  - ਆਬਾਦੀ: ਘਰੇਲੂ ਬਿੰਦੂ (ਆਬਾਦੀ ਖੇਤਰ ਦਾ ਜੋੜ) ਜੇ ਦਿੱਤੇ ਹੋਣ,\n"
        "    ਨਹੀਂ ਤਾਂ ਗਰਿੱਡ ਅਧਾਰਿਤ ਆਬਾਦੀ ਰਾਸਟਰ।\n"
        "  - ਜਨਤਕ ਖੁੱਲ੍ਹੀਆਂ ਥਾਵਾਂ ਦਾ ਰਕਬਾ ਸ਼ਹਿਰੀ ਹੱਦ ਤੱਕ ਕਲਿੱਪ ਕਰਨ ਤੋਂ ਬਾਅਦ ਮਾਪਿਆ ਜਾਂਦਾ ਹੈ।\n"
        "  - ਇਨਪੁੱਟ ਸ਼ਹਿਰੀ ਖੇਤਰ + ਖੋਜ ਸੀਮਾ ਤੱਕ ਕਲਿੱਪ ਹੁੰਦਾ ਹੈ ਅਤੇ ਵਿਚਕਾਰਲੀਆਂ\n"
        "    ਪਰਤਾਂ ਮੈਮਰੀ ਵਿੱਚ ਰਹਿੰਦੀਆਂ ਹਨ (ਦੂਰੀਆਂ ਟੈਬ ਵੇਖੋ)।\n"
        "  - ਸੰਯੁਕਤ ਆਵਾਜਾਈ = ਘੱਟ ਸਮਰੱਥਾ ਵਾਲੇ ਸਟਾਪ + ਫੈਰੀ + ਰੇਲ\n"
        "    (ਜਨਤਕ ਖੁੱਲ੍ਹੀਆਂ ਥਾਵਾਂ ਸ਼ਾਮਲ ਨਹੀਂ)।\n"
        "  - ਸੜਕਾਂ ਲਈ ਨਿਰਧਾਰਿਤ ਜ਼ਮੀਨ: ਚੌੜਾਈ ਅਨੁਸਾਰ ਸੜਕਾਂ ਦਾ ਬਫ਼ਰ,\n"
        "    ਰਲੇਵਾਂ ਕਰਕੇ ਸ਼ਹਿਰੀ ਫੈਲਾਅ ਤੱਕ ਕਲਿੱਪ।\n"
        "  - ਅੰਕੜਾ ਸਾਰਣੀ ਚੁਣੀ ਭਾਸ਼ਾ ਵਿੱਚ ਲਿਖੀ ਜਾਂਦੀ ਹੈ।\n"
        "  - ਗ਼ਲਤੀ ਤੋਂ ਬਾਅਦ ਬਟਨ ਮੁੜ ਚਾਲੂ ਕਰਨ ਲਈ 'ਲੌਗ ਸਾਫ਼ ਕਰੋ' ਵਰਤੋ।",
    'msg_running_title': 'ਚੱਲ ਰਿਹਾ ਹੈ',
    'msg_cannot_reset': 'ਵਿਸ਼ਲੇਸ਼ਣ ਚੱਲਦੇ ਸਮੇਂ ਸਾਫ਼ ਨਹੀਂ ਕੀਤਾ ਜਾ ਸਕਦਾ। ਪਹਿਲਾਂ ਰੱਦ ਕਰੋ।',
    'msg_missing_layer': 'ਪਰਤ ਮੌਜੂਦ ਨਹੀਂ',
    'msg_select_streets': 'ਕਿਰਪਾ ਕਰਕੇ ਸੜਕਾਂ ਦੀ ਪਰਤ ਚੁਣੋ।',
    'msg_select_urban': 'ਕਿਰਪਾ ਕਰਕੇ ਸ਼ਹਿਰੀ ਹੱਦ ਦੀ ਪਰਤ ਚੁਣੋ।',
    'msg_missing_pop_title': 'ਆਬਾਦੀ ਡੇਟਾ ਮੌਜੂਦ ਨਹੀਂ',
    'msg_missing_pop': 'ਕਿਰਪਾ ਕਰਕੇ ਗਰਿੱਡ ਅਧਾਰਿਤ ਆਬਾਦੀ (ਰਾਸਟਰ) ਪਰਤ ਜਾਂ ਘਰੇਲੂ ਆਬਾਦੀ '
                       '(ਬਿੰਦੂ) ਪਰਤ ਚੁਣੋ - ਦੋਵਾਂ ਵਿੱਚੋਂ ਇੱਕ ਲਾਜ਼ਮੀ ਹੈ।',
    'msg_missing_popfield_title': 'ਆਬਾਦੀ ਖੇਤਰ ਮੌਜੂਦ ਨਹੀਂ',
    'msg_missing_popfield': 'ਕਿਰਪਾ ਕਰਕੇ ਘਰੇਲੂ ਆਬਾਦੀ (ਬਿੰਦੂ) ਪਰਤ ਲਈ ਕੁੱਲ ਆਬਾਦੀ ਵਾਲਾ '
                            'ਖੇਤਰ ਚੁਣੋ।',
    'msg_missing_city_title': 'ਸ਼ਹਿਰ ਦਾ ਨਾਮ ਮੌਜੂਦ ਨਹੀਂ',
    'msg_missing_city': 'ਕਿਰਪਾ ਕਰਕੇ ਸ਼ਹਿਰ ਦਾ ਨਾਮ ਦਰਜ ਕਰੋ।',
    'msg_missing_output_title': 'ਨਤੀਜਾ ਫੋਲਡਰ ਮੌਜੂਦ ਨਹੀਂ',
    'msg_missing_output': 'ਕਿਰਪਾ ਕਰਕੇ ਨਤੀਜਾ ਫੋਲਡਰ ਚੁਣੋ।',
    'msg_invalid_crs_title': 'ਅਵੈਧ CRS',
    'msg_invalid_crs': 'ਕਿਰਪਾ ਕਰਕੇ ਵੈਧ ਟੀਚਾ CRS ਚੁਣੋ।',
    'msg_no_transport_title': 'ਕੋਈ ਆਵਾਜਾਈ ਪਰਤ ਨਹੀਂ',
    'msg_no_transport': 'ਜਨਤਕ ਖੁੱਲ੍ਹੀਆਂ ਥਾਵਾਂ / ਘੱਟ ਸਮਰੱਥਾ / ਫੈਰੀ / ਰੇਲ ਦੀ ਕੋਈ ਪਰਤ '
                        'ਨਹੀਂ ਚੁਣੀ ਗਈ। ਸਿਰਫ਼ ਸ਼ਹਿਰੀ ਖੇਤਰ ਅਤੇ ਸੜਕਾਂ ਦੀ ਪ੍ਰੋਸੈਸਿੰਗ ਹੋਵੇਗੀ। '
                        'ਜਾਰੀ ਰੱਖਣਾ ਹੈ?',
    'msg_complete': 'ਪੂਰਾ',
    'msg_error': 'ਗ਼ਲਤੀ',
    'msg_failed': 'ਵਿਸ਼ਲੇਸ਼ਣ ਅਸਫ਼ਲ ਰਿਹਾ। ਵੇਰਵੇ ਲਈ ਲੌਗ ਵੇਖੋ।\n\n'
                  '\'ਲੌਗ ਸਾਫ਼ ਕਰੋ\' ਤੇ ਕਲਿੱਕ ਕਰਕੇ ਮੁੜ ਚਲਾਓ।',
    'msg_close_running': 'ਵਿਸ਼ਲੇਸ਼ਣ ਅਜੇ ਚੱਲ ਰਿਹਾ ਹੈ। ਰੱਦ ਕਰਕੇ ਬੰਦ ਕਰਨਾ ਹੈ?',
    'msg_cancel_requested': 'ਰੱਦ ਕਰਨ ਦੀ ਬੇਨਤੀ ਕੀਤੀ ਗਈ...',
    'dlg_select_output': 'ਨਤੀਜਾ ਫੋਲਡਰ ਚੁਣੋ',
    'dlg_select_csv': 'ਮਾਪੀ ਗਈ ਸੜਕ ਚੌੜਾਈ ਦੀ CSV ਚੁਣੋ',
    'csv_filter': 'CSV ਫ਼ਾਈਲਾਂ (*.csv *.txt);;ਸਾਰੀਆਂ ਫ਼ਾਈਲਾਂ (*)',
    'msg_invalid_csv_title': 'ਅਵੈਧ CSV',
    'msg_invalid_csv': 'ਪੜ੍ਹੀ ਨਹੀਂ ਜਾ ਸਕੀ:',
    'msg_widths_title': 'ਸੜਕ ਚੌੜਾਈ CSV',
    'msg_widths_cols': 'ਸੜਕ ਚੌੜਾਈ ਸਾਰਣੀ ਵਿੱਚ ਘੱਟੋ-ਘੱਟ ਦੋ ਕਾਲਮ (ਸੜਕ ਸ਼੍ਰੇਣੀ, ਚੌੜਾਈ) '
                       'ਹੋਣੇ ਚਾਹੀਦੇ ਹਨ। ਇਸਨੂੰ ਅਣਡਿੱਠਾ ਕੀਤਾ ਜਾਵੇਗਾ।',
    'res_done': 'ਪੂਰਾ!',
    'res_las': 'ਸੜਕਾਂ ਲਈ ਨਿਰਧਾਰਿਤ ਜ਼ਮੀਨ',
    'res_stats': 'ਅੰਕੜਾ ਸਾਰਣੀ (CSV)',
    'res_excel': 'ਅੰਕੜਾ ਵਰਕਬੁੱਕ (Excel)',
    'res_roads': 'ਸੜਕ ਸਾਰਣੀ',
    'res_folder': 'ਫੋਲਡਰ',
    'res_time': 'ਸਮਾਂ',
    'h_city': 'ਸ਼ਹਿਰ',
    'h_urban_area': 'ਸ਼ਹਿਰੀ ਰਕਬਾ (ਵਰਗ ਕਿਮੀ)',
    'h_pos_area': 'ਜਨਤਕ ਖੁੱਲ੍ਹੀਆਂ ਥਾਵਾਂ ਦਾ ਰਕਬਾ (ਵਰਗ ਕਿਮੀ)',
    'h_las': 'ਸੜਕਾਂ ਲਈ ਨਿਰਧਾਰਿਤ ਜ਼ਮੀਨ (ਵਰਗ ਕਿਮੀ)',
    'h_ops_las': 'ਜਨਤਕ ਖੁੱਲ੍ਹੀਆਂ ਥਾਵਾਂ + ਸੜਕਾਂ ਲਈ ਨਿਰਧਾਰਿਤ ਜ਼ਮੀਨ (ਵਰਗ ਕਿਮੀ)',
    'h_prop_ops_las': 'ਸ਼ਹਿਰੀ ਰਕਬੇ ਵਿੱਚ ਜਨਤਕ ਖੁੱਲ੍ਹੀਆਂ ਥਾਵਾਂ + ਸੜਕਾਂ ਲਈ ਨਿਰਧਾਰਿਤ ਜ਼ਮੀਨ '
                      'ਦਾ ਅਨੁਪਾਤ (%)',
    'h_total_pop': 'ਕੁੱਲ ਸ਼ਹਿਰੀ ਆਬਾਦੀ',
    'h_pop_pos': 'ਜਨਤਕ ਖੁੱਲ੍ਹੀਆਂ ਥਾਵਾਂ ਤੱਕ ਪਹੁੰਚ ਵਾਲੀ ਆਬਾਦੀ',
    'h_pop_bus': 'ਘੱਟ ਸਮਰੱਥਾ ਵਾਲੇ ਆਵਾਜਾਈ ਸਟਾਪਾਂ (ਬੱਸ ਸਟਾਪ, ਲਾਈਟ ਰੇਲ ਸਟਾਪ) ਤੱਕ ਪਹੁੰਚ '
                 'ਵਾਲੀ ਆਬਾਦੀ',
    'h_pop_hc': 'ਉੱਚ ਸਮਰੱਥਾ ਵਾਲੀ ਆਵਾਜਾਈ (ਰੇਲ + ਫੈਰੀ) ਤੱਕ ਪਹੁੰਚ ਵਾਲੀ ਆਬਾਦੀ',
    'h_pop_comb': 'ਸੰਯੁਕਤ ਜਨਤਕ ਆਵਾਜਾਈ ਤੱਕ ਪਹੁੰਚ ਵਾਲੀ ਆਬਾਦੀ',
    'h_pct_pos': 'ਜਨਤਕ ਖੁੱਲ੍ਹੀਆਂ ਥਾਵਾਂ ਤੱਕ ਪਹੁੰਚ ਵਾਲੀ ਆਬਾਦੀ ਦੀ ਪ੍ਰਤੀਸ਼ਤਤਾ',
    'h_pct_bus': 'ਘੱਟ ਸਮਰੱਥਾ ਵਾਲੇ ਆਵਾਜਾਈ ਸਟਾਪਾਂ (ਬੱਸ ਸਟਾਪ, ਲਾਈਟ ਰੇਲ ਸਟਾਪ) ਤੱਕ ਪਹੁੰਚ '
                 'ਵਾਲੀ ਆਬਾਦੀ ਦੀ ਪ੍ਰਤੀਸ਼ਤਤਾ',
    'h_pct_hc': 'ਉੱਚ ਸਮਰੱਥਾ ਵਾਲੀ ਆਵਾਜਾਈ ਤੱਕ ਪਹੁੰਚ ਵਾਲੀ ਆਬਾਦੀ ਦੀ ਪ੍ਰਤੀਸ਼ਤਤਾ',
    'h_pct_comb': 'ਸੰਯੁਕਤ ਜਨਤਕ ਆਵਾਜਾਈ ਤੱਕ ਪਹੁੰਚ ਵਾਲੀ ਆਬਾਦੀ ਦੀ ਪ੍ਰਤੀਸ਼ਤਤਾ',
    'h_pop_source': 'ਆਬਾਦੀ ਡੇਟਾ ਦਾ ਸਰੋਤ',
    'src_household': 'ਘਰੇਲੂ ਬਿੰਦੂ',
    'src_raster': 'ਗਰਿੱਡ ਰਾਸਟਰ',
    'src_field': 'ਖੇਤਰ',
}


# ---------------------------------------------------------- mr: मराठी
_EXTRA_TEXT['mr'] = {
    'win_title': 'SDG 11.2.1 आणि 11.7.1 सांख्यिकी गणना',
    'subtitle': 'शहरी क्षेत्रापर्यंत पूर्व-क्लिप -> पुनर्प्रक्षेपण + भूमिती दुरुस्ती -> '
                'सार्वजनिक खुल्या जागांचे क्लिपिंग -> सीमा बिंदू -> सेवा क्षेत्र -> '
                'बहिर्वक्र आवरण -> क्लिप -> विलीनीकरण -> सेवा क्षेत्रांतील लोकसंख्या '
                '-> रस्ता रुंदी जोडणे -> बफर -> विलीनीकरण -> क्लिप (रस्त्यांसाठी '
                'राखीव जमीन) -> सांख्यिकी तक्ता',
    'language': 'भाषा:',
    'tab_layers': 'स्तर',
    'tab_distances': 'अंतरे',
    'tab_output': 'आउटपुट',
    'progress': 'प्रगती',
    'btn_run': 'विश्लेषण चालवा',
    'btn_cancel': 'रद्द करा',
    'btn_reset': 'लॉग साफ करा',
    'btn_close': 'बंद करा',
    'grp_streets': 'रस्ते',
    'note_streets': 'नेटवर्कवरील मार्ग निश्चितीसाठी वापरला जाणारा रस्त्यांचा स्तर',
    'grp_urban': 'शहरी सीमा',
    'note_urban': 'शहरी विस्तार निश्चित करणारा बहुभुज स्तर',
    'grp_pop_raster': 'ग्रिड आधारित लोकसंख्या (रास्टर)',
    'note_pop_raster': 'ग्रिड आधारित लोकसंख्या डेटासेट. हा किंवा खालील कुटुंब लोकसंख्या '
                       '(बिंदू) द्या - दोन्हींपैकी एक आवश्यक आहे.',
    'grp_hh': 'कुटुंब लोकसंख्या (बिंदू)',
    'note_hh': 'कुटुंब स्तरावरील लोकसंख्या असलेला बिंदू स्तर. हा किंवा ग्रिड आधारित '
               'लोकसंख्या रास्टर द्या - दोन्हींपैकी एक आवश्यक आहे. दोन्ही दिल्यास '
               'कुटुंब बिंदू वापरले जातात. प्रत्येक सेवा क्षेत्राची लोकसंख्या = '
               'त्यातील बिंदूंच्या निवडलेल्या फील्डची बेरीज.',
    'lbl_pop_field': 'एकूण लोकसंख्येचे फील्ड (प्रति कुटुंब बिंदू):',
    'grp_pos': 'सार्वजनिक खुल्या जागा (बहुभुज)',
    'note_pos': 'लोकांसाठी खुली असलेली अविकसित किंवा मोकळी जमीन दर्शवणारे बहुभुज '
                'स्तर, जे रहिवाशांना मनोरंजनाची ठिकाणे देतात आणि पर्यावरणाचा दर्जा '
                'सुधारतात. उदा. उद्याने, बागा, खेळाची मैदाने, सार्वजनिक किनारे, '
                'नदीकाठ आणि जलकिनारे',
    'grp_bus': 'कमी क्षमतेच्या वाहतुकीचे थांबे (बस थांबे, लाइट रेल थांबे)',
    'note_bus': 'बस थांबे / लाइट रेल थांब्यांच्या ठिकाणांचा बिंदू स्तर',
    'grp_rail': 'उच्च क्षमतेच्या वाहतुकीचे थांबे (रेल्वे स्थानके, मेट्रो स्थानके)',
    'note_rail': 'रेल्वे / मेट्रो स्थानकांच्या ठिकाणांचा बिंदू स्तर',
    'grp_ferry': 'उच्च क्षमतेच्या वाहतुकीचे थांबे (फेरी धक्के)',
    'note_ferry': 'फेरी टर्मिनलच्या ठिकाणांचा बिंदू स्तर',
    'grp_widths': 'मोजलेली रस्ता रुंदी (CSV तक्ता)',
    'note_widths': 'रस्त्यांसाठी राखीव जमिनीच्या गणनेसाठी वापरले जाते. स्तंभ 1 = रस्ता '
                   'प्रकार (खाली निवडलेल्या रस्ता प्रकार फील्डशी जुळवला जातो), स्तंभ 2 '
                   '= मीटरमध्ये मोजलेली रुंदी. CSV न दिल्यास आणि प्रकार फील्ड नसल्यास '
                   'रस्त्यांसाठी राखीव जमीन = 0.',
    'btn_browse_csv': 'CSV निवडा...',
    'grp_catfield': 'रस्ता प्रकार फील्ड (रस्ते स्तरातून)',
    'note_catfield': 'रस्ते स्तरातील रस्त्यांचे प्रकार असलेले फील्ड, रुंदी जोडण्यासाठी '
                     'वापरले जाते. \'fclass\', \'highway\' किंवा \'type\' असल्यास '
                     'आपोआप निवडले जाते; अन्यथा येथे फील्ड निवडा. आपोआप ओळखीसाठी '
                     'रिकामे ठेवा.',
    'grp_crs': 'लक्ष्य निर्देशांक संदर्भ प्रणाली (प्रक्षेपित, मीटरमध्ये - उदा. शहरी '
               'क्षेत्राचा UTM विभाग)',
    'dist_header': 'नेटवर्क अंतर मर्यादा:',
    'dist_pos': 'सार्वजनिक खुल्या जागा',
    'spacing_header': 'सार्वजनिक खुल्या जागांच्या सीमा बिंदूंमधील अंतर:',
    'spacing_note': 'प्रत्येक खुल्या जागेच्या बाह्यरेषेवर ठेवलेले प्रारंभ बिंदू. 100 मीटर '
                    'मानक आहे; जास्त अंतर (उदा. 200 मीटर) अनेक मोठी उद्याने असलेल्या '
                    'शहरांसाठी जलद आहे पण थोडे कमी अचूक.',
    'perf_header': 'कार्यक्षमता:',
    'chk_preclip': 'इनपुट आधीच शहरी क्षेत्रापर्यंत क्लिप करा',
    'note_preclip': 'शिफारस केलेले. फक्त शहरी क्षेत्राच्या शोध मर्यादेतील रस्ते, थांबे '
                    'आणि खुल्या जागा ठेवते - राष्ट्रीय/प्रादेशिक डेटासाठी खूप जलद.',
    'chk_memory': 'मधले स्तर मेमरीत ठेवा',
    'note_memory': 'जलद. संगणकाची RAM कमी पडल्यासच खूण काढा.',
    'chk_native': 'QGIS चा मूळ सेवा क्षेत्र अल्गोरिदम वापरा',
    'note_native': 'फक्त पडताळणीसाठी - अनेक प्रारंभ बिंदू असल्यास खूप संथ. '
                   'डीफॉल्ट जलद मर्यादित शोध आहे (निकाल तेच).',
    'grp_city': 'शहराचे नाव (सूचना: विशेष वर्ण टाळा)',
    'city_placeholder': 'उदा. Mombasa',
    'lbl_output_folder': 'आउटपुट फोल्डर:',
    'btn_browse': 'निवडा...',
    'info_block':
        "जतन केल्या जाणाऱ्या अंतिम फाइल्स:\n"
        "  क्लिप आणि विलीन केलेली सेवा क्षेत्रे:\n"
        "  SA_POS_dissolved.shp                सार्वजनिक खुल्या जागा\n"
        "  SA_Bus_dissolved.shp                कमी क्षमतेचे थांबे\n"
        "  SA_Ferry_dissolved.shp              फेरी धक्के\n"
        "  SA_Rail_dissolved.shp               रेल्वे स्थानके\n"
        "  SA_HighCapacity_dissolved.shp       उच्च क्षमता (रेल्वे + फेरी)\n"
        "  SA_CombinedTransport_dissolved.shp  एकत्रित सार्वजनिक वाहतूक\n"
        "  स्वतंत्र (प्रति थांबा) सेवा क्षेत्रे:\n"
        "  SA_Bus_individual.shp / SA_Ferry_individual.shp / SA_Rail_individual.shp\n"
        "  ZonalStats_*.shp                    सेवा क्षेत्र + pop_sum फील्ड\n"
        "  LAS_streets_dissolved.shp           रस्त्यांसाठी राखीव जमीन\n"
        "  {city}_statistics_11.2.1_and_11.7.1.xlsx\n\n"
        "टिपा:\n"
        "  - प्रक्रियेपूर्वी भूमिती आपोआप दुरुस्त केली जाते.\n"
        "  - लोकसंख्या: कुटुंब बिंदू (लोकसंख्या फील्डची बेरीज) दिले असल्यास,\n"
        "    अन्यथा ग्रिड आधारित लोकसंख्या रास्टर.\n"
        "  - सार्वजनिक खुल्या जागांचे क्षेत्रफळ शहरी सीमेवर क्लिप केल्यानंतर मोजले जाते.\n"
        "  - इनपुट शहरी क्षेत्र + शोध मर्यादेपर्यंत क्लिप होते आणि मधले स्तर\n"
        "    मेमरीत ठेवले जातात (अंतरे टॅब पहा).\n"
        "  - एकत्रित वाहतूक = कमी क्षमतेचे थांबे + फेरी + रेल्वे\n"
        "    (सार्वजनिक खुल्या जागा वगळून).\n"
        "  - रस्त्यांसाठी राखीव जमीन: रुंदीनुसार रस्त्यांचा बफर,\n"
        "    विलीन करून शहरी विस्तारापर्यंत क्लिप.\n"
        "  - सांख्यिकी तक्ता निवडलेल्या भाषेत लिहिला जातो.\n"
        "  - त्रुटीनंतर बटणे पुन्हा सक्रिय करण्यासाठी 'लॉग साफ करा' वापरा.",
    'msg_running_title': 'चालू आहे',
    'msg_cannot_reset': 'विश्लेषण चालू असताना साफ करता येत नाही. आधी रद्द करा.',
    'msg_missing_layer': 'स्तर उपलब्ध नाही',
    'msg_select_streets': 'कृपया रस्त्यांचा स्तर निवडा.',
    'msg_select_urban': 'कृपया शहरी सीमा स्तर निवडा.',
    'msg_missing_pop_title': 'लोकसंख्या डेटा उपलब्ध नाही',
    'msg_missing_pop': 'कृपया ग्रिड आधारित लोकसंख्या (रास्टर) स्तर किंवा कुटुंब लोकसंख्या '
                       '(बिंदू) स्तर निवडा - दोन्हींपैकी एक आवश्यक आहे.',
    'msg_missing_popfield_title': 'लोकसंख्या फील्ड उपलब्ध नाही',
    'msg_missing_popfield': 'कृपया कुटुंब लोकसंख्या (बिंदू) स्तरासाठी एकूण लोकसंख्येचे '
                            'फील्ड निवडा.',
    'msg_missing_city_title': 'शहराचे नाव उपलब्ध नाही',
    'msg_missing_city': 'कृपया शहराचे नाव लिहा.',
    'msg_missing_output_title': 'आउटपुट उपलब्ध नाही',
    'msg_missing_output': 'कृपया आउटपुट फोल्डर निवडा.',
    'msg_invalid_crs_title': 'अवैध CRS',
    'msg_invalid_crs': 'कृपया वैध लक्ष्य CRS निवडा.',
    'msg_no_transport_title': 'वाहतूक स्तर नाहीत',
    'msg_no_transport': 'सार्वजनिक खुल्या जागा / कमी क्षमता / फेरी / रेल्वे यांचा कोणताही '
                        'स्तर निवडलेला नाही. फक्त शहरी क्षेत्र आणि रस्त्यांवर प्रक्रिया '
                        'होईल. सुरू ठेवायचे?',
    'msg_complete': 'पूर्ण',
    'msg_error': 'त्रुटी',
    'msg_failed': 'विश्लेषण अयशस्वी झाले. तपशीलासाठी लॉग पहा.\n\n'
                  '\'लॉग साफ करा\' वर क्लिक करून पुन्हा चालवा.',
    'msg_close_running': 'विश्लेषण अजून चालू आहे. रद्द करून बंद करायचे?',
    'msg_cancel_requested': 'रद्द करण्याची विनंती केली...',
    'dlg_select_output': 'आउटपुट फोल्डर निवडा',
    'dlg_select_csv': 'मोजलेल्या रस्ता रुंदीची CSV निवडा',
    'csv_filter': 'CSV फाइल्स (*.csv *.txt);;सर्व फाइल्स (*)',
    'msg_invalid_csv_title': 'अवैध CSV',
    'msg_invalid_csv': 'वाचता आले नाही:',
    'msg_widths_title': 'रस्ता रुंदी CSV',
    'msg_widths_cols': 'रस्ता रुंदी तक्त्यात किमान दोन स्तंभ (रस्ता प्रकार, रुंदी) असणे '
                       'आवश्यक आहे. तो दुर्लक्षित केला जाईल.',
    'res_done': 'पूर्ण!',
    'res_las': 'रस्त्यांसाठी राखीव जमीन',
    'res_stats': 'सांख्यिकी तक्ता (CSV)',
    'res_excel': 'सांख्यिकी वर्कबुक (Excel)',
    'res_roads': 'रस्ते तक्ता',
    'res_folder': 'फोल्डर',
    'res_time': 'वेळ',
    'h_city': 'शहर',
    'h_urban_area': 'शहरी क्षेत्रफळ (चौ. किमी)',
    'h_pos_area': 'सार्वजनिक खुल्या जागांचे क्षेत्रफळ (चौ. किमी)',
    'h_las': 'रस्त्यांसाठी राखीव जमीन (चौ. किमी)',
    'h_ops_las': 'सार्वजनिक खुल्या जागा + रस्त्यांसाठी राखीव जमीन (चौ. किमी)',
    'h_prop_ops_las': 'शहरी क्षेत्रफळातील सार्वजनिक खुल्या जागा + रस्त्यांसाठी राखीव '
                      'जमिनीचे प्रमाण (%)',
    'h_total_pop': 'एकूण शहरी लोकसंख्या',
    'h_pop_pos': 'सार्वजनिक खुल्या जागांपर्यंत पोहोच असलेली लोकसंख्या',
    'h_pop_bus': 'कमी क्षमतेच्या वाहतूक थांब्यांपर्यंत (बस थांबे, लाइट रेल थांबे) पोहोच '
                 'असलेली लोकसंख्या',
    'h_pop_hc': 'उच्च क्षमतेच्या वाहतुकीपर्यंत (रेल्वे + फेरी) पोहोच असलेली लोकसंख्या',
    'h_pop_comb': 'एकत्रित सार्वजनिक वाहतुकीपर्यंत पोहोच असलेली लोकसंख्या',
    'h_pct_pos': 'सार्वजनिक खुल्या जागांपर्यंत पोहोच असलेल्या लोकसंख्येची टक्केवारी',
    'h_pct_bus': 'कमी क्षमतेच्या वाहतूक थांब्यांपर्यंत (बस थांबे, लाइट रेल थांबे) पोहोच '
                 'असलेल्या लोकसंख्येची टक्केवारी',
    'h_pct_hc': 'उच्च क्षमतेच्या वाहतुकीपर्यंत पोहोच असलेल्या लोकसंख्येची टक्केवारी',
    'h_pct_comb': 'एकत्रित सार्वजनिक वाहतुकीपर्यंत पोहोच असलेल्या लोकसंख्येची टक्केवारी',
    'h_pop_source': 'लोकसंख्या डेटाचा स्रोत',
    'src_household': 'कुटुंब बिंदू',
    'src_raster': 'ग्रिड रास्टर',
    'src_field': 'फील्ड',
}


# ---------------------------------------------------------- te: తెలుగు
_EXTRA_TEXT['te'] = {
    'win_title': 'SDG 11.2.1 మరియు 11.7.1 గణాంకాల గణన',
    'subtitle': 'పట్టణ ప్రాంతానికి ముందస్తు క్లిప్ -> రీప్రొజెక్ట్ + జ్యామితి సవరణ -> '
                'బహిరంగ ప్రజా స్థలాల క్లిప్ -> సరిహద్దు బిందువులు -> సేవా ప్రాంతం -> '
                'కుంభాకార కవచం -> క్లిప్ -> విలీనం -> సేవా ప్రాంతాల్లో జనాభా -> రహదారి '
                'వెడల్పుల జోడింపు -> బఫర్ -> విలీనం -> క్లిప్ (వీధులకు కేటాయించిన భూమి) '
                '-> గణాంకాల పట్టిక',
    'language': 'భాష:',
    'tab_layers': 'లేయర్లు',
    'tab_distances': 'దూరాలు',
    'tab_output': 'అవుట్‌పుట్',
    'progress': 'పురోగతి',
    'btn_run': 'విశ్లేషణను అమలు చేయండి',
    'btn_cancel': 'రద్దు చేయండి',
    'btn_reset': 'లాగ్ క్లియర్ చేయండి',
    'btn_close': 'మూసివేయండి',
    'grp_streets': 'వీధులు',
    'note_streets': 'నెట్‌వర్క్‌పై మార్గం కనుగొనడానికి ఉపయోగించే వీధుల లేయర్',
    'grp_urban': 'పట్టణ సరిహద్దు',
    'note_urban': 'పట్టణ విస్తీర్ణాన్ని నిర్వచించే బహుభుజి లేయర్',
    'grp_pop_raster': 'గ్రిడ్ జనాభా (రాస్టర్)',
    'note_pop_raster': 'గ్రిడ్ జనాభా డేటాసెట్. దీన్ని లేదా దిగువ ఉన్న గృహ జనాభా '
                       '(బిందువులు) లేయర్‌ను అందించండి - రెండింటిలో ఒకటి తప్పనిసరి.',
    'grp_hh': 'గృహ జనాభా (బిందువులు)',
    'note_hh': 'గృహ స్థాయిలో జనాభా సంఖ్యలు ఉన్న బిందువుల లేయర్. దీన్ని లేదా గ్రిడ్ జనాభా '
               'రాస్టర్‌ను అందించండి - రెండింటిలో ఒకటి తప్పనిసరి. రెండూ ఇస్తే గృహ బిందువులు '
               'ఉపయోగించబడతాయి. ప్రతి సేవా ప్రాంతంలోని జనాభా = దాని లోపల ఉన్న బిందువుల '
               'ఎంచుకున్న ఫీల్డ్ మొత్తం.',
    'lbl_pop_field': 'మొత్తం జనాభా ఉన్న ఫీల్డ్ (ప్రతి గృహ బిందువుకు):',
    'grp_pos': 'బహిరంగ ప్రజా స్థలాలు (బహుభుజులు)',
    'note_pos': 'ప్రజలకు అందుబాటులో ఉండే అభివృద్ధి చేయని లేదా బహిరంగ భూమిని సూచించే '
                'బహుభుజి లేయర్లు; ఇవి నివాసితులకు వినోద ప్రదేశాలను అందిస్తాయి మరియు '
                'పర్యావరణ నాణ్యతను మెరుగుపరుస్తాయి. ఉదాహరణలు: పార్కులు, తోటలు, ఆట '
                'స్థలాలు, ప్రజా బీచ్‌లు, నదీ తీరాలు మరియు జల తీరాలు',
    'grp_bus': 'తక్కువ సామర్థ్య రవాణా స్టాప్‌లు (బస్ స్టాప్‌లు, లైట్ రైల్ స్టాప్‌లు)',
    'note_bus': 'బస్ స్టాప్ / లైట్ రైల్ స్టాప్ స్థానాల బిందువుల లేయర్',
    'grp_rail': 'అధిక సామర్థ్య రవాణా స్టాప్‌లు (రైల్వే స్టేషన్లు, మెట్రో స్టేషన్లు)',
    'note_rail': 'రైల్వే/మెట్రో స్టేషన్ స్థానాల బిందువుల లేయర్',
    'grp_ferry': 'అధిక సామర్థ్య రవాణా స్టాప్‌లు (ఫెర్రీ స్టాప్‌లు)',
    'note_ferry': 'ఫెర్రీ టెర్మినల్ స్థానాల బిందువుల లేయర్',
    'grp_widths': 'కొలిచిన రహదారి వెడల్పులు (CSV పట్టిక)',
    'note_widths': 'వీధులకు కేటాయించిన భూమి కోసం ఉపయోగించబడుతుంది. నిలువు వరుస 1 = '
                   'రహదారి వర్గం (దిగువ ఎంచుకున్న రహదారి వర్గ ఫీల్డ్‌తో సరిపోల్చబడుతుంది), '
                   'నిలువు వరుస 2 = మీటర్లలో కొలిచిన రహదారి వెడల్పు. CSV ఇవ్వకపోతే మరియు '
                   'రహదారి వర్గ ఫీల్డ్ లేకపోతే, వీధులకు కేటాయించిన భూమి = 0.',
    'btn_browse_csv': 'CSV ఎంచుకోండి...',
    'grp_catfield': 'రహదారి వర్గ ఫీల్డ్ (వీధుల లేయర్ నుండి)',
    'note_catfield': "రహదారి వర్గాలను కలిగి ఉన్న వీధుల లేయర్ ఫీల్డ్, రహదారి వెడల్పులను "
                     "జోడించడానికి ఉపయోగించబడుతుంది. 'fclass', 'highway' లేదా 'type' "
                     "ఉంటే స్వయంచాలకంగా ఎంచుకోబడుతుంది; లేకపోతే ఇక్కడ ఫీల్డ్‌ను "
                     "ఎంచుకోండి. స్వయంచాలక గుర్తింపు కోసం ఖాళీగా వదిలేయండి.",
    'grp_crs': 'లక్ష్య కోఆర్డినేట్ రిఫరెన్స్ సిస్టమ్ (ప్రొజెక్టెడ్, మీటర్లు - ఉదా. పట్టణ '
               'ప్రాంతానికి UTM)',
    'dist_header': 'నెట్‌వర్క్ దూర పరిమితి:',
    'dist_pos': 'బహిరంగ ప్రజా స్థలాలు',
    'spacing_header': 'బహిరంగ ప్రజా స్థలాల సరిహద్దు బిందువుల మధ్య దూరం:',
    'spacing_note': 'ప్రతి బహిరంగ స్థలం అంచు వెంబడి ఉంచే ప్రారంభ బిందువులు. 100 మీ '
                    'ప్రామాణికం; ఎక్కువ దూరం (ఉదా. 200 మీ) అనేక పెద్ద పార్కులు ఉన్న '
                    'నగరాలకు వేగంగా ఉంటుంది కానీ కొంచెం తక్కువ ఖచ్చితత్వం.',
    'perf_header': 'పనితీరు:',
    'chk_preclip': 'ఇన్‌పుట్‌లను పట్టణ ప్రాంతానికి ముందుగానే క్లిప్ చేయండి',
    'note_preclip': 'సిఫార్సు చేయబడింది. పట్టణ ప్రాంతం యొక్క శోధన అంచు లోపల ఉన్న వీధులు, '
                    'స్టాప్‌లు మరియు బహిరంగ స్థలాలను మాత్రమే ఉంచుతుంది - దేశ/ప్రాంత '
                    'స్థాయి డేటాతో చాలా వేగంగా ఉంటుంది.',
    'chk_memory': 'మధ్యంతర లేయర్లను మెమరీలో ఉంచండి',
    'note_memory': 'వేగంగా ఉంటుంది. కంప్యూటర్‌లో RAM సరిపోకపోతే మాత్రమే ఎంపిక తీసివేయండి.',
    'chk_native': 'QGIS స్థానిక సేవా ప్రాంత అల్గారిథమ్‌ను ఉపయోగించండి',
    'note_native': 'క్రాస్-చెకింగ్ కోసం మాత్రమే - అనేక ప్రారంభ బిందువులతో చాలా నెమ్మదిగా '
                   'ఉంటుంది. డిఫాల్ట్ వేగవంతమైన పరిమిత శోధన (అవే ఫలితాలు).',
    'grp_city': 'నగరం పేరు (సూచన: ప్రత్యేక అక్షరాలను నివారించండి)',
    'city_placeholder': 'ఉదా. Mombasa',
    'lbl_output_folder': 'అవుట్‌పుట్ ఫోల్డర్:',
    'btn_browse': 'బ్రౌజ్ చేయండి...',
    'info_block':
        "ఉంచబడే చివరి ఫైళ్లు:\n"
        "  క్లిప్ + విలీనం చేసిన సేవా ప్రాంతాలు:\n"
        "  SA_POS_dissolved.shp                బహిరంగ ప్రజా స్థలాలు\n"
        "  SA_Bus_dissolved.shp                తక్కువ సామర్థ్య రవాణా స్టాప్‌లు\n"
        "  SA_Ferry_dissolved.shp              ఫెర్రీ స్టాప్‌లు\n"
        "  SA_Rail_dissolved.shp               రైలు స్టాప్‌లు\n"
        "  SA_HighCapacity_dissolved.shp       అధిక సామర్థ్యం (రైలు + ఫెర్రీ)\n"
        "  SA_CombinedTransport_dissolved.shp  సమ్మిళిత ప్రజా రవాణా\n"
        "  వేర్వేరు (ప్రతి స్టాప్) సేవా ప్రాంతాలు:\n"
        "  SA_Bus_individual.shp / SA_Ferry_individual.shp / SA_Rail_individual.shp\n"
        "  ZonalStats_*.shp                    సేవా ప్రాంతం + pop_sum ఫీల్డ్\n"
        "  LAS_streets_dissolved.shp           వీధులకు కేటాయించిన భూమి\n"
        "  {city}_statistics_11.2.1_and_11.7.1.xlsx\n\n"
        "గమనికలు:\n"
        "  - ప్రాసెసింగ్‌కు ముందు జ్యామితులు స్వయంచాలకంగా సవరించబడతాయి.\n"
        "  - జనాభా: ఇస్తే గృహ బిందువులు (జనాభా ఫీల్డ్ మొత్తం),\n"
        "    లేకపోతే గ్రిడ్ జనాభా రాస్టర్.\n"
        "  - బహిరంగ ప్రజా స్థలాల విస్తీర్ణం పట్టణ సరిహద్దుకు క్లిప్ చేసిన తర్వాత కొలుస్తారు.\n"
        "  - ఇన్‌పుట్‌లు పట్టణ ప్రాంతం + శోధన అంచుకు ముందుగానే క్లిప్ చేయబడతాయి మరియు\n"
        "    మధ్యంతర లేయర్లు మెమరీలో ఉంచబడతాయి (మార్చడానికి దూరాలు ట్యాబ్ చూడండి).\n"
        "  - సమ్మిళిత రవాణా = తక్కువ సామర్థ్య స్టాప్‌లు + ఫెర్రీ + రైలు\n"
        "    (బహిరంగ ప్రజా స్థలాలు మినహా).\n"
        "  - వీధులకు కేటాయించిన భూమి: రహదారులు వెడల్పు ప్రకారం బఫర్ చేయబడి,\n"
        "    విలీనం చేయబడి, పట్టణ విస్తీర్ణానికి క్లిప్ చేయబడతాయి.\n"
        "  - గణాంకాల పట్టిక ఎంచుకున్న భాషలో వ్రాయబడుతుంది.\n"
        "  - లోపం తర్వాత లాగ్ క్లియర్ చేసి బటన్లను మళ్లీ ప్రారంభించడానికి 'లాగ్ క్లియర్ చేయండి' ఉపయోగించండి.",
    'msg_running_title': 'అమలవుతోంది',
    'msg_cannot_reset': 'విశ్లేషణ అమలవుతున్నప్పుడు క్లియర్ చేయలేము. ముందుగా రద్దు చేయండి.',
    'msg_missing_layer': 'లేయర్ లేదు',
    'msg_select_streets': 'దయచేసి వీధుల లేయర్‌ను ఎంచుకోండి.',
    'msg_select_urban': 'దయచేసి పట్టణ సరిహద్దు లేయర్‌ను ఎంచుకోండి.',
    'msg_missing_pop_title': 'జనాభా డేటా లేదు',
    'msg_missing_pop': 'దయచేసి గ్రిడ్ జనాభా (రాస్టర్) లేయర్ లేదా గృహ జనాభా (బిందువులు) '
                       'లేయర్‌ను ఎంచుకోండి - రెండింటిలో ఒకటి తప్పనిసరి.',
    'msg_missing_popfield_title': 'జనాభా ఫీల్డ్ లేదు',
    'msg_missing_popfield': 'దయచేసి గృహ జనాభా (బిందువులు) లేయర్ కోసం మొత్తం జనాభా ఉన్న '
                            'ఫీల్డ్‌ను ఎంచుకోండి.',
    'msg_missing_city_title': 'నగరం పేరు లేదు',
    'msg_missing_city': 'దయచేసి నగరం పేరును నమోదు చేయండి.',
    'msg_missing_output_title': 'అవుట్‌పుట్ లేదు',
    'msg_missing_output': 'దయచేసి అవుట్‌పుట్ ఫోల్డర్‌ను ఎంచుకోండి.',
    'msg_invalid_crs_title': 'చెల్లని CRS',
    'msg_invalid_crs': 'దయచేసి చెల్లుబాటు అయ్యే లక్ష్య CRS ను ఎంచుకోండి.',
    'msg_no_transport_title': 'రవాణా లేయర్లు లేవు',
    'msg_no_transport': 'బహిరంగ ప్రజా స్థలాలు / తక్కువ సామర్థ్యం / ఫెర్రీ / రైలు లేయర్లు '
                        'ఏవీ ఎంచుకోలేదు. పట్టణ ప్రాంతం మరియు వీధులు మాత్రమే ప్రాసెస్ '
                        'చేయబడతాయి. కొనసాగించాలా?',
    'msg_complete': 'పూర్తయింది',
    'msg_error': 'లోపం',
    'msg_failed': "విశ్లేషణ విఫలమైంది. వివరాల కోసం లాగ్ చూడండి.\n\n"
                  "క్లియర్ చేసి మళ్లీ అమలు చేయడానికి 'లాగ్ క్లియర్ చేయండి' క్లిక్ చేయండి.",
    'msg_close_running': 'విశ్లేషణ ఇంకా అమలవుతోంది. రద్దు చేసి మూసివేయాలా?',
    'msg_cancel_requested': 'రద్దు అభ్యర్థించబడింది...',
    'dlg_select_output': 'అవుట్‌పుట్ ఫోల్డర్‌ను ఎంచుకోండి',
    'dlg_select_csv': 'కొలిచిన రహదారి వెడల్పుల CSV ని ఎంచుకోండి',
    'csv_filter': 'CSV ఫైళ్లు (*.csv *.txt);;అన్ని ఫైళ్లు (*)',
    'msg_invalid_csv_title': 'చెల్లని CSV',
    'msg_invalid_csv': 'చదవలేకపోయింది:',
    'msg_widths_title': 'రహదారి వెడల్పుల CSV',
    'msg_widths_cols': 'రహదారి వెడల్పుల పట్టికకు కనీసం రెండు నిలువు వరుసలు (రహదారి వర్గం, '
                       'వెడల్పు) అవసరం. ఇది విస్మరించబడుతుంది.',
    'res_done': 'పూర్తయింది!',
    'res_las': 'వీధులకు కేటాయించిన భూమి',
    'res_stats': 'గణాంకాల పట్టిక (CSV)',
    'res_excel': 'గణాంకాల వర్క్‌బుక్ (Excel)',
    'res_roads': 'రహదారుల పట్టిక',
    'res_folder': 'ఫోల్డర్',
    'res_time': 'సమయం',
    'h_city': 'నగరం',
    'h_urban_area': 'పట్టణ విస్తీర్ణం (km2)',
    'h_pos_area': 'బహిరంగ ప్రజా స్థలాల విస్తీర్ణం (km2)',
    'h_las': 'వీధులకు కేటాయించిన భూమి (km2)',
    'h_ops_las': 'బహిరంగ ప్రజా స్థలం + వీధులకు కేటాయించిన భూమి (km2)',
    'h_prop_ops_las': 'బహిరంగ ప్రజా స్థలం + వీధులకు కేటాయించిన భూమి ఉన్న పట్టణ '
                      'విస్తీర్ణ నిష్పత్తి (%)',
    'h_total_pop': 'మొత్తం పట్టణ జనాభా',
    'h_pop_pos': 'బహిరంగ ప్రజా స్థలాలకు అందుబాటు ఉన్న జనాభా',
    'h_pop_bus': 'తక్కువ సామర్థ్య రవాణా స్టాప్‌లకు (బస్ స్టాప్‌లు, లైట్ రైల్ స్టాప్‌లు) '
                 'అందుబాటు ఉన్న జనాభా',
    'h_pop_hc': 'అధిక సామర్థ్య రవాణాకు (రైలు + ఫెర్రీ) అందుబాటు ఉన్న జనాభా',
    'h_pop_comb': 'సమ్మిళిత ప్రజా రవాణాకు అందుబాటు ఉన్న జనాభా',
    'h_pct_pos': 'బహిరంగ ప్రజా స్థలాలకు అందుబాటు ఉన్న జనాభా శాతం',
    'h_pct_bus': 'తక్కువ సామర్థ్య రవాణా స్టాప్‌లకు (బస్ స్టాప్‌లు, లైట్ రైల్ స్టాప్‌లు) '
                 'అందుబాటు ఉన్న జనాభా శాతం',
    'h_pct_hc': 'అధిక సామర్థ్య రవాణాకు అందుబాటు ఉన్న జనాభా శాతం',
    'h_pct_comb': 'సమ్మిళిత ప్రజా రవాణాకు అందుబాటు ఉన్న జనాభా శాతం',
    'h_pop_source': 'జనాభా డేటా మూలం',
    'src_household': 'గృహ బిందువులు',
    'src_raster': 'గ్రిడ్ రాస్టర్',
    'src_field': 'ఫీల్డ్',
}


# ---------------------------------------------------------- ta: தமிழ்
_EXTRA_TEXT['ta'] = {
    'win_title': 'SDG 11.2.1 மற்றும் 11.7.1 புள்ளிவிவரக் கணக்கீடு',
    'subtitle': 'நகர்ப்புறப் பகுதிக்கு முன்-வெட்டு -> மறு வீழ்ப்பு + வடிவியல் திருத்தம் '
                '-> பொதுத் திறந்தவெளிகளை வெட்டுதல் -> எல்லைப் புள்ளிகள் -> சேவைப் '
                'பகுதி -> குவிவு உறை -> வெட்டு -> ஒன்றிணைப்பு -> சேவைப் பகுதிகளில் '
                'மக்கள்தொகை -> சாலை அகல இணைப்பு -> இடையகம் -> ஒன்றிணைப்பு -> வெட்டு '
                '(தெருக்களுக்கு ஒதுக்கப்பட்ட நிலம்) -> புள்ளிவிவர அட்டவணை',
    'language': 'மொழி:',
    'tab_layers': 'அடுக்குகள்',
    'tab_distances': 'தூரங்கள்',
    'tab_output': 'வெளியீடு',
    'progress': 'முன்னேற்றம்',
    'btn_run': 'பகுப்பாய்வை இயக்கு',
    'btn_cancel': 'ரத்துசெய்',
    'btn_reset': 'பதிவை அழி',
    'btn_close': 'மூடு',
    'grp_streets': 'தெருக்கள்',
    'note_streets': 'வலையமைப்பில் வழி கண்டறியப் பயன்படும் தெரு அடுக்கு',
    'grp_urban': 'நகர எல்லை',
    'note_urban': 'நகர்ப்புறப் பரப்பை வரையறுக்கும் பல்கோண அடுக்கு',
    'grp_pop_raster': 'கட்டமைப்பு மக்கள்தொகை (ராஸ்டர்)',
    'note_pop_raster': 'கட்டமைப்பு மக்கள்தொகைத் தரவுத்தொகுப்பு. இதை அல்லது கீழே உள்ள '
                       'குடும்ப மக்கள்தொகை (புள்ளிகள்) அடுக்கை வழங்கவும் - இரண்டில் '
                       'ஒன்று கட்டாயம்.',
    'grp_hh': 'குடும்ப மக்கள்தொகை (புள்ளிகள்)',
    'note_hh': 'குடும்ப அளவில் மக்கள்தொகை எண்ணிக்கை கொண்ட புள்ளி அடுக்கு. இதை அல்லது '
               'கட்டமைப்பு மக்கள்தொகை ராஸ்டரை வழங்கவும் - இரண்டில் ஒன்று கட்டாயம். '
               'இரண்டும் வழங்கப்பட்டால் குடும்பப் புள்ளிகள் பயன்படுத்தப்படும். ஒவ்வொரு '
               'சேவைப் பகுதியின் மக்கள்தொகை = அதனுள் உள்ள புள்ளிகளின் தேர்ந்தெடுத்த '
               'புலத்தின் கூட்டுத்தொகை.',
    'lbl_pop_field': 'மொத்த மக்கள்தொகை கொண்ட புலம் (ஒவ்வொரு குடும்பப் புள்ளிக்கும்):',
    'grp_pos': 'பொதுத் திறந்தவெளிகள் (பல்கோணங்கள்)',
    'note_pos': 'பொதுமக்கள் அணுகக்கூடிய, கட்டடம் இல்லாத அல்லது திறந்த நிலத்தைக் குறிக்கும் '
                'பல்கோண அடுக்குகள்; இவை குடியிருப்பாளர்களுக்குப் பொழுதுபோக்கு இடங்களை '
                'வழங்கி சுற்றுச்சூழல் தரத்தை மேம்படுத்துகின்றன. எடுத்துக்காட்டுகள்: '
                'பூங்காக்கள், தோட்டங்கள், விளையாட்டு மைதானங்கள், பொதுக் கடற்கரைகள், '
                'ஆற்றங்கரைகள் மற்றும் நீர்முனைகள்',
    'grp_bus': 'குறைந்த திறன் போக்குவரத்து நிறுத்தங்கள் (பேருந்து நிறுத்தங்கள், இலகு '
               'ரயில் நிறுத்தங்கள்)',
    'note_bus': 'பேருந்து நிறுத்தம் / இலகு ரயில் நிறுத்த இருப்பிடங்களின் புள்ளி அடுக்கு',
    'grp_rail': 'உயர் திறன் போக்குவரத்து நிறுத்தங்கள் (ரயில் நிலையங்கள், மெட்ரோ '
                'நிலையங்கள்)',
    'note_rail': 'ரயில்/மெட்ரோ நிலைய இருப்பிடங்களின் புள்ளி அடுக்கு',
    'grp_ferry': 'உயர் திறன் போக்குவரத்து நிறுத்தங்கள் (படகுத் துறைகள்)',
    'note_ferry': 'படகு முனைய இருப்பிடங்களின் புள்ளி அடுக்கு',
    'grp_widths': 'அளவிடப்பட்ட சாலை அகலங்கள் (CSV அட்டவணை)',
    'note_widths': 'தெருக்களுக்கு ஒதுக்கப்பட்ட நிலத்திற்குப் பயன்படுகிறது. நெடுவரிசை 1 = '
                   'சாலை வகை (கீழே தேர்ந்தெடுக்கும் சாலை வகைப் புலத்துடன் பொருத்தப்படும்), '
                   'நெடுவரிசை 2 = மீட்டரில் அளவிடப்பட்ட சாலை அகலம். CSV இல்லாமலும் சாலை '
                   'வகைப் புலம் இல்லாமலும் இருந்தால், தெருக்களுக்கு ஒதுக்கப்பட்ட நிலம் = 0.',
    'btn_browse_csv': 'CSV தேர்வு...',
    'grp_catfield': 'சாலை வகைப் புலம் (தெருக்கள் அடுக்கிலிருந்து)',
    'note_catfield': "சாலை வகைகளைக் கொண்ட தெருக்கள் அடுக்கின் புலம், சாலை அகலங்களை "
                     "இணைக்கப் பயன்படுகிறது. 'fclass', 'highway' அல்லது 'type' இருந்தால் "
                     "தானாகத் தேர்ந்தெடுக்கப்படும்; இல்லையெனில் இங்கே புலத்தைத் "
                     "தேர்ந்தெடுக்கவும். தானியங்கு கண்டறிதலுக்குக் காலியாக விடவும்.",
    'grp_crs': 'இலக்கு ஆயத்தொலை குறிப்பு அமைப்பு (வீழ்ப்பு, மீட்டர் - எ.கா. நகர்ப்புறப் '
               'பகுதிக்கான UTM)',
    'dist_header': 'வலையமைப்புத் தூர வரம்பு:',
    'dist_pos': 'பொதுத் திறந்தவெளிகள்',
    'spacing_header': 'பொதுத் திறந்தவெளிகளின் எல்லைப் புள்ளி இடைவெளி:',
    'spacing_note': 'ஒவ்வொரு திறந்தவெளியின் எல்லைக்கோட்டிலும் வைக்கப்படும் தொடக்கப் '
                    'புள்ளிகள். 100 மீ நிலையானது; அதிக இடைவெளி (எ.கா. 200 மீ) பல பெரிய '
                    'பூங்காக்கள் உள்ள நகரங்களுக்கு வேகமானது, ஆனால் சற்றுக் குறைவான '
                    'துல்லியம்.',
    'perf_header': 'செயல்திறன்:',
    'chk_preclip': 'உள்ளீடுகளை நகர்ப்புறப் பகுதிக்கு முன்கூட்டியே வெட்டு',
    'note_preclip': 'பரிந்துரைக்கப்படுகிறது. நகர்ப்புறப் பகுதியின் தேடல் விளிம்பிற்குள் உள்ள '
                    'தெருக்கள், நிறுத்தங்கள் மற்றும் திறந்தவெளிகளை மட்டும் வைத்திருக்கும் '
                    '- நாடு/பிராந்திய அளவிலான தரவுடன் மிக வேகமானது.',
    'chk_memory': 'இடைநிலை அடுக்குகளை நினைவகத்தில் வைத்திரு',
    'note_memory': 'வேகமானது. கணினியில் RAM போதவில்லை என்றால் மட்டும் தேர்வை நீக்கவும்.',
    'chk_native': 'QGIS இன் சொந்த சேவைப் பகுதி அல்காரிதத்தைப் பயன்படுத்து',
    'note_native': 'குறுக்குச் சரிபார்ப்புக்கு மட்டும் - பல தொடக்கப் புள்ளிகளுடன் மிக மெதுவானது. '
                   'இயல்புநிலை வேகமான வரம்புக்குட்பட்ட தேடல் (அதே முடிவுகள்).',
    'grp_city': 'நகரத்தின் பெயர் (குறிப்பு: சிறப்பு எழுத்துகளைத் தவிர்க்கவும்)',
    'city_placeholder': 'எ.கா. Mombasa',
    'lbl_output_folder': 'வெளியீட்டுக் கோப்புறை:',
    'btn_browse': 'உலாவு...',
    'info_block':
        "தக்கவைக்கப்படும் இறுதிக் கோப்புகள்:\n"
        "  வெட்டி ஒன்றிணைக்கப்பட்ட சேவைப் பகுதிகள்:\n"
        "  SA_POS_dissolved.shp                பொதுத் திறந்தவெளிகள்\n"
        "  SA_Bus_dissolved.shp                குறைந்த திறன் போக்குவரத்து நிறுத்தங்கள்\n"
        "  SA_Ferry_dissolved.shp              படகுத் துறைகள்\n"
        "  SA_Rail_dissolved.shp               ரயில் நிறுத்தங்கள்\n"
        "  SA_HighCapacity_dissolved.shp       உயர் திறன் (ரயில் + படகு)\n"
        "  SA_CombinedTransport_dissolved.shp  ஒருங்கிணைந்த பொதுப் போக்குவரத்து\n"
        "  தனித்தனி (நிறுத்தவாரி) சேவைப் பகுதிகள்:\n"
        "  SA_Bus_individual.shp / SA_Ferry_individual.shp / SA_Rail_individual.shp\n"
        "  ZonalStats_*.shp                    சேவைப் பகுதி + pop_sum புலம்\n"
        "  LAS_streets_dissolved.shp           தெருக்களுக்கு ஒதுக்கப்பட்ட நிலம்\n"
        "  {city}_statistics_11.2.1_and_11.7.1.xlsx\n\n"
        "குறிப்புகள்:\n"
        "  - செயலாக்கத்திற்கு முன் வடிவியல்கள் தானாகத் திருத்தப்படும்.\n"
        "  - மக்கள்தொகை: வழங்கப்பட்டால் குடும்பப் புள்ளிகள் (மக்கள்தொகைப் புலத்தின்\n"
        "    கூட்டுத்தொகை), இல்லையெனில் கட்டமைப்பு மக்கள்தொகை ராஸ்டர்.\n"
        "  - பொதுத் திறந்தவெளிப் பரப்பு நகர எல்லைக்கு வெட்டிய பின் அளவிடப்படுகிறது.\n"
        "  - உள்ளீடுகள் நகர்ப்புறப் பகுதி + தேடல் விளிம்புக்கு முன்கூட்டியே வெட்டப்பட்டு\n"
        "    இடைநிலை அடுக்குகள் நினைவகத்தில் வைக்கப்படும் (மாற்ற தூரங்கள் தாவலைப் பார்க்கவும்).\n"
        "  - ஒருங்கிணைந்த போக்குவரத்து = குறைந்த திறன் நிறுத்தங்கள் + படகு + ரயில்\n"
        "    (பொதுத் திறந்தவெளிகள் தவிர்த்து).\n"
        "  - தெருக்களுக்கு ஒதுக்கப்பட்ட நிலம்: சாலைகள் அகலத்தின்படி இடையகப்படுத்தப்பட்டு,\n"
        "    ஒன்றிணைக்கப்பட்டு, நகர்ப்புறப் பரப்புக்கு வெட்டப்படும்.\n"
        "  - புள்ளிவிவர அட்டவணை தேர்ந்தெடுத்த மொழியில் எழுதப்படும்.\n"
        "  - பிழைக்குப் பின் பதிவை அழித்துப் பொத்தான்களை மீண்டும் இயக்க 'பதிவை அழி' பயன்படுத்தவும்.",
    'msg_running_title': 'இயங்குகிறது',
    'msg_cannot_reset': 'பகுப்பாய்வு இயங்கும்போது அழிக்க முடியாது. முதலில் ரத்துசெய்யவும்.',
    'msg_missing_layer': 'அடுக்கு இல்லை',
    'msg_select_streets': 'தயவுசெய்து தெருக்கள் அடுக்கைத் தேர்ந்தெடுக்கவும்.',
    'msg_select_urban': 'தயவுசெய்து நகர எல்லை அடுக்கைத் தேர்ந்தெடுக்கவும்.',
    'msg_missing_pop_title': 'மக்கள்தொகைத் தரவு இல்லை',
    'msg_missing_pop': 'தயவுசெய்து கட்டமைப்பு மக்கள்தொகை (ராஸ்டர்) அடுக்கு அல்லது குடும்ப '
                       'மக்கள்தொகை (புள்ளிகள்) அடுக்கைத் தேர்ந்தெடுக்கவும் - இரண்டில் '
                       'ஒன்று கட்டாயம்.',
    'msg_missing_popfield_title': 'மக்கள்தொகைப் புலம் இல்லை',
    'msg_missing_popfield': 'தயவுசெய்து குடும்ப மக்கள்தொகை (புள்ளிகள்) அடுக்கிற்கான மொத்த '
                            'மக்கள்தொகை கொண்ட புலத்தைத் தேர்ந்தெடுக்கவும்.',
    'msg_missing_city_title': 'நகரத்தின் பெயர் இல்லை',
    'msg_missing_city': 'தயவுசெய்து நகரத்தின் பெயரை உள்ளிடவும்.',
    'msg_missing_output_title': 'வெளியீடு இல்லை',
    'msg_missing_output': 'தயவுசெய்து வெளியீட்டுக் கோப்புறையைத் தேர்ந்தெடுக்கவும்.',
    'msg_invalid_crs_title': 'தவறான CRS',
    'msg_invalid_crs': 'தயவுசெய்து சரியான இலக்கு CRS ஐத் தேர்ந்தெடுக்கவும்.',
    'msg_no_transport_title': 'போக்குவரத்து அடுக்குகள் இல்லை',
    'msg_no_transport': 'பொதுத் திறந்தவெளிகள் / குறைந்த திறன் / படகு / ரயில் அடுக்குகள் '
                        'எதுவும் தேர்ந்தெடுக்கப்படவில்லை. நகர்ப்புறப் பகுதியும் தெருக்களும் '
                        'மட்டுமே செயலாக்கப்படும். தொடரவா?',
    'msg_complete': 'முடிந்தது',
    'msg_error': 'பிழை',
    'msg_failed': "பகுப்பாய்வு தோல்வியடைந்தது. விவரங்களுக்குப் பதிவைப் பார்க்கவும்.\n\n"
                  "அழித்து மீண்டும் இயக்க 'பதிவை அழி' என்பதைக் கிளிக் செய்யவும்.",
    'msg_close_running': 'பகுப்பாய்வு இன்னும் இயங்குகிறது. ரத்துசெய்து மூடவா?',
    'msg_cancel_requested': 'ரத்துசெய்யக் கோரப்பட்டது...',
    'dlg_select_output': 'வெளியீட்டுக் கோப்புறையைத் தேர்ந்தெடுக்கவும்',
    'dlg_select_csv': 'அளவிடப்பட்ட சாலை அகலங்கள் CSV ஐத் தேர்ந்தெடுக்கவும்',
    'csv_filter': 'CSV கோப்புகள் (*.csv *.txt);;அனைத்துக் கோப்புகளும் (*)',
    'msg_invalid_csv_title': 'தவறான CSV',
    'msg_invalid_csv': 'படிக்க முடியவில்லை:',
    'msg_widths_title': 'சாலை அகலங்கள் CSV',
    'msg_widths_cols': 'சாலை அகல அட்டவணைக்குக் குறைந்தது இரண்டு நெடுவரிசைகள் (சாலை வகை, '
                       'அகலம்) தேவை. இது புறக்கணிக்கப்படும்.',
    'res_done': 'முடிந்தது!',
    'res_las': 'தெருக்களுக்கு ஒதுக்கப்பட்ட நிலம்',
    'res_stats': 'புள்ளிவிவர அட்டவணை (CSV)',
    'res_excel': 'புள்ளிவிவரப் பணிப்புத்தகம் (Excel)',
    'res_roads': 'சாலைகள் அட்டவணை',
    'res_folder': 'கோப்புறை',
    'res_time': 'நேரம்',
    'h_city': 'நகரம்',
    'h_urban_area': 'நகர்ப்புறப் பரப்பு (km2)',
    'h_pos_area': 'பொதுத் திறந்தவெளிகளின் பரப்பு (km2)',
    'h_las': 'தெருக்களுக்கு ஒதுக்கப்பட்ட நிலம் (km2)',
    'h_ops_las': 'பொதுத் திறந்தவெளி + தெருக்களுக்கு ஒதுக்கப்பட்ட நிலம் (km2)',
    'h_prop_ops_las': 'பொதுத் திறந்தவெளி + தெருக்களுக்கு ஒதுக்கப்பட்ட நிலம் கொண்ட '
                      'நகர்ப்புறப் பரப்பின் விகிதம் (%)',
    'h_total_pop': 'மொத்த நகர்ப்புற மக்கள்தொகை',
    'h_pop_pos': 'பொதுத் திறந்தவெளிகளை அணுகக்கூடிய மக்கள்தொகை',
    'h_pop_bus': 'குறைந்த திறன் போக்குவரத்து நிறுத்தங்களை (பேருந்து நிறுத்தங்கள், இலகு '
                 'ரயில் நிறுத்தங்கள்) அணுகக்கூடிய மக்கள்தொகை',
    'h_pop_hc': 'உயர் திறன் போக்குவரத்தை (ரயில் + படகு) அணுகக்கூடிய மக்கள்தொகை',
    'h_pop_comb': 'ஒருங்கிணைந்த பொதுப் போக்குவரத்தை அணுகக்கூடிய மக்கள்தொகை',
    'h_pct_pos': 'பொதுத் திறந்தவெளிகளை அணுகக்கூடிய மக்கள்தொகை சதவீதம்',
    'h_pct_bus': 'குறைந்த திறன் போக்குவரத்து நிறுத்தங்களை (பேருந்து நிறுத்தங்கள், இலகு '
                 'ரயில் நிறுத்தங்கள்) அணுகக்கூடிய மக்கள்தொகை சதவீதம்',
    'h_pct_hc': 'உயர் திறன் போக்குவரத்தை அணுகக்கூடிய மக்கள்தொகை சதவீதம்',
    'h_pct_comb': 'ஒருங்கிணைந்த பொதுப் போக்குவரத்தை அணுகக்கூடிய மக்கள்தொகை சதவீதம்',
    'h_pop_source': 'மக்கள்தொகைத் தரவு மூலம்',
    'src_household': 'குடும்பப் புள்ளிகள்',
    'src_raster': 'கட்டமைப்பு ராஸ்டர்',
    'src_field': 'புலம்',
}


# ---------------------------------------------------------- gu: ગુજરાતી
_EXTRA_TEXT['gu'] = {
    'win_title': 'SDG 11.2.1 અને 11.7.1 આંકડાકીય ગણતરી',
    'subtitle': 'શહેરી વિસ્તાર સુધી પૂર્વ-ક્લિપ -> પુનઃપ્રક્ષેપણ + ભૂમિતિ સુધારણા -> '
                'જાહેર ખુલ્લી જગ્યાઓનું ક્લિપિંગ -> સીમા બિંદુઓ -> સેવા વિસ્તાર -> '
                'બહિર્ગોળ આવરણ -> ક્લિપ -> વિલય -> સેવા વિસ્તારોમાં વસ્તી -> રસ્તાની '
                'પહોળાઈ જોડવી -> બફર -> વિલય -> ક્લિપ (શેરીઓ માટે ફાળવેલી જમીન) -> '
                'આંકડાકીય કોષ્ટક',
    'language': 'ભાષા:',
    'tab_layers': 'સ્તરો',
    'tab_distances': 'અંતરો',
    'tab_output': 'આઉટપુટ',
    'progress': 'પ્રગતિ',
    'btn_run': 'વિશ્લેષણ ચલાવો',
    'btn_cancel': 'રદ કરો',
    'btn_reset': 'લૉગ સાફ કરો',
    'btn_close': 'બંધ કરો',
    'grp_streets': 'શેરીઓ',
    'note_streets': 'નેટવર્ક માર્ગ નિર્ધારણ માટે વપરાતો શેરીઓનો સ્તર',
    'grp_urban': 'શહેરી સીમા',
    'note_urban': 'શહેરી વિસ્તાર નિર્ધારિત કરતો બહુકોણ સ્તર',
    'grp_pop_raster': 'ગ્રિડ આધારિત વસ્તી (રાસ્ટર)',
    'note_pop_raster': 'ગ્રિડ આધારિત વસ્તી ડેટાસેટ. આ અથવા નીચેની ઘરગથ્થુ વસ્તી '
                       '(બિંદુઓ) આપો - બેમાંથી એક જરૂરી છે.',
    'grp_hh': 'ઘરગથ્થુ વસ્તી (બિંદુઓ)',
    'note_hh': 'કુટુંબ સ્તરની વસ્તી ગણતરી ધરાવતો બિંદુ સ્તર. આ અથવા ગ્રિડ આધારિત '
               'વસ્તી રાસ્ટર આપો - બેમાંથી એક જરૂરી છે. બંને આપ્યા હોય તો ઘરગથ્થુ '
               'બિંદુઓ વપરાશે. દરેક સેવા વિસ્તારની વસ્તી = તેની અંદરના બિંદુઓના '
               'પસંદ કરેલા ક્ષેત્રનો સરવાળો.',
    'lbl_pop_field': 'કુલ વસ્તી ધરાવતું ક્ષેત્ર (દરેક ઘરગથ્થુ બિંદુ માટે):',
    'grp_pos': 'જાહેર ખુલ્લી જગ્યાઓ (બહુકોણ)',
    'note_pos': 'જનતા માટે સુલભ અવિકસિત અથવા ખુલ્લી જમીન દર્શાવતા બહુકોણ સ્તરો, જે '
                'રહેવાસીઓને મનોરંજનની જગ્યાઓ આપે છે અને પર્યાવરણની ગુણવત્તા સુધારે '
                'છે. ઉદાહરણ: ઉદ્યાનો, બગીચા, રમતનાં મેદાનો, જાહેર દરિયાકિનારા, નદીકાંઠા '
                'અને જળકિનારા',
    'grp_bus': 'ઓછી ક્ષમતાના પરિવહન સ્ટોપ (બસ સ્ટોપ, લાઇટ રેલ સ્ટોપ)',
    'note_bus': 'બસ સ્ટોપ / લાઇટ રેલ સ્ટોપના સ્થાનોનો બિંદુ સ્તર',
    'grp_rail': 'ઉચ્ચ ક્ષમતાના પરિવહન સ્ટોપ (રેલવે સ્ટેશનો, મેટ્રો સ્ટેશનો)',
    'note_rail': 'રેલવે / મેટ્રો સ્ટેશનોના સ્થાનોનો બિંદુ સ્તર',
    'grp_ferry': 'ઉચ્ચ ક્ષમતાના પરિવહન સ્ટોપ (ફેરી ઘાટ)',
    'note_ferry': 'ફેરી ટર્મિનલના સ્થાનોનો બિંદુ સ્તર',
    'grp_widths': 'માપેલી રસ્તાની પહોળાઈ (CSV કોષ્ટક)',
    'note_widths': 'શેરીઓ માટે ફાળવેલી જમીનની ગણતરીમાં વપરાય છે. કૉલમ 1 = રસ્તાનો પ્રકાર '
                   '(નીચે પસંદ કરેલા રસ્તા પ્રકાર ક્ષેત્ર સાથે મેળવવામાં આવે છે), કૉલમ 2 '
                   '= મીટરમાં માપેલી પહોળાઈ. CSV ન આપી હોય અને પ્રકાર ક્ષેત્ર ન હોય તો '
                   'શેરીઓ માટે ફાળવેલી જમીન = 0.',
    'btn_browse_csv': 'CSV પસંદ કરો...',
    'grp_catfield': 'રસ્તા પ્રકાર ક્ષેત્ર (શેરીઓના સ્તરમાંથી)',
    'note_catfield': 'શેરીઓના સ્તરનું રસ્તાના પ્રકારો ધરાવતું ક્ષેત્ર, પહોળાઈ જોડવા માટે '
                     'વપરાય છે. \'fclass\', \'highway\' અથવા \'type\' હોય તો આપમેળે '
                     'પસંદ થાય છે; અન્યથા અહીં ક્ષેત્ર પસંદ કરો. આપમેળે ઓળખ માટે ખાલી '
                     'રાખો.',
    'grp_crs': 'લક્ષ્ય કોઓર્ડિનેટ સંદર્ભ પ્રણાલી (પ્રક્ષેપિત, મીટરમાં - દા.ત. શહેરી '
               'વિસ્તારનો UTM ઝોન)',
    'dist_header': 'નેટવર્ક અંતરની મર્યાદા:',
    'dist_pos': 'જાહેર ખુલ્લી જગ્યાઓ',
    'spacing_header': 'જાહેર ખુલ્લી જગ્યાઓના સીમા બિંદુઓ વચ્ચેનું અંતર:',
    'spacing_note': 'દરેક ખુલ્લી જગ્યાની રૂપરેખા પર મૂકેલા પ્રારંભ બિંદુઓ. 100 મીટર '
                    'માનક છે; વધુ અંતર (દા.ત. 200 મીટર) ઘણા મોટા ઉદ્યાનો ધરાવતા '
                    'શહેરો માટે ઝડપી છે પણ થોડું ઓછું ચોક્કસ.',
    'perf_header': 'કામગીરી:',
    'chk_preclip': 'ઇનપુટને પહેલેથી શહેરી વિસ્તાર સુધી ક્લિપ કરો',
    'note_preclip': 'ભલામણ કરેલ. ફક્ત શહેરી વિસ્તારની શોધ મર્યાદામાંની શેરીઓ, સ્ટોપ અને '
                    'ખુલ્લી જગ્યાઓ રાખે છે - રાષ્ટ્રીય/પ્રાદેશિક ડેટા સાથે ઘણું ઝડપી.',
    'chk_memory': 'મધ્યવર્તી સ્તરો મેમરીમાં રાખો',
    'note_memory': 'ઝડપી. કમ્પ્યુટરની RAM ખૂટે ત્યારે જ નિશાન દૂર કરો.',
    'chk_native': 'QGIS નો મૂળ સેવા વિસ્તાર અલ્ગોરિધમ વાપરો',
    'note_native': 'ફક્ત ચકાસણી માટે - ઘણા પ્રારંભ બિંદુઓ સાથે ખૂબ ધીમું. '
                   'ડિફૉલ્ટ ઝડપી મર્યાદિત શોધ છે (પરિણામો સમાન).',
    'grp_city': 'શહેરનું નામ (સૂચન: વિશેષ અક્ષરો ટાળો)',
    'city_placeholder': 'દા.ત. Mombasa',
    'lbl_output_folder': 'આઉટપુટ ફોલ્ડર:',
    'btn_browse': 'પસંદ કરો...',
    'info_block':
        "સાચવવામાં આવતી અંતિમ ફાઇલો:\n"
        "  ક્લિપ અને વિલય કરેલા સેવા વિસ્તારો:\n"
        "  SA_POS_dissolved.shp                જાહેર ખુલ્લી જગ્યાઓ\n"
        "  SA_Bus_dissolved.shp                ઓછી ક્ષમતાના સ્ટોપ\n"
        "  SA_Ferry_dissolved.shp              ફેરી ઘાટ\n"
        "  SA_Rail_dissolved.shp               રેલવે સ્ટેશનો\n"
        "  SA_HighCapacity_dissolved.shp       ઉચ્ચ ક્ષમતા (રેલ + ફેરી)\n"
        "  SA_CombinedTransport_dissolved.shp  સંયુક્ત જાહેર પરિવહન\n"
        "  અલગ (દરેક સ્ટોપના) સેવા વિસ્તારો:\n"
        "  SA_Bus_individual.shp / SA_Ferry_individual.shp / SA_Rail_individual.shp\n"
        "  ZonalStats_*.shp                    સેવા વિસ્તાર + pop_sum ક્ષેત્ર\n"
        "  LAS_streets_dissolved.shp           શેરીઓ માટે ફાળવેલી જમીન\n"
        "  {city}_statistics_11.2.1_and_11.7.1.xlsx\n\n"
        "નોંધો:\n"
        "  - પ્રક્રિયા પહેલાં ભૂમિતિ આપમેળે સુધારવામાં આવે છે.\n"
        "  - વસ્તી: ઘરગથ્થુ બિંદુઓ (વસ્તી ક્ષેત્રનો સરવાળો) આપ્યા હોય તો,\n"
        "    અન્યથા ગ્રિડ આધારિત વસ્તી રાસ્ટર.\n"
        "  - જાહેર ખુલ્લી જગ્યાઓનું ક્ષેત્રફળ શહેરી સીમા પર ક્લિપ કર્યા પછી મપાય છે.\n"
        "  - ઇનપુટ શહેરી વિસ્તાર + શોધ મર્યાદા સુધી ક્લિપ થાય છે અને મધ્યવર્તી\n"
        "    સ્તરો મેમરીમાં રહે છે (અંતરો ટૅબ જુઓ).\n"
        "  - સંયુક્ત પરિવહન = ઓછી ક્ષમતાના સ્ટોપ + ફેરી + રેલ\n"
        "    (જાહેર ખુલ્લી જગ્યાઓ સિવાય).\n"
        "  - શેરીઓ માટે ફાળવેલી જમીન: પહોળાઈ મુજબ શેરીઓનો બફર,\n"
        "    વિલય કરીને શહેરી વિસ્તાર સુધી ક્લિપ.\n"
        "  - આંકડાકીય કોષ્ટક પસંદ કરેલી ભાષામાં લખાય છે.\n"
        "  - ભૂલ પછી બટનો ફરી સક્રિય કરવા 'લૉગ સાફ કરો' વાપરો.",
    'msg_running_title': 'ચાલી રહ્યું છે',
    'msg_cannot_reset': 'વિશ્લેષણ ચાલતું હોય ત્યારે સાફ કરી શકાતું નથી. પહેલાં રદ કરો.',
    'msg_missing_layer': 'સ્તર ઉપલબ્ધ નથી',
    'msg_select_streets': 'કૃપા કરીને શેરીઓનો સ્તર પસંદ કરો.',
    'msg_select_urban': 'કૃપા કરીને શહેરી સીમાનો સ્તર પસંદ કરો.',
    'msg_missing_pop_title': 'વસ્તી ડેટા ઉપલબ્ધ નથી',
    'msg_missing_pop': 'કૃપા કરીને ગ્રિડ આધારિત વસ્તી (રાસ્ટર) સ્તર અથવા ઘરગથ્થુ વસ્તી '
                       '(બિંદુઓ) સ્તર પસંદ કરો - બેમાંથી એક જરૂરી છે.',
    'msg_missing_popfield_title': 'વસ્તી ક્ષેત્ર ઉપલબ્ધ નથી',
    'msg_missing_popfield': 'કૃપા કરીને ઘરગથ્થુ વસ્તી (બિંદુઓ) સ્તર માટે કુલ વસ્તીનું '
                            'ક્ષેત્ર પસંદ કરો.',
    'msg_missing_city_title': 'શહેરનું નામ ઉપલબ્ધ નથી',
    'msg_missing_city': 'કૃપા કરીને શહેરનું નામ દાખલ કરો.',
    'msg_missing_output_title': 'આઉટપુટ ઉપલબ્ધ નથી',
    'msg_missing_output': 'કૃપા કરીને આઉટપુટ ફોલ્ડર પસંદ કરો.',
    'msg_invalid_crs_title': 'અમાન્ય CRS',
    'msg_invalid_crs': 'કૃપા કરીને માન્ય લક્ષ્ય CRS પસંદ કરો.',
    'msg_no_transport_title': 'કોઈ પરિવહન સ્તર નથી',
    'msg_no_transport': 'જાહેર ખુલ્લી જગ્યાઓ / ઓછી ક્ષમતા / ફેરી / રેલનો કોઈ સ્તર પસંદ '
                        'કરાયો નથી. ફક્ત શહેરી વિસ્તાર અને શેરીઓની પ્રક્રિયા થશે. ચાલુ '
                        'રાખવું છે?',
    'msg_complete': 'પૂર્ણ',
    'msg_error': 'ભૂલ',
    'msg_failed': 'વિશ્લેષણ નિષ્ફળ ગયું. વિગતો માટે લૉગ જુઓ.\n\n'
                  '\'લૉગ સાફ કરો\' પર ક્લિક કરીને ફરી ચલાવો.',
    'msg_close_running': 'વિશ્લેષણ હજુ ચાલી રહ્યું છે. રદ કરીને બંધ કરવું છે?',
    'msg_cancel_requested': 'રદ કરવાની વિનંતી કરાઈ...',
    'dlg_select_output': 'આઉટપુટ ફોલ્ડર પસંદ કરો',
    'dlg_select_csv': 'માપેલી રસ્તાની પહોળાઈની CSV પસંદ કરો',
    'csv_filter': 'CSV ફાઇલો (*.csv *.txt);;બધી ફાઇલો (*)',
    'msg_invalid_csv_title': 'અમાન્ય CSV',
    'msg_invalid_csv': 'વાંચી શકાયું નથી:',
    'msg_widths_title': 'રસ્તાની પહોળાઈ CSV',
    'msg_widths_cols': 'રસ્તાની પહોળાઈના કોષ્ટકમાં ઓછામાં ઓછી બે કૉલમ (રસ્તાનો પ્રકાર, '
                       'પહોળાઈ) હોવી જોઈએ. તેને અવગણવામાં આવશે.',
    'res_done': 'પૂર્ણ!',
    'res_las': 'શેરીઓ માટે ફાળવેલી જમીન',
    'res_stats': 'આંકડાકીય કોષ્ટક (CSV)',
    'res_excel': 'આંકડાકીય વર્કબુક (Excel)',
    'res_roads': 'શેરીઓનું કોષ્ટક',
    'res_folder': 'ફોલ્ડર',
    'res_time': 'સમય',
    'h_city': 'શહેર',
    'h_urban_area': 'શહેરી ક્ષેત્રફળ (ચો. કિમી)',
    'h_pos_area': 'જાહેર ખુલ્લી જગ્યાઓનું ક્ષેત્રફળ (ચો. કિમી)',
    'h_las': 'શેરીઓ માટે ફાળવેલી જમીન (ચો. કિમી)',
    'h_ops_las': 'જાહેર ખુલ્લી જગ્યાઓ + શેરીઓ માટે ફાળવેલી જમીન (ચો. કિમી)',
    'h_prop_ops_las': 'શહેરી ક્ષેત્રફળમાં જાહેર ખુલ્લી જગ્યાઓ + શેરીઓ માટે ફાળવેલી જમીનનું '
                      'પ્રમાણ (%)',
    'h_total_pop': 'કુલ શહેરી વસ્તી',
    'h_pop_pos': 'જાહેર ખુલ્લી જગ્યાઓ સુધી પહોંચ ધરાવતી વસ્તી',
    'h_pop_bus': 'ઓછી ક્ષમતાના પરિવહન સ્ટોપ (બસ સ્ટોપ, લાઇટ રેલ સ્ટોપ) સુધી પહોંચ '
                 'ધરાવતી વસ્તી',
    'h_pop_hc': 'ઉચ્ચ ક્ષમતાના પરિવહન (રેલ + ફેરી) સુધી પહોંચ ધરાવતી વસ્તી',
    'h_pop_comb': 'સંયુક્ત જાહેર પરિવહન સુધી પહોંચ ધરાવતી વસ્તી',
    'h_pct_pos': 'જાહેર ખુલ્લી જગ્યાઓ સુધી પહોંચ ધરાવતી વસ્તીની ટકાવારી',
    'h_pct_bus': 'ઓછી ક્ષમતાના પરિવહન સ્ટોપ (બસ સ્ટોપ, લાઇટ રેલ સ્ટોપ) સુધી પહોંચ '
                 'ધરાવતી વસ્તીની ટકાવારી',
    'h_pct_hc': 'ઉચ્ચ ક્ષમતાના પરિવહન સુધી પહોંચ ધરાવતી વસ્તીની ટકાવારી',
    'h_pct_comb': 'સંયુક્ત જાહેર પરિવહન સુધી પહોંચ ધરાવતી વસ્તીની ટકાવારી',
    'h_pop_source': 'વસ્તી ડેટાનો સ્રોત',
    'src_household': 'ઘરગથ્થુ બિંદુઓ',
    'src_raster': 'ગ્રિડ રાસ્ટર',
    'src_field': 'ક્ષેત્ર',
}


# ---------------------------------------------------------- id: Bahasa Indonesia
_EXTRA_TEXT['id'] = {
    'win_title': 'Perhitungan Statistik SDG 11.2.1 dan 11.7.1',
    'subtitle': 'Pemotongan awal ke wilayah perkotaan -> Proyeksi ulang + perbaikan '
                'geometri -> Pemotongan ruang terbuka publik -> Titik batas -> Area '
                'layanan -> Selubung cembung -> Pemotongan -> Penggabungan -> '
                'Penduduk dalam area layanan -> Penggabungan lebar jalan -> Buffer -> '
                'Penggabungan -> Pemotongan (lahan untuk jalan) -> Tabel statistik',
    'language': 'Bahasa:',
    'tab_layers': 'Lapisan',
    'tab_distances': 'Jarak',
    'tab_output': 'Keluaran',
    'progress': 'Kemajuan',
    'btn_run': 'Jalankan analisis',
    'btn_cancel': 'Batal',
    'btn_reset': 'Hapus log',
    'btn_close': 'Tutup',
    'grp_streets': 'Jalan',
    'note_streets': 'Lapisan jalan yang digunakan untuk perutean jaringan',
    'grp_urban': 'Batas perkotaan',
    'note_urban': 'Lapisan poligon yang menentukan cakupan wilayah perkotaan',
    'grp_pop_raster': 'Penduduk berbasis grid (raster)',
    'note_pop_raster': 'Data penduduk berbasis grid. Berikan ini ATAU Penduduk rumah '
                       'tangga (titik) di bawah - salah satunya wajib.',
    'grp_hh': 'Penduduk rumah tangga (titik)',
    'note_hh': 'Lapisan titik dengan jumlah penduduk per rumah tangga. Berikan ini '
               'ATAU raster penduduk berbasis grid - salah satunya wajib. Jika '
               'keduanya diberikan, titik rumah tangga yang digunakan. Penduduk '
               'setiap area layanan = jumlah kolom terpilih dari titik-titik di '
               'dalamnya.',
    'lbl_pop_field': 'Kolom berisi total penduduk (per titik rumah tangga):',
    'grp_pos': 'Ruang terbuka publik (poligon)',
    'note_pos': 'Lapisan poligon berupa lahan tak terbangun atau terbuka yang dapat '
                'diakses publik, menyediakan area rekreasi bagi warga dan '
                'meningkatkan kualitas lingkungan. Contohnya taman, kebun, taman '
                'bermain, pantai umum, bantaran sungai, dan tepi air',
    'grp_bus': 'Halte angkutan berkapasitas rendah (halte bus, halte kereta '
               'ringan)',
    'note_bus': 'Lapisan titik lokasi halte bus / halte kereta ringan',
    'grp_rail': 'Halte angkutan berkapasitas tinggi (stasiun kereta, stasiun '
                'metro)',
    'note_rail': 'Lapisan titik lokasi stasiun kereta / metro',
    'grp_ferry': 'Halte angkutan berkapasitas tinggi (dermaga feri)',
    'note_ferry': 'Lapisan titik lokasi terminal feri',
    'grp_widths': 'Lebar jalan terukur (tabel CSV)',
    'note_widths': 'Digunakan untuk lahan untuk jalan. Kolom 1 = kategori jalan '
                   '(dicocokkan dengan kolom kategori jalan yang dipilih di bawah), '
                   'kolom 2 = lebar terukur dalam meter. Jika CSV tidak diberikan dan '
                   'tidak ada kolom kategori, lahan untuk jalan = 0.',
    'btn_browse_csv': 'Telusuri CSV...',
    'grp_catfield': 'Kolom kategori jalan (dari lapisan jalan)',
    'note_catfield': 'Kolom pada lapisan jalan yang berisi kategori jalan, digunakan '
                     'untuk menggabungkan lebar jalan. \'fclass\', \'highway\' atau '
                     '\'type\' dipilih otomatis jika ada; jika tidak, pilih kolom di '
                     'sini. Biarkan kosong untuk deteksi otomatis.',
    'grp_crs': 'Sistem referensi koordinat tujuan (terproyeksi, dalam meter - '
               'mis. UTM wilayah perkotaan)',
    'dist_header': 'Ambang jarak jaringan untuk:',
    'dist_pos': 'Ruang terbuka publik',
    'spacing_header': 'Jarak antar titik batas ruang terbuka publik:',
    'spacing_note': 'Titik awal yang ditempatkan di sepanjang garis tepi setiap ruang '
                    'terbuka. 100 m adalah standar; jarak lebih besar (mis. 200 m) '
                    'lebih cepat untuk kota dengan banyak taman besar, tetapi sedikit '
                    'kurang akurat.',
    'perf_header': 'Kinerja:',
    'chk_preclip': 'Potong data masukan terlebih dahulu ke wilayah perkotaan',
    'note_preclip': 'Disarankan. Hanya menyimpan jalan, halte, dan ruang terbuka di '
                    'dalam batas pencarian wilayah perkotaan - jauh lebih cepat untuk '
                    'data tingkat nasional atau regional.',
    'chk_memory': 'Simpan lapisan perantara di memori',
    'note_memory': 'Lebih cepat. Hapus centang hanya jika komputer kehabisan RAM.',
    'chk_native': 'Gunakan algoritma area layanan bawaan QGIS',
    'note_native': 'Hanya untuk pemeriksaan - sangat lambat dengan banyak titik awal. '
                   'Bawaan adalah pencarian terbatas yang cepat (hasil sama).',
    'grp_city': 'Nama kota (Tips: hindari karakter khusus)',
    'city_placeholder': 'mis. Mombasa',
    'lbl_output_folder': 'Folder keluaran:',
    'btn_browse': 'Telusuri...',
    'info_block':
        "Berkas akhir yang disimpan:\n"
        "  Area layanan yang dipotong dan digabungkan:\n"
        "  SA_POS_dissolved.shp                Ruang terbuka publik\n"
        "  SA_Bus_dissolved.shp                Halte kapasitas rendah\n"
        "  SA_Ferry_dissolved.shp              Dermaga feri\n"
        "  SA_Rail_dissolved.shp               Stasiun kereta\n"
        "  SA_HighCapacity_dissolved.shp       Kapasitas tinggi (kereta + feri)\n"
        "  SA_CombinedTransport_dissolved.shp  Angkutan umum gabungan\n"
        "  Area layanan individual (per halte):\n"
        "  SA_Bus_individual.shp / SA_Ferry_individual.shp / SA_Rail_individual.shp\n"
        "  ZonalStats_*.shp                    Area layanan + kolom pop_sum\n"
        "  LAS_streets_dissolved.shp           Lahan untuk jalan\n"
        "  {city}_statistics_11.2.1_and_11.7.1.xlsx\n\n"
        "CATATAN:\n"
        "  - Geometri diperbaiki otomatis sebelum pemrosesan.\n"
        "  - Penduduk: titik rumah tangga (jumlah kolom penduduk) jika diberikan,\n"
        "    jika tidak, raster penduduk berbasis grid.\n"
        "  - Luas ruang terbuka publik diukur setelah dipotong ke batas perkotaan.\n"
        "  - Data dipotong ke wilayah perkotaan + batas pencarian dan lapisan\n"
        "    perantara disimpan di memori (lihat tab Jarak).\n"
        "  - Angkutan gabungan = halte kapasitas rendah + feri + kereta\n"
        "    (ruang terbuka publik tidak termasuk).\n"
        "  - Lahan untuk jalan: buffer jalan sesuai lebarnya, digabungkan\n"
        "    dan dipotong ke cakupan perkotaan.\n"
        "  - Tabel statistik ditulis dalam bahasa yang dipilih.\n"
        "  - Gunakan 'Hapus log' untuk mengaktifkan kembali tombol setelah gagal.",
    'msg_running_title': 'Sedang berjalan',
    'msg_cannot_reset': 'Tidak dapat menghapus saat analisis berjalan. Batalkan '
                        'terlebih dahulu.',
    'msg_missing_layer': 'Lapisan tidak ada',
    'msg_select_streets': 'Silakan pilih lapisan jalan.',
    'msg_select_urban': 'Silakan pilih lapisan batas perkotaan.',
    'msg_missing_pop_title': 'Data penduduk tidak ada',
    'msg_missing_pop': 'Silakan pilih lapisan penduduk berbasis grid (raster) atau '
                       'lapisan penduduk rumah tangga (titik) - salah satunya wajib.',
    'msg_missing_popfield_title': 'Kolom penduduk tidak ada',
    'msg_missing_popfield': 'Silakan pilih kolom total penduduk untuk lapisan '
                            'penduduk rumah tangga (titik).',
    'msg_missing_city_title': 'Nama kota tidak ada',
    'msg_missing_city': 'Silakan masukkan nama kota.',
    'msg_missing_output_title': 'Folder keluaran tidak ada',
    'msg_missing_output': 'Silakan pilih folder keluaran.',
    'msg_invalid_crs_title': 'SRK tidak valid',
    'msg_invalid_crs': 'Silakan pilih SRK tujuan yang valid.',
    'msg_no_transport_title': 'Tidak ada lapisan transportasi',
    'msg_no_transport': 'Tidak ada lapisan ruang terbuka publik / kapasitas rendah / '
                        'feri / kereta yang dipilih. Hanya wilayah perkotaan dan '
                        'jalan yang akan diproses. Lanjutkan?',
    'msg_complete': 'Selesai',
    'msg_error': 'Galat',
    'msg_failed': 'Analisis gagal. Lihat log untuk detailnya.\n\n'
                  'Klik \'Hapus log\' lalu jalankan kembali.',
    'msg_close_running': 'Analisis masih berjalan. Batalkan dan tutup?',
    'msg_cancel_requested': 'Pembatalan diminta...',
    'dlg_select_output': 'Pilih folder keluaran',
    'dlg_select_csv': 'Pilih CSV lebar jalan terukur',
    'csv_filter': 'Berkas CSV (*.csv *.txt);;Semua berkas (*)',
    'msg_invalid_csv_title': 'CSV tidak valid',
    'msg_invalid_csv': 'Tidak dapat dibaca:',
    'msg_widths_title': 'CSV lebar jalan',
    'msg_widths_cols': 'Tabel lebar jalan memerlukan minimal dua kolom (kategori '
                       'jalan, lebar). Tabel ini akan diabaikan.',
    'res_done': 'Selesai!',
    'res_las': 'Lahan untuk jalan',
    'res_stats': 'Tabel statistik (CSV)',
    'res_excel': 'Buku kerja statistik (Excel)',
    'res_roads': 'Tabel jalan',
    'res_folder': 'Folder',
    'res_time': 'Waktu',
    'h_city': 'Kota',
    'h_urban_area': 'Luas wilayah perkotaan (km2)',
    'h_pos_area': 'Luas ruang terbuka publik (km2)',
    'h_las': 'Lahan untuk jalan (km2)',
    'h_ops_las': 'Ruang terbuka publik + lahan untuk jalan (km2)',
    'h_prop_ops_las': 'Proporsi wilayah perkotaan berupa ruang terbuka publik + '
                      'lahan untuk jalan (%)',
    'h_total_pop': 'Total penduduk perkotaan',
    'h_pop_pos': 'Penduduk dengan akses ke ruang terbuka publik',
    'h_pop_bus': 'Penduduk dengan akses ke halte angkutan berkapasitas rendah '
                 '(halte bus, halte kereta ringan)',
    'h_pop_hc': 'Penduduk dengan akses ke angkutan berkapasitas tinggi (kereta + '
                'feri)',
    'h_pop_comb': 'Penduduk dengan akses ke angkutan umum gabungan',
    'h_pct_pos': 'Persentase penduduk dengan akses ke ruang terbuka publik',
    'h_pct_bus': 'Persentase penduduk dengan akses ke halte angkutan berkapasitas '
                 'rendah (halte bus, halte kereta ringan)',
    'h_pct_hc': 'Persentase penduduk dengan akses ke angkutan berkapasitas tinggi',
    'h_pct_comb': 'Persentase penduduk dengan akses ke angkutan umum gabungan',
    'h_pop_source': 'Sumber data penduduk',
    'src_household': 'Titik rumah tangga',
    'src_raster': 'Raster grid',
    'src_field': 'kolom',
}


# ---------------------------------------------------------- tr: Türkçe
_EXTRA_TEXT['tr'] = {
    'win_title': 'SDG 11.2.1 ve 11.7.1 İstatistik Hesaplama',
    'subtitle': 'Kentsel Alana Ön Kırpma -> Yeniden Projeksiyon + Geometri Onarımı -> '
                'Açık Kamusal Alanları Kırpma -> Sınır Noktaları -> Hizmet Alanı -> '
                'Dışbükey Örtü -> Kırpma -> Birleştirme -> Etki Alanlarındaki Nüfus '
                '-> Yol Genişliği Birleştirme -> Tampon -> Birleştirme -> Kırpma '
                '(Sokaklara Ayrılan Alan) -> İstatistik Tablosu',
    'language': 'Dil:',
    'tab_layers': 'Katmanlar',
    'tab_distances': 'Mesafeler',
    'tab_output': 'Çıktı',
    'progress': 'İlerleme',
    'btn_run': 'Analizi Çalıştır',
    'btn_cancel': 'İptal',
    'btn_reset': 'Günlüğü Sıfırla',
    'btn_close': 'Kapat',
    'grp_streets': 'Sokaklar',
    'note_streets': 'Ağ üzerinde rota bulmak için kullanılan sokak katmanı',
    'grp_urban': 'Kentsel Sınır',
    'note_urban': 'Kentsel alanın kapsamını tanımlayan poligon katmanı',
    'grp_pop_raster': 'Gridlenmiş Nüfus (Raster)',
    'note_pop_raster': 'Gridlenmiş nüfus veri seti. Bunu VEYA aşağıdaki Hane Nüfusu '
                       '(Noktalar) katmanını sağlayın - ikisinden biri zorunludur.',
    'grp_hh': 'Hane Nüfusu (Noktalar)',
    'note_hh': 'Hane düzeyinde nüfus sayılarını içeren nokta katmanı. Bunu VEYA '
               'Gridlenmiş Nüfus rasterını sağlayın - ikisinden biri zorunludur. '
               'İkisi de verilirse hane noktaları kullanılır. Her etki alanındaki '
               'nüfus = içindeki noktalarda seçilen alanın toplamı.',
    'lbl_pop_field': 'Toplam nüfusu içeren alan (her hane noktası için):',
    'grp_pos': 'Açık Kamusal Alanlar (Poligonlar)',
    'note_pos': 'Halkın erişimine açık, yapılaşmamış veya açık araziyi temsil eden; '
                'sakinlere rekreasyon alanı sağlayan ve çevre kalitesini artıran '
                'poligon katmanları. Örnekler: parklar, bahçeler, oyun alanları, '
                'halk plajları, nehir kıyıları ve sahil şeritleri',
    'grp_bus': 'Düşük Kapasiteli Ulaşım Durakları (Otobüs Durakları, Hafif Raylı '
               'Durakları)',
    'note_bus': 'Otobüs durağı / hafif raylı durağı konumlarının nokta katmanı',
    'grp_rail': 'Yüksek Kapasiteli Ulaşım Durakları (Tren İstasyonları, Metro '
                'İstasyonları)',
    'note_rail': 'Tren/metro istasyonu konumlarının nokta katmanı',
    'grp_ferry': 'Yüksek Kapasiteli Ulaşım Durakları (Vapur İskeleleri)',
    'note_ferry': 'Vapur iskelesi konumlarının nokta katmanı',
    'grp_widths': 'Ölçülmüş Yol Genişlikleri (CSV tablosu)',
    'note_widths': 'Sokaklara Ayrılan Alan için kullanılır. Sütun 1 = yol kategorisi '
                   '(aşağıda seçilen Yol Kategorisi Alanı ile eşleştirilir), sütun 2 '
                   '= metre cinsinden ölçülmüş yol genişliği. CSV verilmezse ve yol '
                   'kategorisi alanı yoksa Sokaklara Ayrılan Alan = 0.',
    'btn_browse_csv': 'CSV Seç...',
    'grp_catfield': 'Yol Kategorisi Alanı (Sokaklar katmanından)',
    'note_catfield': "Sokaklar katmanında yol kategorilerini tutan ve yol "
                     "genişliklerini birleştirmek için kullanılan alan. 'fclass', "
                     "'highway' veya 'type' varsa otomatik seçilir; yoksa alanı "
                     "buradan seçin. Otomatik algılama için boş bırakın.",
    'grp_crs': 'Hedef Koordinat Referans Sistemi (Projeksiyonlu, Metre - ör. kentsel '
               'alan için UTM)',
    'dist_header': 'Ağ mesafesi eşiği:',
    'dist_pos': 'Açık Kamusal Alanlar',
    'spacing_header': 'Açık Kamusal Alanların sınır noktası aralığı:',
    'spacing_note': 'Her açık alanın sınırı boyunca yerleştirilen başlangıç '
                    'noktaları. Standart 100 m\'dir; daha geniş aralık (ör. 200 m) '
                    'çok sayıda büyük parkı olan şehirlerde daha hızlıdır ancak '
                    'biraz daha az hassastır.',
    'perf_header': 'Performans:',
    'chk_preclip': 'Girdileri kentsel alana göre önceden kırp',
    'note_preclip': 'Önerilir. Yalnızca kentsel alanın arama payı içindeki sokakları, '
                    'durakları ve açık alanları tutar - ülke/bölge çapındaki '
                    'verilerle çok daha hızlıdır.',
    'chk_memory': 'Ara katmanları bellekte tut',
    'note_memory': 'Daha hızlı. Yalnızca bilgisayarın RAM\'i yetmezse işareti kaldırın.',
    'chk_native': 'QGIS\'in yerel Hizmet Alanı algoritmasını kullan',
    'note_native': 'Yalnızca çapraz kontrol için - çok sayıda başlangıç noktasıyla '
                   'çok yavaştır. Varsayılan, hızlı sınırlı aramadır (aynı sonuçlar).',
    'grp_city': 'Şehir Adı (İpucu: Özel karakterlerden kaçının)',
    'city_placeholder': 'ör. Mombasa',
    'lbl_output_folder': 'Çıktı klasörü:',
    'btn_browse': 'Gözat...',
    'info_block':
        "Saklanan son dosyalar:\n"
        "  Kırpılmış + birleştirilmiş etki alanları (hizmet alanları):\n"
        "  SA_POS_dissolved.shp                Açık Kamusal Alanlar\n"
        "  SA_Bus_dissolved.shp                Düşük Kapasiteli Ulaşım Durakları\n"
        "  SA_Ferry_dissolved.shp              Vapur iskeleleri\n"
        "  SA_Rail_dissolved.shp               Raylı sistem durakları\n"
        "  SA_HighCapacity_dissolved.shp       Yüksek Kapasite (Raylı + Vapur)\n"
        "  SA_CombinedTransport_dissolved.shp  Toplam Toplu Taşıma\n"
        "  Tekil (durak başına) hizmet alanları:\n"
        "  SA_Bus_individual.shp / SA_Ferry_individual.shp / SA_Rail_individual.shp\n"
        "  ZonalStats_*.shp                    Etki alanı + pop_sum alanı\n"
        "  LAS_streets_dissolved.shp           Sokaklara Ayrılan Alan\n"
        "  {city}_statistics_11.2.1_and_11.7.1.xlsx\n\n"
        "NOTLAR:\n"
        "  - Geometriler işlemden önce otomatik olarak onarılır.\n"
        "  - Nüfus: verilmişse hane noktaları (nüfus alanının toplamı),\n"
        "    aksi halde gridlenmiş nüfus rasterı.\n"
        "  - Açık Kamusal Alan yüzölçümü kentsel sınıra kırpıldıktan sonra ölçülür.\n"
        "  - Girdiler kentsel alan + arama payına göre önceden kırpılır ve\n"
        "    ara katmanlar bellekte tutulur (değiştirmek için Mesafeler sekmesi).\n"
        "  - Toplam ulaşım = düşük kapasiteli duraklar + vapur + raylı\n"
        "    (Açık Kamusal Alanlar hariç).\n"
        "  - Sokaklara Ayrılan Alan: yollar genişliğe göre tamponlanır,\n"
        "    birleştirilir ve kentsel alana kırpılır.\n"
        "  - İstatistik tablosu seçilen dilde yazılır.\n"
        "  - Bir hatadan sonra günlüğü temizleyip düğmeleri etkinleştirmek için 'Günlüğü Sıfırla'yı kullanın.",
    'msg_running_title': 'Çalışıyor',
    'msg_cannot_reset': 'Analiz çalışırken sıfırlanamaz. Önce iptal edin.',
    'msg_missing_layer': 'Eksik Katman',
    'msg_select_streets': 'Lütfen bir Sokaklar katmanı seçin.',
    'msg_select_urban': 'Lütfen bir Kentsel Sınır katmanı seçin.',
    'msg_missing_pop_title': 'Eksik Nüfus Verisi',
    'msg_missing_pop': 'Lütfen bir Gridlenmiş Nüfus (Raster) katmanı veya bir Hane '
                       'Nüfusu (Noktalar) katmanı seçin - ikisinden biri zorunludur.',
    'msg_missing_popfield_title': 'Eksik Nüfus Alanı',
    'msg_missing_popfield': 'Lütfen Hane Nüfusu (Noktalar) katmanı için toplam nüfusu '
                            'içeren alanı seçin.',
    'msg_missing_city_title': 'Eksik Şehir Adı',
    'msg_missing_city': 'Lütfen bir şehir adı girin.',
    'msg_missing_output_title': 'Eksik Çıktı',
    'msg_missing_output': 'Lütfen bir çıktı klasörü seçin.',
    'msg_invalid_crs_title': 'Geçersiz CRS',
    'msg_invalid_crs': 'Lütfen geçerli bir hedef CRS seçin.',
    'msg_no_transport_title': 'Ulaşım Katmanı Yok',
    'msg_no_transport': 'Açık Kamusal Alan / Düşük Kapasite / Vapur / Raylı katmanı '
                        'seçilmedi. Yalnızca kentsel alan ve sokaklar işlenecek. '
                        'Devam edilsin mi?',
    'msg_complete': 'Tamamlandı',
    'msg_error': 'Hata',
    'msg_failed': "Analiz başarısız oldu. Ayrıntılar için günlüğe bakın.\n\n"
                  "Temizleyip yeniden çalıştırmak için 'Günlüğü Sıfırla'ya tıklayın.",
    'msg_close_running': 'Analiz hâlâ çalışıyor. İptal edip kapatılsın mı?',
    'msg_cancel_requested': 'İptal istendi...',
    'dlg_select_output': 'Çıktı Klasörünü Seçin',
    'dlg_select_csv': 'Ölçülmüş Yol Genişlikleri CSV Dosyasını Seçin',
    'csv_filter': 'CSV dosyaları (*.csv *.txt);;Tüm dosyalar (*)',
    'msg_invalid_csv_title': 'Geçersiz CSV',
    'msg_invalid_csv': 'Okunamadı:',
    'msg_widths_title': 'Yol Genişlikleri CSV',
    'msg_widths_cols': 'Yol genişlikleri tablosu en az iki sütun gerektirir (yol '
                       'kategorisi, genişlik). Yok sayılacak.',
    'res_done': 'Bitti!',
    'res_las': 'Sokaklara Ayrılan Alan',
    'res_stats': 'İstatistik tablosu (CSV)',
    'res_excel': 'İstatistik çalışma kitabı (Excel)',
    'res_roads': 'Yollar tablosu',
    'res_folder': 'Klasör',
    'res_time': 'Süre',
    'h_city': 'Şehir',
    'h_urban_area': 'Kentsel Alan (km2)',
    'h_pos_area': 'Açık Kamusal Alanların Yüzölçümü (km2)',
    'h_las': 'Sokaklara Ayrılan Alan (km2)',
    'h_ops_las': 'Açık Kamusal Alan + Sokaklara Ayrılan Alan (km2)',
    'h_prop_ops_las': 'Açık Kamusal Alan + Sokaklara Ayrılan Alanın Kentsel Alana '
                      'Oranı (%)',
    'h_total_pop': 'Toplam Kentsel Nüfus',
    'h_pop_pos': 'Açık Kamusal Alanlara Erişimi Olan Nüfus',
    'h_pop_bus': 'Düşük Kapasiteli Ulaşım Duraklarına (Otobüs Durakları, Hafif Raylı '
                 'Durakları) Erişimi Olan Nüfus',
    'h_pop_hc': 'Yüksek Kapasiteli Ulaşıma (Raylı + Vapur) Erişimi Olan Nüfus',
    'h_pop_comb': 'Toplam Toplu Taşımaya Erişimi Olan Nüfus',
    'h_pct_pos': 'Açık Kamusal Alanlara Erişimi Olan Nüfus Yüzdesi',
    'h_pct_bus': 'Düşük Kapasiteli Ulaşım Duraklarına (Otobüs Durakları, Hafif Raylı '
                 'Durakları) Erişimi Olan Nüfus Yüzdesi',
    'h_pct_hc': 'Yüksek Kapasiteli Ulaşıma Erişimi Olan Nüfus Yüzdesi',
    'h_pct_comb': 'Toplam Toplu Taşımaya Erişimi Olan Nüfus Yüzdesi',
    'h_pop_source': 'Nüfus Verisi Kaynağı',
    'src_household': 'Hane noktaları',
    'src_raster': 'Gridlenmiş raster',
    'src_field': 'alan',
}


# ---------------------------------------------------------- ko: 한국어
_EXTRA_TEXT['ko'] = {
    'win_title': 'SDG 11.2.1 및 11.7.1 통계 산출',
    'subtitle': '도시 지역으로 사전 자르기 -> 재투영 + 지오메트리 수정 -> 공공 오픈 '
                '스페이스 자르기 -> 경계점 -> 서비스 영역 -> 볼록 껍질 -> 자르기 -> '
                '디졸브 -> 서비스권 내 인구 -> 도로 폭 결합 -> 버퍼 -> 디졸브 -> '
                '자르기(도로 용지) -> 통계표',
    'language': '언어:',
    'tab_layers': '레이어',
    'tab_distances': '거리',
    'tab_output': '출력',
    'progress': '진행 상황',
    'btn_run': '분석 실행',
    'btn_cancel': '취소',
    'btn_reset': '로그 지우기',
    'btn_close': '닫기',
    'grp_streets': '도로',
    'note_streets': '네트워크 경로 탐색에 사용하는 도로 레이어',
    'grp_urban': '도시 경계',
    'note_urban': '도시 범위를 정의하는 폴리곤 레이어',
    'grp_pop_raster': '격자 인구(래스터)',
    'note_pop_raster': '격자 인구 데이터셋입니다. 이것 또는 아래의 가구 인구(포인트) 중 '
                       '하나를 지정하세요(둘 중 하나는 필수).',
    'grp_hh': '가구 인구(포인트)',
    'note_hh': '가구 단위 인구수를 담은 포인트 레이어입니다. 이것 또는 격자 인구 '
               '래스터 중 하나를 지정하세요(둘 중 하나는 필수). 둘 다 지정하면 가구 '
               '포인트를 사용합니다. 각 서비스권 인구 = 그 안에 있는 포인트의 선택한 '
               '필드 합계.',
    'lbl_pop_field': '총인구가 담긴 필드(가구 포인트별):',
    'grp_pos': '공공 오픈 스페이스(폴리곤)',
    'note_pos': '일반에 개방된 미개발지 또는 열린 토지를 나타내는 폴리곤 레이어로, '
                '주민에게 여가 공간을 제공하고 환경의 질을 높입니다. 예: 공원, 정원, '
                '놀이터, 공공 해변, 하천변, 수변 공간',
    'grp_bus': '저용량 대중교통 정류장(버스 정류장, 경전철 정류장)',
    'note_bus': '버스 정류장 / 경전철 정류장 위치 포인트 레이어',
    'grp_rail': '고용량 대중교통 역(철도역, 지하철역)',
    'note_rail': '철도역 / 지하철역 위치 포인트 레이어',
    'grp_ferry': '고용량 대중교통(여객선 터미널)',
    'note_ferry': '여객선 터미널 위치 포인트 레이어',
    'grp_widths': '실측 도로 폭(CSV 표)',
    'note_widths': '도로 용지 산출에 사용됩니다. 1열 = 도로 등급(아래에서 선택한 도로 '
                   '등급 필드와 대조), 2열 = 실측 폭(미터). CSV가 없고 도로 등급 필드도 '
                   '없으면 도로 용지 = 0입니다.',
    'btn_browse_csv': 'CSV 찾아보기...',
    'grp_catfield': '도로 등급 필드(도로 레이어)',
    'note_catfield': '도로 등급을 담은 도로 레이어의 필드로, 도로 폭 결합에 사용됩니다. '
                     '\'fclass\', \'highway\', \'type\'이 있으면 자동으로 선택되며, '
                     '없으면 여기서 필드를 선택하세요. 비워 두면 자동으로 감지합니다.',
    'grp_crs': '대상 좌표계(투영 좌표계, 미터 단위 - 예: 도시 지역의 UTM 존)',
    'dist_header': '네트워크 거리 임계값:',
    'dist_pos': '공공 오픈 스페이스',
    'spacing_header': '공공 오픈 스페이스 경계점 간격:',
    'spacing_note': '각 오픈 스페이스 외곽선을 따라 배치하는 시작점입니다. 표준은 100 m'
                    '입니다. 큰 공원이 많은 도시는 간격을 넓히면(예: 200 m) 더 빠르지만 '
                    '정확도는 약간 떨어집니다.',
    'perf_header': '성능:',
    'chk_preclip': '입력 데이터를 도시 지역으로 미리 자르기',
    'note_preclip': '권장. 도시 지역 탐색 범위 안의 도로, 정류장, 오픈 스페이스만 '
                    '유지합니다. 국가·지역 단위 데이터에서 훨씬 빠릅니다.',
    'chk_memory': '중간 레이어를 메모리에 유지',
    'note_memory': '더 빠릅니다. 컴퓨터 메모리가 부족할 때만 해제하세요.',
    'chk_native': 'QGIS 기본 서비스 영역 알고리즘 사용',
    'note_native': '검증용으로만 사용 - 시작점이 많으면 매우 느립니다. 기본값은 빠른 '
                   '제한 탐색입니다(결과 동일).',
    'grp_city': '도시 이름(팁: 특수 문자는 피하세요)',
    'city_placeholder': '예: Mombasa',
    'lbl_output_folder': '출력 폴더:',
    'btn_browse': '찾아보기...',
    'info_block':
        "보존되는 최종 파일:\n"
        "  자르기·디졸브한 서비스권:\n"
        "  SA_POS_dissolved.shp                공공 오픈 스페이스\n"
        "  SA_Bus_dissolved.shp                저용량 정류장\n"
        "  SA_Ferry_dissolved.shp              여객선 터미널\n"
        "  SA_Rail_dissolved.shp               철도역\n"
        "  SA_HighCapacity_dissolved.shp       고용량(철도 + 여객선)\n"
        "  SA_CombinedTransport_dissolved.shp  대중교통 전체\n"
        "  개별(정류장별) 서비스 영역:\n"
        "  SA_Bus_individual.shp / SA_Ferry_individual.shp / SA_Rail_individual.shp\n"
        "  ZonalStats_*.shp                    서비스권 + pop_sum 필드\n"
        "  LAS_streets_dissolved.shp           도로 용지\n"
        "  {city}_statistics_11.2.1_and_11.7.1.xlsx\n\n"
        "참고:\n"
        "  - 처리 전에 지오메트리를 자동으로 수정합니다.\n"
        "  - 인구: 가구 포인트가 있으면 인구 필드 합계,\n"
        "    없으면 격자 인구 래스터를 사용합니다.\n"
        "  - 공공 오픈 스페이스 면적은 도시 경계로 자른 뒤 측정합니다.\n"
        "  - 입력은 도시 지역 + 탐색 범위로 미리 자르고 중간 레이어는\n"
        "    메모리에 유지합니다(거리 탭에서 변경 가능).\n"
        "  - 대중교통 전체 = 저용량 정류장 + 여객선 + 철도\n"
        "    (공공 오픈 스페이스 제외).\n"
        "  - 도로 용지: 도로 폭에 따라 버퍼를 만들고 디졸브한 뒤\n"
        "    도시 범위로 자릅니다.\n"
        "  - 통계표는 선택한 언어로 작성됩니다.\n"
        "  - 실패 후에는 '로그 지우기'로 버튼을 다시 활성화하세요.",
    'msg_running_title': '실행 중',
    'msg_cannot_reset': '분석 실행 중에는 지울 수 없습니다. 먼저 취소하세요.',
    'msg_missing_layer': '레이어 없음',
    'msg_select_streets': '도로 레이어를 선택하세요.',
    'msg_select_urban': '도시 경계 레이어를 선택하세요.',
    'msg_missing_pop_title': '인구 데이터 없음',
    'msg_missing_pop': '격자 인구(래스터) 레이어 또는 가구 인구(포인트) 레이어를 '
                       '선택하세요(둘 중 하나는 필수).',
    'msg_missing_popfield_title': '인구 필드 없음',
    'msg_missing_popfield': '가구 인구(포인트) 레이어의 총인구 필드를 선택하세요.',
    'msg_missing_city_title': '도시 이름 없음',
    'msg_missing_city': '도시 이름을 입력하세요.',
    'msg_missing_output_title': '출력 폴더 없음',
    'msg_missing_output': '출력 폴더를 선택하세요.',
    'msg_invalid_crs_title': '잘못된 좌표계',
    'msg_invalid_crs': '올바른 대상 좌표계를 선택하세요.',
    'msg_no_transport_title': '교통 레이어 없음',
    'msg_no_transport': '공공 오픈 스페이스 / 저용량 / 여객선 / 철도 레이어가 선택되지 '
                        '않았습니다. 도시 지역과 도로만 처리합니다. 계속하시겠습니까?',
    'msg_complete': '완료',
    'msg_error': '오류',
    'msg_failed': '분석에 실패했습니다. 자세한 내용은 로그를 확인하세요.\n\n'
                  '\'로그 지우기\'를 누른 뒤 다시 실행하세요.',
    'msg_close_running': '분석이 아직 실행 중입니다. 취소하고 닫으시겠습니까?',
    'msg_cancel_requested': '취소를 요청했습니다...',
    'dlg_select_output': '출력 폴더 선택',
    'dlg_select_csv': '실측 도로 폭 CSV 선택',
    'csv_filter': 'CSV 파일 (*.csv *.txt);;모든 파일 (*)',
    'msg_invalid_csv_title': '잘못된 CSV',
    'msg_invalid_csv': '읽을 수 없습니다:',
    'msg_widths_title': '도로 폭 CSV',
    'msg_widths_cols': '도로 폭 표에는 최소 두 개의 열(도로 등급, 폭)이 필요합니다. 이 '
                       '표는 무시됩니다.',
    'res_done': '완료되었습니다!',
    'res_las': '도로 용지',
    'res_stats': '통계표(CSV)',
    'res_excel': '통계 통합 문서(Excel)',
    'res_roads': '도로 표',
    'res_folder': '폴더',
    'res_time': '소요 시간',
    'h_city': '도시',
    'h_urban_area': '도시 면적(km2)',
    'h_pos_area': '공공 오픈 스페이스 면적(km2)',
    'h_las': '도로 용지(km2)',
    'h_ops_las': '공공 오픈 스페이스 + 도로 용지(km2)',
    'h_prop_ops_las': '도시 면적 중 공공 오픈 스페이스 + 도로 용지 비율(%)',
    'h_total_pop': '도시 총인구',
    'h_pop_pos': '공공 오픈 스페이스 접근 가능 인구',
    'h_pop_bus': '저용량 대중교통 정류장(버스 정류장, 경전철 정류장) 접근 가능 인구',
    'h_pop_hc': '고용량 대중교통(철도 + 여객선) 접근 가능 인구',
    'h_pop_comb': '대중교통 전체 접근 가능 인구',
    'h_pct_pos': '공공 오픈 스페이스 접근 가능 인구 비율(%)',
    'h_pct_bus': '저용량 대중교통 정류장(버스 정류장, 경전철 정류장) 접근 가능 인구 '
                 '비율(%)',
    'h_pct_hc': '고용량 대중교통 접근 가능 인구 비율(%)',
    'h_pct_comb': '대중교통 전체 접근 가능 인구 비율(%)',
    'h_pop_source': '인구 데이터 출처',
    'src_household': '가구 포인트',
    'src_raster': '격자 래스터',
    'src_field': '필드',
}


# ---------------------------------------------------------- vi: Tiếng Việt
_EXTRA_TEXT['vi'] = {
    'win_title': 'Tính toán thống kê SDG 11.2.1 và 11.7.1',
    'subtitle': 'Cắt sơ bộ theo khu vực đô thị -> Chiếu lại + Sửa hình học -> Cắt '
                'không gian công cộng mở -> Điểm ranh giới -> Vùng phục vụ -> Bao '
                'lồi -> Cắt -> Hợp nhất -> Dân số trong vùng phục vụ -> Ghép độ '
                'rộng đường -> Vùng đệm -> Hợp nhất -> Cắt (Đất dành cho đường phố) '
                '-> Bảng thống kê',
    'language': 'Ngôn ngữ:',
    'tab_layers': 'Lớp',
    'tab_distances': 'Khoảng cách',
    'tab_output': 'Đầu ra',
    'progress': 'Tiến trình',
    'btn_run': 'Chạy phân tích',
    'btn_cancel': 'Hủy',
    'btn_reset': 'Xóa nhật ký',
    'btn_close': 'Đóng',
    'grp_streets': 'Đường phố',
    'note_streets': 'Lớp đường phố dùng để định tuyến trên mạng lưới',
    'grp_urban': 'Ranh giới đô thị',
    'note_urban': 'Lớp đa giác xác định phạm vi đô thị',
    'grp_pop_raster': 'Dân số dạng lưới (Raster)',
    'note_pop_raster': 'Bộ dữ liệu dân số dạng lưới. Cung cấp lớp này HOẶC lớp Dân số '
                       'hộ gia đình (Điểm) bên dưới - bắt buộc có một trong hai.',
    'grp_hh': 'Dân số hộ gia đình (Điểm)',
    'note_hh': 'Lớp điểm chứa số dân ở cấp hộ gia đình. Cung cấp lớp này HOẶC raster '
               'Dân số dạng lưới - bắt buộc có một trong hai. Nếu có cả hai, các điểm '
               'hộ gia đình sẽ được dùng. Dân số trong mỗi vùng phục vụ = tổng của '
               'trường đã chọn trên các điểm nằm bên trong.',
    'lbl_pop_field': 'Trường chứa tổng dân số (cho mỗi điểm hộ gia đình):',
    'grp_pos': 'Không gian công cộng mở (Đa giác)',
    'note_pos': 'Các lớp đa giác thể hiện đất chưa xây dựng hoặc đất trống mà công '
                'chúng có thể tiếp cận, cung cấp khu vui chơi giải trí cho cư dân và '
                'nâng cao chất lượng môi trường. Ví dụ: công viên, vườn hoa, sân '
                'chơi, bãi biển công cộng, bờ sông và khu ven nước',
    'grp_bus': 'Điểm dừng giao thông sức chứa thấp (Trạm xe buýt, Trạm đường sắt nhẹ)',
    'note_bus': 'Lớp điểm vị trí trạm xe buýt / trạm đường sắt nhẹ',
    'grp_rail': 'Điểm dừng giao thông sức chứa cao (Ga đường sắt, Ga tàu điện ngầm)',
    'note_rail': 'Lớp điểm vị trí ga đường sắt/tàu điện ngầm',
    'grp_ferry': 'Điểm dừng giao thông sức chứa cao (Bến phà)',
    'note_ferry': 'Lớp điểm vị trí bến phà',
    'grp_widths': 'Độ rộng đường đã đo (bảng CSV)',
    'note_widths': 'Dùng cho Đất dành cho đường phố. Cột 1 = loại đường (khớp với '
                   'Trường loại đường được chọn bên dưới), cột 2 = độ rộng đường đã '
                   'đo tính bằng mét. Nếu không có CSV và không có trường loại đường, '
                   'Đất dành cho đường phố = 0.',
    'btn_browse_csv': 'Chọn CSV...',
    'grp_catfield': 'Trường loại đường (từ lớp Đường phố)',
    'note_catfield': "Trường của lớp Đường phố chứa loại đường, dùng để ghép độ "
                     "rộng đường. 'fclass', 'highway' hoặc 'type' được chọn tự động "
                     "nếu có; nếu không, hãy chọn trường tại đây. Để trống để tự "
                     "động phát hiện.",
    'grp_crs': 'Hệ quy chiếu tọa độ đích (Phép chiếu, Mét - ví dụ UTM cho khu vực '
               'đô thị)',
    'dist_header': 'Ngưỡng khoảng cách mạng lưới cho:',
    'dist_pos': 'Không gian công cộng mở',
    'spacing_header': 'Khoảng cách giữa các điểm ranh giới của không gian công cộng mở:',
    'spacing_note': 'Các điểm xuất phát đặt dọc theo đường viền của mỗi không gian '
                    'mở. 100 m là tiêu chuẩn; khoảng cách lớn hơn (ví dụ 200 m) '
                    'nhanh hơn với các thành phố có nhiều công viên lớn nhưng kém '
                    'chính xác hơn một chút.',
    'perf_header': 'Hiệu năng:',
    'chk_preclip': 'Cắt sơ bộ dữ liệu đầu vào theo khu vực đô thị',
    'note_preclip': 'Khuyến nghị. Chỉ giữ lại đường phố, điểm dừng và không gian mở '
                    'trong phạm vi tìm kiếm quanh khu vực đô thị - nhanh hơn nhiều '
                    'với dữ liệu toàn quốc/toàn vùng.',
    'chk_memory': 'Giữ các lớp trung gian trong bộ nhớ',
    'note_memory': 'Nhanh hơn. Chỉ bỏ chọn nếu máy tính hết RAM.',
    'chk_native': 'Dùng thuật toán Vùng phục vụ gốc của QGIS',
    'note_native': 'Chỉ để kiểm tra chéo - rất chậm khi có nhiều điểm xuất phát. Mặc '
                   'định là tìm kiếm giới hạn nhanh (cùng kết quả).',
    'grp_city': 'Tên thành phố (Gợi ý: Tránh ký tự đặc biệt)',
    'city_placeholder': 'ví dụ Mombasa',
    'lbl_output_folder': 'Thư mục đầu ra:',
    'btn_browse': 'Duyệt...',
    'info_block':
        "Các tệp cuối cùng được giữ lại:\n"
        "  Vùng phục vụ đã cắt + hợp nhất:\n"
        "  SA_POS_dissolved.shp                Không gian công cộng mở\n"
        "  SA_Bus_dissolved.shp                Điểm dừng sức chứa thấp\n"
        "  SA_Ferry_dissolved.shp              Bến phà\n"
        "  SA_Rail_dissolved.shp               Ga đường sắt\n"
        "  SA_HighCapacity_dissolved.shp       Sức chứa cao (Đường sắt + Phà)\n"
        "  SA_CombinedTransport_dissolved.shp  Giao thông công cộng tổng hợp\n"
        "  Vùng phục vụ riêng (theo từng điểm dừng):\n"
        "  SA_Bus_individual.shp / SA_Ferry_individual.shp / SA_Rail_individual.shp\n"
        "  ZonalStats_*.shp                    Vùng phục vụ + trường pop_sum\n"
        "  LAS_streets_dissolved.shp           Đất dành cho đường phố\n"
        "  {city}_statistics_11.2.1_and_11.7.1.xlsx\n\n"
        "GHI CHÚ:\n"
        "  - Hình học được tự động sửa trước khi xử lý.\n"
        "  - Dân số: điểm hộ gia đình (tổng trường dân số) nếu có,\n"
        "    nếu không thì dùng raster dân số dạng lưới.\n"
        "  - Diện tích không gian công cộng mở được đo sau khi cắt theo ranh giới đô thị.\n"
        "  - Dữ liệu đầu vào được cắt sơ bộ theo khu vực đô thị + phạm vi tìm kiếm\n"
        "    và lớp trung gian được giữ trong bộ nhớ (xem thẻ Khoảng cách để thay đổi).\n"
        "  - Giao thông tổng hợp = điểm dừng sức chứa thấp + phà + đường sắt\n"
        "    (không bao gồm không gian công cộng mở).\n"
        "  - Đất dành cho đường phố: đường được tạo vùng đệm theo độ rộng,\n"
        "    hợp nhất và cắt theo phạm vi đô thị.\n"
        "  - Bảng thống kê được ghi bằng ngôn ngữ đã chọn.\n"
        "  - Dùng 'Xóa nhật ký' để xóa nhật ký và bật lại các nút sau khi gặp lỗi.",
    'msg_running_title': 'Đang chạy',
    'msg_cannot_reset': 'Không thể xóa khi phân tích đang chạy. Hãy hủy trước.',
    'msg_missing_layer': 'Thiếu lớp',
    'msg_select_streets': 'Vui lòng chọn lớp Đường phố.',
    'msg_select_urban': 'Vui lòng chọn lớp Ranh giới đô thị.',
    'msg_missing_pop_title': 'Thiếu dữ liệu dân số',
    'msg_missing_pop': 'Vui lòng chọn lớp Dân số dạng lưới (Raster) hoặc lớp Dân số '
                       'hộ gia đình (Điểm) - bắt buộc có một trong hai.',
    'msg_missing_popfield_title': 'Thiếu trường dân số',
    'msg_missing_popfield': 'Vui lòng chọn trường chứa tổng dân số cho lớp Dân số hộ '
                            'gia đình (Điểm).',
    'msg_missing_city_title': 'Thiếu tên thành phố',
    'msg_missing_city': 'Vui lòng nhập tên thành phố.',
    'msg_missing_output_title': 'Thiếu đầu ra',
    'msg_missing_output': 'Vui lòng chọn thư mục đầu ra.',
    'msg_invalid_crs_title': 'CRS không hợp lệ',
    'msg_invalid_crs': 'Vui lòng chọn CRS đích hợp lệ.',
    'msg_no_transport_title': 'Không có lớp giao thông',
    'msg_no_transport': 'Chưa chọn lớp Không gian công cộng mở / Sức chứa thấp / Phà / '
                        'Đường sắt nào. Chỉ khu vực đô thị và đường phố được xử lý. '
                        'Tiếp tục?',
    'msg_complete': 'Hoàn tất',
    'msg_error': 'Lỗi',
    'msg_failed': "Phân tích thất bại. Xem nhật ký để biết chi tiết.\n\n"
                  "Nhấn 'Xóa nhật ký' để xóa và chạy lại.",
    'msg_close_running': 'Phân tích vẫn đang chạy. Hủy và đóng?',
    'msg_cancel_requested': 'Đã yêu cầu hủy...',
    'dlg_select_output': 'Chọn thư mục đầu ra',
    'dlg_select_csv': 'Chọn CSV độ rộng đường đã đo',
    'csv_filter': 'Tệp CSV (*.csv *.txt);;Tất cả tệp (*)',
    'msg_invalid_csv_title': 'CSV không hợp lệ',
    'msg_invalid_csv': 'Không thể đọc:',
    'msg_widths_title': 'CSV độ rộng đường',
    'msg_widths_cols': 'Bảng độ rộng đường cần ít nhất hai cột (loại đường, độ rộng). '
                       'Bảng sẽ bị bỏ qua.',
    'res_done': 'Xong!',
    'res_las': 'Đất dành cho đường phố',
    'res_stats': 'Bảng thống kê (CSV)',
    'res_excel': 'Sổ thống kê (Excel)',
    'res_roads': 'Bảng đường',
    'res_folder': 'Thư mục',
    'res_time': 'Thời gian',
    'h_city': 'Thành phố',
    'h_urban_area': 'Diện tích đô thị (km2)',
    'h_pos_area': 'Diện tích không gian công cộng mở (km2)',
    'h_las': 'Đất dành cho đường phố (km2)',
    'h_ops_las': 'Không gian công cộng mở + Đất dành cho đường phố (km2)',
    'h_prop_ops_las': 'Tỷ lệ diện tích đô thị là không gian công cộng mở + đất dành '
                      'cho đường phố (%)',
    'h_total_pop': 'Tổng dân số đô thị',
    'h_pop_pos': 'Dân số tiếp cận được không gian công cộng mở',
    'h_pop_bus': 'Dân số tiếp cận được điểm dừng giao thông sức chứa thấp (Trạm xe '
                 'buýt, Trạm đường sắt nhẹ)',
    'h_pop_hc': 'Dân số tiếp cận được giao thông sức chứa cao (Đường sắt + Phà)',
    'h_pop_comb': 'Dân số tiếp cận được giao thông công cộng tổng hợp',
    'h_pct_pos': 'Tỷ lệ phần trăm dân số tiếp cận được không gian công cộng mở',
    'h_pct_bus': 'Tỷ lệ phần trăm dân số tiếp cận được điểm dừng giao thông sức chứa '
                 'thấp (Trạm xe buýt, Trạm đường sắt nhẹ)',
    'h_pct_hc': 'Tỷ lệ phần trăm dân số tiếp cận được giao thông sức chứa cao',
    'h_pct_comb': 'Tỷ lệ phần trăm dân số tiếp cận được giao thông công cộng tổng hợp',
    'h_pop_source': 'Nguồn dữ liệu dân số',
    'src_household': 'Điểm hộ gia đình',
    'src_raster': 'Raster dạng lưới',
    'src_field': 'trường',
}


# ---------------------------------------------------------- fa: فارسی
_EXTRA_TEXT['fa'] = {
    'win_title': 'محاسبه آمار SDG 11.2.1 و 11.7.1',
    'subtitle': 'برش اولیه به محدوده شهری ← بازتصویر + اصلاح هندسه ← برش فضاهای '
                'باز عمومی ← نقاط مرزی ← محدوده خدمات ← پوسته محدب ← برش ← ادغام ← '
                'جمعیت محدوده‌های خدمات ← پیوند عرض معابر ← حریم (بافر) ← ادغام ← '
                'برش (زمین اختصاص‌یافته به خیابان‌ها) ← جدول آماری',
    'language': 'زبان:',
    'tab_layers': 'لایه‌ها',
    'tab_distances': 'فاصله‌ها',
    'tab_output': 'خروجی',
    'progress': 'پیشرفت',
    'btn_run': 'اجرای تحلیل',
    'btn_cancel': 'لغو',
    'btn_reset': 'پاک کردن گزارش',
    'btn_close': 'بستن',
    'grp_streets': 'خیابان‌ها',
    'note_streets': 'لایه خیابان‌ها برای مسیریابی در شبکه',
    'grp_urban': 'محدوده شهری',
    'note_urban': 'لایه چندضلعی تعیین‌کننده گستره شهری',
    'grp_pop_raster': 'جمعیت شبکه‌ای (رستر)',
    'note_pop_raster': 'مجموعه داده جمعیت شبکه‌ای. این یا جمعیت خانوار (نقطه) در زیر '
                       'را وارد کنید - یکی از این دو الزامی است.',
    'grp_hh': 'جمعیت خانوار (نقطه)',
    'note_hh': 'لایه نقطه‌ای شامل تعداد جمعیت در سطح خانوار. این یا رستر جمعیت '
               'شبکه‌ای را وارد کنید - یکی از این دو الزامی است. اگر هر دو وارد '
               'شوند، نقاط خانوار استفاده می‌شوند. جمعیت هر محدوده خدمات = مجموع '
               'فیلد انتخاب‌شده نقاط درون آن.',
    'lbl_pop_field': 'فیلد حاوی کل جمعیت (برای هر نقطه خانوار):',
    'grp_pos': 'فضاهای باز عمومی (چندضلعی)',
    'note_pos': 'لایه‌های چندضلعی زمین‌های ساخته‌نشده یا باز در دسترس عموم که فضای '
                'تفریحی برای ساکنان فراهم می‌کنند و کیفیت محیط را بهبود می‌بخشند. '
                'مانند پارک‌ها، باغ‌ها، زمین‌های بازی، سواحل عمومی، حاشیه رودخانه‌ها '
                'و کرانه‌های آبی',
    'grp_bus': 'ایستگاه‌های حمل‌ونقل کم‌ظرفیت (ایستگاه اتوبوس، ایستگاه قطار سبک)',
    'note_bus': 'لایه نقطه‌ای موقعیت ایستگاه‌های اتوبوس / قطار سبک',
    'grp_rail': 'ایستگاه‌های حمل‌ونقل پرظرفیت (ایستگاه راه‌آهن، ایستگاه مترو)',
    'note_rail': 'لایه نقطه‌ای موقعیت ایستگاه‌های راه‌آهن / مترو',
    'grp_ferry': 'ایستگاه‌های حمل‌ونقل پرظرفیت (اسکله‌های کشتی مسافربری)',
    'note_ferry': 'لایه نقطه‌ای موقعیت پایانه‌های کشتی مسافربری',
    'grp_widths': 'عرض اندازه‌گیری‌شده معابر (جدول CSV)',
    'note_widths': 'برای محاسبه زمین اختصاص‌یافته به خیابان‌ها استفاده می‌شود. ستون 1 = '
                   'رده معبر (با فیلد رده معبر انتخاب‌شده در زیر تطبیق داده می‌شود)، '
                   'ستون 2 = عرض اندازه‌گیری‌شده به متر. اگر CSV وارد نشود و فیلد رده '
                   'وجود نداشته باشد، زمین اختصاص‌یافته به خیابان‌ها = 0.',
    'btn_browse_csv': 'انتخاب CSV...',
    'grp_catfield': 'فیلد رده معبر (از لایه خیابان‌ها)',
    'note_catfield': 'فیلدی از لایه خیابان‌ها که رده معابر را دارد و برای پیوند عرض‌ها '
                     'به کار می‌رود. \'fclass\'، \'highway\' یا \'type\' در صورت وجود '
                     'خودکار انتخاب می‌شود؛ در غیر این صورت فیلد را اینجا انتخاب کنید. '
                     'برای تشخیص خودکار خالی بگذارید.',
    'grp_crs': 'سیستم مختصات مرجع مقصد (تصویرشده، بر حسب متر - مثلاً منطقه UTM '
               'محدوده شهری)',
    'dist_header': 'آستانه فاصله شبکه برای:',
    'dist_pos': 'فضاهای باز عمومی',
    'spacing_header': 'فاصله نقاط مرزی فضاهای باز عمومی:',
    'spacing_note': 'نقاط شروعی که در امتداد محیط هر فضای باز قرار می‌گیرند. 100 متر '
                    'استاندارد است؛ فاصله بیشتر (مثلاً 200 متر) برای شهرهایی با '
                    'پارک‌های بزرگ فراوان سریع‌تر است اما کمی دقت کمتری دارد.',
    'perf_header': 'کارایی:',
    'chk_preclip': 'برش اولیه داده‌های ورودی به محدوده شهری',
    'note_preclip': 'توصیه می‌شود. فقط خیابان‌ها، ایستگاه‌ها و فضاهای باز درون حاشیه '
                    'جستجوی محدوده شهری را نگه می‌دارد - با داده‌های ملی یا منطقه‌ای '
                    'بسیار سریع‌تر است.',
    'chk_memory': 'نگهداری لایه‌های میانی در حافظه',
    'note_memory': 'سریع‌تر. فقط اگر حافظه RAM رایانه کافی نیست تیک را بردارید.',
    'chk_native': 'استفاده از الگوریتم محدوده خدمات خود QGIS',
    'note_native': 'فقط برای بررسی - با نقاط شروع زیاد بسیار کند است. پیش‌فرض، جستجوی '
                   'محدود سریع است (نتایج یکسان).',
    'grp_city': 'نام شهر (نکته: از نویسه‌های خاص پرهیز کنید)',
    'city_placeholder': 'مثلاً Mombasa',
    'lbl_output_folder': 'پوشه خروجی:',
    'btn_browse': 'انتخاب...',
    'info_block':
        "فایل‌های نهایی نگهداری‌شده:\n"
        "  محدوده‌های خدمات برش‌خورده و ادغام‌شده:\n"
        "  SA_POS_dissolved.shp                فضاهای باز عمومی\n"
        "  SA_Bus_dissolved.shp                ایستگاه‌های کم‌ظرفیت\n"
        "  SA_Ferry_dissolved.shp              اسکله‌های کشتی\n"
        "  SA_Rail_dissolved.shp               ایستگاه‌های راه‌آهن\n"
        "  SA_HighCapacity_dissolved.shp       پرظرفیت (ریلی + کشتی)\n"
        "  SA_CombinedTransport_dissolved.shp  حمل‌ونقل عمومی تجمیعی\n"
        "  محدوده‌های خدمات جداگانه (برای هر ایستگاه):\n"
        "  SA_Bus_individual.shp / SA_Ferry_individual.shp / SA_Rail_individual.shp\n"
        "  ZonalStats_*.shp                    محدوده خدمات + فیلد pop_sum\n"
        "  LAS_streets_dissolved.shp           زمین اختصاص‌یافته به خیابان‌ها\n"
        "  {city}_statistics_11.2.1_and_11.7.1.xlsx\n\n"
        "یادداشت‌ها:\n"
        "  - هندسه‌ها پیش از پردازش به‌طور خودکار اصلاح می‌شوند.\n"
        "  - جمعیت: نقاط خانوار (مجموع فیلد جمعیت) در صورت وجود،\n"
        "    وگرنه رستر جمعیت شبکه‌ای.\n"
        "  - مساحت فضاهای باز عمومی پس از برش به محدوده شهری اندازه‌گیری می‌شود.\n"
        "  - ورودی‌ها به محدوده شهری + حاشیه جستجو برش می‌خورند و لایه‌های\n"
        "    میانی در حافظه نگه داشته می‌شوند (زبانه فاصله‌ها را ببینید).\n"
        "  - حمل‌ونقل تجمیعی = ایستگاه‌های کم‌ظرفیت + کشتی + ریلی\n"
        "    (بدون فضاهای باز عمومی).\n"
        "  - زمین اختصاص‌یافته به خیابان‌ها: حریم خیابان‌ها بر اساس عرض،\n"
        "    ادغام و برش به گستره شهری.\n"
        "  - جدول آماری به زبان انتخاب‌شده نوشته می‌شود.\n"
        "  - پس از خطا با «پاک کردن گزارش» دکمه‌ها را دوباره فعال کنید.",
    'msg_running_title': 'در حال اجرا',
    'msg_cannot_reset': 'هنگام اجرای تحلیل نمی‌توان پاک کرد. ابتدا لغو کنید.',
    'msg_missing_layer': 'لایه موجود نیست',
    'msg_select_streets': 'لطفاً لایه خیابان‌ها را انتخاب کنید.',
    'msg_select_urban': 'لطفاً لایه محدوده شهری را انتخاب کنید.',
    'msg_missing_pop_title': 'داده جمعیت موجود نیست',
    'msg_missing_pop': 'لطفاً لایه جمعیت شبکه‌ای (رستر) یا لایه جمعیت خانوار (نقطه) را '
                       'انتخاب کنید - یکی از این دو الزامی است.',
    'msg_missing_popfield_title': 'فیلد جمعیت موجود نیست',
    'msg_missing_popfield': 'لطفاً فیلد کل جمعیت را برای لایه جمعیت خانوار (نقطه) '
                            'انتخاب کنید.',
    'msg_missing_city_title': 'نام شهر وارد نشده',
    'msg_missing_city': 'لطفاً نام شهر را وارد کنید.',
    'msg_missing_output_title': 'پوشه خروجی تعیین نشده',
    'msg_missing_output': 'لطفاً یک پوشه خروجی انتخاب کنید.',
    'msg_invalid_crs_title': 'سیستم مختصات نامعتبر',
    'msg_invalid_crs': 'لطفاً یک سیستم مختصات مقصد معتبر انتخاب کنید.',
    'msg_no_transport_title': 'لایه حمل‌ونقل وجود ندارد',
    'msg_no_transport': 'هیچ لایه‌ای از فضاهای باز عمومی / کم‌ظرفیت / کشتی / ریلی '
                        'انتخاب نشده است. فقط محدوده شهری و خیابان‌ها پردازش می‌شوند. '
                        'ادامه می‌دهید؟',
    'msg_complete': 'تکمیل شد',
    'msg_error': 'خطا',
    'msg_failed': 'تحلیل ناموفق بود. برای جزئیات گزارش را ببینید.\n\n'
                  'روی «پاک کردن گزارش» کلیک کنید و دوباره اجرا کنید.',
    'msg_close_running': 'تحلیل هنوز در حال اجراست. لغو و بسته شود؟',
    'msg_cancel_requested': 'درخواست لغو ثبت شد...',
    'dlg_select_output': 'انتخاب پوشه خروجی',
    'dlg_select_csv': 'انتخاب CSV عرض اندازه‌گیری‌شده معابر',
    'csv_filter': 'فایل‌های CSV (*.csv *.txt);;همه فایل‌ها (*)',
    'msg_invalid_csv_title': 'CSV نامعتبر',
    'msg_invalid_csv': 'خوانده نشد:',
    'msg_widths_title': 'CSV عرض معابر',
    'msg_widths_cols': 'جدول عرض معابر باید دست‌کم دو ستون (رده معبر، عرض) داشته باشد. '
                       'این جدول نادیده گرفته می‌شود.',
    'res_done': 'تکمیل شد!',
    'res_las': 'زمین اختصاص‌یافته به خیابان‌ها',
    'res_stats': 'جدول آماری (CSV)',
    'res_excel': 'کارپوشه آماری (Excel)',
    'res_roads': 'جدول خیابان‌ها',
    'res_folder': 'پوشه',
    'res_time': 'زمان',
    'h_city': 'شهر',
    'h_urban_area': 'مساحت شهری (کیلومتر مربع)',
    'h_pos_area': 'مساحت فضاهای باز عمومی (کیلومتر مربع)',
    'h_las': 'زمین اختصاص‌یافته به خیابان‌ها (کیلومتر مربع)',
    'h_ops_las': 'فضاهای باز عمومی + زمین اختصاص‌یافته به خیابان‌ها (کیلومتر مربع)',
    'h_prop_ops_las': 'سهم فضاهای باز عمومی + زمین اختصاص‌یافته به خیابان‌ها از مساحت '
                      'شهری (%)',
    'h_total_pop': 'کل جمعیت شهری',
    'h_pop_pos': 'جمعیت دارای دسترسی به فضاهای باز عمومی',
    'h_pop_bus': 'جمعیت دارای دسترسی به ایستگاه‌های حمل‌ونقل کم‌ظرفیت (ایستگاه '
                 'اتوبوس، ایستگاه قطار سبک)',
    'h_pop_hc': 'جمعیت دارای دسترسی به حمل‌ونقل پرظرفیت (ریلی + کشتی)',
    'h_pop_comb': 'جمعیت دارای دسترسی به حمل‌ونقل عمومی تجمیعی',
    'h_pct_pos': 'درصد جمعیت دارای دسترسی به فضاهای باز عمومی',
    'h_pct_bus': 'درصد جمعیت دارای دسترسی به ایستگاه‌های حمل‌ونقل کم‌ظرفیت (ایستگاه '
                 'اتوبوس، ایستگاه قطار سبک)',
    'h_pct_hc': 'درصد جمعیت دارای دسترسی به حمل‌ونقل پرظرفیت',
    'h_pct_comb': 'درصد جمعیت دارای دسترسی به حمل‌ونقل عمومی تجمیعی',
    'h_pop_source': 'منبع داده جمعیت',
    'src_household': 'نقاط خانوار',
    'src_raster': 'رستر شبکه‌ای',
    'src_field': 'فیلد',
}


# ---------------------------------------------------------- th: ไทย
_EXTRA_TEXT['th'] = {
    'win_title': 'การคำนวณสถิติ SDG 11.2.1 และ 11.7.1',
    'subtitle': 'ตัดข้อมูลเบื้องต้นตามพื้นที่เมือง -> ฉายพิกัดใหม่ + แก้ไขรูปเรขาคณิต '
                '-> ตัดพื้นที่สาธารณะเปิดโล่ง -> จุดขอบเขต -> พื้นที่บริการ -> '
                'เปลือกนูน -> ตัด -> รวม -> ประชากรในพื้นที่บริการ -> เชื่อมความกว้าง'
                'ถนน -> บัฟเฟอร์ -> รวม -> ตัด (ที่ดินที่จัดสรรให้ถนน) -> ตารางสถิติ',
    'language': 'ภาษา:',
    'tab_layers': 'ชั้นข้อมูล',
    'tab_distances': 'ระยะทาง',
    'tab_output': 'ผลลัพธ์',
    'progress': 'ความคืบหน้า',
    'btn_run': 'เริ่มการวิเคราะห์',
    'btn_cancel': 'ยกเลิก',
    'btn_reset': 'ล้างบันทึก',
    'btn_close': 'ปิด',
    'grp_streets': 'ถนน',
    'note_streets': 'ชั้นข้อมูลถนนที่ใช้หาเส้นทางบนโครงข่าย',
    'grp_urban': 'ขอบเขตเมือง',
    'note_urban': 'ชั้นข้อมูลรูปหลายเหลี่ยมที่กำหนดขอบเขตพื้นที่เมือง',
    'grp_pop_raster': 'ประชากรแบบกริด (แรสเตอร์)',
    'note_pop_raster': 'ชุดข้อมูลประชากรแบบกริด ระบุชั้นข้อมูลนี้ หรือ ประชากรครัวเรือน '
                       '(จุด) ด้านล่าง - ต้องมีอย่างใดอย่างหนึ่ง',
    'grp_hh': 'ประชากรครัวเรือน (จุด)',
    'note_hh': 'ชั้นข้อมูลจุดที่มีจำนวนประชากรระดับครัวเรือน ระบุชั้นข้อมูลนี้ หรือ '
               'แรสเตอร์ประชากรแบบกริด - ต้องมีอย่างใดอย่างหนึ่ง หากระบุทั้งสองจะใช้จุด'
               'ครัวเรือน ประชากรในแต่ละพื้นที่บริการ = ผลรวมของฟิลด์ที่เลือกจากจุดที่อยู่'
               'ภายใน',
    'lbl_pop_field': 'ฟิลด์ที่มีจำนวนประชากรทั้งหมด (ต่อจุดครัวเรือน):',
    'grp_pos': 'พื้นที่สาธารณะเปิดโล่ง (รูปหลายเหลี่ยม)',
    'note_pos': 'ชั้นข้อมูลรูปหลายเหลี่ยมที่แสดงพื้นที่ว่างหรือที่โล่งซึ่งประชาชนเข้าถึงได้ '
                'เป็นพื้นที่นันทนาการสำหรับผู้อยู่อาศัยและช่วยยกระดับคุณภาพสิ่งแวดล้อม '
                'ตัวอย่างเช่น สวนสาธารณะ สวน สนามเด็กเล่น ชายหาดสาธารณะ ริมแม่น้ำ และ'
                'พื้นที่ริมน้ำ',
    'grp_bus': 'จุดจอดขนส่งความจุต่ำ (ป้ายรถเมล์ สถานีรถไฟฟ้ารางเบา)',
    'note_bus': 'ชั้นข้อมูลจุดตำแหน่งป้ายรถเมล์ / สถานีรถไฟฟ้ารางเบา',
    'grp_rail': 'จุดจอดขนส่งความจุสูง (สถานีรถไฟ สถานีรถไฟฟ้ามหานคร)',
    'note_rail': 'ชั้นข้อมูลจุดตำแหน่งสถานีรถไฟ/รถไฟฟ้ามหานคร',
    'grp_ferry': 'จุดจอดขนส่งความจุสูง (ท่าเรือข้ามฟาก)',
    'note_ferry': 'ชั้นข้อมูลจุดตำแหน่งท่าเรือข้ามฟาก',
    'grp_widths': 'ความกว้างถนนที่วัดได้ (ตาราง CSV)',
    'note_widths': 'ใช้สำหรับที่ดินที่จัดสรรให้ถนน คอลัมน์ 1 = ประเภทถนน (จับคู่กับ'
                   'ฟิลด์ประเภทถนนที่เลือกด้านล่าง) คอลัมน์ 2 = ความกว้างถนนที่วัดได้'
                   'เป็นเมตร หากไม่มี CSV และไม่มีฟิลด์ประเภทถนน ที่ดินที่จัดสรรให้ถนน = 0',
    'btn_browse_csv': 'เลือก CSV...',
    'grp_catfield': 'ฟิลด์ประเภทถนน (จากชั้นข้อมูลถนน)',
    'note_catfield': "ฟิลด์ของชั้นข้อมูลถนนที่เก็บประเภทถนน ใช้สำหรับเชื่อมความกว้าง"
                     "ถนน 'fclass', 'highway' หรือ 'type' จะถูกเลือกอัตโนมัติหากมี "
                     "มิฉะนั้นให้เลือกฟิลด์ที่นี่ เว้นว่างไว้เพื่อตรวจหาอัตโนมัติ",
    'grp_crs': 'ระบบพิกัดอ้างอิงเป้าหมาย (แบบฉาย หน่วยเมตร - เช่น UTM สำหรับพื้นที่'
               'เมือง)',
    'dist_header': 'เกณฑ์ระยะทางบนโครงข่ายสำหรับ:',
    'dist_pos': 'พื้นที่สาธารณะเปิดโล่ง',
    'spacing_header': 'ระยะห่างของจุดขอบเขตพื้นที่สาธารณะเปิดโล่ง:',
    'spacing_note': 'จุดเริ่มต้นที่วางตามแนวขอบของพื้นที่เปิดโล่งแต่ละแห่ง 100 ม. เป็น'
                    'ค่ามาตรฐาน ระยะห่างที่มากขึ้น (เช่น 200 ม.) จะเร็วกว่าสำหรับเมืองที่มี'
                    'สวนขนาดใหญ่จำนวนมาก แต่แม่นยำน้อยลงเล็กน้อย',
    'perf_header': 'ประสิทธิภาพ:',
    'chk_preclip': 'ตัดข้อมูลนำเข้าเบื้องต้นตามพื้นที่เมือง',
    'note_preclip': 'แนะนำ เก็บเฉพาะถนน จุดจอด และพื้นที่เปิดโล่งที่อยู่ในระยะค้นหา'
                    'รอบพื้นที่เมือง - เร็วกว่ามากเมื่อใช้ข้อมูลระดับประเทศ/ภูมิภาค',
    'chk_memory': 'เก็บชั้นข้อมูลระหว่างกลางไว้ในหน่วยความจำ',
    'note_memory': 'เร็วกว่า ยกเลิกการเลือกเฉพาะเมื่อคอมพิวเตอร์มี RAM ไม่พอ',
    'chk_native': 'ใช้อัลกอริทึมพื้นที่บริการดั้งเดิมของ QGIS',
    'note_native': 'สำหรับการตรวจสอบเปรียบเทียบเท่านั้น - ช้ามากเมื่อมีจุดเริ่มต้นจำนวน'
                   'มาก ค่าเริ่มต้นคือการค้นหาแบบจำกัดขอบเขตที่รวดเร็ว (ผลลัพธ์เหมือนกัน)',
    'grp_city': 'ชื่อเมือง (คำแนะนำ: หลีกเลี่ยงอักขระพิเศษ)',
    'city_placeholder': 'เช่น Mombasa',
    'lbl_output_folder': 'โฟลเดอร์ผลลัพธ์:',
    'btn_browse': 'เรียกดู...',
    'info_block':
        "ไฟล์สุดท้ายที่เก็บไว้:\n"
        "  พื้นที่บริการที่ตัดและรวมแล้ว:\n"
        "  SA_POS_dissolved.shp                พื้นที่สาธารณะเปิดโล่ง\n"
        "  SA_Bus_dissolved.shp                จุดจอดขนส่งความจุต่ำ\n"
        "  SA_Ferry_dissolved.shp              ท่าเรือข้ามฟาก\n"
        "  SA_Rail_dissolved.shp               สถานีรถไฟ\n"
        "  SA_HighCapacity_dissolved.shp       ความจุสูง (ราง + เรือข้ามฟาก)\n"
        "  SA_CombinedTransport_dissolved.shp  ขนส่งสาธารณะรวม\n"
        "  พื้นที่บริการรายจุดจอด:\n"
        "  SA_Bus_individual.shp / SA_Ferry_individual.shp / SA_Rail_individual.shp\n"
        "  ZonalStats_*.shp                    พื้นที่บริการ + ฟิลด์ pop_sum\n"
        "  LAS_streets_dissolved.shp           ที่ดินที่จัดสรรให้ถนน\n"
        "  {city}_statistics_11.2.1_and_11.7.1.xlsx\n\n"
        "หมายเหตุ:\n"
        "  - รูปเรขาคณิตจะถูกแก้ไขโดยอัตโนมัติก่อนการประมวลผล\n"
        "  - ประชากร: จุดครัวเรือน (ผลรวมของฟิลด์ประชากร) หากระบุ\n"
        "    มิฉะนั้นใช้แรสเตอร์ประชากรแบบกริด\n"
        "  - พื้นที่สาธารณะเปิดโล่งวัดหลังจากตัดตามขอบเขตเมือง\n"
        "  - ข้อมูลนำเข้าถูกตัดเบื้องต้นตามพื้นที่เมือง + ระยะค้นหา และ\n"
        "    ชั้นข้อมูลระหว่างกลางเก็บในหน่วยความจำ (ดูแท็บระยะทางเพื่อเปลี่ยน)\n"
        "  - ขนส่งรวม = จุดจอดความจุต่ำ + เรือข้ามฟาก + ราง\n"
        "    (ไม่รวมพื้นที่สาธารณะเปิดโล่ง)\n"
        "  - ที่ดินที่จัดสรรให้ถนน: บัฟเฟอร์ถนนตามความกว้าง รวม\n"
        "    และตัดตามขอบเขตเมือง\n"
        "  - ตารางสถิติจะเขียนเป็นภาษาที่เลือก\n"
        "  - ใช้ 'ล้างบันทึก' เพื่อล้างบันทึกและเปิดใช้งานปุ่มอีกครั้งหลังเกิดข้อผิดพลาด",
    'msg_running_title': 'กำลังทำงาน',
    'msg_cannot_reset': 'ไม่สามารถล้างได้ขณะการวิเคราะห์กำลังทำงาน กรุณายกเลิกก่อน',
    'msg_missing_layer': 'ไม่พบชั้นข้อมูล',
    'msg_select_streets': 'กรุณาเลือกชั้นข้อมูลถนน',
    'msg_select_urban': 'กรุณาเลือกชั้นข้อมูลขอบเขตเมือง',
    'msg_missing_pop_title': 'ไม่พบข้อมูลประชากร',
    'msg_missing_pop': 'กรุณาเลือกชั้นข้อมูลประชากรแบบกริด (แรสเตอร์) หรือชั้นข้อมูล'
                       'ประชากรครัวเรือน (จุด) - ต้องมีอย่างใดอย่างหนึ่ง',
    'msg_missing_popfield_title': 'ไม่พบฟิลด์ประชากร',
    'msg_missing_popfield': 'กรุณาเลือกฟิลด์ที่มีจำนวนประชากรทั้งหมดสำหรับชั้นข้อมูล'
                            'ประชากรครัวเรือน (จุด)',
    'msg_missing_city_title': 'ไม่พบชื่อเมือง',
    'msg_missing_city': 'กรุณาป้อนชื่อเมือง',
    'msg_missing_output_title': 'ไม่พบโฟลเดอร์ผลลัพธ์',
    'msg_missing_output': 'กรุณาเลือกโฟลเดอร์ผลลัพธ์',
    'msg_invalid_crs_title': 'CRS ไม่ถูกต้อง',
    'msg_invalid_crs': 'กรุณาเลือก CRS เป้าหมายที่ถูกต้อง',
    'msg_no_transport_title': 'ไม่มีชั้นข้อมูลขนส่ง',
    'msg_no_transport': 'ไม่ได้เลือกชั้นข้อมูลพื้นที่สาธารณะเปิดโล่ง / ความจุต่ำ / เรือ'
                        'ข้ามฟาก / ราง จะประมวลผลเฉพาะพื้นที่เมืองและถนน ดำเนินการต่อ'
                        'หรือไม่?',
    'msg_complete': 'เสร็จสมบูรณ์',
    'msg_error': 'ข้อผิดพลาด',
    'msg_failed': "การวิเคราะห์ล้มเหลว ดูรายละเอียดในบันทึก\n\n"
                  "คลิก 'ล้างบันทึก' เพื่อล้างและเรียกใช้อีกครั้ง",
    'msg_close_running': 'การวิเคราะห์ยังคงทำงานอยู่ ยกเลิกและปิดหรือไม่?',
    'msg_cancel_requested': 'ส่งคำขอยกเลิกแล้ว...',
    'dlg_select_output': 'เลือกโฟลเดอร์ผลลัพธ์',
    'dlg_select_csv': 'เลือก CSV ความกว้างถนนที่วัดได้',
    'csv_filter': 'ไฟล์ CSV (*.csv *.txt);;ไฟล์ทั้งหมด (*)',
    'msg_invalid_csv_title': 'CSV ไม่ถูกต้อง',
    'msg_invalid_csv': 'ไม่สามารถอ่าน:',
    'msg_widths_title': 'CSV ความกว้างถนน',
    'msg_widths_cols': 'ตารางความกว้างถนนต้องมีอย่างน้อยสองคอลัมน์ (ประเภทถนน '
                       'ความกว้าง) ตารางนี้จะถูกละเว้น',
    'res_done': 'เสร็จแล้ว!',
    'res_las': 'ที่ดินที่จัดสรรให้ถนน',
    'res_stats': 'ตารางสถิติ (CSV)',
    'res_excel': 'สมุดงานสถิติ (Excel)',
    'res_roads': 'ตารางถนน',
    'res_folder': 'โฟลเดอร์',
    'res_time': 'เวลา',
    'h_city': 'เมือง',
    'h_urban_area': 'พื้นที่เมือง (km2)',
    'h_pos_area': 'พื้นที่สาธารณะเปิดโล่ง (km2)',
    'h_las': 'ที่ดินที่จัดสรรให้ถนน (km2)',
    'h_ops_las': 'พื้นที่สาธารณะเปิดโล่ง + ที่ดินที่จัดสรรให้ถนน (km2)',
    'h_prop_ops_las': 'สัดส่วนพื้นที่เมืองที่เป็นพื้นที่สาธารณะเปิดโล่ง + ที่ดินที่จัดสรร'
                      'ให้ถนน (%)',
    'h_total_pop': 'ประชากรเมืองทั้งหมด',
    'h_pop_pos': 'ประชากรที่เข้าถึงพื้นที่สาธารณะเปิดโล่ง',
    'h_pop_bus': 'ประชากรที่เข้าถึงจุดจอดขนส่งความจุต่ำ (ป้ายรถเมล์ สถานีรถไฟฟ้า'
                 'รางเบา)',
    'h_pop_hc': 'ประชากรที่เข้าถึงขนส่งความจุสูง (ราง + เรือข้ามฟาก)',
    'h_pop_comb': 'ประชากรที่เข้าถึงขนส่งสาธารณะรวม',
    'h_pct_pos': 'ร้อยละของประชากรที่เข้าถึงพื้นที่สาธารณะเปิดโล่ง',
    'h_pct_bus': 'ร้อยละของประชากรที่เข้าถึงจุดจอดขนส่งความจุต่ำ (ป้ายรถเมล์ สถานี'
                 'รถไฟฟ้ารางเบา)',
    'h_pct_hc': 'ร้อยละของประชากรที่เข้าถึงขนส่งความจุสูง',
    'h_pct_comb': 'ร้อยละของประชากรที่เข้าถึงขนส่งสาธารณะรวม',
    'h_pop_source': 'แหล่งข้อมูลประชากร',
    'src_household': 'จุดครัวเรือน',
    'src_raster': 'แรสเตอร์แบบกริด',
    'src_field': 'ฟิลด์',
}


# ---------------------------------------------------------- pl: Polski
_EXTRA_TEXT['pl'] = {
    'win_title': 'Obliczanie statystyk SDG 11.2.1 i 11.7.1',
    'subtitle': 'Wstępne przycięcie do obszaru miejskiego -> Ponowne odwzorowanie + '
                'naprawa geometrii -> Przycięcie otwartych przestrzeni publicznych -> '
                'Punkty granicy -> Obszar obsługi -> Otoczka wypukła -> Przycięcie -> '
                'Scalenie -> Ludność w obszarach obsługi -> Połączenie szerokości ulic '
                '-> Bufor -> Scalenie -> Przycięcie (teren przeznaczony pod ulice) -> '
                'Tabela statystyczna',
    'language': 'Język:',
    'tab_layers': 'Warstwy',
    'tab_distances': 'Odległości',
    'tab_output': 'Wyniki',
    'progress': 'Postęp',
    'btn_run': 'Uruchom analizę',
    'btn_cancel': 'Anuluj',
    'btn_reset': 'Wyczyść dziennik',
    'btn_close': 'Zamknij',
    'grp_streets': 'Ulice',
    'note_streets': 'Warstwa ulic używana do wyznaczania tras w sieci',
    'grp_urban': 'Granica miasta',
    'note_urban': 'Warstwa poligonowa określająca zasięg obszaru miejskiego',
    'grp_pop_raster': 'Ludność w siatce (raster)',
    'note_pop_raster': 'Zbiór danych o ludności w siatce. Podaj go LUB Ludność '
                       'gospodarstw domowych (punkty) poniżej - jedno z nich jest '
                       'wymagane.',
    'grp_hh': 'Ludność gospodarstw domowych (punkty)',
    'note_hh': 'Warstwa punktowa z liczbą osób w gospodarstwach domowych. Podaj ją LUB '
               'raster ludności w siatce - jedno z nich jest wymagane. Jeśli podano '
               'oba, używane są punkty gospodarstw domowych. Ludność każdego obszaru '
               'obsługi = suma wybranego pola dla punktów znajdujących się w jego '
               'wnętrzu.',
    'lbl_pop_field': 'Pole z łączną liczbą ludności (na punkt gospodarstwa '
                     'domowego):',
    'grp_pos': 'Otwarte przestrzenie publiczne (poligony)',
    'note_pos': 'Warstwy poligonowe niezabudowanych lub otwartych terenów dostępnych '
                'publicznie, zapewniających mieszkańcom miejsca rekreacji i '
                'poprawiających jakość środowiska. Przykłady: parki, ogrody, place '
                'zabaw, plaże publiczne, brzegi rzek i nabrzeża',
    'grp_bus': 'Przystanki transportu o małej pojemności (przystanki autobusowe, '
               'tramwajowe)',
    'note_bus': 'Warstwa punktowa lokalizacji przystanków autobusowych / '
                'tramwajowych',
    'grp_rail': 'Przystanki transportu o dużej pojemności (stacje kolejowe, stacje '
                'metra)',
    'note_rail': 'Warstwa punktowa lokalizacji stacji kolejowych / metra',
    'grp_ferry': 'Przystanki transportu o dużej pojemności (przystanie promowe)',
    'note_ferry': 'Warstwa punktowa lokalizacji terminali promowych',
    'grp_widths': 'Zmierzone szerokości ulic (tabela CSV)',
    'note_widths': 'Używane do terenu przeznaczonego pod ulice. Kolumna 1 = kategoria '
                   'drogi (dopasowywana do wybranego poniżej pola kategorii drogi), '
                   'kolumna 2 = zmierzona szerokość w metrach. Jeśli nie podano CSV i '
                   'brak pola kategorii, teren przeznaczony pod ulice = 0.',
    'btn_browse_csv': 'Wybierz CSV...',
    'grp_catfield': 'Pole kategorii drogi (z warstwy ulic)',
    'note_catfield': 'Pole warstwy ulic zawierające kategorie dróg, używane do '
                     'połączenia szerokości. \'fclass\', \'highway\' lub \'type\' '
                     'jest wybierane automatycznie, jeśli istnieje; w przeciwnym '
                     'razie wybierz pole tutaj. Pozostaw puste, aby wykryć '
                     'automatycznie.',
    'grp_crs': 'Docelowy układ współrzędnych (odwzorowany, w metrach - np. strefa '
               'UTM obszaru miejskiego)',
    'dist_header': 'Próg odległości sieciowej dla:',
    'dist_pos': 'Otwarte przestrzenie publiczne',
    'spacing_header': 'Odstęp punktów na granicy otwartych przestrzeni publicznych:',
    'spacing_note': 'Punkty startowe rozmieszczone wzdłuż obrysu każdej otwartej '
                    'przestrzeni. Standardem jest 100 m; większy odstęp (np. 200 m) '
                    'przyspiesza obliczenia w miastach z wieloma dużymi parkami, ale '
                    'nieco obniża dokładność.',
    'perf_header': 'Wydajność:',
    'chk_preclip': 'Wstępnie przytnij dane wejściowe do obszaru miejskiego',
    'note_preclip': 'Zalecane. Zachowuje tylko ulice, przystanki i otwarte przestrzenie '
                    'w marginesie wyszukiwania wokół miasta - znacznie szybciej przy '
                    'danych krajowych lub regionalnych.',
    'chk_memory': 'Przechowuj warstwy pośrednie w pamięci',
    'note_memory': 'Szybciej. Odznacz tylko, gdy komputerowi brakuje pamięci RAM.',
    'chk_native': 'Użyj wbudowanego algorytmu obszaru obsługi QGIS',
    'note_native': 'Tylko do kontroli - bardzo wolne przy wielu punktach startowych. '
                   'Domyślnie używane jest szybkie wyszukiwanie ograniczone (te same '
                   'wyniki).',
    'grp_city': 'Nazwa miasta (wskazówka: unikaj znaków specjalnych)',
    'city_placeholder': 'np. Mombasa',
    'lbl_output_folder': 'Folder wyników:',
    'btn_browse': 'Przeglądaj...',
    'info_block':
        "Zachowywane pliki wynikowe:\n"
        "  Przycięte i scalone obszary obsługi:\n"
        "  SA_POS_dissolved.shp                Otwarte przestrzenie publiczne\n"
        "  SA_Bus_dissolved.shp                Przystanki o małej pojemności\n"
        "  SA_Ferry_dissolved.shp              Przystanie promowe\n"
        "  SA_Rail_dissolved.shp               Stacje kolejowe\n"
        "  SA_HighCapacity_dissolved.shp       Duża pojemność (kolej + prom)\n"
        "  SA_CombinedTransport_dissolved.shp  Transport publiczny łącznie\n"
        "  Pojedyncze obszary obsługi (dla każdego przystanku):\n"
        "  SA_Bus_individual.shp / SA_Ferry_individual.shp / SA_Rail_individual.shp\n"
        "  ZonalStats_*.shp                    Obszar obsługi + pole pop_sum\n"
        "  LAS_streets_dissolved.shp           Teren przeznaczony pod ulice\n"
        "  {city}_statistics_11.2.1_and_11.7.1.xlsx\n\n"
        "UWAGI:\n"
        "  - Geometrie są automatycznie naprawiane przed przetwarzaniem.\n"
        "  - Ludność: punkty gospodarstw domowych (suma pola ludności), jeśli podano,\n"
        "    w przeciwnym razie raster ludności w siatce.\n"
        "  - Powierzchnia otwartych przestrzeni mierzona po przycięciu do granicy miasta.\n"
        "  - Dane są przycinane do obszaru miejskiego + margines wyszukiwania,\n"
        "    a warstwy pośrednie trzymane w pamięci (zob. kartę Odległości).\n"
        "  - Transport łącznie = przystanki o małej pojemności + prom + kolej\n"
        "    (bez otwartych przestrzeni publicznych).\n"
        "  - Teren pod ulice: bufor ulic według szerokości, scalony\n"
        "    i przycięty do zasięgu miasta.\n"
        "  - Tabela statystyczna jest zapisywana w wybranym języku.\n"
        "  - Po błędzie użyj „Wyczyść dziennik”, aby ponownie włączyć przyciski.",
    'msg_running_title': 'W toku',
    'msg_cannot_reset': 'Nie można wyczyścić podczas analizy. Najpierw ją anuluj.',
    'msg_missing_layer': 'Brak warstwy',
    'msg_select_streets': 'Wybierz warstwę ulic.',
    'msg_select_urban': 'Wybierz warstwę granicy miasta.',
    'msg_missing_pop_title': 'Brak danych o ludności',
    'msg_missing_pop': 'Wybierz warstwę ludności w siatce (raster) lub warstwę ludności '
                       'gospodarstw domowych (punkty) - jedna z nich jest wymagana.',
    'msg_missing_popfield_title': 'Brak pola ludności',
    'msg_missing_popfield': 'Wybierz pole z łączną liczbą ludności dla warstwy ludności '
                            'gospodarstw domowych (punkty).',
    'msg_missing_city_title': 'Brak nazwy miasta',
    'msg_missing_city': 'Wpisz nazwę miasta.',
    'msg_missing_output_title': 'Brak folderu wyników',
    'msg_missing_output': 'Wybierz folder wyników.',
    'msg_invalid_crs_title': 'Nieprawidłowy układ współrzędnych',
    'msg_invalid_crs': 'Wybierz prawidłowy docelowy układ współrzędnych.',
    'msg_no_transport_title': 'Brak warstw transportu',
    'msg_no_transport': 'Nie wybrano warstw otwartych przestrzeni publicznych / małej '
                        'pojemności / promów / kolei. Przetworzony zostanie tylko '
                        'obszar miejski i ulice. Kontynuować?',
    'msg_complete': 'Zakończono',
    'msg_error': 'Błąd',
    'msg_failed': 'Analiza nie powiodła się. Szczegóły w dzienniku.\n\n'
                  'Kliknij „Wyczyść dziennik” i uruchom ponownie.',
    'msg_close_running': 'Analiza nadal trwa. Anulować i zamknąć?',
    'msg_cancel_requested': 'Zażądano anulowania...',
    'dlg_select_output': 'Wybierz folder wyników',
    'dlg_select_csv': 'Wybierz CSV ze zmierzonymi szerokościami ulic',
    'csv_filter': 'Pliki CSV (*.csv *.txt);;Wszystkie pliki (*)',
    'msg_invalid_csv_title': 'Nieprawidłowy CSV',
    'msg_invalid_csv': 'Nie można odczytać:',
    'msg_widths_title': 'CSV szerokości ulic',
    'msg_widths_cols': 'Tabela szerokości ulic musi mieć co najmniej dwie kolumny '
                       '(kategoria drogi, szerokość). Zostanie pominięta.',
    'res_done': 'Gotowe!',
    'res_las': 'Teren przeznaczony pod ulice',
    'res_stats': 'Tabela statystyczna (CSV)',
    'res_excel': 'Skoroszyt statystyczny (Excel)',
    'res_roads': 'Tabela ulic',
    'res_folder': 'Folder',
    'res_time': 'Czas',
    'h_city': 'Miasto',
    'h_urban_area': 'Powierzchnia obszaru miejskiego (km2)',
    'h_pos_area': 'Powierzchnia otwartych przestrzeni publicznych (km2)',
    'h_las': 'Teren przeznaczony pod ulice (km2)',
    'h_ops_las': 'Otwarte przestrzenie publiczne + teren przeznaczony pod ulice (km2)',
    'h_prop_ops_las': 'Udział otwartych przestrzeni publicznych + terenu pod ulice w '
                      'powierzchni miasta (%)',
    'h_total_pop': 'Łączna ludność miasta',
    'h_pop_pos': 'Ludność z dostępem do otwartych przestrzeni publicznych',
    'h_pop_bus': 'Ludność z dostępem do przystanków transportu o małej pojemności '
                 '(przystanki autobusowe, tramwajowe)',
    'h_pop_hc': 'Ludność z dostępem do transportu o dużej pojemności (kolej + prom)',
    'h_pop_comb': 'Ludność z dostępem do transportu publicznego łącznie',
    'h_pct_pos': 'Odsetek ludności z dostępem do otwartych przestrzeni publicznych',
    'h_pct_bus': 'Odsetek ludności z dostępem do przystanków transportu o małej '
                 'pojemności (przystanki autobusowe, tramwajowe)',
    'h_pct_hc': 'Odsetek ludności z dostępem do transportu o dużej pojemności',
    'h_pct_comb': 'Odsetek ludności z dostępem do transportu publicznego łącznie',
    'h_pop_source': 'Źródło danych o ludności',
    'src_household': 'Punkty gospodarstw domowych',
    'src_raster': 'Raster w siatce',
    'src_field': 'pole',
}


# ---------------------------------------------------------- nl: Nederlands
_EXTRA_TEXT['nl'] = {
    'win_title': 'Berekening van statistieken voor SDG 11.2.1 en 11.7.1',
    'subtitle': 'Vooraf knippen tot het stedelijk gebied -> Herprojectie + '
                'geometrieherstel -> Knippen van open openbare ruimten -> Grenspunten '
                '-> Verzorgingsgebied -> Convex omhulsel -> Knippen -> Samenvoegen -> '
                'Bevolking in verzorgingsgebieden -> Koppeling van straatbreedtes -> '
                'Buffer -> Samenvoegen -> Knippen (grond bestemd voor straten) -> '
                'Statistiektabel',
    'language': 'Taal:',
    'tab_layers': 'Lagen',
    'tab_distances': 'Afstanden',
    'tab_output': 'Uitvoer',
    'progress': 'Voortgang',
    'btn_run': 'Analyse starten',
    'btn_cancel': 'Annuleren',
    'btn_reset': 'Logboek wissen',
    'btn_close': 'Sluiten',
    'grp_streets': 'Straten',
    'note_streets': 'Stratenlaag voor routeberekening over het netwerk',
    'grp_urban': 'Stedelijke grens',
    'note_urban': 'Polygoonlaag die de omvang van het stedelijk gebied bepaalt',
    'grp_pop_raster': 'Gerasterde bevolking (raster)',
    'note_pop_raster': 'Gerasterde bevolkingsdataset. Geef deze OF de '
                       'Huishoudbevolking (punten) hieronder op - één van beide is '
                       'verplicht.',
    'grp_hh': 'Huishoudbevolking (punten)',
    'note_hh': 'Puntenlaag met het aantal inwoners per huishouden. Geef deze OF het '
               'gerasterde bevolkingsraster op - één van beide is verplicht. Als beide '
               'zijn opgegeven, worden de huishoudpunten gebruikt. Bevolking per '
               'verzorgingsgebied = som van het gekozen veld over de punten erbinnen.',
    'lbl_pop_field': 'Veld met de totale bevolking (per huishoudpunt):',
    'grp_pos': 'Open openbare ruimten (polygonen)',
    'note_pos': 'Polygoonlagen met onbebouwde of open, publiek toegankelijke grond die '
                'bewoners recreatieruimte biedt en de milieukwaliteit verbetert. '
                'Voorbeelden: parken, tuinen, speeltuinen, openbare stranden, '
                'rivieroevers en waterkanten',
    'grp_bus': 'Haltes van vervoer met lage capaciteit (bushaltes, '
               'sneltram-/tramhaltes)',
    'note_bus': 'Puntenlaag met de locaties van bus- / tramhaltes',
    'grp_rail': 'Haltes van vervoer met hoge capaciteit (treinstations, '
                'metrostations)',
    'note_rail': 'Puntenlaag met de locaties van trein- / metrostations',
    'grp_ferry': 'Haltes van vervoer met hoge capaciteit (veersteigers)',
    'note_ferry': 'Puntenlaag met de locaties van veerterminals',
    'grp_widths': 'Gemeten straatbreedtes (CSV-tabel)',
    'note_widths': 'Gebruikt voor de grond bestemd voor straten. Kolom 1 = '
                   'wegcategorie (gekoppeld aan het hieronder gekozen veld voor de '
                   'wegcategorie), kolom 2 = gemeten breedte in meters. Zonder CSV en '
                   'zonder categorieveld is de grond bestemd voor straten = 0.',
    'btn_browse_csv': 'CSV bladeren...',
    'grp_catfield': 'Veld wegcategorie (uit de stratenlaag)',
    'note_catfield': 'Veld van de stratenlaag met de wegcategorieën, gebruikt om de '
                     'breedtes te koppelen. \'fclass\', \'highway\' of \'type\' wordt '
                     'automatisch gekozen als het bestaat; kies anders hier het veld. '
                     'Leeg laten voor automatische herkenning.',
    'grp_crs': 'Doel-coördinatenreferentiesysteem (geprojecteerd, in meters - bijv. '
               'UTM-zone van het stedelijk gebied)',
    'dist_header': 'Drempelwaarde netwerkafstand voor:',
    'dist_pos': 'Open openbare ruimten',
    'spacing_header': 'Afstand tussen grenspunten van open openbare ruimten:',
    'spacing_note': 'Startpunten langs de omtrek van elke open ruimte. 100 m is de '
                    'standaard; een grotere afstand (bijv. 200 m) is sneller voor '
                    'steden met veel grote parken, maar iets minder nauwkeurig.',
    'perf_header': 'Prestaties:',
    'chk_preclip': 'Invoer vooraf knippen tot het stedelijk gebied',
    'note_preclip': 'Aanbevolen. Behoudt alleen straten, haltes en open ruimten binnen '
                    'de zoekmarge rond het stedelijk gebied - veel sneller met '
                    'landelijke of regionale gegevens.',
    'chk_memory': 'Tussenlagen in het geheugen houden',
    'note_memory': 'Sneller. Alleen uitvinken als de computer te weinig RAM heeft.',
    'chk_native': 'Ingebouwd QGIS-algoritme voor verzorgingsgebieden gebruiken',
    'note_native': 'Alleen ter controle - zeer traag bij veel startpunten. Standaard '
                   'wordt de snelle begrensde zoekmethode gebruikt (zelfde '
                   'resultaten).',
    'grp_city': 'Naam van de stad (tip: vermijd speciale tekens)',
    'city_placeholder': 'bijv. Mombasa',
    'lbl_output_folder': 'Uitvoermap:',
    'btn_browse': 'Bladeren...',
    'info_block':
        "Bewaarde eindbestanden:\n"
        "  Geknipte en samengevoegde verzorgingsgebieden:\n"
        "  SA_POS_dissolved.shp                Open openbare ruimten\n"
        "  SA_Bus_dissolved.shp                Haltes met lage capaciteit\n"
        "  SA_Ferry_dissolved.shp              Veersteigers\n"
        "  SA_Rail_dissolved.shp               Treinstations\n"
        "  SA_HighCapacity_dissolved.shp       Hoge capaciteit (spoor + veer)\n"
        "  SA_CombinedTransport_dissolved.shp  Openbaar vervoer totaal\n"
        "  Afzonderlijke verzorgingsgebieden (per halte):\n"
        "  SA_Bus_individual.shp / SA_Ferry_individual.shp / SA_Rail_individual.shp\n"
        "  ZonalStats_*.shp                    Verzorgingsgebied + veld pop_sum\n"
        "  LAS_streets_dissolved.shp           Grond bestemd voor straten\n"
        "  {city}_statistics_11.2.1_and_11.7.1.xlsx\n\n"
        "OPMERKINGEN:\n"
        "  - Geometrieën worden vóór de verwerking automatisch hersteld.\n"
        "  - Bevolking: huishoudpunten (som van het bevolkingsveld) indien\n"
        "    opgegeven, anders het gerasterde bevolkingsraster.\n"
        "  - Oppervlakte van open openbare ruimten gemeten na knippen tot de stadsgrens.\n"
        "  - Invoer wordt geknipt tot stedelijk gebied + zoekmarge en tussenlagen\n"
        "    blijven in het geheugen (zie tabblad Afstanden).\n"
        "  - Openbaar vervoer totaal = lage capaciteit + veer + spoor\n"
        "    (zonder open openbare ruimten).\n"
        "  - Grond bestemd voor straten: straten gebufferd naar breedte,\n"
        "    samengevoegd en geknipt tot het stedelijk gebied.\n"
        "  - De statistiektabel wordt in de gekozen taal geschreven.\n"
        "  - Gebruik na een fout 'Logboek wissen' om de knoppen weer te activeren.",
    'msg_running_title': 'Bezig',
    'msg_cannot_reset': 'Wissen is niet mogelijk tijdens de analyse. Annuleer eerst.',
    'msg_missing_layer': 'Ontbrekende laag',
    'msg_select_streets': 'Selecteer een stratenlaag.',
    'msg_select_urban': 'Selecteer een laag met de stedelijke grens.',
    'msg_missing_pop_title': 'Ontbrekende bevolkingsgegevens',
    'msg_missing_pop': 'Selecteer een laag met gerasterde bevolking (raster) of '
                       'huishoudbevolking (punten) - één van beide is verplicht.',
    'msg_missing_popfield_title': 'Ontbrekend bevolkingsveld',
    'msg_missing_popfield': 'Selecteer het veld met de totale bevolking voor de laag '
                            'huishoudbevolking (punten).',
    'msg_missing_city_title': 'Ontbrekende stadsnaam',
    'msg_missing_city': 'Voer de naam van de stad in.',
    'msg_missing_output_title': 'Ontbrekende uitvoermap',
    'msg_missing_output': 'Selecteer een uitvoermap.',
    'msg_invalid_crs_title': 'Ongeldig CRS',
    'msg_invalid_crs': 'Selecteer een geldig doel-CRS.',
    'msg_no_transport_title': 'Geen vervoerslagen',
    'msg_no_transport': 'Er is geen laag voor open openbare ruimten / lage capaciteit / '
                        'veer / spoor gekozen. Alleen het stedelijk gebied en de straten '
                        'worden verwerkt. Doorgaan?',
    'msg_complete': 'Voltooid',
    'msg_error': 'Fout',
    'msg_failed': 'De analyse is mislukt. Zie het logboek voor details.\n\n'
                  'Klik op \'Logboek wissen\' en start opnieuw.',
    'msg_close_running': 'De analyse loopt nog. Annuleren en sluiten?',
    'msg_cancel_requested': 'Annulering aangevraagd...',
    'dlg_select_output': 'Uitvoermap selecteren',
    'dlg_select_csv': 'CSV met gemeten straatbreedtes selecteren',
    'csv_filter': 'CSV-bestanden (*.csv *.txt);;Alle bestanden (*)',
    'msg_invalid_csv_title': 'Ongeldige CSV',
    'msg_invalid_csv': 'Kon niet worden gelezen:',
    'msg_widths_title': 'CSV straatbreedtes',
    'msg_widths_cols': 'De tabel met straatbreedtes moet minstens twee kolommen hebben '
                       '(wegcategorie, breedte). Hij wordt genegeerd.',
    'res_done': 'Klaar!',
    'res_las': 'Grond bestemd voor straten',
    'res_stats': 'Statistiektabel (CSV)',
    'res_excel': 'Statistiekwerkmap (Excel)',
    'res_roads': 'Stratentabel',
    'res_folder': 'Map',
    'res_time': 'Duur',
    'h_city': 'Stad',
    'h_urban_area': 'Stedelijke oppervlakte (km2)',
    'h_pos_area': 'Oppervlakte open openbare ruimten (km2)',
    'h_las': 'Grond bestemd voor straten (km2)',
    'h_ops_las': 'Open openbare ruimten + grond bestemd voor straten (km2)',
    'h_prop_ops_las': 'Aandeel van de stedelijke oppervlakte in open openbare ruimten '
                      '+ grond bestemd voor straten (%)',
    'h_total_pop': 'Totale stedelijke bevolking',
    'h_pop_pos': 'Bevolking met toegang tot open openbare ruimten',
    'h_pop_bus': 'Bevolking met toegang tot haltes van vervoer met lage capaciteit '
                 '(bushaltes, sneltram-/tramhaltes)',
    'h_pop_hc': 'Bevolking met toegang tot vervoer met hoge capaciteit (spoor + veer)',
    'h_pop_comb': 'Bevolking met toegang tot openbaar vervoer totaal',
    'h_pct_pos': 'Percentage bevolking met toegang tot open openbare ruimten',
    'h_pct_bus': 'Percentage bevolking met toegang tot haltes van vervoer met lage '
                 'capaciteit (bushaltes, sneltram-/tramhaltes)',
    'h_pct_hc': 'Percentage bevolking met toegang tot vervoer met hoge capaciteit',
    'h_pct_comb': 'Percentage bevolking met toegang tot openbaar vervoer totaal',
    'h_pop_source': 'Bron van bevolkingsgegevens',
    'src_household': 'Huishoudpunten',
    'src_raster': 'Bevolkingsraster',
    'src_field': 'veld',
}


# ---------------------------------------------------------- uk: Українська
_EXTRA_TEXT['uk'] = {
    'win_title': 'Обчислення статистики ЦСР 11.2.1 та 11.7.1',
    'subtitle': 'Попереднє обрізання за міською територією -> Перепроєктування + '
                'Виправлення геометрій -> Обрізання відкритих громадських просторів '
                '-> Граничні точки -> Зона обслуговування -> Опукла оболонка -> '
                'Обрізання -> Обʼєднання -> Населення в зонах доступності -> '
                'Приєднання ширини доріг -> Буфер -> Обʼєднання -> Обрізання '
                '(Територія під вулицями) -> Таблиця статистики',
    'language': 'Мова:',
    'tab_layers': 'Шари',
    'tab_distances': 'Відстані',
    'tab_output': 'Результати',
    'progress': 'Хід виконання',
    'btn_run': 'Запустити аналіз',
    'btn_cancel': 'Скасувати',
    'btn_reset': 'Очистити журнал',
    'btn_close': 'Закрити',
    'grp_streets': 'Вулиці',
    'note_streets': 'Шар вулиць для мережевої маршрутизації',
    'grp_urban': 'Межа міста',
    'note_urban': 'Полігональний шар, що визначає межі міської території',
    'grp_pop_raster': 'Населення за сіткою (растр)',
    'note_pop_raster': 'Набір даних про населення за сіткою. Вкажіть його АБО шар '
                       'Населення домогосподарств (точки) нижче - один із двох '
                       'обовʼязковий.',
    'grp_hh': 'Населення домогосподарств (точки)',
    'note_hh': 'Точковий шар із чисельністю населення на рівні домогосподарств. '
               'Вкажіть його АБО растр Населення за сіткою - один із двох '
               'обовʼязковий. Якщо вказано обидва, використовуються точки '
               'домогосподарств. Населення кожної зони доступності = сума вибраного '
               'поля для точок усередині неї.',
    'lbl_pop_field': 'Поле із загальною чисельністю населення (для кожної точки '
                     'домогосподарства):',
    'grp_pos': 'Відкриті громадські простори (полігони)',
    'note_pos': 'Полігональні шари незабудованих або відкритих територій, доступних '
                'для громадськості, що забезпечують мешканцям місця відпочинку та '
                'покращують якість довкілля. Приклади: парки, сади, дитячі '
                'майданчики, громадські пляжі, береги річок і набережні',
    'grp_bus': 'Зупинки транспорту малої місткості (автобусні зупинки, зупинки '
               'легкорейкового транспорту)',
    'note_bus': 'Точковий шар розташування автобусних / легкорейкових зупинок',
    'grp_rail': 'Зупинки транспорту великої місткості (залізничні станції, станції '
                'метро)',
    'note_rail': 'Точковий шар розташування залізничних станцій / станцій метро',
    'grp_ferry': 'Зупинки транспорту великої місткості (поромні причали)',
    'note_ferry': 'Точковий шар розташування поромних терміналів',
    'grp_widths': 'Виміряна ширина доріг (таблиця CSV)',
    'note_widths': 'Використовується для території під вулицями. Стовпець 1 = '
                   'категорія дороги (зіставляється з Полем категорії доріг, '
                   'вибраним нижче), стовпець 2 = виміряна ширина дороги в метрах. '
                   'Якщо CSV не вказано і поле категорії доріг відсутнє, територія '
                   'під вулицями = 0.',
    'btn_browse_csv': 'Вибрати CSV...',
    'grp_catfield': 'Поле категорії доріг (із шару Вулиці)',
    'note_catfield': "Поле шару Вулиці з категоріями доріг, що використовується для "
                     "приєднання ширини доріг. 'fclass', 'highway' або 'type' "
                     "вибирається автоматично за наявності; інакше виберіть поле "
                     "тут. Залиште порожнім для автовизначення.",
    'grp_crs': 'Цільова система координат (проєкційна, метри - напр. UTM для міської '
               'території)',
    'dist_header': 'Поріг мережевої відстані для:',
    'dist_pos': 'Відкриті громадські простори',
    'spacing_header': 'Інтервал граничних точок відкритих громадських просторів:',
    'spacing_note': 'Початкові точки, розміщені вздовж контуру кожного відкритого '
                    'простору. Стандарт - 100 м; більший інтервал (напр. 200 м) '
                    'швидший для міст із багатьма великими парками, але дещо менш '
                    'точний.',
    'perf_header': 'Продуктивність:',
    'chk_preclip': 'Попередньо обрізати вхідні дані за міською територією',
    'note_preclip': 'Рекомендовано. Залишає лише вулиці, зупинки та відкриті '
                    'простори в межах пошукового запасу міської території - значно '
                    'швидше з даними на рівні країни/регіону.',
    'chk_memory': 'Зберігати проміжні шари в памʼяті',
    'note_memory': 'Швидше. Зніміть позначку, лише якщо компʼютеру бракує ОЗП.',
    'chk_native': 'Використовувати вбудований алгоритм QGIS «Зона обслуговування»',
    'note_native': 'Лише для перехресної перевірки - дуже повільно за великої '
                   'кількості початкових точок. За замовчуванням - швидкий обмежений '
                   'пошук (ті самі результати).',
    'grp_city': 'Назва міста (Порада: уникайте спеціальних символів)',
    'city_placeholder': 'напр. Mombasa',
    'lbl_output_folder': 'Папка результатів:',
    'btn_browse': 'Огляд...',
    'info_block':
        "Збережені кінцеві файли:\n"
        "  Обрізані + обʼєднані зони доступності (зони обслуговування):\n"
        "  SA_POS_dissolved.shp                Відкриті громадські простори\n"
        "  SA_Bus_dissolved.shp                Зупинки транспорту малої місткості\n"
        "  SA_Ferry_dissolved.shp              Поромні причали\n"
        "  SA_Rail_dissolved.shp               Залізничні зупинки\n"
        "  SA_HighCapacity_dissolved.shp       Велика місткість (залізниця + пором)\n"
        "  SA_CombinedTransport_dissolved.shp  Громадський транспорт загалом\n"
        "  Окремі зони обслуговування (для кожної зупинки):\n"
        "  SA_Bus_individual.shp / SA_Ferry_individual.shp / SA_Rail_individual.shp\n"
        "  ZonalStats_*.shp                    Зона доступності + поле pop_sum\n"
        "  LAS_streets_dissolved.shp           Територія під вулицями\n"
        "  {city}_statistics_11.2.1_and_11.7.1.xlsx\n\n"
        "ПРИМІТКИ:\n"
        "  - Геометрії автоматично виправляються перед обробкою.\n"
        "  - Населення: точки домогосподарств (сума поля населення),\n"
        "    якщо вказано, інакше растр населення за сіткою.\n"
        "  - Площа відкритих громадських просторів вимірюється після обрізання за межею міста.\n"
        "  - Вхідні дані попередньо обрізаються за міською територією + пошуковим\n"
        "    запасом, проміжні шари зберігаються в памʼяті (див. вкладку Відстані).\n"
        "  - Транспорт загалом = зупинки малої місткості + пором + залізниця\n"
        "    (без відкритих громадських просторів).\n"
        "  - Територія під вулицями: дороги з буфером за шириною, обʼєднані\n"
        "    та обрізані за міською територією.\n"
        "  - Таблиця статистики записується вибраною мовою.\n"
        "  - Після збою натисніть «Очистити журнал», щоб очистити журнал і знову ввімкнути кнопки.",
    'msg_running_title': 'Виконується',
    'msg_cannot_reset': 'Неможливо очистити під час виконання аналізу. Спочатку '
                        'скасуйте.',
    'msg_missing_layer': 'Відсутній шар',
    'msg_select_streets': 'Будь ласка, виберіть шар Вулиці.',
    'msg_select_urban': 'Будь ласка, виберіть шар Межа міста.',
    'msg_missing_pop_title': 'Відсутні дані про населення',
    'msg_missing_pop': 'Будь ласка, виберіть шар Населення за сіткою (растр) або шар '
                       'Населення домогосподарств (точки) - один із двох '
                       'обовʼязковий.',
    'msg_missing_popfield_title': 'Відсутнє поле населення',
    'msg_missing_popfield': 'Будь ласка, виберіть поле із загальною чисельністю '
                            'населення для шару Населення домогосподарств (точки).',
    'msg_missing_city_title': 'Відсутня назва міста',
    'msg_missing_city': 'Будь ласка, введіть назву міста.',
    'msg_missing_output_title': 'Відсутня папка результатів',
    'msg_missing_output': 'Будь ласка, виберіть папку результатів.',
    'msg_invalid_crs_title': 'Недійсна СК',
    'msg_invalid_crs': 'Будь ласка, виберіть дійсну цільову систему координат.',
    'msg_no_transport_title': 'Немає транспортних шарів',
    'msg_no_transport': 'Не вибрано шарів відкритих громадських просторів / малої '
                        'місткості / поромів / залізниці. Буде оброблено лише міську '
                        'територію та вулиці. Продовжити?',
    'msg_complete': 'Завершено',
    'msg_error': 'Помилка',
    'msg_failed': "Аналіз не вдався. Подробиці в журналі.\n\n"
                  "Натисніть «Очистити журнал», щоб очистити і запустити знову.",
    'msg_close_running': 'Аналіз ще виконується. Скасувати і закрити?',
    'msg_cancel_requested': 'Запит на скасування надіслано...',
    'dlg_select_output': 'Виберіть папку результатів',
    'dlg_select_csv': 'Виберіть CSV з виміряною шириною доріг',
    'csv_filter': 'Файли CSV (*.csv *.txt);;Усі файли (*)',
    'msg_invalid_csv_title': 'Недійсний CSV',
    'msg_invalid_csv': 'Не вдалося прочитати:',
    'msg_widths_title': 'CSV ширини доріг',
    'msg_widths_cols': 'Таблиця ширини доріг потребує щонайменше двох стовпців '
                       '(категорія дороги, ширина). Її буде проігноровано.',
    'res_done': 'Готово!',
    'res_las': 'Територія під вулицями',
    'res_stats': 'Таблиця статистики (CSV)',
    'res_excel': 'Книга статистики (Excel)',
    'res_roads': 'Таблиця доріг',
    'res_folder': 'Папка',
    'res_time': 'Час',
    'h_city': 'Місто',
    'h_urban_area': 'Міська територія (км2)',
    'h_pos_area': 'Площа відкритих громадських просторів (км2)',
    'h_las': 'Територія під вулицями (км2)',
    'h_ops_las': 'Відкриті громадські простори + територія під вулицями (км2)',
    'h_prop_ops_las': 'Частка міської території під відкритими громадськими '
                      'просторами + вулицями (%)',
    'h_total_pop': 'Загальна чисельність міського населення',
    'h_pop_pos': 'Населення з доступом до відкритих громадських просторів',
    'h_pop_bus': 'Населення з доступом до зупинок транспорту малої місткості '
                 '(автобусні зупинки, зупинки легкорейкового транспорту)',
    'h_pop_hc': 'Населення з доступом до транспорту великої місткості (залізниця + '
                'пором)',
    'h_pop_comb': 'Населення з доступом до громадського транспорту загалом',
    'h_pct_pos': 'Відсоток населення з доступом до відкритих громадських просторів',
    'h_pct_bus': 'Відсоток населення з доступом до зупинок транспорту малої '
                 'місткості (автобусні зупинки, зупинки легкорейкового транспорту)',
    'h_pct_hc': 'Відсоток населення з доступом до транспорту великої місткості',
    'h_pct_comb': 'Відсоток населення з доступом до громадського транспорту загалом',
    'h_pop_source': 'Джерело даних про населення',
    'src_household': 'Точки домогосподарств',
    'src_raster': 'Растр за сіткою',
    'src_field': 'поле',
}


# ---------------------------------------------------------- am: አማርኛ
_EXTRA_TEXT['am'] = {
    'win_title': 'የSDG 11.2.1 እና 11.7.1 ስታቲስቲክስ ስሌት',
    'subtitle': 'ወደ ከተማ ክልል ቅድመ መቁረጥ -> እንደገና ማቀድ + ጂኦሜትሪ ማስተካከል -> '
                'የሕዝብ ክፍት ቦታዎችን መቁረጥ -> የወሰን ነጥቦች -> የአገልግሎት ክልል -> '
                'ኮንቬክስ ሽፋን -> መቁረጥ -> ማዋሀድ -> በአገልግሎት ክልሎች ያለ ሕዝብ -> '
                'የመንገድ ስፋት ማያያዝ -> ቋት -> ማዋሀድ -> መቁረጥ (ለመንገዶች የተመደበ '
                'መሬት) -> የስታቲስቲክስ ሰንጠረዥ',
    'language': 'ቋንቋ:',
    'tab_layers': 'ንብርብሮች',
    'tab_distances': 'ርቀቶች',
    'tab_output': 'ውጤት',
    'progress': 'ሂደት',
    'btn_run': 'ትንተና አሂድ',
    'btn_cancel': 'ሰርዝ',
    'btn_reset': 'መዝገብ አጽዳ',
    'btn_close': 'ዝጋ',
    'grp_streets': 'መንገዶች',
    'note_streets': 'በመረቡ ላይ መስመር ለመፈለግ የሚያገለግል የመንገዶች ንብርብር',
    'grp_urban': 'የከተማ ወሰን',
    'note_urban': 'የከተማውን ስፋት የሚወስን ባለብዙ ጎን ንብርብር',
    'grp_pop_raster': 'በፍርግርግ የተዘጋጀ የሕዝብ መረጃ (ራስተር)',
    'note_pop_raster': 'በፍርግርግ የተዘጋጀ የሕዝብ መረጃ ስብስብ። ይህንን ወይም ከታች ያለውን '
                       'የቤተሰብ ሕዝብ (ነጥቦች) ያቅርቡ - ከሁለቱ አንዱ ግዴታ ነው።',
    'grp_hh': 'የቤተሰብ ሕዝብ (ነጥቦች)',
    'note_hh': 'በቤተሰብ ደረጃ የሕዝብ ቁጥር የያዘ የነጥብ ንብርብር። ይህንን ወይም በፍርግርግ '
               'የተዘጋጀውን የሕዝብ ራስተር ያቅርቡ - ከሁለቱ አንዱ ግዴታ ነው። ሁለቱም ከቀረቡ '
               'የቤተሰብ ነጥቦች ጥቅም ላይ ይውላሉ። የእያንዳንዱ የአገልግሎት ክልል ሕዝብ = '
               'በውስጡ ያሉ ነጥቦች የተመረጠው መስክ ድምር።',
    'lbl_pop_field': 'ጠቅላላ ሕዝብ የያዘ መስክ (ለእያንዳንዱ የቤተሰብ ነጥብ):',
    'grp_pos': 'የሕዝብ ክፍት ቦታዎች (ባለብዙ ጎን)',
    'note_pos': 'ለሕዝብ ክፍት የሆኑ ያልተገነቡ ወይም ክፍት መሬቶችን የሚያሳዩ ባለብዙ ጎን '
                'ንብርብሮች፤ ለነዋሪዎች የመዝናኛ ቦታ ይሰጣሉ፣ የአካባቢ ጥራትንም ያሻሽላሉ። '
                'ምሳሌዎች፦ መናፈሻዎች፣ የአትክልት ቦታዎች፣ የመጫወቻ ሜዳዎች፣ የሕዝብ '
                'የባሕር ዳርቻዎች፣ የወንዝ ዳርቻዎች እና የውሃ ዳርቻዎች',
    'grp_bus': 'ዝቅተኛ አቅም ያላቸው የትራንስፖርት ማቆሚያዎች (የአውቶቡስ ማቆሚያዎች፣ የቀላል '
               'ባቡር ማቆሚያዎች)',
    'note_bus': 'የአውቶቡስ / የቀላል ባቡር ማቆሚያዎች መገኛ የነጥብ ንብርብር',
    'grp_rail': 'ከፍተኛ አቅም ያላቸው የትራንስፖርት ማቆሚያዎች (የባቡር ጣቢያዎች፣ የሜትሮ '
                'ጣቢያዎች)',
    'note_rail': 'የባቡር / የሜትሮ ጣቢያዎች መገኛ የነጥብ ንብርብር',
    'grp_ferry': 'ከፍተኛ አቅም ያላቸው የትራንስፖርት ማቆሚያዎች (የጀልባ ወደቦች)',
    'note_ferry': 'የጀልባ ተርሚናሎች መገኛ የነጥብ ንብርብር',
    'grp_widths': 'የተለኩ የመንገድ ስፋቶች (CSV ሰንጠረዥ)',
    'note_widths': 'ለመንገዶች የተመደበ መሬትን ለማስላት ያገለግላል። አምድ 1 = የመንገድ ዓይነት '
                   '(ከታች ከተመረጠው የመንገድ ዓይነት መስክ ጋር ይዛመዳል)፣ አምድ 2 = በሜትር '
                   'የተለካ ስፋት። CSV ካልቀረበ እና የዓይነት መስክ ከሌለ፣ ለመንገዶች የተመደበ '
                   'መሬት = 0።',
    'btn_browse_csv': 'CSV ምረጥ...',
    'grp_catfield': 'የመንገድ ዓይነት መስክ (ከመንገዶች ንብርብር)',
    'note_catfield': 'የመንገድ ዓይነቶችን የያዘው የመንገዶች ንብርብር መስክ፣ ስፋቶችን ለማያያዝ '
                     'ያገለግላል። \'fclass\'፣ \'highway\' ወይም \'type\' ካለ በራስ-ሰር '
                     'ይመረጣል፤ ካልሆነ እዚህ መስኩን ይምረጡ። በራስ-ሰር ለመለየት ባዶ ይተዉት።',
    'grp_crs': 'የዒላማ መጋጠሚያ ማጣቀሻ ሥርዓት (የታቀደ፣ በሜትር - ለምሳሌ የከተማው ክልል '
               'UTM ዞን)',
    'dist_header': 'የመረብ ርቀት ገደብ ለ:',
    'dist_pos': 'የሕዝብ ክፍት ቦታዎች',
    'spacing_header': 'በሕዝብ ክፍት ቦታዎች ወሰን ነጥቦች መካከል ያለው ርቀት:',
    'spacing_note': 'በእያንዳንዱ ክፍት ቦታ ዙሪያ መስመር ላይ የሚቀመጡ መነሻ ነጥቦች። 100 ሜትር '
                    'መደበኛ ነው፤ የበለጠ ርቀት (ለምሳሌ 200 ሜትር) ብዙ ትላልቅ መናፈሻዎች '
                    'ላሏቸው ከተሞች ፈጣን ነው፣ ግን ትክክለኛነቱ በትንሹ ይቀንሳል።',
    'perf_header': 'አፈጻጸም:',
    'chk_preclip': 'ግብዓቶችን አስቀድሞ ወደ ከተማ ክልል ቁረጥ',
    'note_preclip': 'የሚመከር። በከተማው ክልል የፍለጋ ወሰን ውስጥ ያሉ መንገዶችን፣ ማቆሚያዎችን '
                    'እና ክፍት ቦታዎችን ብቻ ያስቀራል - በአገር ወይም በክልል ደረጃ ባለ መረጃ '
                    'በጣም ፈጣን ነው።',
    'chk_memory': 'መካከለኛ ንብርብሮችን በማህደረ ትውስታ አቆይ',
    'note_memory': 'ፈጣን ነው። የኮምፒውተሩ RAM ሲያንስ ብቻ ምልክቱን ያንሱ።',
    'chk_native': 'የQGIS የራሱን የአገልግሎት ክልል ስልተ ቀመር ተጠቀም',
    'note_native': 'ለማረጋገጫ ብቻ - ብዙ መነሻ ነጥቦች ሲኖሩ በጣም ቀርፋፋ ነው። ነባሪው ፈጣን '
                   'የተገደበ ፍለጋ ነው (ተመሳሳይ ውጤት)።',
    'grp_city': 'የከተማ ስም (ጠቃሚ ምክር: ልዩ ምልክቶችን ያስወግዱ)',
    'city_placeholder': 'ለምሳሌ Mombasa',
    'lbl_output_folder': 'የውጤት አቃፊ:',
    'btn_browse': 'ምረጥ...',
    'info_block':
        "የሚቀመጡ የመጨረሻ ፋይሎች:\n"
        "  የተቆረጡ እና የተዋሀዱ የአገልግሎት ክልሎች:\n"
        "  SA_POS_dissolved.shp                የሕዝብ ክፍት ቦታዎች\n"
        "  SA_Bus_dissolved.shp                ዝቅተኛ አቅም ያላቸው ማቆሚያዎች\n"
        "  SA_Ferry_dissolved.shp              የጀልባ ወደቦች\n"
        "  SA_Rail_dissolved.shp               የባቡር ጣቢያዎች\n"
        "  SA_HighCapacity_dissolved.shp       ከፍተኛ አቅም (ባቡር + ጀልባ)\n"
        "  SA_CombinedTransport_dissolved.shp  የተቀናጀ የሕዝብ ትራንስፖርት\n"
        "  የየማቆሚያው የተናጠል የአገልግሎት ክልሎች:\n"
        "  SA_Bus_individual.shp / SA_Ferry_individual.shp / SA_Rail_individual.shp\n"
        "  ZonalStats_*.shp                    የአገልግሎት ክልል + pop_sum መስክ\n"
        "  LAS_streets_dissolved.shp           ለመንገዶች የተመደበ መሬት\n"
        "  {city}_statistics_11.2.1_and_11.7.1.xlsx\n\n"
        "ማስታወሻዎች:\n"
        "  - ከሂደቱ በፊት ጂኦሜትሪ በራስ-ሰር ይስተካከላል።\n"
        "  - ሕዝብ: የቤተሰብ ነጥቦች (የሕዝብ መስክ ድምር) ከቀረቡ፣\n"
        "    ካልሆነ በፍርግርግ የተዘጋጀ የሕዝብ ራስተር።\n"
        "  - የሕዝብ ክፍት ቦታዎች ስፋት ወደ ከተማ ወሰን ከተቆረጠ በኋላ ይለካል።\n"
        "  - ግብዓቶች ወደ ከተማ ክልል + የፍለጋ ወሰን ይቆረጣሉ፤ መካከለኛ\n"
        "    ንብርብሮች በማህደረ ትውስታ ይቆያሉ (የርቀቶች ትርን ይመልከቱ)።\n"
        "  - የተቀናጀ ትራንስፖርት = ዝቅተኛ አቅም ማቆሚያዎች + ጀልባ + ባቡር\n"
        "    (የሕዝብ ክፍት ቦታዎችን አያካትትም)።\n"
        "  - ለመንገዶች የተመደበ መሬት: በስፋታቸው መሠረት የመንገዶች ቋት፣\n"
        "    ተዋህዶ ወደ ከተማው ስፋት ይቆረጣል።\n"
        "  - የስታቲስቲክስ ሰንጠረዡ በተመረጠው ቋንቋ ይጻፋል።\n"
        "  - ከስህተት በኋላ አዝራሮችን እንደገና ለማንቃት 'መዝገብ አጽዳ'ን ይጠቀሙ።",
    'msg_running_title': 'በሂደት ላይ',
    'msg_cannot_reset': 'ትንተናው በሂደት ላይ እያለ ማጽዳት አይቻልም። መጀመሪያ ይሰርዙ።',
    'msg_missing_layer': 'ንብርብር የለም',
    'msg_select_streets': 'እባክዎ የመንገዶች ንብርብር ይምረጡ።',
    'msg_select_urban': 'እባክዎ የከተማ ወሰን ንብርብር ይምረጡ።',
    'msg_missing_pop_title': 'የሕዝብ መረጃ የለም',
    'msg_missing_pop': 'እባክዎ በፍርግርግ የተዘጋጀ የሕዝብ (ራስተር) ንብርብር ወይም የቤተሰብ '
                       'ሕዝብ (ነጥቦች) ንብርብር ይምረጡ - ከሁለቱ አንዱ ግዴታ ነው።',
    'msg_missing_popfield_title': 'የሕዝብ መስክ የለም',
    'msg_missing_popfield': 'እባክዎ ለቤተሰብ ሕዝብ (ነጥቦች) ንብርብር ጠቅላላ ሕዝብ የያዘውን '
                            'መስክ ይምረጡ።',
    'msg_missing_city_title': 'የከተማ ስም የለም',
    'msg_missing_city': 'እባክዎ የከተማውን ስም ያስገቡ።',
    'msg_missing_output_title': 'የውጤት አቃፊ የለም',
    'msg_missing_output': 'እባክዎ የውጤት አቃፊ ይምረጡ።',
    'msg_invalid_crs_title': 'ልክ ያልሆነ CRS',
    'msg_invalid_crs': 'እባክዎ ትክክለኛ የዒላማ CRS ይምረጡ።',
    'msg_no_transport_title': 'የትራንስፖርት ንብርብሮች የሉም',
    'msg_no_transport': 'የሕዝብ ክፍት ቦታዎች / ዝቅተኛ አቅም / ጀልባ / ባቡር ንብርብር '
                        'አልተመረጠም። የከተማው ክልል እና መንገዶች ብቻ ይሠራሉ። ይቀጥሉ?',
    'msg_complete': 'ተጠናቋል',
    'msg_error': 'ስህተት',
    'msg_failed': 'ትንተናው አልተሳካም። ለዝርዝሩ መዝገቡን ይመልከቱ።\n\n'
                  '\'መዝገብ አጽዳ\'ን ጠቅ አድርገው እንደገና ያሂዱ።',
    'msg_close_running': 'ትንተናው አሁንም በሂደት ላይ ነው። ሰርዘው ይዝጉ?',
    'msg_cancel_requested': 'የመሰረዝ ጥያቄ ቀርቧል...',
    'dlg_select_output': 'የውጤት አቃፊ ይምረጡ',
    'dlg_select_csv': 'የተለኩ የመንገድ ስፋቶች CSV ይምረጡ',
    'csv_filter': 'CSV ፋይሎች (*.csv *.txt);;ሁሉም ፋይሎች (*)',
    'msg_invalid_csv_title': 'ልክ ያልሆነ CSV',
    'msg_invalid_csv': 'ማንበብ አልተቻለም:',
    'msg_widths_title': 'የመንገድ ስፋት CSV',
    'msg_widths_cols': 'የመንገድ ስፋት ሰንጠረዡ ቢያንስ ሁለት አምዶች (የመንገድ ዓይነት፣ ስፋት) '
                       'ሊኖሩት ይገባል። ችላ ይባላል።',
    'res_done': 'ተጠናቋል!',
    'res_las': 'ለመንገዶች የተመደበ መሬት',
    'res_stats': 'የስታቲስቲክስ ሰንጠረዥ (CSV)',
    'res_excel': 'የስታቲስቲክስ የሥራ መጽሐፍ (Excel)',
    'res_roads': 'የመንገዶች ሰንጠረዥ',
    'res_folder': 'አቃፊ',
    'res_time': 'ጊዜ',
    'h_city': 'ከተማ',
    'h_urban_area': 'የከተማ ስፋት (ካሬ ኪሜ)',
    'h_pos_area': 'የሕዝብ ክፍት ቦታዎች ስፋት (ካሬ ኪሜ)',
    'h_las': 'ለመንገዶች የተመደበ መሬት (ካሬ ኪሜ)',
    'h_ops_las': 'የሕዝብ ክፍት ቦታዎች + ለመንገዶች የተመደበ መሬት (ካሬ ኪሜ)',
    'h_prop_ops_las': 'ከከተማ ስፋት የሕዝብ ክፍት ቦታዎች + ለመንገዶች የተመደበ መሬት ድርሻ (%)',
    'h_total_pop': 'ጠቅላላ የከተማ ሕዝብ',
    'h_pop_pos': 'የሕዝብ ክፍት ቦታዎችን ማግኘት የሚችል ሕዝብ',
    'h_pop_bus': 'ዝቅተኛ አቅም ያላቸውን የትራንስፖርት ማቆሚያዎች (የአውቶቡስ ማቆሚያዎች፣ '
                 'የቀላል ባቡር ማቆሚያዎች) ማግኘት የሚችል ሕዝብ',
    'h_pop_hc': 'ከፍተኛ አቅም ያለውን ትራንስፖርት (ባቡር + ጀልባ) ማግኘት የሚችል ሕዝብ',
    'h_pop_comb': 'የተቀናጀ የሕዝብ ትራንስፖርት ማግኘት የሚችል ሕዝብ',
    'h_pct_pos': 'የሕዝብ ክፍት ቦታዎችን ማግኘት የሚችል ሕዝብ መቶኛ',
    'h_pct_bus': 'ዝቅተኛ አቅም ያላቸውን የትራንስፖርት ማቆሚያዎች (የአውቶቡስ ማቆሚያዎች፣ '
                 'የቀላል ባቡር ማቆሚያዎች) ማግኘት የሚችል ሕዝብ መቶኛ',
    'h_pct_hc': 'ከፍተኛ አቅም ያለውን ትራንስፖርት ማግኘት የሚችል ሕዝብ መቶኛ',
    'h_pct_comb': 'የተቀናጀ የሕዝብ ትራንስፖርት ማግኘት የሚችል ሕዝብ መቶኛ',
    'h_pop_source': 'የሕዝብ መረጃ ምንጭ',
    'src_household': 'የቤተሰብ ነጥቦች',
    'src_raster': 'የፍርግርግ ራስተር',
    'src_field': 'መስክ',
}


# ---------------------------------------------------------- ha: Hausa
_EXTRA_TEXT['ha'] = {
    'win_title': 'Lissafin Ƙididdigar SDG 11.2.1 da 11.7.1',
    'subtitle': 'Yanke farko zuwa yankin birni -> Sake tsarin taswira + gyaran '
                'siffofi -> Yanke wuraren buɗaɗɗu na jama\'a -> Ɗigogin iyaka -> '
                'Yankin hidima -> Kewaye mai lanƙwasa -> Yanke -> Haɗewa -> Yawan '
                'jama\'a a yankunan hidima -> Haɗa faɗin hanyoyi -> Kariya (buffer) '
                '-> Haɗewa -> Yanke (ƙasar da aka keɓe wa tituna) -> Teburin '
                'ƙididdiga',
    'language': 'Harshe:',
    'tab_layers': 'Layuka',
    'tab_distances': 'Nisa',
    'tab_output': 'Sakamako',
    'progress': 'Ci gaba',
    'btn_run': 'Fara bincike',
    'btn_cancel': 'Soke',
    'btn_reset': 'Share rajista',
    'btn_close': 'Rufe',
    'grp_streets': 'Tituna',
    'note_streets': 'Layin tituna da ake amfani da shi wajen nemo hanya a cikin '
                    'hanyar sadarwa',
    'grp_urban': 'Iyakar birni',
    'note_urban': 'Layin polygon da ke ayyana faɗin yankin birni',
    'grp_pop_raster': 'Yawan jama\'a a grid (raster)',
    'note_pop_raster': 'Bayanan yawan jama\'a a grid. Samar da wannan KO Yawan jama\'ar '
                       'gidaje (ɗigogi) a ƙasa - ɗaya daga cikinsu wajibi ne.',
    'grp_hh': 'Yawan jama\'ar gidaje (ɗigogi)',
    'note_hh': 'Layin ɗigogi mai ɗauke da yawan mutane a matakin gida. Samar da wannan '
               'KO raster na yawan jama\'a a grid - ɗaya daga cikinsu wajibi ne. Idan '
               'an samar da duka biyun, za a yi amfani da ɗigogin gidaje. Yawan '
               'jama\'ar kowane yankin hidima = jimillar filin da aka zaɓa na ɗigogin '
               'da ke cikinsa.',
    'lbl_pop_field': 'Filin da ke ɗauke da jimillar yawan jama\'a (ga kowane ɗigon '
                     'gida):',
    'grp_pos': 'Wuraren buɗaɗɗu na jama\'a (polygon)',
    'note_pos': 'Layukan polygon na ƙasar da ba a gina ba ko buɗaɗɗiya wadda jama\'a '
                'za su iya shiga, da ke ba mazauna wuraren shaƙatawa tare da '
                'inganta muhalli. Misali: wuraren shakatawa, lambuna, filayen wasan '
                'yara, gaɓar teku ta jama\'a, gefen koguna da bakin ruwa',
    'grp_bus': 'Tashoshin sufuri masu ƙaramin ƙarfi (tashoshin bas, tashoshin '
               'jirgin ƙasa mai sauƙi)',
    'note_bus': 'Layin ɗigogin wuraren tashoshin bas / jirgin ƙasa mai sauƙi',
    'grp_rail': 'Tashoshin sufuri masu babban ƙarfi (tashoshin jirgin ƙasa, '
                'tashoshin metro)',
    'note_rail': 'Layin ɗigogin wuraren tashoshin jirgin ƙasa / metro',
    'grp_ferry': 'Tashoshin sufuri masu babban ƙarfi (tashoshin jirgin ruwa)',
    'note_ferry': 'Layin ɗigogin wuraren tashoshin jirgin ruwa',
    'grp_widths': 'Faɗin hanyoyi da aka auna (teburin CSV)',
    'note_widths': 'Ana amfani da shi wajen lissafin ƙasar da aka keɓe wa tituna. '
                   'Shafi na 1 = nau\'in hanya (ana daidaita shi da filin nau\'in hanya '
                   'da aka zaɓa a ƙasa), shafi na 2 = faɗin da aka auna a mita. Idan '
                   'ba a samar da CSV ba kuma babu filin nau\'i, ƙasar da aka keɓe wa '
                   'tituna = 0.',
    'btn_browse_csv': 'Zaɓi CSV...',
    'grp_catfield': 'Filin nau\'in hanya (daga layin tituna)',
    'note_catfield': 'Filin layin tituna da ke ɗauke da nau\'ikan hanyoyi, ana amfani '
                     'da shi wajen haɗa faɗin hanyoyi. Ana zaɓar \'fclass\', '
                     '\'highway\' ko \'type\' kai tsaye idan akwai; in ba haka ba, '
                     'zaɓi filin a nan. Bar shi babu komai don ganowa kai tsaye.',
    'grp_crs': 'Tsarin daidaitawar wuri na manufa (projected, a mita - misali yankin '
               'UTM na birnin)',
    'dist_header': 'Iyakar nisa a hanyar sadarwa ga:',
    'dist_pos': 'Wuraren buɗaɗɗu na jama\'a',
    'spacing_header': 'Tazarar ɗigogin iyakar wuraren buɗaɗɗu na jama\'a:',
    'spacing_note': 'Ɗigogin farawa da ake sanyawa a kewayen kowane buɗaɗɗen wuri. Mita '
                    '100 shi ne na al\'ada; tazara mafi girma (misali mita 200) tana '
                    'sauri ga biranen da ke da manyan wuraren shakatawa da yawa, amma '
                    'daidaito yana raguwa kaɗan.',
    'perf_header': 'Aiki:',
    'chk_preclip': 'Yanke bayanan shigarwa zuwa yankin birni tun farko',
    'note_preclip': 'An ba da shawara. Yana riƙe tituna, tashoshi da buɗaɗɗun wurare '
                    'da ke cikin iyakar bincike na birnin kawai - ya fi sauri sosai da '
                    'bayanan ƙasa ko yanki baki ɗaya.',
    'chk_memory': 'Ajiye layukan tsaka-tsaki a ma\'adana',
    'note_memory': 'Ya fi sauri. Cire alamar kawai idan RAM ɗin kwamfutar ya ƙare.',
    'chk_native': 'Yi amfani da algorithm ɗin yankin hidima na QGIS na asali',
    'note_native': 'Don tabbatarwa kawai - yana da jinkiri sosai idan ɗigogin farawa '
                   'sun yi yawa. Na asali shi ne bincike mai iyaka mai sauri (sakamako '
                   'iri ɗaya).',
    'grp_city': 'Sunan birni (Shawara: guji haruffa na musamman)',
    'city_placeholder': 'misali Mombasa',
    'lbl_output_folder': 'Babban fayil na sakamako:',
    'btn_browse': 'Zaɓi...',
    'info_block':
        "Fayilolin ƙarshe da ake ajiyewa:\n"
        "  Yankunan hidima da aka yanke aka haɗe:\n"
        "  SA_POS_dissolved.shp                Wuraren buɗaɗɗu na jama'a\n"
        "  SA_Bus_dissolved.shp                Tashoshi masu ƙaramin ƙarfi\n"
        "  SA_Ferry_dissolved.shp              Tashoshin jirgin ruwa\n"
        "  SA_Rail_dissolved.shp               Tashoshin jirgin ƙasa\n"
        "  SA_HighCapacity_dissolved.shp       Babban ƙarfi (jirgin ƙasa + ruwa)\n"
        "  SA_CombinedTransport_dissolved.shp  Sufurin jama'a gaba ɗaya\n"
        "  Yankunan hidima na kowace tasha:\n"
        "  SA_Bus_individual.shp / SA_Ferry_individual.shp / SA_Rail_individual.shp\n"
        "  ZonalStats_*.shp                    Yankin hidima + filin pop_sum\n"
        "  LAS_streets_dissolved.shp           Ƙasar da aka keɓe wa tituna\n"
        "  {city}_statistics_11.2.1_and_11.7.1.xlsx\n\n"
        "BAYANAI:\n"
        "  - Ana gyara siffofi kai tsaye kafin a sarrafa su.\n"
        "  - Yawan jama'a: ɗigogin gidaje (jimillar filin yawan jama'a) idan an\n"
        "    samar da su, in ba haka ba raster na yawan jama'a a grid.\n"
        "  - Ana auna faɗin wuraren buɗaɗɗu bayan an yanke su zuwa iyakar birni.\n"
        "  - Ana yanke bayanai zuwa yankin birni + iyakar bincike, kuma ana ajiye\n"
        "    layukan tsaka-tsaki a ma'adana (duba shafin Nisa).\n"
        "  - Sufuri gaba ɗaya = tashoshi masu ƙaramin ƙarfi + jirgin ruwa + jirgin ƙasa\n"
        "    (ba tare da wuraren buɗaɗɗu na jama'a ba).\n"
        "  - Ƙasar da aka keɓe wa tituna: kariyar tituna bisa faɗinsu,\n"
        "    a haɗe a yanke zuwa faɗin birni.\n"
        "  - Ana rubuta teburin ƙididdiga a harshen da aka zaɓa.\n"
        "  - Bayan kuskure, yi amfani da 'Share rajista' don sake kunna maɓallai.",
    'msg_running_title': 'Ana gudana',
    'msg_cannot_reset': 'Ba za a iya sharewa yayin da bincike ke gudana ba. Soke shi '
                        'tukuna.',
    'msg_missing_layer': 'Babu layi',
    'msg_select_streets': 'Da fatan za a zaɓi layin tituna.',
    'msg_select_urban': 'Da fatan za a zaɓi layin iyakar birni.',
    'msg_missing_pop_title': 'Babu bayanan yawan jama\'a',
    'msg_missing_pop': 'Da fatan za a zaɓi layin yawan jama\'a a grid (raster) ko layin '
                       'yawan jama\'ar gidaje (ɗigogi) - ɗaya daga cikinsu wajibi ne.',
    'msg_missing_popfield_title': 'Babu filin yawan jama\'a',
    'msg_missing_popfield': 'Da fatan za a zaɓi filin jimillar yawan jama\'a ga layin '
                            'yawan jama\'ar gidaje (ɗigogi).',
    'msg_missing_city_title': 'Babu sunan birni',
    'msg_missing_city': 'Da fatan za a shigar da sunan birni.',
    'msg_missing_output_title': 'Babu babban fayil na sakamako',
    'msg_missing_output': 'Da fatan za a zaɓi babban fayil na sakamako.',
    'msg_invalid_crs_title': 'CRS mara inganci',
    'msg_invalid_crs': 'Da fatan za a zaɓi CRS na manufa mai inganci.',
    'msg_no_transport_title': 'Babu layukan sufuri',
    'msg_no_transport': 'Ba a zaɓi layin wuraren buɗaɗɗu na jama\'a / ƙaramin ƙarfi / '
                        'jirgin ruwa / jirgin ƙasa ba. Yankin birni da tituna kawai za '
                        'a sarrafa. A ci gaba?',
    'msg_complete': 'An kammala',
    'msg_error': 'Kuskure',
    'msg_failed': 'Binciken bai yi nasara ba. Duba rajista don cikakken bayani.\n\n'
                  'Danna \'Share rajista\' sannan a sake gudanarwa.',
    'msg_close_running': 'Bincike yana gudana har yanzu. A soke a rufe?',
    'msg_cancel_requested': 'An nemi sokewa...',
    'dlg_select_output': 'Zaɓi babban fayil na sakamako',
    'dlg_select_csv': 'Zaɓi CSV na faɗin hanyoyi da aka auna',
    'csv_filter': 'Fayilolin CSV (*.csv *.txt);;Duk fayiloli (*)',
    'msg_invalid_csv_title': 'CSV mara inganci',
    'msg_invalid_csv': 'Ba a iya karantawa ba:',
    'msg_widths_title': 'CSV na faɗin hanyoyi',
    'msg_widths_cols': 'Teburin faɗin hanyoyi yana buƙatar aƙalla shafuka biyu (nau\'in '
                       'hanya, faɗi). Za a yi watsi da shi.',
    'res_done': 'An kammala!',
    'res_las': 'Ƙasar da aka keɓe wa tituna',
    'res_stats': 'Teburin ƙididdiga (CSV)',
    'res_excel': 'Littafin aikin ƙididdiga (Excel)',
    'res_roads': 'Teburin tituna',
    'res_folder': 'Babban fayil',
    'res_time': 'Lokaci',
    'h_city': 'Birni',
    'h_urban_area': 'Faɗin yankin birni (km2)',
    'h_pos_area': 'Faɗin wuraren buɗaɗɗu na jama\'a (km2)',
    'h_las': 'Ƙasar da aka keɓe wa tituna (km2)',
    'h_ops_las': 'Wuraren buɗaɗɗu na jama\'a + ƙasar da aka keɓe wa tituna (km2)',
    'h_prop_ops_las': 'Kason yankin birni na wuraren buɗaɗɗu na jama\'a + ƙasar da aka '
                      'keɓe wa tituna (%)',
    'h_total_pop': 'Jimillar yawan jama\'ar birni',
    'h_pop_pos': 'Yawan jama\'a masu samun damar zuwa wuraren buɗaɗɗu na jama\'a',
    'h_pop_bus': 'Yawan jama\'a masu samun damar zuwa tashoshin sufuri masu ƙaramin '
                 'ƙarfi (tashoshin bas, tashoshin jirgin ƙasa mai sauƙi)',
    'h_pop_hc': 'Yawan jama\'a masu samun damar zuwa sufuri mai babban ƙarfi (jirgin '
                'ƙasa + jirgin ruwa)',
    'h_pop_comb': 'Yawan jama\'a masu samun damar zuwa sufurin jama\'a gaba ɗaya',
    'h_pct_pos': 'Kashi na yawan jama\'a masu samun damar zuwa wuraren buɗaɗɗu na '
                 'jama\'a',
    'h_pct_bus': 'Kashi na yawan jama\'a masu samun damar zuwa tashoshin sufuri masu '
                 'ƙaramin ƙarfi (tashoshin bas, tashoshin jirgin ƙasa mai sauƙi)',
    'h_pct_hc': 'Kashi na yawan jama\'a masu samun damar zuwa sufuri mai babban ƙarfi',
    'h_pct_comb': 'Kashi na yawan jama\'a masu samun damar zuwa sufurin jama\'a gaba '
                  'ɗaya',
    'h_pop_source': 'Tushen bayanan yawan jama\'a',
    'src_household': 'Ɗigogin gidaje',
    'src_raster': 'Raster na grid',
    'src_field': 'fili',
}


def _load_extra_languages():
    """Merge the built-in _EXTRA_TEXT blocks into STRINGS, then any optional
    translations/<code>.py (TEXT dict) files, which take precedence."""
    import importlib
    for code, text in _EXTRA_TEXT.items():
        for key, value in text.items():
            if key in STRINGS and value:
                STRINGS[key][code] = value
    base = {'en', 'fr', 'es', 'it', 'zh', 'ar'}
    for code in [c for c, _ in LANGUAGES if c not in base]:
        mod = None
        for prefix in ('.translations.', '.'):
            try:
                mod = importlib.import_module(prefix + code, __package__)
                break
            except Exception:
                mod = None
        if mod is None:
            continue
        for key, value in getattr(mod, 'TEXT', {}).items():
            if key in STRINGS and value:
                STRINGS[key][code] = value


_load_extra_languages()

SUPPORTED = [code for code, _ in LANGUAGES]


def tr(key, lang='en'):
    """Text for `key` in `lang`; falls back to English, then to the key."""
    entry = STRINGS.get(key)
    if entry is None:
        return key
    return entry.get(lang) or entry.get('en') or key


def default_language():
    """The user's saved choice, else the QGIS interface language, else
    English."""
    try:
        from qgis.PyQt.QtCore import QSettings
        s = QSettings()
        saved = s.value('transport_sa/language', '', type=str)
        if saved in SUPPORTED:
            return saved
        loc = s.value('locale/userLocale', '', type=str) or ''
        code = loc[:2].lower()
        code = LOCALE_ALIASES.get(code, code)
        if code in SUPPORTED:
            return code
    except (ImportError, TypeError):
        return 'en'
    return 'en'


def save_language(lang):
    from qgis.PyQt.QtCore import QSettings
    QSettings().setValue('transport_sa/language', lang)
