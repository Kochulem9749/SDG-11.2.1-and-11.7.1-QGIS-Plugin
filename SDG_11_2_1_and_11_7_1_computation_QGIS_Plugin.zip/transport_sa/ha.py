# -*- coding: utf-8 -*-
"""Hausa."""

TEXT = {
    'win_title': 'Lissafin Ƙididdigar SDG 11.2.1 da 11.7.1',
    'subtitle': 'Yanke farko zuwa yankin birni -> Sake tsarin taswira + gyaran '
                'siffofi -> Yanke wuraren buɗaɗɗu na jama\'a -> Ɗigogin iyaka -> '
                'Yankin hidima -> Kewaye mai lanƙwasa -> Yanke -> Haɗewa -> Yawan '
                'jama\'a a yankunan hidima -> Haɗa faɗin hanyoyi -> Kariya (buffer) '
                '-> Haɗewa -> Yanke (ƙasar da aka keɓe wa tituna) -> Teburin '
                'ƙididdiga',
    'language': 'Harshe:',
    'tab_layers': 'Layuka',
    'tab_distances': 'Nisa',
    'tab_output': 'Sakamako',
    'progress': 'Ci gaba',
    'btn_run': 'Fara bincike',
    'btn_cancel': 'Soke',
    'btn_reset': 'Share rajista',
    'btn_close': 'Rufe',
    'grp_streets': 'Tituna',
    'note_streets': 'Layin tituna da ake amfani da shi wajen nemo hanya a cikin '
                    'hanyar sadarwa',
    'grp_urban': 'Iyakar birni',
    'note_urban': 'Layin polygon da ke ayyana faɗin yankin birni',
    'grp_pop_raster': 'Yawan jama\'a a grid (raster)',
    'note_pop_raster': 'Bayanan yawan jama\'a a grid. Samar da wannan KO Yawan jama\'ar '
                       'gidaje (ɗigogi) a ƙasa - ɗaya daga cikinsu wajibi ne.',
    'grp_hh': 'Yawan jama\'ar gidaje (ɗigogi)',
    'note_hh': 'Layin ɗigogi mai ɗauke da yawan mutane a matakin gida. Samar da wannan '
               'KO raster na yawan jama\'a a grid - ɗaya daga cikinsu wajibi ne. Idan '
               'an samar da duka biyun, za a yi amfani da ɗigogin gidaje. Yawan '
               'jama\'ar kowane yankin hidima = jimillar filin da aka zaɓa na ɗigogin '
               'da ke cikinsa.',
    'lbl_pop_field': 'Filin da ke ɗauke da jimillar yawan jama\'a (ga kowane ɗigon '
                     'gida):',
    'grp_pos': 'Wuraren buɗaɗɗu na jama\'a (polygon)',
    'note_pos': 'Layukan polygon na ƙasar da ba a gina ba ko buɗaɗɗiya wadda jama\'a '
                'za su iya shiga, da ke ba mazauna wuraren shaƙatawa tare da '
                'inganta muhalli. Misali: wuraren shakatawa, lambuna, filayen wasan '
                'yara, gaɓar teku ta jama\'a, gefen koguna da bakin ruwa',
    'grp_bus': 'Tashoshin sufuri masu ƙaramin ƙarfi (tashoshin bas, tashoshin '
               'jirgin ƙasa mai sauƙi)',
    'note_bus': 'Layin ɗigogin wuraren tashoshin bas / jirgin ƙasa mai sauƙi',
    'grp_rail': 'Tashoshin sufuri masu babban ƙarfi (tashoshin jirgin ƙasa, '
                'tashoshin metro)',
    'note_rail': 'Layin ɗigogin wuraren tashoshin jirgin ƙasa / metro',
    'grp_ferry': 'Tashoshin sufuri masu babban ƙarfi (tashoshin jirgin ruwa)',
    'note_ferry': 'Layin ɗigogin wuraren tashoshin jirgin ruwa',
    'grp_widths': 'Faɗin hanyoyi da aka auna (teburin CSV)',
    'note_widths': 'Ana amfani da shi wajen lissafin ƙasar da aka keɓe wa tituna. '
                   'Shafi na 1 = nau\'in hanya (ana daidaita shi da filin nau\'in hanya '
                   'da aka zaɓa a ƙasa), shafi na 2 = faɗin da aka auna a mita. Idan '
                   'ba a samar da CSV ba kuma babu filin nau\'i, ƙasar da aka keɓe wa '
                   'tituna = 0.',
    'btn_browse_csv': 'Zaɓi CSV...',
    'grp_catfield': 'Filin nau\'in hanya (daga layin tituna)',
    'note_catfield': 'Filin layin tituna da ke ɗauke da nau\'ikan hanyoyi, ana amfani '
                     'da shi wajen haɗa faɗin hanyoyi. Ana zaɓar \'fclass\', '
                     '\'highway\' ko \'type\' kai tsaye idan akwai; in ba haka ba, '
                     'zaɓi filin a nan. Bar shi babu komai don ganowa kai tsaye.',
    'grp_crs': 'Tsarin daidaitawar wuri na manufa (projected, a mita - misali yankin '
               'UTM na birnin)',
    'dist_header': 'Iyakar nisa a hanyar sadarwa ga:',
    'dist_pos': 'Wuraren buɗaɗɗu na jama\'a',
    'spacing_header': 'Tazarar ɗigogin iyakar wuraren buɗaɗɗu na jama\'a:',
    'spacing_note': 'Ɗigogin farawa da ake sanyawa a kewayen kowane buɗaɗɗen wuri. Mita '
                    '100 shi ne na al\'ada; tazara mafi girma (misali mita 200) tana '
                    'sauri ga biranen da ke da manyan wuraren shakatawa da yawa, amma '
                    'daidaito yana raguwa kaɗan.',
    'perf_header': 'Aiki:',
    'chk_preclip': 'Yanke bayanan shigarwa zuwa yankin birni tun farko',
    'note_preclip': 'An ba da shawara. Yana riƙe tituna, tashoshi da buɗaɗɗun wurare '
                    'da ke cikin iyakar bincike na birnin kawai - ya fi sauri sosai da '
                    'bayanan ƙasa ko yanki baki ɗaya.',
    'chk_memory': 'Ajiye layukan tsaka-tsaki a ma\'adana',
    'note_memory': 'Ya fi sauri. Cire alamar kawai idan RAM ɗin kwamfutar ya ƙare.',
    'chk_native': 'Yi amfani da algorithm ɗin yankin hidima na QGIS na asali',
    'note_native': 'Don tabbatarwa kawai - yana da jinkiri sosai idan ɗigogin farawa '
                   'sun yi yawa. Na asali shi ne bincike mai iyaka mai sauri (sakamako '
                   'iri ɗaya).',
    'grp_city': 'Sunan birni (Shawara: guji haruffa na musamman)',
    'city_placeholder': 'misali Mombasa',
    'lbl_output_folder': 'Babban fayil na sakamako:',
    'btn_browse': 'Zaɓi...',
    'info_block':
        "Fayilolin ƙarshe da ake ajiyewa:\n"
        "  Yankunan hidima da aka yanke aka haɗe:\n"
        "  SA_POS_dissolved.shp                Wuraren buɗaɗɗu na jama'a\n"
        "  SA_Bus_dissolved.shp                Tashoshi masu ƙaramin ƙarfi\n"
        "  SA_Ferry_dissolved.shp              Tashoshin jirgin ruwa\n"
        "  SA_Rail_dissolved.shp               Tashoshin jirgin ƙasa\n"
        "  SA_HighCapacity_dissolved.shp       Babban ƙarfi (jirgin ƙasa + ruwa)\n"
        "  SA_CombinedTransport_dissolved.shp  Sufurin jama'a gaba ɗaya\n"
        "  Yankunan hidima na kowace tasha:\n"
        "  SA_Bus_individual.shp / SA_Ferry_individual.shp / SA_Rail_individual.shp\n"
        "  ZonalStats_*.shp                    Yankin hidima + filin pop_sum\n"
        "  LAS_streets_dissolved.shp           Ƙasar da aka keɓe wa tituna\n"
        "  {city}_statistics_11.2.1_and_11.7.1.xlsx\n\n"
        "BAYANAI:\n"
        "  - Ana gyara siffofi kai tsaye kafin a sarrafa su.\n"
        "  - Yawan jama'a: ɗigogin gidaje (jimillar filin yawan jama'a) idan an\n"
        "    samar da su, in ba haka ba raster na yawan jama'a a grid.\n"
        "  - Ana auna faɗin wuraren buɗaɗɗu bayan an yanke su zuwa iyakar birni.\n"
        "  - Ana yanke bayanai zuwa yankin birni + iyakar bincike, kuma ana ajiye\n"
        "    layukan tsaka-tsaki a ma'adana (duba shafin Nisa).\n"
        "  - Sufuri gaba ɗaya = tashoshi masu ƙaramin ƙarfi + jirgin ruwa + jirgin ƙasa\n"
        "    (ba tare da wuraren buɗaɗɗu na jama'a ba).\n"
        "  - Ƙasar da aka keɓe wa tituna: kariyar tituna bisa faɗinsu,\n"
        "    a haɗe a yanke zuwa faɗin birni.\n"
        "  - Ana rubuta teburin ƙididdiga a harshen da aka zaɓa.\n"
        "  - Bayan kuskure, yi amfani da 'Share rajista' don sake kunna maɓallai.",
    'msg_running_title': 'Ana gudana',
    'msg_cannot_reset': 'Ba za a iya sharewa yayin da bincike ke gudana ba. Soke shi '
                        'tukuna.',
    'msg_missing_layer': 'Babu layi',
    'msg_select_streets': 'Da fatan za a zaɓi layin tituna.',
    'msg_select_urban': 'Da fatan za a zaɓi layin iyakar birni.',
    'msg_missing_pop_title': 'Babu bayanan yawan jama\'a',
    'msg_missing_pop': 'Da fatan za a zaɓi layin yawan jama\'a a grid (raster) ko layin '
                       'yawan jama\'ar gidaje (ɗigogi) - ɗaya daga cikinsu wajibi ne.',
    'msg_missing_popfield_title': 'Babu filin yawan jama\'a',
    'msg_missing_popfield': 'Da fatan za a zaɓi filin jimillar yawan jama\'a ga layin '
                            'yawan jama\'ar gidaje (ɗigogi).',
    'msg_missing_city_title': 'Babu sunan birni',
    'msg_missing_city': 'Da fatan za a shigar da sunan birni.',
    'msg_missing_output_title': 'Babu babban fayil na sakamako',
    'msg_missing_output': 'Da fatan za a zaɓi babban fayil na sakamako.',
    'msg_invalid_crs_title': 'CRS mara inganci',
    'msg_invalid_crs': 'Da fatan za a zaɓi CRS na manufa mai inganci.',
    'msg_no_transport_title': 'Babu layukan sufuri',
    'msg_no_transport': 'Ba a zaɓi layin wuraren buɗaɗɗu na jama\'a / ƙaramin ƙarfi / '
                        'jirgin ruwa / jirgin ƙasa ba. Yankin birni da tituna kawai za '
                        'a sarrafa. A ci gaba?',
    'msg_complete': 'An kammala',
    'msg_error': 'Kuskure',
    'msg_failed': 'Binciken bai yi nasara ba. Duba rajista don cikakken bayani.\n\n'
                  'Danna \'Share rajista\' sannan a sake gudanarwa.',
    'msg_close_running': 'Bincike yana gudana har yanzu. A soke a rufe?',
    'msg_cancel_requested': 'An nemi sokewa...',
    'dlg_select_output': 'Zaɓi babban fayil na sakamako',
    'dlg_select_csv': 'Zaɓi CSV na faɗin hanyoyi da aka auna',
    'csv_filter': 'Fayilolin CSV (*.csv *.txt);;Duk fayiloli (*)',
    'msg_invalid_csv_title': 'CSV mara inganci',
    'msg_invalid_csv': 'Ba a iya karantawa ba:',
    'msg_widths_title': 'CSV na faɗin hanyoyi',
    'msg_widths_cols': 'Teburin faɗin hanyoyi yana buƙatar aƙalla shafuka biyu (nau\'in '
                       'hanya, faɗi). Za a yi watsi da shi.',
    'res_done': 'An kammala!',
    'res_las': 'Ƙasar da aka keɓe wa tituna',
    'res_stats': 'Teburin ƙididdiga (CSV)',
    'res_excel': 'Littafin aikin ƙididdiga (Excel)',
    'res_roads': 'Teburin tituna',
    'res_folder': 'Babban fayil',
    'res_time': 'Lokaci',
    'h_city': 'Birni',
    'h_urban_area': 'Faɗin yankin birni (km2)',
    'h_pos_area': 'Faɗin wuraren buɗaɗɗu na jama\'a (km2)',
    'h_las': 'Ƙasar da aka keɓe wa tituna (km2)',
    'h_ops_las': 'Wuraren buɗaɗɗu na jama\'a + ƙasar da aka keɓe wa tituna (km2)',
    'h_prop_ops_las': 'Kason yankin birni na wuraren buɗaɗɗu na jama\'a + ƙasar da aka '
                      'keɓe wa tituna (%)',
    'h_total_pop': 'Jimillar yawan jama\'ar birni',
    'h_pop_pos': 'Yawan jama\'a masu samun damar zuwa wuraren buɗaɗɗu na jama\'a',
    'h_pop_bus': 'Yawan jama\'a masu samun damar zuwa tashoshin sufuri masu ƙaramin '
                 'ƙarfi (tashoshin bas, tashoshin jirgin ƙasa mai sauƙi)',
    'h_pop_hc': 'Yawan jama\'a masu samun damar zuwa sufuri mai babban ƙarfi (jirgin '
                'ƙasa + jirgin ruwa)',
    'h_pop_comb': 'Yawan jama\'a masu samun damar zuwa sufurin jama\'a gaba ɗaya',
    'h_pct_pos': 'Kashi na yawan jama\'a masu samun damar zuwa wuraren buɗaɗɗu na '
                 'jama\'a',
    'h_pct_bus': 'Kashi na yawan jama\'a masu samun damar zuwa tashoshin sufuri masu '
                 'ƙaramin ƙarfi (tashoshin bas, tashoshin jirgin ƙasa mai sauƙi)',
    'h_pct_hc': 'Kashi na yawan jama\'a masu samun damar zuwa sufuri mai babban ƙarfi',
    'h_pct_comb': 'Kashi na yawan jama\'a masu samun damar zuwa sufurin jama\'a gaba '
                  'ɗaya',
    'h_pop_source': 'Tushen bayanan yawan jama\'a',
    'src_household': 'Ɗigogin gidaje',
    'src_raster': 'Raster na grid',
    'src_field': 'fili',
}
