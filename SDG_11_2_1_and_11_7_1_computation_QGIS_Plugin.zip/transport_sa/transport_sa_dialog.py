# -*- coding: utf-8 -*-
"""
SDG 11.2.1 and 11.7.1 Statistics Computation Plugin
Author: Data and Statistics Unit, UN-Habitat
Version 2.3 - adds Land Allocated to Streets (LAS) computation
"""

import os
import time
import traceback

PLUGIN_VERSION = "2.4"

# Default street widths (metres) used when a road category has no measured
# width in the user-supplied CSV (or when no CSV is supplied at all).
DEFAULT_ROAD_WIDTHS = {

    "abandoned":10.0,
    "access":6.5,
    "bridge":4.0,
    "bridleway":4.5,
    "bus_guideway":5.5,

    "bus_stop":4.5,

    "byway":6,

    "closed":9,

    "construction":10,

    "corridor":4.5,

    "crossing":4,

    "cycleway":3.5,

    "digitized":6,

    "disused":7.0,

    "elevator":2.0,

    "escape":6.5,

    "footway":3.5,

    "living_street":6.0,

    "motorway":16.0,

    "motorway_link":9.5,

    "path":2,

    "pedestrian":2,

    "pistz cyclable":4,

    "planned":4,

    "platform":3,
    "primary":13,

    "primary_link":8.0,

    "proposed":8.5,

    "raceway":7.5,

    "residential":7,
    "residential_link":7,
    "residentials":7,
    "rest_area":3.0,

    "rezidential":4.5,

    "road":7,

    "secondary":11.5,

    "secondary_link":7,

    "service":6,

    "services":6,

    "sidewalks":4,

    "steps":3,

    "tertiary":10,

    "tertiary_link":7,

    "track":4.5,

    "trail":3,
    "trunk":14,

    "trunk_link":8.5,

    "unclassified":8,

    "unclassified_link":8,
    "unmarked_route":3.0,

    "unsurfaced":5.5,

    "virtual":5,


}
# Road-category fields searched (in this order) on the clipped roads layer.
ROAD_CATEGORY_FIELDS = ['fclass', 'highway', 'type']

# Likely names of the total-population field on household points
# (pre-selected in the dialog when present).
POP_FIELD_CANDIDATES = ['total_pop', 'tot_pop', 'totpop', 'population',
                        'pop_total', 'hh_pop', 'hhpop', 'pop', 'pop_count',
                        'persons', 'hh_size', 'hhsize', 'household_size']

from qgis.PyQt.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QGridLayout,
    QLabel, QPushButton, QProgressBar, QTextEdit,
    QGroupBox, QTabWidget, QWidget, QFileDialog,
    QLineEdit, QDoubleSpinBox, QMessageBox, QScrollArea, QCheckBox,
    QSplitter
)
from qgis.PyQt.QtCore import Qt, QThread, pyqtSignal
from qgis.PyQt.QtGui import QFont

from qgis.core import (
    QgsProject, QgsVectorLayer, QgsCoordinateReferenceSystem, QgsProperty,
    QgsProcessingContext, QgsFeatureRequest, QgsSpatialIndex, QgsRectangle,
    QgsPointXY, QgsGeometry, QgsFeature, QgsWkbTypes, QgsDistanceArea,
    QgsField, QgsFields, QgsMemoryProviderUtils, QgsCoordinateTransform,
    QgsCsException
)
from qgis.PyQt.QtCore import QVariant
from qgis.PyQt.QtCore import QUrl
from qgis.gui import (
    QgsMapLayerComboBox, QgsProjectionSelectionWidget, QgsFieldComboBox
)
from qgis.core import QgsFieldProxyModel
from qgis.PyQt.QtWidgets import QComboBox

from .i18n import (
    LANGUAGES, RTL_LANGUAGES, tr as i18n_tr, default_language, save_language
)
from .filenames import (
    file_name as fn_tr, sheet_name as sheet_tr, translate_info_file_list
)
from qgis.core import QgsMapLayerProxyModel

import processing
import math

PLUGIN_BUILD = '2.5 (2026-10-29)'

# Start points (open-space boundary points, stops) farther than this from
# any street are not located on the network and create no service area -
# the same rule as the ArcGIS Pro tool (Add Locations, search tolerance
# 100 Meters). Without it, a boundary point of a large park or riverbank
# far from any street was snapped to the nearest street and produced a full
# catchment there, inflating the Open Public Spaces population.
SEARCH_TOLERANCE_M = 100.0

import re


def _to_number(value):
    """Population value of a household point as a float, or None when it
    is NULL / empty / not a number. Accepts numbers stored as text,
    thousands separators ('1,234', '1 234') and decimal commas ('3,5')."""
    if value is None:
        return None
    is_null = getattr(value, 'isNull', None)
    if callable(is_null) and is_null():
        return None
    if isinstance(value, (int, float)) and not isinstance(value, bool):
        x = float(value)
    else:
        txt = str(value).strip().replace('\u00a0', '').replace(' ', '')
        if txt == '' or txt.upper() in ('NULL', 'NONE', 'NAN'):
            return None
        if ',' in txt and '.' in txt:
            txt = txt.replace(',', '')
        elif ',' in txt:
            if re.fullmatch(r'-?\d{1,3}(,\d{3})+', txt):
                txt = txt.replace(',', '')
            else:
                txt = txt.replace(',', '.')
        try:
            x = float(txt)
        except ValueError:
            return None
    if math.isnan(x) or math.isinf(x):
        return None
    return x


# ---------------------------------------------------------------------------
# Fast network service areas
# ---------------------------------------------------------------------------
def math_hypot(x, y):
    return (x * x + y * y) ** 0.5


class FastServiceArea:
    """
    Network service areas with a distance-bounded shortest-path search.

    Equivalent to QGIS 'Service area (from layer)' (shortest path, no
    direction field, topology tolerance 0, INCLUDE_BOUNDS = False) followed
    by 'Convex hull' per start point, but much faster for many start points:

      * the street graph is built ONCE and reused for every mode;
      * each start point is snapped to the nearest street segment using a
        spatial index (QGIS checks every segment for every point);
      * the shortest-path search stops at the distance threshold
        (QGIS computes paths to the whole network for every point).

    Reachable area per start point = convex hull of the snapped start
    point, every street vertex reachable within the threshold, and the
    point where each partially-reachable street segment hits the threshold.
    Streets are joined only where they share an identical vertex, exactly
    like the QGIS network builder with tolerance 0.
    """

    def __init__(self, road_layer, log=None, cancelled=None):
        import math
        self.scale = 1.0
        self._hypot = math.hypot
        self.log = log or (lambda m: None)
        self.cancelled = cancelled or (lambda: False)
        self.xs, self.ys, self.adj, self.segs = [], [], [], []
        self.index = QgsSpatialIndex()
        node_id = {}

        def nid(x, y):
            k = (round(x, 4), round(y, 4))
            i = node_id.get(k)
            if i is None:
                i = len(self.xs)
                node_id[k] = i
                self.xs.append(x)
                self.ys.append(y)
                self.adj.append([])
            return i

        req = QgsFeatureRequest().setNoAttributes()
        for n, f in enumerate(road_layer.getFeatures(req)):
            if n % 20000 == 0 and self.cancelled():
                raise RuntimeError("Cancelled by user.")
            g = f.geometry()
            if g is None or g.isEmpty():
                continue
            parts = g.asMultiPolyline() if g.isMultipart() \
                else [g.asPolyline()]
            for pl in parts:
                for p1, p2 in zip(pl[:-1], pl[1:]):
                    a = nid(p1.x(), p1.y())
                    b = nid(p2.x(), p2.y())
                    if a == b:
                        continue
                    c = self._hypot(p2.x() - p1.x(), p2.y() - p1.y())
                    self.adj[a].append((b, c))
                    self.adj[b].append((a, c))
                    sid = len(self.segs)
                    self.segs.append((a, b, c))
                    self.index.addFeature(sid, QgsRectangle(
                        min(p1.x(), p2.x()), min(p1.y(), p2.y()),
                        max(p1.x(), p2.x()), max(p1.y(), p2.y())))
        self.log("  Street network graph: {:,} nodes, {:,} segments.".format(
            len(self.xs), len(self.segs)))
        self._set_ellipsoid_scale(road_layer)

    def _set_ellipsoid_scale(self, road_layer):
        """QGIS measures network costs on the project ellipsoid (true ground
        metres) - the project ellipsoid, or WGS84 when none is set.
        Projected metres differ slightly (e.g. UTM scale factor 0.9996), so
        derive the local ground/planar ratio at the network centre and
        apply it to the distance threshold, matching QGIS."""
        try:
            if not self.xs:
                return
            ell = QgsProject.instance().ellipsoid()
            if not ell or ell.upper() == 'NONE':
                ell = 'EPSG:7030'  # WGS84, as used by QGIS network analysis
            da = QgsDistanceArea()
            da.setSourceCrs(road_layer.crs(),
                            QgsProject.instance().transformContext())
            da.setEllipsoid(ell)
            if not da.willUseEllipsoid():
                return
            ext = road_layer.extent()
            cx, cy = ext.center().x(), ext.center().y()
            ratios = []
            for dx, dy in ((500, 0), (0, 500), (354, 354)):
                planar = math_hypot(dx, dy)
                ground = da.measureLine(QgsPointXY(cx - dx, cy - dy),
                                        QgsPointXY(cx + dx, cy + dy)) / 2.0
                if ground > 0:
                    ratios.append(ground / planar)
            if ratios:
                r = sum(ratios) / len(ratios)
                if 0.9 < r < 1.1:
                    self.scale = r
                    self.log("  Ellipsoidal distance correction ({}): "
                             "x{:.5f}".format(ell, r))
        except Exception:
            self.scale = 1.0

    # -- snapping ------------------------------------------------------------
    def _seg_closest(self, sid, px, py):
        a, b, c = self.segs[sid]
        ax, ay, bx, by = self.xs[a], self.ys[a], self.xs[b], self.ys[b]
        dx, dy = bx - ax, by - ay
        t = ((px - ax) * dx + (py - ay) * dy) / (c * c)
        t = 0.0 if t < 0 else (1.0 if t > 1 else t)
        cx, cy = ax + t * dx, ay + t * dy
        return self._hypot(px - cx, py - cy), t, cx, cy

    def snap(self, px, py):
        """Exact nearest segment: bbox-nearest gives an upper bound on the
        distance, then every segment within that bound is tested exactly."""
        ids = self.index.nearestNeighbor(QgsPointXY(px, py), 1)
        if not ids:
            return None
        d0 = self._seg_closest(ids[0], px, py)[0]
        cand = self.index.intersects(QgsRectangle(
            px - d0 - 1e-6, py - d0 - 1e-6, px + d0 + 1e-6, py + d0 + 1e-6))
        best = None
        for sid in cand or ids:
            d, t, cx, cy = self._seg_closest(sid, px, py)
            if best is None or d < best[0]:
                best = (d, sid, t, cx, cy)
        return best

    # -- bounded search ------------------------------------------------------
    def reach_points(self, px, py, limit):
        import heapq
        s = self.snap(px, py)
        if s is None:
            return []
        _, sid, t, sx, sy = s
        a, b, c = self.segs[sid]
        xs, ys, adj = self.xs, self.ys, self.adj
        pts = [QgsPointXY(sx, sy)]
        heap = []
        for node, cost in ((a, t * c), (b, (1.0 - t) * c)):
            if cost <= limit:
                heapq.heappush(heap, (cost, node))
            elif cost > 0:
                f = limit / cost
                pts.append(QgsPointXY(sx + (xs[node] - sx) * f,
                                      sy + (ys[node] - sy) * f))
        done = {}
        while heap:
            d, u = heapq.heappop(heap)
            if u in done:
                continue
            done[u] = d
            ux, uy = xs[u], ys[u]
            pts.append(QgsPointXY(ux, uy))
            for v, cst in adj[u]:
                nd = d + cst
                if nd <= limit:
                    if v not in done:
                        heapq.heappush(heap, (nd, v))
                else:
                    f = (limit - d) / cst
                    if f > 0:
                        pts.append(QgsPointXY(ux + (xs[v] - ux) * f,
                                              uy + (ys[v] - uy) * f))
        return pts

    def hull_layer(self, stops_layer, limit, crs, label=''):
        """Memory polygon layer with one convex hull per start point."""
        out = QgsVectorLayer("Polygon?field=src_fid:integer",
                             "sa_hulls_" + label, "memory")
        out.setCrs(crs)
        feats = []
        n_total = stops_layer.featureCount()
        skipped = 0
        req = QgsFeatureRequest().setNoAttributes()
        for i, f in enumerate(stops_layer.getFeatures(req)):
            if i % 250 == 0:
                if self.cancelled():
                    raise RuntimeError("Cancelled by user.")
                if i and i % 1000 == 0:
                    self.log("    [{}] {:,}/{:,} start points...".format(
                        label, i, n_total))
            g = f.geometry()
            if g is None or g.isEmpty():
                continue
            pts = g.asMultiPoint() if g.isMultipart() else [g.asPoint()]
            for pt in pts:
                rp = self.reach_points(pt.x(), pt.y(),
                                       float(limit) / self.scale)
                if len(rp) < 3:
                    skipped += 1
                    continue
                h = QgsGeometry.fromMultiPointXY(rp).convexHull()
                if h.isEmpty() or h.type() != QgsWkbTypes.PolygonGeometry \
                        or h.area() <= 0:
                    skipped += 1
                    continue
                nf = QgsFeature(out.fields())
                nf.setGeometry(h)
                nf.setAttributes([f.id()])
                feats.append(nf)
        out.dataProvider().addFeatures(feats)
        out.updateExtents()
        if skipped:
            self.log("    [{}] {} start point(s) reach no street area "
                     "(isolated / degenerate) - ignored.".format(
                         label, skipped))
        return out


# ---------------------------------------------------------------------------
# Worker
# ---------------------------------------------------------------------------
class SAWorker(QThread):
    log = pyqtSignal(str)
    progress = pyqtSignal(int)
    finished = pyqtSignal(bool, str)

    def __init__(self, params):
        super().__init__()
        self.params = params
        self._cancelled = False

    def cancel(self):
        self._cancelled = True

    def run(self):
        try:
            self._execute()
        except Exception as e:
            self.finished.emit(False, str(e) + '\n' + traceback.format_exc())

    # -----------------------------------------------------------------------
    def _execute(self):
        p = self.params
        lang = p.get('lang', 'en')

        def L(key):
            return i18n_tr(key, lang)

        def FN(key, label=None):
            """Output file name translated to the selected language."""
            return fn_tr(lang, key, label, city)

        out_dir = p['output_dir']
        crs = p['crs']
        city = p['city_name'].strip().replace(' ', '_') or 'city'
        city_label = p['city_name'].strip() or 'city'
        crs_str = "EPSG:{}".format(
            crs.postgisSrid()) if crs.postgisSrid() else crs.toWkt()

        use_mem = p.get('use_memory', True)
        preclip = p.get('preclip', True)
        pos_spacing = float(p.get('pos_spacing', 100) or 100)

        os.makedirs(out_dir, exist_ok=True)
        out_dir = os.path.normpath(out_dir)

        all_files = []
        keep_files = []

        step = [0]
        total = 95

        def tick(msg, n=1):
            step[0] += n
            self.log.emit(msg)
            self.progress.emit(min(int(step[0] / total * 100), 99))
            if self._cancelled:
                raise RuntimeError("Cancelled by user.")

        def shp(name):
            return os.path.join(out_dir, name + ".shp")

        def track(path, keep=False):
            if keep:
                keep_files.append(path)
            else:
                all_files.append(path)
            return path

        def tmp(name):
            """Output target for an intermediate layer: in memory (fast)
            or a temporary shapefile that is deleted at the end."""
            if use_mem:
                return 'TEMPORARY_OUTPUT'
            return track(shp(name))

        def as_layer(src):
            if isinstance(src, QgsVectorLayer):
                return src
            return QgsVectorLayer(src, '', 'ogr')

        def fcount(src):
            lyr = as_layer(src)
            return lyr.featureCount() if lyr and lyr.isValid() else 0

        # Context that skips geometry-validity checks: used only for the
        # fast pre-filter steps that run BEFORE geometries are fixed.
        ctx_nocheck = QgsProcessingContext()
        ctx_nocheck.setProject(QgsProject.instance())
        ctx_nocheck.setInvalidGeometryCheck(QgsFeatureRequest.GeometryNoCheck)

        t_start = time.time()
        t_step = [time.time()]

        def timed(label):
            now = time.time()
            tick("  ({} took {:.1f} s)".format(label, now - t_step[0]), 0)
            t_step[0] = now

        # ---- helpers -------------------------------------------------------
        def fix_geometry(layer_src, tmp_name):
            """Fix invalid geometries before any processing step."""
            r = processing.run("native:fixgeometries", {
                'INPUT': layer_src,
                'METHOD': 1,
                'OUTPUT': tmp(tmp_name)
            })
            return r['OUTPUT']

        def layer_area_km2(lyr_src):
            lyr = as_layer(lyr_src)
            if not lyr.isValid():
                return None
            total_m2 = sum(f.geometry().area() for f in lyr.getFeatures())
            return total_m2 / 1e6

        def delete_all_fields(layer_src, tmp_name):
            lyr = as_layer(layer_src)
            fnames = [f.name() for f in lyr.fields()]
            if not fnames:
                return layer_src
            r = processing.run("native:deletecolumn", {
                'INPUT': layer_src,
                'COLUMN': fnames,
                'OUTPUT': tmp(tmp_name)
            })
            return r['OUTPUT']

        def sum_points_in_polygons(poly_src, label):
            """Like ArcGIS 'Summarize Within': copy of `poly_src` with
            'pop_sum' = sum of the household population of the points inside
            each polygon and 'hh_count' = number of those points (points on
            the boundary count as inside)."""
            poly = as_layer(poly_src)
            fields = QgsFields(poly.fields())
            fields.append(QgsField('pop_sum', QVariant.Double))
            fields.append(QgsField('hh_count', QVariant.Int))
            mem = QgsMemoryProviderUtils.createMemoryLayer(
                'pop_' + label, fields, poly.wkbType(), poly.crs())
            xform = None
            if poly.crs().isValid() and poly.crs() != pop_pts_crs:
                xform = QgsCoordinateTransform(
                    poly.crs(), pop_pts_crs, QgsProject.instance())
            out_feats = []
            all_pop, all_n = 0.0, 0
            for pf in poly.getFeatures():
                g = pf.geometry()
                total, n = 0.0, 0
                if g is not None and not g.isEmpty():
                    gt = QgsGeometry(g)
                    if xform is not None:
                        gt.transform(xform)
                    engine = QgsGeometry.createGeometryEngine(gt.constGet())
                    engine.prepareGeometry()
                    for fid in pop_index.intersects(gt.boundingBox()):
                        if engine.intersects(pop_geoms[fid].constGet()):
                            total += pop_vals[fid]
                            n += 1
                nf = QgsFeature(fields)
                nf.setGeometry(g)
                nf.setAttributes(list(pf.attributes()) + [total, n])
                out_feats.append(nf)
                all_pop += total
                all_n += n
            mem.dataProvider().addFeatures(out_feats)
            mem.updateExtents()
            tick("    Summarize Within: {:,.0f} people in {:,} household "
                 "points".format(all_pop, all_n))
            return mem

        def run_zonal_stats(clean_layer, label, keep=True):
            """Population inside each catchment polygon -> field 'pop_sum'.
            Household points: sum of the population field of the points
            inside the polygon (QGIS 'Count points in polygon' with a weight
            field). Raster: zonal statistics sum of the population grid."""
            out_name = label
            zs_target = shp(FN('zonal', label)) if keep \
                else tmp("_tmp_zonal_" + label)
            if pop_pts is not None:
                tick("  [Household population] {}...".format(out_name))
                zs_out = sum_points_in_polygons(clean_layer, out_name)
                if keep:
                    processing.run("native:savefeatures", {
                        'INPUT': zs_out, 'OUTPUT': zs_target
                    })
            else:
                tick("  [ZonalStats] {}...".format(out_name))
                zs_out = processing.run("native:zonalstatisticsfb", {
                    'INPUT': clean_layer,
                    'INPUT_RASTER': p['pop_raster'],
                    'RASTER_BAND': 1,
                    'COLUMN_PREFIX': 'pop_',
                    'STATISTICS': [1],
                    'OUTPUT': zs_target
                })['OUTPUT']
            if keep:
                track(zs_target, keep=True)

            lyr = as_layer(zs_out)
            pop_val = None
            if lyr.isValid():
                fnames = [f.name() for f in lyr.fields()]
                tick(
                    "    Fields in {}: {}".format(
                        out_name, ', '.join(fnames)))
                if 'pop_sum' in fnames:
                    for feat in lyr.getFeatures():
                        v = feat['pop_sum']
                        try:
                            fv = float(v)
                            pop_val = (pop_val or 0) + fv
                        except (TypeError, ValueError):
                            pass
                    tick("    pop_sum = {}".format(pop_val))
                else:
                    tick("    WARNING: 'pop_sum' field not found!")
            else:
                tick("    WARNING: zonal stats layer invalid: {}".format(
                    out_name))
            return (zs_target if keep else zs_out), pop_val

        def reproject_and_fix(layer, name):
            tick("  Reprojecting {}...".format(name))
            r = processing.run("native:reprojectlayer", {
                'INPUT': layer, 'TARGET_CRS': crs_str,
                'OPERATION': '', 'OUTPUT': tmp("_tmp_reproj_" + name)
            })
            tick("  Fixing geometries for {}...".format(name))
            return fix_geometry(r['OUTPUT'], "_tmp_fixed_" + name)

        # ---- 1. Urban boundary first ---------------------------------------
        tick("Plugin build {} - household population: Summarize Within "
             "method".format(PLUGIN_BUILD))
        tick("Running from: {}".format(os.path.abspath(__file__)))
        tick("=== STEP 1: Urban boundary - reproject and fix ===")
        urban_r = reproject_and_fix(p['urban_layer'], 'urban_boundary')
        urban_area_km2 = layer_area_km2(urban_r)
        tick("  Urban area: {:.2f} km2".format(urban_area_km2 or 0))

        # ---- 1a. Population source -----------------------------------------
        # Household population points (if given) take priority over the
        # gridded population raster.
        pop_pts = None
        pop_weight = None
        if p.get('pop_points') is not None:
            tick("\n=== STEP 1a: Population - household points ===")
            if p.get('pop_raster') is not None:
                tick("  Both population inputs given - household points are "
                     "used; the population raster is ignored.")
            # Same approach as the ArcGIS Pro tool: project ALL household
            # points to the analysis CRS (arcpy Project), then sum the
            # population field inside each catchment (Summarize Within).
            pts_src = p['pop_points']
            n0 = pts_src.featureCount()
            src_fields = pts_src.fields()
            names = {f.name().lower(): f.name() for f in src_fields}
            want = (p.get('pop_field') or '').strip().lower()
            pop_weight = names.get(want) or names.get(want[:10])
            if not pop_weight:
                raise RuntimeError(
                    "Population field '{}' not found on the household "
                    "points layer.".format(p.get('pop_field')))
            w_idx = src_fields.indexOf(pop_weight)

            urban_lyr = as_layer(urban_r)
            pop_pts_crs = urban_lyr.crs()          # analysis (target) CRS
            urban_geom = QgsGeometry.unaryUnion(
                [f.geometry() for f in urban_lyr.getFeatures()])
            urban_rect = urban_geom.boundingBox()
            tick("  Household points layer: {:,} points, CRS {}, population "
                 "field '{}'.".format(n0, pts_src.crs().authid() or
                                      pts_src.crs().description() or
                                      'NOT SET', pop_weight))

            # Read every point once (geometry + population value).
            raw_pts = []
            n_null, n_nogeom = 0, 0
            bad_examples = []
            for f in pts_src.getFeatures():
                g = f.geometry()
                if g is None or g.isEmpty():
                    n_nogeom += 1
                    continue
                raw = f.attribute(w_idx)
                v = _to_number(raw)
                if v is None:
                    n_null += 1
                    if len(bad_examples) < 5 and str(raw) not in bad_examples:
                        bad_examples.append(str(raw))
                    continue
                raw_pts.append((QgsGeometry(g), v))
            tick("  Points with a usable population value: {:,}; NULL / "
                 "non-numeric: {:,}{}; without geometry: {:,}.".format(
                     len(raw_pts), n_null,
                     " (e.g. {})".format(', '.join(repr(b) for b in
                                                   bad_examples))
                     if bad_examples else '', n_nogeom))
            if not raw_pts:
                raise RuntimeError(
                    "The population field '{}' has no usable numeric values "
                    "(examples of values found: {}). Choose the field that "
                    "holds the number of people per household.".format(
                        pop_weight,
                        ', '.join(repr(b) for b in bad_examples) or 'none'))

            # Which CRS are the coordinates really in? Use the layer's own
            # CRS; if no point then lands on the urban area, test the CRSs a
            # mislabelled layer most often has (urban layer, analysis CRS,
            # WGS 84) and use the one that puts the points on the city.
            def transformer(src_crs):
                if not src_crs.isValid():
                    return None, False
                if src_crs == pop_pts_crs:
                    return None, True
                return QgsCoordinateTransform(
                    src_crs, pop_pts_crs, QgsProject.instance()), True

            def hits(src_crs, sample):
                xf, ok = transformer(src_crs)
                if not ok:
                    return -1
                n = 0
                for g, _ in sample:
                    gt = QgsGeometry(g)
                    if xf is not None:
                        try:
                            gt.transform(xf)
                        except QgsCsException:
                            # point cannot be expressed in the target CRS
                            # under this assumption -> not a hit
                            continue
                    if urban_rect.intersects(gt.boundingBox()) and \
                            urban_geom.intersects(gt):
                        n += 1
                return n

            step_n = max(1, len(raw_pts) // 5000)
            sample = raw_pts[::step_n]
            declared = pts_src.crs()
            candidates = [('the layer CRS', declared),
                          ('the Urban Boundary CRS', p['urban_layer'].crs()),
                          ('the target CRS', pop_pts_crs),
                          ('WGS 84', QgsCoordinateReferenceSystem('EPSG:4326'))]
            use_crs, use_label = None, None
            seen = []
            for label, c in candidates:
                if not c.isValid() or any(c == x for x in seen):
                    continue
                seen.append(c)
                if hits(c, sample) > 0:
                    use_crs, use_label = c, label
                    break
            if use_crs is None:
                raise RuntimeError(
                    "None of the {:,} household points fall inside the urban "
                    "boundary, whichever CRS is assumed (layer CRS: {}). "
                    "Check that the household points and the Urban Boundary "
                    "cover the same city.".format(
                        n0, declared.authid() or 'not set'))
            if not (declared.isValid() and use_crs == declared):
                tick("  WARNING: with its declared CRS ({}) no household "
                     "point lands on the urban area. The coordinates match "
                     "{} ({}), so that CRS is used. Please correct the CRS "
                     "of the household layer (Layer Properties > Source)."
                     .format(declared.authid() or 'not set', use_label,
                             use_crs.authid()))

            # Project every point to the analysis CRS and index it.
            xf, _ = transformer(use_crs)
            pop_index = QgsSpatialIndex()
            pop_geoms, pop_vals = {}, {}
            n_fail = 0
            for i, (g, v) in enumerate(raw_pts):
                if xf is not None:
                    try:
                        g.transform(xf)
                    except QgsCsException:
                        n_fail += 1
                        continue
                pop_geoms[i] = g
                pop_vals[i] = v
                pop_index.addFeature(i, g.boundingBox())
            raw_pts = None
            if n_fail:
                tick("  {:,} points could not be projected and were "
                     "skipped.".format(n_fail))

            in_urban = [i for i in pop_index.intersects(urban_rect)
                        if urban_geom.intersects(pop_geoms[i])]
            total_hh_pop = sum(pop_vals[i] for i in in_urban)
            tick("  Household points inside the urban area: {:,}; their "
                 "total population: {:,.0f}".format(len(in_urban),
                                                     total_hh_pop))
            if total_hh_pop == 0:
                raise RuntimeError(
                    "The population field '{}' sums to 0 for the household "
                    "points inside the urban area. Choose the field that "
                    "holds the number of people per household.".format(
                        pop_weight))
            pop_pts = 'household_points'
            timed("Household points preparation")
        elif p.get('pop_raster') is None:
            raise RuntimeError(
                "No population input: provide a gridded population raster or "
                "a household population points layer.")

        # ---- 1b. Pre-clip inputs to the urban area + search margin ---------
        buf_cache = {}

        def urban_buffer(dist):
            """Urban boundary buffered by `dist` metres (cached)."""
            dist = float(dist)
            if dist not in buf_cache:
                buf_cache[dist] = processing.run("native:buffer", {
                    'INPUT': urban_r, 'DISTANCE': dist, 'SEGMENTS': 8,
                    'END_CAP_STYLE': 0, 'JOIN_STYLE': 0, 'MITER_LIMIT': 2,
                    'DISSOLVE': True,
                    'OUTPUT': tmp("_tmp_urban_buf_{}".format(int(dist)))
                })['OUTPUT']
            return buf_cache[dist]

        def prefilter(layer, dist, name, clip=False):
            """Keep only features of `layer` within `dist` m of the urban
            boundary. Done on the ORIGINAL layer, before reprojection, so
            country-wide inputs are cut down immediately."""
            if layer is None or not preclip:
                return layer
            n_before = layer.featureCount()
            zone = urban_buffer(dist)
            if clip:
                res = processing.run("native:clip", {
                    'INPUT': layer, 'OVERLAY': zone,
                    'OUTPUT': tmp("_tmp_preclip_" + name)
                }, context=ctx_nocheck)['OUTPUT']
            else:
                res = processing.run("native:extractbylocation", {
                    'INPUT': layer, 'PREDICATE': [0], 'INTERSECT': zone,
                    'OUTPUT': tmp("_tmp_preclip_" + name)
                }, context=ctx_nocheck)['OUTPUT']
            tick("  {}: {:,} -> {:,} features (within {:,.0f} m of urban "
                 "area)".format(name, n_before, fcount(res), dist))
            return res

        pos_in = p['pos_layer']
        bus_in = p['bus_layer']
        ferry_in = p['ferry_layer']
        rail_in = p['rail_layer']
        road_in = p['road_layer']

        if preclip:
            tick("\n=== STEP 1b: Pre-clipping inputs to urban area + search "
                 "margin ===")
            active = []
            if pos_in:
                active.append(p['dist_pos'])
            if bus_in:
                active.append(p['dist_bus'])
            if ferry_in:
                active.append(p['dist_ferry'])
            if rail_in:
                active.append(p['dist_rail'])
            # A stop up to D outside the boundary can route along streets
            # up to D further out, so 2 x D (+ safety) keeps every route
            # that can reach the urban area.
            road_margin = (2 * max(active) + 500) if active else 100
            road_in = prefilter(road_in, road_margin, 'roads', clip=True)
            pos_in = prefilter(pos_in, p['dist_pos'], 'open_spaces')
            bus_in = prefilter(bus_in, p['dist_bus'], 'bus_stops')
            ferry_in = prefilter(ferry_in, p['dist_ferry'], 'ferry_stops')
            rail_in = prefilter(rail_in, p['dist_rail'], 'rail_stops')
            timed("Pre-clip")

            def empty_to_none(src, label):
                if src is not None and fcount(src) == 0:
                    tick("  {}: no features near the urban area - "
                         "treated as not provided.".format(label))
                    return None
                return src
            pos_in = empty_to_none(pos_in, 'Open Public Spaces')
            bus_in = empty_to_none(bus_in, 'Low Capacity Transport Stops')
            ferry_in = empty_to_none(ferry_in, 'Ferry stops')
            rail_in = empty_to_none(rail_in, 'Rail stops')
            if fcount(road_in) == 0:
                raise RuntimeError(
                    "No streets found within the urban area. Check that "
                    "the Streets and Urban Boundary layers overlap.")
        else:
            tick("\n  Pre-clipping disabled - using full input layers.")

        # ---- 1c. Reproject + fix remaining layers ---------------------------
        tick("\n=== STEP 1c: Reprojecting and fixing geometries ===")
        road_r = reproject_and_fix(road_in, 'road_network')
        pos_r = reproject_and_fix(pos_in, 'pos_polygon') if pos_in else None
        bus_r = reproject_and_fix(bus_in, 'bus_stops') if bus_in else None
        ferry_r = reproject_and_fix(
            ferry_in, 'ferry_stops') if ferry_in else None
        rail_r = reproject_and_fix(rail_in, 'rail_stops') if rail_in else None
        timed("Reproject + fix")

        # ---- 2. Open Public Spaces area: clip to urban boundary first ------
        if pos_r:
            tick("  Clipping Open Public Spaces to urban boundary for area "
                 "measurement...")
            pos_area_clipped = processing.run("native:clip", {
                'INPUT': pos_r, 'OVERLAY': urban_r,
                'OUTPUT': tmp("_tmp_pos_clipped_area")
            })['OUTPUT']
            pos_area_km2 = layer_area_km2(pos_area_clipped)
            tick(
                "  Open Public Spaces area (clipped to urban): {:.2f} km2".format(
                    pos_area_km2 or 0))
        else:
            pos_area_km2 = None

        # ---- 3. Open Public Spaces: polygon -> points ----------------------
        pos_pts = None
        if pos_r:
            tick("\n=== STEP 3: Open Public Spaces - Points along geometry "
                 "({:g}m) ===".format(pos_spacing))
            pos_pts_raw = processing.run("native:pointsalonglines", {
                'INPUT': pos_r, 'DISTANCE': pos_spacing,
                'START_OFFSET': 0, 'END_OFFSET': 0,
                'OUTPUT': tmp("_tmp_pos_pts_along_geom")
            })['OUTPUT']
            n_raw = fcount(pos_pts_raw)
            pos_pts = processing.run("native:deleteduplicategeometries", {
                'INPUT': pos_pts_raw,
                'OUTPUT': tmp("_tmp_pos_pts_dedup")
            })['OUTPUT']
            tick("  {:,} points ({:,} duplicates removed).".format(
                fcount(pos_pts), n_raw - fcount(pos_pts)))
        else:
            tick("\n  Open Public Spaces layer not provided - skipping.")

        # ---- 4-6. Pipeline per transport type ------------------------------
        def locate_on_network(stops, label):
            """Keep only start points within SEARCH_TOLERANCE_M of a street
            (ArcGIS 'Add Locations' search tolerance)."""
            net = get_network()
            src = as_layer(stops)
            out = QgsMemoryProviderUtils.createMemoryLayer(
                'located_' + label, src.fields(), src.wkbType(), src.crs())
            keep, n_far, n_all = [], 0, 0
            for f in src.getFeatures():
                g = f.geometry()
                if g is None or g.isEmpty():
                    continue
                n_all += 1
                pts = g.asMultiPoint() if g.isMultipart() else [g.asPoint()]
                near = False
                for pt in pts:
                    s_ = net.snap(pt.x(), pt.y())
                    if s_ is not None and s_[0] <= SEARCH_TOLERANCE_M:
                        near = True
                        break
                if near:
                    keep.append(QgsFeature(f))
                else:
                    n_far += 1
            out.dataProvider().addFeatures(keep)
            out.updateExtents()
            if n_far:
                tick("  [{}] {:,} of {:,} start points are more than {:g} m "
                     "from any street - not located on the network, no "
                     "service area (as ArcGIS search tolerance).".format(
                         label, n_far, n_all, SEARCH_TOLERANCE_M))
            return out if keep else None

        def process_transport(road, stops, dist_m, label):
            if stops is None:
                tick("  [{}] Not provided - skipping.".format(label))
                return None, None
            stops = locate_on_network(stops, label)
            if stops is None:
                tick("  [{}] WARNING: no start point within {:g} m of a "
                     "street - skipping.".format(label, SEARCH_TOLERANCE_M))
                return None, None

            tick("\n--- {} ({}m, {:,} start points) ---".format(
                label, dist_m, fcount(stops)))

            if use_native_sa:
                tick("  [{}] Service Area -> lines (QGIS native)...".format(
                    label))
                sa_lines = processing.run("native:serviceareafromlayer", {
                    'INPUT': road, 'START_POINTS': stops,
                    'STRATEGY': 0, 'TRAVEL_COST2': dist_m,
                    'INCLUDE_BOUNDS': False,
                    'OUTPUT_LINES': tmp("_tmp_sa_lines_" + label),
                    'OUTPUT': 'TEMPORARY_OUTPUT'
                })['OUTPUT_LINES']

                tick("  [{}] Convex Hull -> polygon...".format(label))
                hull = processing.run("native:convexhull", {
                    'INPUT': sa_lines,
                    'OUTPUT': tmp("_tmp_convexhull_" + label)
                })['OUTPUT']
            else:
                tick("  [{}] Service Area + Convex Hull (fast bounded "
                     "search)...".format(label))
                hull = get_network().hull_layer(
                    as_layer(stops), dist_m, crs, label)
                tick("  [{}] {:,} service area polygons.".format(
                    label, hull.featureCount()))
                if hull.featureCount() == 0:
                    tick("  [{}] WARNING: no reachable street area - "
                         "skipping.".format(label))
                    return None, None

            if label in ('POS', 'Bus', 'Ferry', 'Rail'):
                # Keep the individual (per-stop) service areas.
                ind_path = shp(FN('sa_individual', label))
                processing.run("native:savefeatures", {
                    'INPUT': hull, 'OUTPUT': ind_path
                })
                track(ind_path, keep=True)
                tick("  [{}] Individual service areas saved: {}".format(
                    label, os.path.basename(ind_path)))

            tick("  [{}] Clip to urban boundary...".format(label))
            clipped_path = shp(FN('sa_clipped', label))
            clipped = processing.run("native:clip", {
                'INPUT': hull, 'OVERLAY': urban_r,
                'OUTPUT': clipped_path
            })['OUTPUT']
            track(clipped_path, keep=True)
            tick("  [{}] Clipped service areas saved: {}".format(
                label, os.path.basename(clipped_path)))

            tick("  [{}] Dissolve...".format(label))
            dissolved_path = shp(FN('sa_dissolved', label))
            dissolved = processing.run("native:dissolve", {
                'INPUT': clipped, 'FIELD': [],
                'SEPARATE_DISJOINT': False, 'OUTPUT': dissolved_path
            })['OUTPUT']
            track(dissolved_path, keep=True)
            timed(label + " service area")

            return dissolved_path, dissolved

        use_native_sa = p.get('native_sa', False)
        net_cache = []

        def get_network():
            """Street graph built once, shared by all modes."""
            if not net_cache:
                tick("  Building street network graph (once)...")
                net_cache.append(FastServiceArea(
                    as_layer(road_r), log=lambda m: tick(m, 0),
                    cancelled=lambda: self._cancelled))
            return net_cache[0]

        pos_dp, pos_d = process_transport(
            road_r, pos_pts, p['dist_pos'], 'POS')
        bus_dp, bus_d = process_transport(road_r, bus_r, p['dist_bus'], 'Bus')
        ferry_dp, ferry_d = process_transport(
            road_r, ferry_r, p['dist_ferry'], 'Ferry')
        rail_dp, rail_d = process_transport(
            road_r, rail_r, p['dist_rail'], 'Rail')

        # ---- 7. Population in catchments ------------------------------------
        if pop_pts is not None:
            tick("\n=== STEP 7: Population in catchments (household points, "
                 "sum of '{}' -> field 'pop_sum') ===".format(pop_weight))
        else:
            tick("\n=== STEP 7: Zonal Statistics (prefix='pop_' -> "
                 "field='pop_sum') ===")

        urban_clean = delete_all_fields(urban_r, "_tmp_urban_clean")
        urban_zs, urban_pop = run_zonal_stats(
            urban_clean, 'urban_boundary', keep=False)

        def zs_if_available(dissolved, label):
            if dissolved is None:
                return None, None
            dl = as_layer(dissolved)
            tick("  [{}] Population computed on {} (service areas clipped "
                 "to the urban boundary, then dissolved): {} feature(s), "
                 "{:.2f} km2.".format(
                     label, os.path.basename(str(dissolved)),
                     dl.featureCount(), layer_area_km2(dl) or 0))
            clean = delete_all_fields(dissolved, "_tmp_clean_" + label)
            return run_zonal_stats(clean, label)

        pos_zs, pos_pop = zs_if_available(pos_d, 'POS')
        bus_zs, bus_pop = zs_if_available(bus_d, 'Bus')
        ferry_zs, ferry_pop = zs_if_available(ferry_d, 'Ferry')
        rail_zs, rail_pop = zs_if_available(rail_d, 'Rail')

        def keep_copy(src, name):
            """Save a retained copy of a catchment layer under `name`.shp so
            every catchment file exists even when only one mode is given."""
            out = shp(name)
            processing.run("native:savefeatures", {
                'INPUT': src, 'OUTPUT': out
            })
            track(out, keep=True)
            tick("  Saved {}".format(os.path.basename(out)))
            return out

        # ---- 8. High-Capacity (Ferry + Rail) -------------------------------
        hc_pop = None
        hc_zs = None
        hc_clipped_path = None
        if ferry_dp and rail_dp:
            tick("\n=== STEP 8: High-Capacity Transport (Ferry + Rail) ===")
            merged_hc = processing.run("native:mergevectorlayers", {
                'LAYERS': [ferry_dp, rail_dp], 'CRS': crs_str,
                'OUTPUT': track(shp(FN('sa_merged', 'HighCap')), keep=True)
            })['OUTPUT']

            hc_diss = processing.run("native:dissolve", {
                'INPUT': merged_hc, 'FIELD': [],
                'SEPARATE_DISJOINT': False,
                'OUTPUT': track(shp(FN('sa_unclipped', 'HighCap')), keep=True)
            })['OUTPUT']

            hc_clipped_path = shp(FN('sa_dissolved', 'HighCap'))
            hc_clipped = processing.run("native:clip", {
                'INPUT': hc_diss, 'OVERLAY': urban_r, 'OUTPUT': hc_clipped_path
            })['OUTPUT']
            track(hc_clipped_path, keep=True)

            hc_clean = delete_all_fields(hc_clipped, "_tmp_clean_HighCap")
            hc_zs, hc_pop = run_zonal_stats(hc_clean, 'HighCap')
        elif ferry_dp:
            hc_zs, hc_pop = ferry_zs, ferry_pop
            hc_clipped_path = keep_copy(ferry_dp,
                                        FN('sa_dissolved', 'HighCap'))
        elif rail_dp:
            hc_zs, hc_pop = rail_zs, rail_pop
            hc_clipped_path = keep_copy(rail_dp,
                                        FN('sa_dissolved', 'HighCap'))
        else:
            tick("\n  No ferry or rail layers - skipping High-Capacity SA.")

        # ---- 9. Combined Transport (bus + ferry + rail; POS excluded) ------
        comb_pop = None
        comb_zs = None
        transport_dp = [dp for dp in [bus_dp, ferry_dp, rail_dp] if dp]
        if len(transport_dp) >= 2:
            tick("\n=== STEP 9: Combined Transport SA ({} modes) ===".format(
                len(transport_dp)))
            merged_all = processing.run("native:mergevectorlayers", {
                'LAYERS': transport_dp, 'CRS': crs_str,
                'OUTPUT': track(shp(FN('sa_merged', 'Combined')), keep=True)
            })['OUTPUT']

            comb_diss = processing.run("native:dissolve", {
                'INPUT': merged_all, 'FIELD': [],
                'SEPARATE_DISJOINT': False,
                'OUTPUT': track(shp(FN('sa_unclipped', 'Combined')), keep=True)
            })['OUTPUT']

            comb_clipped_path = shp(FN('sa_dissolved', 'Combined'))
            comb_clipped = processing.run("native:clip", {
                'INPUT': comb_diss, 'OVERLAY': urban_r, 'OUTPUT': comb_clipped_path
            })['OUTPUT']
            track(comb_clipped_path, keep=True)

            comb_clean = delete_all_fields(comb_clipped, "_tmp_clean_Combined")
            comb_zs, comb_pop = run_zonal_stats(comb_clean, 'Combined')
        elif bus_dp:
            tick("\n  No high-capacity layers - combined transport = bus only.")
            comb_zs, comb_pop = bus_zs, bus_pop
            keep_copy(bus_dp, FN('sa_dissolved', 'Combined'))
        elif ferry_dp or rail_dp:
            tick("\n  No bus layer - combined transport = high-capacity only.")
            comb_zs, comb_pop = hc_zs, hc_pop
            keep_copy(hc_clipped_path, FN('sa_dissolved', 'Combined'))
        else:
            tick("\n  No transport mode layers available - skipping Combined SA.")
        timed("Zonal statistics")

        # ---- 10. Roads: clip -> R_Length -> export CSV ---------------------
        tick("\n=== STEP 10: Roads - clip, R_Length, export CSV ===")

        tick("  Clipping roads to urban boundary...")
        roads_clipped = processing.run("native:clip", {
            'INPUT': road_r, 'OVERLAY': urban_r,
            'OUTPUT': tmp("_tmp_roads_clipped")
        })['OUTPUT']

        tick("  Adding R_Length field...")
        roads_len = processing.run("native:fieldcalculator", {
            'INPUT': roads_clipped,
            'FIELD_NAME': 'R_Length',
            'FIELD_TYPE': 0,
            'FIELD_LENGTH': 20,
            'FIELD_PRECISION': 3,
            'FORMULA': '$length',
            'OUTPUT': tmp("_tmp_roads_with_length")
        })['OUTPUT']

        tick("  Checking for Shape_Length / Shape_Leng fields...")
        fnames = [f.name() for f in as_layer(roads_len).fields()]
        fields_to_drop = [
            fn for fn in fnames if fn in (
                'Shape_Length', 'Shape_Leng')]
        if fields_to_drop:
            tick("  Deleting fields: {}...".format(', '.join(fields_to_drop)))
            roads_final = processing.run("native:deletecolumn", {
                'INPUT': roads_len,
                'COLUMN': fields_to_drop,
                'OUTPUT': tmp("_tmp_roads_clean")
            })['OUTPUT']
        else:
            roads_final = roads_len
            tick("  Shape_Length / Shape_Leng not found - skipping.")

        # ---- 10b. Land Allocated to Streets (LAS) --------------------------
        las_km2, roads_final, las_path = self._compute_las(
            roads_final, urban_r, shp, track, tick, layer_area_km2,
            tmp, as_layer, FN('las'))
        timed("Roads + LAS")

        # ---- 11. Statistics workbook (Excel only) -------------------------
        tick("\n=== STEP 11: Writing the statistics workbook (Excel) ===")
        xlsx_path = os.path.join(out_dir, FN('stats') + '.xlsx')
        if pop_pts is not None:
            pop_source = "{} ({}, {} '{}')".format(
                L('src_household'), p['pop_points'].name(), L('src_field'),
                p.get('pop_field'))
        else:
            pop_source = "{} ({})".format(L('src_raster'),
                                          p['pop_raster'].name())
        written, err = self._write_stats(
            xlsx_path, city_label, urban_area_km2, pos_area_km2, las_km2,
            urban_pop, pos_pop, bus_pop, hc_pop, comb_pop, pop_source, lang,
            as_layer(roads_final), tick)
        if not written:
            raise RuntimeError("Statistics workbook could not be written: "
                               "{}".format(err))
        xlsx_path = written
        tick("  Statistics workbook: {}".format(xlsx_path))

        # ---- 12. Clean up --------------------------------------------------
        tick("\n=== STEP 12: Removing intermediate files ===")
        deleted = 0
        not_removed = []
        for base in all_files:
            if base in keep_files:
                continue
            stem = os.path.splitext(base)[0]
            for ext in ['.shp', '.shx', '.dbf', '.prj', '.cpg',
                        '.qpj', '.qix', '.sbn', '.sbx', '.fix']:
                f = stem + ext
                if os.path.exists(f):
                    try:
                        os.remove(f)
                        deleted += 1
                    except OSError as err:
                        # File may still be locked by QGIS; report it and
                        # carry on - leftover temp files do not affect results.
                        not_removed.append((f, err))
        tick("  Removed {} file components.".format(deleted))
        if not_removed:
            tick("  WARNING: {} intermediate file(s) could not be removed "
                 "(probably locked) - delete them manually:".format(
                     len(not_removed)))
            for f, err in not_removed[:10]:
                tick("    {} ({})".format(os.path.basename(f), err), 0)

        # ---- 13. Load final layers into QGIS -------------------------------
        tick("\n=== STEP 13: Loading results into QGIS ===")
        to_load = [
            (pos_zs, 'SDG 11.7.1'), (bus_zs, 'SDG 11.2.1'),
            (ferry_zs, 'SDG 11.2.1'), (rail_zs, 'SDG 11.2.1'),
            (hc_zs, 'SDG 11.2.1'), (comb_zs, 'SDG 11.2.1'),
            (las_path, ''),
        ]
        loaded = set()
        for path, prefix in to_load:
            if path is None or path in loaded:
                continue
            loaded.add(path)
            stem = os.path.splitext(os.path.basename(path))[0]
            name = '{} - {}'.format(prefix, stem) if prefix else stem
            lyr = QgsVectorLayer(path, name, 'ogr')
            if lyr.isValid():
                QgsProject.instance().addMapLayer(lyr)
                tick("  Loaded: {}".format(name))
            else:
                tick("  WARNING: could not load {}".format(name))

        tick("\nTotal processing time: {:.1f} s".format(
            time.time() - t_start), 0)
        self.progress.emit(100)
        self.finished.emit(
            True, "{}\n{}: {:.4f} km2\n{}: {}\n{}: {}\n{}: {:.1f} s".format(
                L('res_done'), L('res_las'), las_km2 or 0.0,
                L('res_excel'), xlsx_path,
                L('res_folder'), out_dir, L('res_time'),
                time.time() - t_start))

    # -----------------------------------------------------------------------
    def _compute_las(self, roads_clipped, urban_r, shp, track, tick,
                     layer_area_km2, tmp, as_layer,
                     las_name='LAS_streets_dissolved'):
        """
        Land Allocated to Streets (LAS).

        1. Join road widths to the clipped roads using the first road
           category field found (fclass -> highway -> type) against
           column 1 of the measured road widths CSV.
        2. Categories without a measured width fall back to the default
           widths (residential 7 m, motorway 21 m, primary 15 m,
           secondary 12 m, tertiary 9 m).
        3. Buffer each road by its width (half-width either side of the
           centre line, so the buffer polygon is exactly one road width
           wide), dissolve, clip to the urban extent and measure area.
           For speed, roads are first merged by width so only one buffer
           per width class is built; the result is the same as buffering
           every segment individually and dissolving.

        Returns (las_km2, roads_layer_for_csv_export, las_shapefile_or_None).
        If no width CSV was supplied AND the roads have none of the category
        fields, LAS = 0.
        """
        p = self.params
        tick("\n=== STEP 10b: Land Allocated to Streets (LAS) ===")

        measured = p.get('road_widths') or {}
        csv_given = bool(p.get('road_widths_provided'))
        if csv_given:
            tick("  Measured road widths CSV: {} categories read.".format(
                len(measured)))
        else:
            tick("  No measured road widths CSV provided.")

        roads_lyr = as_layer(roads_clipped)
        field_map = {f.name().lower(): f.name() for f in roads_lyr.fields()}
        cat_field = None

        # 1. Field chosen by the user in the dialog. Shapefile intermediates
        #    truncate names to 10 characters, so also try the short form.
        chosen = (p.get('road_cat_field') or '').strip()
        if chosen:
            for key in (chosen.lower(), chosen.lower()[:10]):
                if key in field_map:
                    cat_field = field_map[key]
                    break
            if cat_field:
                tick("  Using selected road category field: '{}'".format(
                    chosen))
            else:
                tick("  WARNING: selected field '{}' not found on the "
                     "processed roads - trying fclass / highway / type."
                     .format(chosen))

        # 2. Default fields.
        if cat_field is None:
            for cand in ROAD_CATEGORY_FIELDS:
                if cand in field_map:
                    cat_field = field_map[cand]
                    break

        if cat_field is None:
            tick("  No road category field selected and roads have no "
                 "'fclass', 'highway' or 'type' field - widths cannot be "
                 "joined. Land Allocated to Streets = 0.")
            return 0.0, roads_clipped, None

        tick("  Join field on roads: '{}'".format(cat_field))

        # Lookup: measured widths take priority; defaults fill the gaps.
        lookup = {}
        source = {}
        for k, v in DEFAULT_ROAD_WIDTHS.items():
            lookup[k] = v
            source[k] = 'Default'
        for k, v in measured.items():
            lookup[k] = v
            source[k] = 'Measured'

        # Report what will be matched, so the user can audit the join.
        cats = {}
        req = QgsFeatureRequest().setFlags(QgsFeatureRequest.NoGeometry)
        req.setSubsetOfAttributes([cat_field], roads_lyr.fields())
        for feat in roads_lyr.getFeatures(req):
            val = feat[cat_field]
            if val is None or (hasattr(val, 'isNull') and val.isNull()):
                key = ''
            else:
                key = str(val).strip().lower()
            cats[key] = cats.get(key, 0) + 1
        matched = sorted(c for c in cats if c in lookup)
        unmatched = sorted(c for c in cats if c not in lookup)
        for c in matched:
            tick("    {:<22} {:>6} segments -> {:g} m ({})".format(
                c, cats[c], lookup[c], source[c]), 0)
        if unmatched:
            tick("    No width (excluded from LAS): {}".format(
                ', '.join('{} ({})'.format(c or '<empty>', cats[c])
                          for c in unmatched)), 0)

        if not matched:
            tick("  No road categories matched a width. LAS = 0.")
            return 0.0, roads_clipped, None

        def q(s):
            return "'" + s.replace("'", "''") + "'"

        key_expr = 'lower(trim(to_string("{}")))'.format(
            cat_field.replace('"', '""'))
        width_expr = 'CASE ' + ' '.join(
            'WHEN {} = {} THEN {}'.format(key_expr, q(k), float(w))
            for k, w in lookup.items()) + ' ELSE NULL END'
        src_expr = 'CASE ' + ' '.join(
            'WHEN {} = {} THEN {}'.format(key_expr, q(k), q(source[k]))
            for k in lookup) + " ELSE 'None' END"

        tick("  Attribute join: adding R_Width (m)...")
        roads_w = processing.run("native:fieldcalculator", {
            'INPUT': roads_clipped,
            'FIELD_NAME': 'R_Width',
            'FIELD_TYPE': 0,
            'FIELD_LENGTH': 10,
            'FIELD_PRECISION': 2,
            'FORMULA': width_expr,
            'OUTPUT': tmp("_tmp_roads_with_width")
        })['OUTPUT']

        roads_ws = processing.run("native:fieldcalculator", {
            'INPUT': roads_w,
            'FIELD_NAME': 'W_Source',
            'FIELD_TYPE': 2,
            'FIELD_LENGTH': 10,
            'FIELD_PRECISION': 0,
            'FORMULA': src_expr,
            'OUTPUT': tmp("_tmp_roads_with_width_src")
        })['OUTPUT']

        tick("  Selecting roads with a width...")
        roads_sel = processing.run("native:extractbyexpression", {
            'INPUT': roads_ws,
            'EXPRESSION': '"R_Width" IS NOT NULL AND "R_Width" > 0',
            'OUTPUT': tmp("_tmp_roads_width_only")
        })['OUTPUT']

        tick("  Merging road centre lines by width class...")
        roads_by_w = processing.run("native:dissolve", {
            'INPUT': roads_sel, 'FIELD': ['R_Width'],
            'SEPARATE_DISJOINT': False,
            'OUTPUT': tmp("_tmp_roads_by_width")
        })['OUTPUT']

        tick("  Buffering roads by R_Width (R_Width/2 each side)...")
        roads_buf = processing.run("native:buffer", {
            'INPUT': roads_by_w,
            'DISTANCE': QgsProperty.fromExpression('"R_Width" / 2.0'),
            'SEGMENTS': 5,
            'END_CAP_STYLE': 0,
            'JOIN_STYLE': 0,
            'MITER_LIMIT': 2,
            'DISSOLVE': False,
            'OUTPUT': tmp("_tmp_roads_buffer")
        })['OUTPUT']

        tick("  Dissolving buffered roads...")
        roads_diss = processing.run("native:dissolve", {
            'INPUT': roads_buf, 'FIELD': [],
            'SEPARATE_DISJOINT': False,
            'OUTPUT': tmp("_tmp_roads_buffer_dissolved")
        })['OUTPUT']

        tick("  Clipping dissolved road buffers to urban extent...")
        las_path = shp(las_name)
        processing.run("native:clip", {
            'INPUT': roads_diss, 'OVERLAY': urban_r, 'OUTPUT': las_path
        })
        track(las_path, keep=True)

        las_km2 = layer_area_km2(las_path) or 0.0
        tick("  LAS area: {:.4f} km2".format(las_km2))
        return las_km2, roads_ws, las_path

    # -----------------------------------------------------------------------
    def _write_stats(self, path, city_label, urban_area_km2, pos_area_km2,
                     las_km2, urban_pop, pos_pop, bus_pop, hc_pop, comb_pop,
                     pop_source, lang, roads_layer=None, tick=None):
        """
        Write the statistics as one Excel workbook (.xlsx) with:
          sheet 1 - the SDG statistics (headers in the selected language)
          sheet 2 - the clipped roads attribute table (lengths, widths)
        Numbers are stored as real numeric cells. Uses the GDAL/OGR XLSX
        driver shipped with QGIS. Returns (path, None) or (None, reason).
        """
        def num(v, d=2):
            return None if v is None else round(float(v), d)

        def pct_num(part, total, d=2):
            if part is None or total is None or float(total) == 0:
                return None
            return round(float(part) / float(total) * 100, d)

        las_val = float(las_km2 or 0.0)
        ops_las = float(pos_area_km2 or 0.0) + las_val
        header_keys = [
            'h_city', 'h_urban_area', 'h_pos_area', 'h_las', 'h_ops_las',
            'h_prop_ops_las', 'h_total_pop', 'h_pop_pos', 'h_pop_bus',
            'h_pop_hc', 'h_pop_comb', 'h_pct_pos', 'h_pct_bus', 'h_pct_hc',
            'h_pct_comb', 'h_pop_source',
        ]
        headers = [i18n_tr(k, lang) for k in header_keys]
        values = [
            city_label, num(urban_area_km2), num(pos_area_km2),
            num(las_val, 4), num(ops_las, 4), pct_num(ops_las, urban_area_km2),
            num(urban_pop), num(pos_pop), num(bus_pop), num(hc_pop),
            num(comb_pop), pct_num(pos_pop, urban_pop),
            pct_num(bus_pop, urban_pop), pct_num(hc_pop, urban_pop),
            pct_num(comb_pop, urban_pop), pop_source,
        ]

        try:
            from osgeo import ogr
        except ImportError as err:
            return None, str(err)
        drv = ogr.GetDriverByName('XLSX')
        if drv is None:
            return None, 'GDAL XLSX driver not available'
        if os.path.exists(path):
            try:
                os.remove(path)
            except OSError as err:
                return None, 'cannot overwrite {} - is it open in Excel? ' \
                             '({})'.format(os.path.basename(path), err)
        ds = drv.CreateDataSource(path)
        if ds is None:
            return None, 'cannot create {}'.format(os.path.basename(path))

        # Sheet 1: statistics
        lyr = ds.CreateLayer(sheet_tr(lang, 'sheet_stats'),
                             geom_type=ogr.wkbNone)
        for h, v in zip(headers, values):
            ftype = ogr.OFTString if isinstance(v, str) else ogr.OFTReal
            lyr.CreateField(ogr.FieldDefn(h, ftype))
        feat = ogr.Feature(lyr.GetLayerDefn())
        for i, v in enumerate(values):
            if v is None:
                feat.SetFieldNull(i)
            else:
                feat.SetField(i, v)
        lyr.CreateFeature(feat)
        feat = None

        # Sheet 2: clipped roads attribute table (no geometry column)
        if roads_layer is not None and roads_layer.isValid():
            n = roads_layer.featureCount()
            if n > 1048575:
                if tick:
                    tick("  NOTE: {:,} roads exceed the Excel row limit - "
                         "roads sheet not written.".format(n))
            else:
                rl = ds.CreateLayer(sheet_tr(lang, 'sheet_roads'),
                                    geom_type=ogr.wkbNone)
                flds = roads_layer.fields()
                for f in flds:
                    if f.isNumeric():
                        ftype = ogr.OFTInteger64 if f.type() in (2, 3, 4, 5) \
                            else ogr.OFTReal
                    else:
                        ftype = ogr.OFTString
                    rl.CreateField(ogr.FieldDefn(f.name(), ftype))
                defn = rl.GetLayerDefn()
                req = QgsFeatureRequest().setFlags(QgsFeatureRequest.NoGeometry)
                for qf in roads_layer.getFeatures(req):
                    of = ogr.Feature(defn)
                    for i, v in enumerate(qf.attributes()):
                        if v is None or (hasattr(v, 'isNull') and v.isNull()):
                            continue
                        if defn.GetFieldDefn(i).GetType() == ogr.OFTString:
                            of.SetField(i, str(v))
                        else:
                            try:
                                of.SetField(i, float(v) if defn.GetFieldDefn(
                                    i).GetType() == ogr.OFTReal else int(v))
                            except (TypeError, ValueError):
                                continue
                    rl.CreateFeature(of)
                    of = None
        ds = None          # flush and close the workbook
        return path, None


# ---------------------------------------------------------------------------
# Dialog
# ---------------------------------------------------------------------------
class TransportSADialog(QDialog):

    def __init__(self, iface, parent=None):
        super(TransportSADialog, self).__init__(parent or iface.mainWindow())
        self.iface = iface
        self.worker = None
        self.lang = default_language()
        self._i18n = []          # (key, setter) pairs re-applied on switch
        self._t('win_title', self.setWindowTitle)
        # Small minimum so the dialog can be dragged down to fit any space;
        # every panel scrolls when there is not enough room.
        self.setMinimumSize(420, 360)
        self.setSizeGripEnabled(True)
        self.setWindowFlags(self.windowFlags()
                            | Qt.WindowMinMaxButtonsHint
                            | Qt.WindowCloseButtonHint)
        self._build_ui()
        self._apply_direction()
        # Never narrower than the button row needs.
        self.setMinimumWidth(max(420, self.layout().minimumSize().width()))
        self._fit_to_screen()

    # ---- language handling -------------------------------------------------
    def T(self, key):
        """Text for `key` in the current interface language."""
        return i18n_tr(key, self.lang)

    def _t(self, key, setter):
        """Set a translatable text now and re-apply it on language change."""
        setter(self.T(key))
        self._i18n.append((key, setter))

    def _on_language_changed(self, index):
        code = self.lang_combo.itemData(index)
        if not code or code == self.lang:
            return
        self.lang = code
        save_language(code)
        for key, setter in self._i18n:
            setter(self.T(key))
        self._apply_direction()
        for b in self._buttons:
            b.setMinimumWidth(0)
            b.setMinimumWidth(b.sizeHint().width())
        self.setMinimumWidth(max(420, self.layout().minimumSize().width()))

    def _apply_direction(self):
        """Right-to-left layout for Arabic; the log stays left-to-right
        because it shows file paths and processing messages."""
        rtl = self.lang in RTL_LANGUAGES
        self.setLayoutDirection(Qt.RightToLeft if rtl else Qt.LeftToRight)
        self.log_box.setLayoutDirection(Qt.LeftToRight)
        self.output_edit.setLayoutDirection(Qt.LeftToRight)

    def _fit_to_screen(self):
        """Open at a comfortable size that never exceeds the screen."""
        from qgis.PyQt.QtWidgets import QApplication
        w, h = 700, 820
        # QWidget.screen() exists from Qt 5.14; older Qt uses primaryScreen.
        scr = self.screen() if hasattr(self, 'screen') else None
        if scr is None:
            scr = QApplication.primaryScreen()
        if scr is not None:
            geo = scr.availableGeometry()
            w = min(w, int(geo.width() * 0.9))
            h = min(h, int(geo.height() * 0.85))
        self.resize(max(w, 420), max(h, 360))
        # Settings tabs get ~65% of the space, progress log ~35%.
        self.splitter.setSizes([650, 350])

    @staticmethod
    def _scrollable(widget):
        scroll = QScrollArea()
        scroll.setWidget(widget)
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QScrollArea.NoFrame)
        return scroll

    def _build_ui(self):
        root = QVBoxLayout(self)
        root.setSpacing(8)

        lang_row = QHBoxLayout()
        lang_row.addStretch()
        lang_lbl = QLabel()
        self._t('language', lang_lbl.setText)
        self.lang_combo = QComboBox()
        for code, name in LANGUAGES:
            self.lang_combo.addItem(name, code)
        self.lang_combo.setCurrentIndex(
            max(0, self.lang_combo.findData(self.lang)))
        self.lang_combo.currentIndexChanged.connect(self._on_language_changed)
        lang_row.addWidget(lang_lbl)
        lang_row.addWidget(self.lang_combo)
        root.addLayout(lang_row)

        title = QLabel()
        self._t('win_title', title.setText)
        title.setAlignment(Qt.AlignCenter)
        title.setWordWrap(True)
        f = QFont()
        f.setBold(True)
        f.setPointSize(12)
        title.setFont(f)
        root.addWidget(title)

        sub = QLabel()
        self._t('subtitle', lambda t, w=sub: w.setText(
            t + "   |   v" + PLUGIN_VERSION))
        sub.setAlignment(Qt.AlignCenter)
        sub.setStyleSheet("color:#555;font-size:9px;")
        sub.setWordWrap(True)
        root.addWidget(sub)

        tabs = QTabWidget()
        tabs.addTab(self._tab_layers(), "")
        tabs.addTab(self._scrollable(self._tab_distances()), "")
        tabs.addTab(self._scrollable(self._tab_output()), "")
        for i, key in enumerate(('tab_layers', 'tab_distances', 'tab_output')):
            self._t(key, lambda t, i=i, w=tabs: w.setTabText(i, t))
        tabs.setMinimumHeight(90)

        pg_box = QGroupBox()
        self._t('progress', pg_box.setTitle)
        pg_lay = QVBoxLayout(pg_box)
        pg_lay.setContentsMargins(6, 6, 6, 6)
        self.progress_bar = QProgressBar()
        self.progress_bar.setRange(0, 100)
        pg_lay.addWidget(self.progress_bar)
        self.log_box = QTextEdit()
        self.log_box.setReadOnly(True)
        self.log_box.setMinimumHeight(40)
        self.log_box.setFont(QFont("Courier New", 9))
        pg_lay.addWidget(self.log_box)
        pg_box.setMinimumHeight(80)

        # Drag the handle between the settings tabs and the progress log
        # to give either one more room.
        self.splitter = QSplitter(Qt.Vertical)
        self.splitter.addWidget(tabs)
        self.splitter.addWidget(pg_box)
        self.splitter.setChildrenCollapsible(False)
        self.splitter.setHandleWidth(8)
        self.splitter.setStyleSheet(
            "QSplitter::handle{background:#e0e0e0;border-radius:3px;}"
            "QSplitter::handle:hover{background:#90caf9;}")
        self.splitter.setStretchFactor(0, 3)
        self.splitter.setStretchFactor(1, 1)
        root.addWidget(self.splitter, 1)

        btn_row = QHBoxLayout()
        self.run_btn = QPushButton()
        self._t('btn_run', self.run_btn.setText)
        self.run_btn.setStyleSheet(
            "QPushButton{background:#2196F3;color:white;font-weight:bold;"
            "padding:6px 12px;border-radius:4px}"
            "QPushButton:hover{background:#1976D2}"
            "QPushButton:disabled{background:#999}")
        self.run_btn.clicked.connect(self.run_analysis)

        self.cancel_btn = QPushButton()
        self._t('btn_cancel', self.cancel_btn.setText)
        self.cancel_btn.setEnabled(False)
        self.cancel_btn.setStyleSheet(
            "QPushButton{background:#f44336;color:white;font-weight:bold;"
            "padding:6px 12px;border-radius:4px}"
            "QPushButton:disabled{background:#999}")
        self.cancel_btn.clicked.connect(self.cancel_analysis)

        self.reset_btn = QPushButton()
        self._t('btn_reset', self.reset_btn.setText)
        self.reset_btn.setStyleSheet(
            "QPushButton{background:#607D8B;color:white;font-weight:bold;"
            "padding:6px 12px;border-radius:4px}"
            "QPushButton:hover{background:#455A64}")
        self.reset_btn.clicked.connect(self._reset_state)

        close_btn = QPushButton()
        self._t('btn_close', close_btn.setText)
        close_btn.clicked.connect(self.close)
        btn_row.addWidget(self.run_btn)
        btn_row.addWidget(self.cancel_btn)
        btn_row.addWidget(self.reset_btn)
        btn_row.addStretch()
        btn_row.addWidget(close_btn)
        self._buttons = (self.run_btn, self.cancel_btn, self.reset_btn,
                         close_btn)
        for b in self._buttons:
            b.setMinimumWidth(b.sizeHint().width())
        root.addLayout(btn_row)

    # -----------------------------------------------------------------------
    def _reset_state(self):
        """Clear log, reset progress bar and button states."""
        # If a worker is still running, don't reset
        if self.worker and self.worker.isRunning():
            QMessageBox.warning(
                self,
                self.T('msg_running_title'),
                self.T('msg_cannot_reset'))
            return
        self.log_box.clear()
        self.progress_bar.setValue(0)
        self.run_btn.setEnabled(True)
        self.cancel_btn.setEnabled(False)
        self.worker = None

    def showEvent(self, event):
        """Auto-reset when the dialog is shown after being hidden/closed."""
        super().showEvent(event)
        # Only reset if no worker is actively running
        if not (self.worker and self.worker.isRunning()):
            self._reset_state()

    # -----------------------------------------------------------------------
    def _tab_layers(self):
        w = QWidget()
        lay = QVBoxLayout(w)
        lay.setSpacing(4)

        def add_combo(label, note, attr, ftype, required=True):
            grp = QGroupBox()
            self._t(label, lambda t, g=grp, r=required: g.setTitle(
                t + " *" if r else t))
            grp.setStyleSheet(
                "QGroupBox{font-weight:bold;font-size:11px;color:#212121;}")
            g_lay = QVBoxLayout(grp)
            if note:
                lbl = QLabel()
                self._t(note, lbl.setText)
                lbl.setStyleSheet(
                    "color:#555;font-size:9px;font-weight:normal;")
                lbl.setWordWrap(True)
                g_lay.addWidget(lbl)
            combo = QgsMapLayerComboBox()
            combo.setFilters(ftype)
            combo.setAllowEmptyLayer(not required)
            if not required:
                combo.setCurrentIndex(0)
            setattr(self, attr, combo)
            g_lay.addWidget(combo)
            lay.addWidget(grp)
            return g_lay

        add_combo('grp_streets', 'note_streets',
                  'combo_road', QgsMapLayerProxyModel.LineLayer, required=True)

        add_combo(
            'grp_urban', 'note_urban',
            'combo_urban',
            QgsMapLayerProxyModel.PolygonLayer,
            required=True)

        add_combo(
            'grp_pop_raster', 'note_pop_raster',
            'combo_pop',
            QgsMapLayerProxyModel.RasterLayer,
            required=False)

        g_hh = add_combo(
            'grp_hh', 'note_hh',
            'combo_hh',
            QgsMapLayerProxyModel.PointLayer,
            required=False)
        lbl_pf = QLabel()
        lbl_pf.setWordWrap(True)
        self._t('lbl_pop_field', lbl_pf.setText)
        lbl_pf.setStyleSheet("color:#212121;font-size:10px;"
                             "font-weight:normal;margin-top:4px;")
        g_hh.addWidget(lbl_pf)
        self.combo_pop_field = QgsFieldComboBox()
        self.combo_pop_field.setFilters(
            QgsFieldProxyModel.Numeric | QgsFieldProxyModel.String)
        self.combo_pop_field.setAllowEmptyFieldName(True)
        g_hh.addWidget(self.combo_pop_field)
        self.combo_hh.layerChanged.connect(self._on_hh_layer_changed)
        self._on_hh_layer_changed(self.combo_hh.currentLayer())

        add_combo(
            'grp_pos', 'note_pos',
            'combo_pos',
            QgsMapLayerProxyModel.PolygonLayer,
            required=False)

        add_combo(
            'grp_bus', 'note_bus',
            'combo_bus',
            QgsMapLayerProxyModel.PointLayer,
            required=False)

        add_combo(
            'grp_rail', 'note_rail',
            'combo_rail',
            QgsMapLayerProxyModel.PointLayer,
            required=False)

        add_combo(
            'grp_ferry', 'note_ferry',
            'combo_ferry',
            QgsMapLayerProxyModel.PointLayer,
            required=False)

        # ---- Measured road widths (CSV) for LAS ----------------------------
        grp_w = QGroupBox()
        self._t('grp_widths', grp_w.setTitle)
        grp_w.setStyleSheet(
            "QGroupBox{font-weight:bold;font-size:11px;color:#212121;}")
        g_w = QVBoxLayout(grp_w)
        lbl_w = QLabel()
        self._t('note_widths', lbl_w.setText)
        lbl_w.setStyleSheet("color:#555;font-size:9px;font-weight:normal;")
        lbl_w.setWordWrap(True)
        g_w.addWidget(lbl_w)
        row_csv = QHBoxLayout()
        self.combo_widths = QgsMapLayerComboBox()
        self.combo_widths.setFilters(QgsMapLayerProxyModel.NoGeometry)
        self.combo_widths.setAllowEmptyLayer(True)
        self.combo_widths.setCurrentIndex(0)
        browse_csv = QPushButton()
        self._t('btn_browse_csv', browse_csv.setText)
        browse_csv.clicked.connect(self._browse_widths_csv)
        row_csv.addWidget(self.combo_widths, 1)
        row_csv.addWidget(browse_csv)
        g_w.addLayout(row_csv)
        lay.addWidget(grp_w)

        # ---- Road category field on the Streets layer ----------------------
        grp_f = QGroupBox()
        self._t('grp_catfield', grp_f.setTitle)
        grp_f.setStyleSheet(
            "QGroupBox{font-weight:bold;font-size:11px;color:#212121;}")
        g_f = QVBoxLayout(grp_f)
        lbl_f = QLabel()
        self._t('note_catfield', lbl_f.setText)
        lbl_f.setStyleSheet("color:#555;font-size:9px;font-weight:normal;")
        lbl_f.setWordWrap(True)
        g_f.addWidget(lbl_f)
        self.combo_cat_field = QgsFieldComboBox()
        self.combo_cat_field.setAllowEmptyFieldName(True)
        g_f.addWidget(self.combo_cat_field)
        lay.addWidget(grp_f)

        self.combo_road.layerChanged.connect(self._on_road_layer_changed)
        self._on_road_layer_changed(self.combo_road.currentLayer())

        grp_crs = QGroupBox()
        self._t('grp_crs', lambda t, g=grp_crs: g.setTitle(t + " *"))
        grp_crs.setStyleSheet("QGroupBox{font-weight:bold;font-size:11px;color:#212121;}")
        g_crs = QVBoxLayout(grp_crs)
        self.crs_widget = QgsProjectionSelectionWidget()
        self.crs_widget.setCrs(QgsCoordinateReferenceSystem("EPSG:32736"))
        g_crs.addWidget(self.crs_widget)
        lay.addWidget(grp_crs)

        lay.addStretch()
        scroll = QScrollArea()
        scroll.setWidget(w)
        scroll.setWidgetResizable(True)
        return scroll

    # -----------------------------------------------------------------------
    def _tab_distances(self):
        w = QWidget()
        lay = QGridLayout(w)
        lay.setSpacing(10)
        lay.setContentsMargins(16, 16, 16, 16)

        header_lbl = QLabel()
        self._t('dist_header', header_lbl.setText)
        header_lbl.setStyleSheet("color:#000000;font-weight:bold;font-size:12px;")
        lay.addWidget(header_lbl, 0, 0, 1, 2)

        configs = [
            ('dist_pos', 'spin_pos', 400),
            ('grp_bus', 'spin_bus', 500),
            ('grp_ferry', 'spin_ferry', 1000),
            ('grp_rail', 'spin_rail', 1000),
        ]
        for row, (lbl, attr, default) in enumerate(configs, start=1):
            spin = QDoubleSpinBox()
            spin.setRange(1, 50000)
            spin.setValue(default)
            spin.setSuffix(" m")
            spin.setDecimals(0)
            spin.setMinimumWidth(90)
            spin.setMaximumWidth(140)
            setattr(self, attr, spin)
            q = QLabel()
            q.setWordWrap(True)
            self._t(lbl, q.setText)
            lay.addWidget(q, row, 0)
            lay.addWidget(spin, row, 1)
        lay.setColumnStretch(0, 1)

        r = len(configs) + 1
        sp_lbl = QLabel()
        sp_lbl.setWordWrap(True)
        self._t('spacing_header', sp_lbl.setText)
        sp_lbl.setStyleSheet("color:#000000;font-weight:bold;font-size:12px;")
        lay.addWidget(sp_lbl, r, 0, 1, 2)
        self.spin_pos_spacing = QDoubleSpinBox()
        self.spin_pos_spacing.setRange(10, 1000)
        self.spin_pos_spacing.setValue(100)
        self.spin_pos_spacing.setSuffix(" m")
        self.spin_pos_spacing.setDecimals(0)
        self.spin_pos_spacing.setMinimumWidth(90)
        self.spin_pos_spacing.setMaximumWidth(140)
        sp_note = QLabel()
        self._t('spacing_note', sp_note.setText)
        sp_note.setWordWrap(True)
        sp_note.setStyleSheet("color:#555;font-size:9px;")
        lay.addWidget(sp_note, r + 1, 0)
        lay.addWidget(self.spin_pos_spacing, r + 1, 1)

        perf_lbl = QLabel()
        self._t('perf_header', perf_lbl.setText)
        perf_lbl.setStyleSheet("color:#000000;font-weight:bold;font-size:12px;")
        lay.addWidget(perf_lbl, r + 2, 0, 1, 2)
        def check(text, note, checked):
            box = QWidget()
            bl = QVBoxLayout(box)
            bl.setContentsMargins(0, 0, 0, 0)
            bl.setSpacing(1)
            cb = QCheckBox()
            self._t(text, cb.setText)
            cb.setChecked(checked)
            bl.addWidget(cb)
            nl = QLabel()
            self._t(note, nl.setText)
            nl.setWordWrap(True)
            nl.setStyleSheet("color:#555;font-size:9px;margin-left:20px;")
            bl.addWidget(nl)
            return cb, box

        self.chk_preclip, b1 = check('chk_preclip', 'note_preclip', True)
        self.chk_memory, b2 = check('chk_memory', 'note_memory', True)
        self.chk_native_sa, b3 = check('chk_native', 'note_native', False)
        for i, b in enumerate((b1, b2, b3)):
            lay.addWidget(b, r + 3 + i, 0, 1, 2)

        lay.setRowStretch(r + 6, 1)
        return w

    # -----------------------------------------------------------------------
    def _tab_output(self):
        w = QWidget()
        lay = QVBoxLayout(w)
        lay.setSpacing(10)
        lay.setContentsMargins(16, 16, 16, 16)

        grp_city = QGroupBox()
        self._t('grp_city', grp_city.setTitle)
        g_city = QVBoxLayout(grp_city)
        self.city_edit = QLineEdit()
        self._t('city_placeholder', self.city_edit.setPlaceholderText)
        g_city.addWidget(self.city_edit)
        lay.addWidget(grp_city)

        out_lbl = QLabel()
        self._t('lbl_output_folder', out_lbl.setText)
        lay.addWidget(out_lbl)
        row_w = QHBoxLayout()
        self.output_edit = QLineEdit()
        self.output_edit.setText(os.path.expanduser("~/transport_sa_output"))
        browse_btn = QPushButton()
        self._t('btn_browse', browse_btn.setText)
        browse_btn.clicked.connect(self._browse_output)
        row_w.addWidget(self.output_edit)
        row_w.addWidget(browse_btn)
        lay.addLayout(row_w)

        info = QLabel()
        self._t('info_block', lambda t: info.setText(
            translate_info_file_list(t, self.lang)))
        info.setTextInteractionFlags(Qt.TextSelectableByMouse)
        info.setStyleSheet(
            "background:#f5f5f5;border:1px solid #ddd;padding:10px;"
            "font-family:Courier New;font-size:9px;border-radius:4px;"
        )
        lay.addWidget(info)
        lay.addStretch()
        return w

    # -----------------------------------------------------------------------
    def _browse_output(self):
        folder = QFileDialog.getExistingDirectory(
            self, self.T('dlg_select_output'), self.output_edit.text())
        if folder:
            self.output_edit.setText(folder)

    def _on_hh_layer_changed(self, layer):
        """Refresh the population field list for the household points
        layer and pre-select a likely total-population field."""
        self.combo_pop_field.setLayer(layer)
        self.combo_pop_field.setField('')
        if layer is None:
            return
        numeric = [f.name() for f in layer.fields() if f.isNumeric()]
        lower = {n.lower(): n for n in numeric}
        # also accept text fields with a known population name
        for f in layer.fields():
            lower.setdefault(f.name().lower(), f.name())
        for cand in POP_FIELD_CANDIDATES:
            if cand in lower:
                self.combo_pop_field.setField(lower[cand])
                return
        for n in numeric:
            if 'pop' in n.lower():
                self.combo_pop_field.setField(n)
                return

    def _on_road_layer_changed(self, layer):
        """Refresh the road category field list for the chosen Streets
        layer and pre-select fclass / highway / type when available."""
        self.combo_cat_field.setLayer(layer)
        self.combo_cat_field.setField('')
        if layer is None:
            return
        names = {f.name().lower(): f.name() for f in layer.fields()}
        for cand in ROAD_CATEGORY_FIELDS:
            if cand in names:
                self.combo_cat_field.setField(names[cand])
                break

    def _browse_widths_csv(self):
        path, _ = QFileDialog.getOpenFileName(
            self, self.T('dlg_select_csv'), "",
            self.T('csv_filter'))
        if not path:
            return
        uri = QUrl.fromLocalFile(path).toString() + \
            "?type=csv&detectTypes=yes&geomType=none"
        name = os.path.splitext(os.path.basename(path))[0]
        lyr = QgsVectorLayer(uri, name, "delimitedtext")
        if not lyr.isValid():
            lyr = QgsVectorLayer(path, name, "ogr")
        if not lyr.isValid():
            QMessageBox.warning(
                self, self.T('msg_invalid_csv_title'),
                "{}\n{}".format(self.T('msg_invalid_csv'), path))
            return
        QgsProject.instance().addMapLayer(lyr)
        self.combo_widths.setLayer(lyr)

    def _read_road_widths(self):
        """
        Read the measured road widths table (col 1 = category,
        col 2 = width in m) into {category_lower: width}. Done on the
        main thread so the worker never touches a project layer.
        Returns (dict, provided_flag).
        """
        lyr = self.combo_widths.currentLayer()
        if lyr is None:
            return {}, False
        if lyr.fields().count() < 2:
            QMessageBox.warning(
                self, self.T('msg_widths_title'),
                self.T('msg_widths_cols'))
            return {}, False
        widths = {}
        skipped = 0
        for feat in lyr.getFeatures():
            attrs = feat.attributes()
            cat, w = attrs[0], attrs[1]
            if cat is None or (hasattr(cat, 'isNull') and cat.isNull()):
                skipped += 1
                continue
            try:
                w = float(str(w).strip().replace(',', '.'))
            except (TypeError, ValueError):
                skipped += 1
                continue
            key = str(cat).strip().lower()
            if key and w > 0:
                widths[key] = w
            else:
                skipped += 1
        if skipped:
            self._log("Road widths CSV: {} row(s) skipped (empty category "
                      "or non-numeric/zero width).".format(skipped))
        return widths, True

    def _log(self, msg):
        self.log_box.append(msg)
        self.log_box.verticalScrollBar().setValue(
            self.log_box.verticalScrollBar().maximum())

    def _validate(self):
        if self.combo_road.currentLayer() is None:
            QMessageBox.warning(
                self,
                self.T('msg_missing_layer'),
                self.T('msg_select_streets'))
            return False
        if self.combo_urban.currentLayer() is None:
            QMessageBox.warning(
                self,
                self.T('msg_missing_layer'),
                self.T('msg_select_urban'))
            return False
        if self.combo_pop.currentLayer() is None and \
                self.combo_hh.currentLayer() is None:
            QMessageBox.warning(
                self,
                self.T('msg_missing_pop_title'),
                self.T('msg_missing_pop'))
            return False
        if self.combo_hh.currentLayer() is not None and \
                not self.combo_pop_field.currentField():
            QMessageBox.warning(
                self,
                self.T('msg_missing_popfield_title'),
                self.T('msg_missing_popfield'))
            return False
        if not self.city_edit.text().strip():
            QMessageBox.warning(
                self,
                self.T('msg_missing_city_title'),
                self.T('msg_missing_city'))
            return False
        if not self.output_edit.text().strip():
            QMessageBox.warning(
                self,
                self.T('msg_missing_output_title'),
                self.T('msg_missing_output'))
            return False
        if not self.crs_widget.crs().isValid():
            QMessageBox.warning(
                self,
                self.T('msg_invalid_crs_title'),
                self.T('msg_invalid_crs'))
            return False
        has_any = any([
            self.combo_pos.currentLayer(),
            self.combo_bus.currentLayer(),
            self.combo_ferry.currentLayer(),
            self.combo_rail.currentLayer(),
        ])
        if not has_any:
            reply = QMessageBox.question(
                self, self.T('msg_no_transport_title'),
                self.T('msg_no_transport'),
                QMessageBox.Yes | QMessageBox.No)
            if reply == QMessageBox.No:
                return False
        return True

    def run_analysis(self):
        if not self._validate():
            return
        self.log_box.clear()
        self.progress_bar.setValue(0)
        self.run_btn.setEnabled(False)
        self.cancel_btn.setEnabled(True)
        self.reset_btn.setEnabled(False)

        road_widths, widths_provided = self._read_road_widths()

        params = {
            'road_widths': road_widths,
            'road_widths_provided': widths_provided,
            'road_cat_field': self.combo_cat_field.currentField() or '',
            'road_layer': self.combo_road.currentLayer(),
            'pos_layer': self.combo_pos.currentLayer(),
            'bus_layer': self.combo_bus.currentLayer(),
            'ferry_layer': self.combo_ferry.currentLayer(),
            'rail_layer': self.combo_rail.currentLayer(),
            'urban_layer': self.combo_urban.currentLayer(),
            'pop_raster': self.combo_pop.currentLayer(),
            'pop_points': self.combo_hh.currentLayer(),
            'pop_field': self.combo_pop_field.currentField() or '',
            'crs': self.crs_widget.crs(),
            'city_name': self.city_edit.text().strip(),
            'output_dir': self.output_edit.text().strip(),
            'dist_pos': self.spin_pos.value(),
            'dist_bus': self.spin_bus.value(),
            'dist_ferry': self.spin_ferry.value(),
            'dist_rail': self.spin_rail.value(),
            'pos_spacing': self.spin_pos_spacing.value(),
            'preclip': self.chk_preclip.isChecked(),
            'use_memory': self.chk_memory.isChecked(),
            'native_sa': self.chk_native_sa.isChecked(),
            'lang': self.lang,
        }

        self.worker = SAWorker(params)
        self.worker.log.connect(self._log)
        self.worker.progress.connect(self.progress_bar.setValue)
        self.worker.finished.connect(self._on_finished)
        self.worker.start()

    def cancel_analysis(self):
        if self.worker:
            self.worker.cancel()
            self._log(self.T('msg_cancel_requested'))
        self.cancel_btn.setEnabled(False)

    def _on_finished(self, success, message):
        self.run_btn.setEnabled(True)
        self.cancel_btn.setEnabled(False)
        self.reset_btn.setEnabled(True)
        if success:
            self._log("\nDONE: " + message)
            QMessageBox.information(self, self.T('msg_complete'), message)
        else:
            self._log("\nERROR:\n" + message)
            QMessageBox.critical(self,
                                 self.T('msg_error'),
                                 self.T('msg_failed') + "\n\n" + message[:500])

    def closeEvent(self, event):
        if self.worker and self.worker.isRunning():
            reply = QMessageBox.question(
                self, self.T('msg_running_title'),
                self.T('msg_close_running'),
                QMessageBox.Yes | QMessageBox.No)
            if reply == QMessageBox.Yes:
                self.worker.cancel()
                self.worker.wait(3000)
                event.accept()
            else:
                event.ignore()
        else:
            event.accept()
