# -*- coding: utf-8 -*-
"""
SDG 11.2.1 and 11.7.1 Statistics Computation Plugin
Author: Data and Statistics Unit, UN-Habitat
"""

import os
import traceback

from qgis.PyQt.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QGridLayout,
    QLabel, QPushButton, QProgressBar, QTextEdit,
    QGroupBox, QTabWidget, QWidget, QFileDialog,
    QLineEdit, QDoubleSpinBox, QMessageBox, QScrollArea
)
from qgis.PyQt.QtCore import Qt, QThread, pyqtSignal
from qgis.PyQt.QtGui import QFont

from qgis.core import (
    QgsProject, QgsVectorLayer, QgsCoordinateReferenceSystem
)
from qgis.gui import QgsMapLayerComboBox, QgsProjectionSelectionWidget
from qgis.core import QgsMapLayerProxyModel

import processing


# ---------------------------------------------------------------------------
# Worker
# ---------------------------------------------------------------------------
class SAWorker(QThread):
    log = pyqtSignal(str)
    progress = pyqtSignal(int)
    finished = pyqtSignal(bool, str)

    def __init__(self, params):
        super().__init__()
        self.params = params
        self._cancelled = False

    def cancel(self):
        self._cancelled = True

    def run(self):
        try:
            self._execute()
        except Exception as e:
            self.finished.emit(False, str(e) + '\n' + traceback.format_exc())

    # -----------------------------------------------------------------------
    def _execute(self):
        p = self.params
        out_dir = p['output_dir']
        crs = p['crs']
        city = p['city_name'].strip().replace(' ', '_') or 'city'
        city_label = p['city_name'].strip() or 'city'
        crs_str = "EPSG:{}".format(
            crs.postgisSrid()) if crs.postgisSrid() else crs.toWkt()

        os.makedirs(out_dir, exist_ok=True)
        out_dir = os.path.normpath(out_dir)

        all_files = []
        keep_files = []

        step = [0]
        total = 70

        def tick(msg, n=1):
            step[0] += n
            self.log.emit(msg)
            self.progress.emit(min(int(step[0] / total * 100), 99))
            if self._cancelled:
                raise RuntimeError("Cancelled by user.")

        def shp(name):
            return os.path.join(out_dir, name + ".shp")

        def track(path, keep=False):
            if keep:
                keep_files.append(path)
            else:
                all_files.append(path)
            return path

        # ---- helpers -------------------------------------------------------
        def fix_geometry(layer_src, tmp_name):
            """Fix invalid geometries before any processing step."""
            out = shp(tmp_name)
            r = processing.run("native:fixgeometries", {
                'INPUT': layer_src,
                'METHOD': 1,
                'OUTPUT': out
            })
            track(out)
            return r['OUTPUT']

        def layer_area_km2(lyr_path):
            lyr = QgsVectorLayer(lyr_path, '', 'ogr')
            if not lyr.isValid():
                return None
            total_m2 = sum(f.geometry().area() for f in lyr.getFeatures())
            return total_m2 / 1e6

        def delete_all_fields(layer_src, tmp_name):
            lyr = QgsVectorLayer(layer_src, '', 'ogr')
            fnames = [f.name() for f in lyr.fields()]
            if not fnames:
                return layer_src
            out = shp(tmp_name)
            r = processing.run("native:deletecolumn", {
                'INPUT': layer_src,
                'COLUMN': fnames,
                'OUTPUT': out
            })
            track(out)
            return r['OUTPUT']

        def run_zonal_stats(clean_layer, out_name, keep=True):
            tick("  [ZonalStats] {}...".format(out_name))
            zs_path = shp("ZonalStats_" + out_name)
            processing.run("native:zonalstatisticsfb", {
                'INPUT': clean_layer,
                'INPUT_RASTER': p['pop_raster'],
                'RASTER_BAND': 1,
                'COLUMN_PREFIX': 'pop_',
                'STATISTICS': [1],
                'OUTPUT': zs_path
            })
            track(zs_path, keep=keep)

            lyr = QgsVectorLayer(zs_path, '', 'ogr')
            pop_val = None
            if lyr.isValid():
                fnames = [f.name() for f in lyr.fields()]
                tick(
                    "    Fields in {}: {}".format(
                        out_name, ', '.join(fnames)))
                if 'pop_sum' in fnames:
                    for feat in lyr.getFeatures():
                        v = feat['pop_sum']
                        try:
                            fv = float(v)
                            pop_val = (pop_val or 0) + fv
                        except (TypeError, ValueError):
                            pass
                    tick("    pop_sum = {}".format(pop_val))
                else:
                    tick("    WARNING: 'pop_sum' field not found!")
            else:
                tick("    WARNING: zonal stats layer invalid: {}".format(zs_path))
            return zs_path, pop_val

        # ---- 1. Reproject + fix geometries ---------------------------------
        tick("=== STEP 1: Reprojecting and fixing geometries ===")

        def reproject_and_fix(layer, name):
            tick("  Reprojecting {}...".format(name))
            reproj_path = shp("_tmp_reproj_" + name)
            r = processing.run("native:reprojectlayer", {
                'INPUT': layer, 'TARGET_CRS': crs_str,
                'OPERATION': '', 'OUTPUT': reproj_path
            })
            track(reproj_path)
            tick("  Fixing geometries for {}...".format(name))
            fixed = fix_geometry(r['OUTPUT'], "_tmp_fixed_" + name)
            return fixed

        road_r = reproject_and_fix(p['road_layer'], 'road_network')
        urban_r = reproject_and_fix(p['urban_layer'], 'urban_boundary')
        track(urban_r)

        urban_area_km2 = layer_area_km2(urban_r)
        tick("  Urban area: {:.2f} km2".format(urban_area_km2 or 0))

        pos_r = reproject_and_fix(p['pos_layer'],
                                  'pos_polygon') if p['pos_layer'] else None
        bus_r = reproject_and_fix(
            p['bus_layer'],
            'bus_stops') if p['bus_layer'] else None
        ferry_r = reproject_and_fix(
            p['ferry_layer'],
            'ferry_stops') if p['ferry_layer'] else None
        rail_r = reproject_and_fix(
            p['rail_layer'],
            'rail_stops') if p['rail_layer'] else None

        # ---- 2. Open Public Spaces area: clip to urban boundary first ------
        if pos_r:
            tick("  Clipping Open Public Spaces to urban boundary for area measurement...")
            pos_area_clip_path = shp("_tmp_pos_clipped_area")
            pos_area_clipped = processing.run("native:clip", {
                'INPUT': pos_r, 'OVERLAY': urban_r, 'OUTPUT': pos_area_clip_path
            })['OUTPUT']
            track(pos_area_clip_path)
            pos_area_km2 = layer_area_km2(pos_area_clipped)
            tick(
                "  Open Public Spaces area (clipped to urban): {:.2f} km2".format(
                    pos_area_km2 or 0))
        else:
            pos_area_km2 = None

        # ---- 3. Open Public Spaces: polygon -> points (100m) ---------------
        pos_pts = None
        if pos_r:
            tick("\n=== STEP 3: Open Public Spaces - Points along geometry (100m) ===")
            pos_pts_path = shp("_tmp_pos_pts_along_geom")
            pos_pts = processing.run("native:pointsalonglines", {
                'INPUT': pos_r, 'DISTANCE': 100,
                'START_OFFSET': 0, 'END_OFFSET': 0,
                'OUTPUT': pos_pts_path
            })['OUTPUT']
            track(pos_pts_path)
            tick("  Done.")
        else:
            tick("\n  Open Public Spaces layer not provided - skipping.")

        # ---- 4-6. Pipeline per transport type ------------------------------
        def process_transport(road, stops, dist_m, label):
            if stops is None:
                tick("  [{}] Not provided - skipping.".format(label))
                return None, None

            tick("\n--- {} ({}m) ---".format(label, dist_m))

            tick("  [{}] Service Area -> lines...".format(label))
            sa_lines_path = shp("_tmp_sa_lines_" + label)
            sa_lines = processing.run("native:serviceareafromlayer", {
                'INPUT': road, 'START_POINTS': stops,
                'STRATEGY': 0, 'TRAVEL_COST2': dist_m,
                'INCLUDE_BOUNDS': False,
                'OUTPUT_LINES': sa_lines_path,
                'OUTPUT': 'TEMPORARY_OUTPUT'
            })['OUTPUT_LINES']
            track(sa_lines_path)

            tick("  [{}] Convex Hull -> polygon...".format(label))
            hull_path = shp("_tmp_convexhull_" + label)
            hull = processing.run("native:convexhull", {
                'INPUT': sa_lines, 'OUTPUT': hull_path
            })['OUTPUT']
            track(hull_path)

            tick("  [{}] Clip to urban boundary...".format(label))
            clipped_path = shp("_tmp_clipped_" + label)
            clipped = processing.run("native:clip", {
                'INPUT': hull, 'OVERLAY': urban_r, 'OUTPUT': clipped_path
            })['OUTPUT']
            track(clipped_path)

            tick("  [{}] Dissolve...".format(label))
            dissolved_path = shp("SA_{}_dissolved".format(label))
            dissolved = processing.run("native:dissolve", {
                'INPUT': clipped, 'FIELD': [],
                'SEPARATE_DISJOINT': False, 'OUTPUT': dissolved_path
            })['OUTPUT']
            track(dissolved_path, keep=True)

            return dissolved_path, dissolved

        pos_dp, pos_d = process_transport(
            road_r, pos_pts, p['dist_pos'], 'POS')
        bus_dp, bus_d = process_transport(road_r, bus_r, p['dist_bus'], 'Bus')
        ferry_dp, ferry_d = process_transport(
            road_r, ferry_r, p['dist_ferry'], 'Ferry')
        rail_dp, rail_d = process_transport(
            road_r, rail_r, p['dist_rail'], 'Rail')

        # ---- 7. Zonal Statistics -------------------------------------------
        tick("\n=== STEP 7: Zonal Statistics (prefix='pop_' -> field='pop_sum') ===")

        urban_clean = delete_all_fields(urban_r, "_tmp_urban_clean")
        urban_zs, urban_pop = run_zonal_stats(
            urban_clean, 'urban_boundary', keep=False)

        def zs_if_available(dissolved, label):
            if dissolved is None:
                return None, None
            clean = delete_all_fields(dissolved, "_tmp_clean_" + label)
            return run_zonal_stats(clean, label + "_SA")

        pos_zs, pos_pop = zs_if_available(pos_d, 'POS')
        bus_zs, bus_pop = zs_if_available(bus_d, 'Bus')
        ferry_zs, ferry_pop = zs_if_available(ferry_d, 'Ferry')
        rail_zs, rail_pop = zs_if_available(rail_d, 'Rail')

        # ---- 8. High-Capacity (Ferry + Rail) -------------------------------
        hc_pop = None
        hc_zs = None
        hc_clipped_path = None
        if ferry_dp and rail_dp:
            tick("\n=== STEP 8: High-Capacity Transport (Ferry + Rail) ===")
            merged_hc = processing.run("native:mergevectorlayers", {
                'LAYERS': [ferry_dp, rail_dp], 'CRS': crs_str,
                'OUTPUT': shp("_tmp_merged_ferry_rail")
            })['OUTPUT']
            track(shp("_tmp_merged_ferry_rail"))

            hc_diss = processing.run("native:dissolve", {
                'INPUT': merged_hc, 'FIELD': [],
                'SEPARATE_DISJOINT': False, 'OUTPUT': shp("_tmp_hc_dissolved")
            })['OUTPUT']
            track(shp("_tmp_hc_dissolved"))

            hc_clipped_path = shp("SA_HighCapacity_dissolved")
            hc_clipped = processing.run("native:clip", {
                'INPUT': hc_diss, 'OVERLAY': urban_r, 'OUTPUT': hc_clipped_path
            })['OUTPUT']
            track(hc_clipped_path, keep=True)

            hc_clean = delete_all_fields(hc_clipped, "_tmp_clean_HighCap")
            hc_zs, hc_pop = run_zonal_stats(hc_clean, 'HighCap_SA')
        elif ferry_dp:
            hc_zs, hc_pop = ferry_zs, ferry_pop
            hc_clipped_path = ferry_dp
        elif rail_dp:
            hc_zs, hc_pop = rail_zs, rail_pop
            hc_clipped_path = rail_dp
        else:
            tick("\n  No ferry or rail layers - skipping High-Capacity SA.")

        # ---- 9. Combined Transport (bus + ferry + rail; POS excluded) ------
        comb_pop = None
        comb_zs = None
        transport_dp = [dp for dp in [bus_dp, ferry_dp, rail_dp] if dp]
        if len(transport_dp) >= 2:
            tick("\n=== STEP 9: Combined Transport SA ({} modes) ===".format(
                len(transport_dp)))
            merged_all = processing.run("native:mergevectorlayers", {
                'LAYERS': transport_dp, 'CRS': crs_str,
                'OUTPUT': shp("_tmp_merged_all_transport")
            })['OUTPUT']
            track(shp("_tmp_merged_all_transport"))

            comb_diss = processing.run("native:dissolve", {
                'INPUT': merged_all, 'FIELD': [],
                'SEPARATE_DISJOINT': False, 'OUTPUT': shp("_tmp_combined_dissolved")
            })['OUTPUT']
            track(shp("_tmp_combined_dissolved"))

            comb_clipped_path = shp("SA_CombinedTransport_dissolved")
            comb_clipped = processing.run("native:clip", {
                'INPUT': comb_diss, 'OVERLAY': urban_r, 'OUTPUT': comb_clipped_path
            })['OUTPUT']
            track(comb_clipped_path, keep=True)

            comb_clean = delete_all_fields(comb_clipped, "_tmp_clean_Combined")
            comb_zs, comb_pop = run_zonal_stats(comb_clean, 'Combined_SA')
        elif bus_dp:
            tick("\n  No high-capacity layers - combined transport = bus only.")
            comb_zs, comb_pop = bus_zs, bus_pop
        elif ferry_dp or rail_dp:
            tick("\n  No bus layer - combined transport = high-capacity only.")
            comb_zs, comb_pop = hc_zs, hc_pop
        else:
            tick("\n  No transport mode layers available - skipping Combined SA.")

        # ---- 10. Roads: clip -> R_Length -> export CSV ---------------------
        tick("\n=== STEP 10: Roads - clip, R_Length, export CSV ===")

        tick("  Clipping roads to urban boundary...")
        roads_clipped_path = shp("_tmp_roads_clipped")
        roads_clipped = processing.run("native:clip", {
            'INPUT': road_r, 'OVERLAY': urban_r, 'OUTPUT': roads_clipped_path
        })['OUTPUT']
        track(roads_clipped_path)

        tick("  Adding R_Length field...")
        roads_len_path = shp("_tmp_roads_with_length")
        roads_len = processing.run("native:fieldcalculator", {
            'INPUT': roads_clipped,
            'FIELD_NAME': 'R_Length',
            'FIELD_TYPE': 0,
            'FIELD_LENGTH': 20,
            'FIELD_PRECISION': 3,
            'FORMULA': '$length',
            'OUTPUT': roads_len_path
        })['OUTPUT']
        track(roads_len_path)

        tick("  Checking for Shape_Length / Shape_Leng fields...")
        roads_lyr = QgsVectorLayer(roads_len, '', 'ogr')
        fnames = [f.name() for f in roads_lyr.fields()]
        fields_to_drop = [
            fn for fn in fnames if fn in (
                'Shape_Length', 'Shape_Leng')]
        if fields_to_drop:
            tick("  Deleting fields: {}...".format(', '.join(fields_to_drop)))
            roads_clean_path = shp("_tmp_roads_clean")
            roads_final = processing.run("native:deletecolumn", {
                'INPUT': roads_len,
                'COLUMN': fields_to_drop,
                'OUTPUT': roads_clean_path
            })['OUTPUT']
            track(roads_clean_path)
        else:
            roads_final = roads_len
            tick("  Shape_Length / Shape_Leng not found - skipping.")

        roads_csv = os.path.join(out_dir, "{}_roads_clipped.csv".format(city))
        processing.run("native:savefeatures", {
            'INPUT': roads_final,
            'OUTPUT': roads_csv,
            'LAYER_NAME': '',
            'DATASOURCE_OPTIONS': '',
            'LAYER_OPTIONS': 'GEOMETRY=AS_WKT'
        })
        tick("  Roads CSV: {}".format(roads_csv))

        # ---- 11. Statistics CSV -------------------------------------------
        tick("\n=== STEP 11: Writing SDG Statistics CSV ===")
        csv_path = os.path.join(
            out_dir, "{}_statistics_11.2.1_and_11.7.1.csv".format(city))
        self._write_csv(csv_path, city_label,
                        urban_area_km2, pos_area_km2, urban_pop,
                        pos_pop, bus_pop, hc_pop, comb_pop)
        tick("  Statistics CSV: {}".format(csv_path))

        # ---- 12. Clean up --------------------------------------------------
        tick("\n=== STEP 12: Removing intermediate files ===")
        deleted = 0
        for base in all_files:
            if base in keep_files:
                continue
            stem = os.path.splitext(base)[0]
            for ext in ['.shp', '.shx', '.dbf', '.prj', '.cpg',
                        '.qpj', '.qix', '.sbn', '.sbx', '.fix']:
                f = stem + ext
                if os.path.exists(f):
                    try:
                        os.remove(f)
                        deleted += 1
                    except Exception:
                        pass
        tick("  Removed {} file components.".format(deleted))

        # ---- 13. Load final layers into QGIS -------------------------------
        tick("\n=== STEP 13: Loading results into QGIS ===")
        to_load = [
            (pos_zs, 'SDG 11.7.1 - Open Public Spaces SA'),
            (bus_zs, 'SDG 11.2.1 - Low Capacity Transport Stops (Bus Stops, Light Rail Stops) SA'),
            (ferry_zs, 'SDG 11.2.1 - Ferry SA'),
            (rail_zs, 'SDG 11.2.1 - Rail SA'),
            (hc_zs, 'SDG 11.2.1 - High-Capacity SA'),
            (comb_zs, 'SDG 11.2.1 - Combined Transport SA'),
        ]
        for path, name in to_load:
            if path is None:
                continue
            lyr = QgsVectorLayer(path, name, 'ogr')
            if lyr.isValid():
                QgsProject.instance().addMapLayer(lyr)
                tick("  Loaded: {}".format(name))
            else:
                tick("  WARNING: could not load {}".format(name))

        self.progress.emit(100)
        self.finished.emit(
            True, "Done!\nStats CSV : {}\nRoads CSV : {}\nFolder    : {}".format(
                csv_path, roads_csv, out_dir))

    # -----------------------------------------------------------------------
    def _write_csv(self, path, city_label,
                   urban_area_km2, pos_area_km2, urban_pop,
                   pos_pop, bus_pop, hc_pop, comb_pop):
        import csv

        def n(v, d=2):
            if v is None:
                return '-'
            return '{:,.{p}f}'.format(float(v), p=d)

        def pct(part, total, d=2):
            if part is None or total is None or float(total) == 0:
                return '-'
            return '{:,.{p}f}'.format(float(part) / float(total) * 100, p=d)

        headers = [
            'City',
            'Urban Area (km2)',
            'Open Public Spaces Area (km2)',
            'Total Urban Population',
            'Population with Access to Open Public Spaces',
            'Population with Access to Low Capacity Transport Stops (Bus Stops, Light Rail Stops)',
            'Population with Access to High Capacity Transport (Rail + Ferry)',
            'Population with Access to Combined Public Transport',
            'Percentage Population with Access to Open Public Spaces',
            'Percentage Population with Access to Low Capacity Transport Stops (Bus Stops, Light Rail Stops)',
            'Percentage Population with Access to High Capacity Transport',
            'Percentage Population with Access to Combined Public Transport',
        ]
        row = [
            city_label,
            n(urban_area_km2),
            n(pos_area_km2),
            n(urban_pop),
            n(pos_pop),
            n(bus_pop),
            n(hc_pop),
            n(comb_pop),
            pct(pos_pop, urban_pop),
            pct(bus_pop, urban_pop),
            pct(hc_pop, urban_pop),
            pct(comb_pop, urban_pop),
        ]
        with open(path, 'w', newline='', encoding='utf-8') as f:
            writer = csv.writer(f)
            writer.writerow(headers)
            writer.writerow(row)


# ---------------------------------------------------------------------------
# Dialog
# ---------------------------------------------------------------------------
class TransportSADialog(QDialog):

    def __init__(self, iface, parent=None):
        super(TransportSADialog, self).__init__(parent or iface.mainWindow())
        self.iface = iface
        self.worker = None
        self.setWindowTitle("SDG 11.2.1 and 11.7.1 Statistics Computation")
        self.setMinimumWidth(670)
        self.setMinimumHeight(800)
        self._build_ui()

    def _build_ui(self):
        root = QVBoxLayout(self)
        root.setSpacing(8)

        title = QLabel("SDG 11.2.1 and 11.7.1 Statistics Computation")
        title.setAlignment(Qt.AlignCenter)
        f = QFont()
        f.setBold(True)
        f.setPointSize(12)
        title.setFont(f)
        root.addWidget(title)

        sub = QLabel(
            "Reproject + Fix Geometries -> Clip Open Public Spaces -> Points (100m) -> Service Area -> "
            "Convex Hull -> Clip -> Dissolve -> Zonal Stats -> CSV")
        sub.setAlignment(Qt.AlignCenter)
        sub.setStyleSheet("color:#555;font-size:9px;")
        sub.setWordWrap(True)
        root.addWidget(sub)

        tabs = QTabWidget()
        root.addWidget(tabs)
        tabs.addTab(self._tab_layers(), "Layers")
        tabs.addTab(self._tab_distances(), "Distances")
        tabs.addTab(self._tab_output(), "Output")

        pg_box = QGroupBox("Progress")
        pg_lay = QVBoxLayout(pg_box)
        self.progress_bar = QProgressBar()
        self.progress_bar.setRange(0, 100)
        pg_lay.addWidget(self.progress_bar)
        self.log_box = QTextEdit()
        self.log_box.setReadOnly(True)
        self.log_box.setMaximumHeight(170)
        self.log_box.setFont(QFont("Courier New", 9))
        pg_lay.addWidget(self.log_box)
        root.addWidget(pg_box)

        btn_row = QHBoxLayout()
        self.run_btn = QPushButton("Run Analysis")
        self.run_btn.setStyleSheet(
            "QPushButton{background:#2196F3;color:white;font-weight:bold;"
            "padding:8px 20px;border-radius:4px}"
            "QPushButton:hover{background:#1976D2}"
            "QPushButton:disabled{background:#999}")
        self.run_btn.clicked.connect(self.run_analysis)

        self.cancel_btn = QPushButton("Cancel")
        self.cancel_btn.setEnabled(False)
        self.cancel_btn.setStyleSheet(
            "QPushButton{background:#f44336;color:white;font-weight:bold;"
            "padding:8px 20px;border-radius:4px}"
            "QPushButton:disabled{background:#999}")
        self.cancel_btn.clicked.connect(self.cancel_analysis)

        self.reset_btn = QPushButton("Reset Log")
        self.reset_btn.setStyleSheet(
            "QPushButton{background:#607D8B;color:white;font-weight:bold;"
            "padding:8px 20px;border-radius:4px}"
            "QPushButton:hover{background:#455A64}")
        self.reset_btn.clicked.connect(self._reset_state)

        close_btn = QPushButton("Close")
        close_btn.clicked.connect(self.close)
        btn_row.addWidget(self.run_btn)
        btn_row.addWidget(self.cancel_btn)
        btn_row.addWidget(self.reset_btn)
        btn_row.addStretch()
        btn_row.addWidget(close_btn)
        root.addLayout(btn_row)

    # -----------------------------------------------------------------------
    def _reset_state(self):
        """Clear log, reset progress bar and button states."""
        # If a worker is still running, don't reset
        if self.worker and self.worker.isRunning():
            QMessageBox.warning(
                self,
                "Running",
                "Cannot reset while analysis is running. Cancel first.")
            return
        self.log_box.clear()
        self.progress_bar.setValue(0)
        self.run_btn.setEnabled(True)
        self.cancel_btn.setEnabled(False)
        self.worker = None

    def showEvent(self, event):
        """Auto-reset when the dialog is shown after being hidden/closed."""
        super().showEvent(event)
        # Only reset if no worker is actively running
        if not (self.worker and self.worker.isRunning()):
            self._reset_state()

    # -----------------------------------------------------------------------
    def _tab_layers(self):
        w = QWidget()
        lay = QVBoxLayout(w)
        lay.setSpacing(4)

        def add_combo(label, note, attr, ftype, required=True):
            display_label = (label + " *") if required else label
            grp = QGroupBox(display_label)
            grp.setStyleSheet(
                "QGroupBox{font-weight:bold;font-size:11px;color:#212121;}")
            g_lay = QVBoxLayout(grp)
            if note:
                lbl = QLabel(note)
                lbl.setStyleSheet(
                    "color:#555;font-size:9px;font-weight:normal;")
                lbl.setWordWrap(True)
                g_lay.addWidget(lbl)
            combo = QgsMapLayerComboBox()
            combo.setFilters(ftype)
            combo.setAllowEmptyLayer(not required)
            if not required:
                combo.setCurrentIndex(0)
            setattr(self, attr, combo)
            g_lay.addWidget(combo)
            lay.addWidget(grp)

        add_combo("Streets",
                  "Street layer used for network routing",
                  'combo_road', QgsMapLayerProxyModel.LineLayer, required=True)

        add_combo(
            "Urban Boundary",
            "Polygon layer defining urban extent",
            'combo_urban',
            QgsMapLayerProxyModel.PolygonLayer,
            required=True)

        add_combo(
            "Gridded Population (Raster)",
            "Gridded population dataset",
            'combo_pop',
            QgsMapLayerProxyModel.RasterLayer,
            required=True)

        add_combo(
            "Open Public Spaces (Polygons)",
            "Polygon layers representing undeveloped or open land that is accessible to the public, "
            "providing recreational areas for residents and enhancing environmental quality. "
            "Examples include parks, gardens, playgrounds, public beaches, riverbanks, and waterfronts",
            'combo_pos',
            QgsMapLayerProxyModel.PolygonLayer,
            required=False)

        add_combo(
            "Low Capacity Transport Stops (Bus Stops, Light Rail Stops)",
            "Point layer of bus stop / light rail stop locations",
            'combo_bus',
            QgsMapLayerProxyModel.PointLayer,
            required=False)

        add_combo(
            "High Capacity Transport Stops (Railway Stops, Metro Stops)",
            "Point layer of railway/metro station locations",
            'combo_rail',
            QgsMapLayerProxyModel.PointLayer,
            required=False)

        add_combo(
            "High Capacity Transport Stops (Ferry Stops)",
            "Point layer of ferry terminal locations",
            'combo_ferry',
            QgsMapLayerProxyModel.PointLayer,
            required=False)

        grp_crs = QGroupBox(
            "Target Coordinate Reference System (Projected, Meters - e.g. UTM for the urban area) *")
        grp_crs.setStyleSheet("QGroupBox{font-weight:bold;font-size:11px;color:#212121;}")
        g_crs = QVBoxLayout(grp_crs)
        self.crs_widget = QgsProjectionSelectionWidget()
        self.crs_widget.setCrs(QgsCoordinateReferenceSystem("EPSG:32736"))
        g_crs.addWidget(self.crs_widget)
        lay.addWidget(grp_crs)

        lay.addStretch()
        scroll = QScrollArea()
        scroll.setWidget(w)
        scroll.setWidgetResizable(True)
        return scroll

    # -----------------------------------------------------------------------
    def _tab_distances(self):
        w = QWidget()
        lay = QGridLayout(w)
        lay.setSpacing(10)
        lay.setContentsMargins(16, 16, 16, 16)

        header_lbl = QLabel("Network distance threshold for:")
        header_lbl.setStyleSheet("color:#000000;font-weight:bold;font-size:12px;")
        lay.addWidget(header_lbl, 0, 0, 1, 2)

        configs = [
            ("Open Public Spaces", 'spin_pos', 400),
            ("Low Capacity Transport Stops (Bus Stops, Light Rail Stops)", 'spin_bus', 500),
            ("High Capacity Transport Stops (Ferry Stops)", 'spin_ferry', 1000),
            ("High Capacity Transport Stops (Railway Stops, Metro Stops)", 'spin_rail', 1000),
        ]
        for row, (lbl, attr, default) in enumerate(configs, start=1):
            spin = QDoubleSpinBox()
            spin.setRange(1, 50000)
            spin.setValue(default)
            spin.setSuffix(" m")
            spin.setDecimals(0)
            spin.setFixedWidth(140)
            setattr(self, attr, spin)
            lay.addWidget(QLabel(lbl), row, 0)
            lay.addWidget(spin, row, 1)

        lay.setRowStretch(len(configs) + 1, 1)
        return w

    # -----------------------------------------------------------------------
    def _tab_output(self):
        w = QWidget()
        lay = QVBoxLayout(w)
        lay.setSpacing(10)
        lay.setContentsMargins(16, 16, 16, 16)

        grp_city = QGroupBox("City Name (Hint: Avoid special characters)")
        g_city = QVBoxLayout(grp_city)
        self.city_edit = QLineEdit()
        self.city_edit.setPlaceholderText("e.g. Mombasa")
        g_city.addWidget(self.city_edit)
        lay.addWidget(grp_city)

        lay.addWidget(QLabel("Output folder:"))
        row_w = QHBoxLayout()
        self.output_edit = QLineEdit()
        self.output_edit.setText(os.path.expanduser("~/transport_sa_output"))
        browse_btn = QPushButton("Browse...")
        browse_btn.clicked.connect(self._browse_output)
        row_w.addWidget(self.output_edit)
        row_w.addWidget(browse_btn)
        lay.addLayout(row_w)

        info = QLabel(
            "Final files retained:\n"
            "  SA_POS_dissolved.shp                Open Public Spaces service area\n"
            "  SA_Bus_dissolved.shp                Low Capacity Transport Stops (Bus Stops, Light Rail Stops) service area\n"
            "  SA_Ferry_dissolved.shp              Ferry service area\n"
            "  SA_Rail_dissolved.shp               Rail service area\n"
            "  SA_HighCapacity_dissolved.shp       High-capacity SA\n"
            "  SA_CombinedTransport_dissolved.shp  Combined SA\n"
            "  ZonalStats_*.shp                    SA + pop_sum field\n"
            "  {city}_roads_clipped.csv            Roads with R_Length\n"
            "  {city}_statistics_11.2.1_and_11.7.1.csv\n\n"
            "NOTES:\n"
            "  - Geometries are fixed automatically before processing.\n"
            "  - Open Public Spaces area measured after clipping to urban boundary.\n"
            "  - Combined transport = Low Capacity Transport Stops (Bus Stops, Light Rail Stops) + ferry + rail (Open Public Spaces excluded).\n"
            "  - If no high-capacity, combined transport = Low Capacity Transport Stops (Bus Stops, Light Rail Stops) only.\n"
            "  - Use 'Reset Log' to clear log and re-enable buttons after failure.")
        info.setStyleSheet(
            "background:#f5f5f5;border:1px solid #ddd;padding:10px;"
            "font-family:Courier New;font-size:9px;border-radius:4px;"
        )
        lay.addWidget(info)
        lay.addStretch()
        return w

    # -----------------------------------------------------------------------
    def _browse_output(self):
        folder = QFileDialog.getExistingDirectory(
            self, "Select Output Folder", self.output_edit.text())
        if folder:
            self.output_edit.setText(folder)

    def _log(self, msg):
        self.log_box.append(msg)
        self.log_box.verticalScrollBar().setValue(
            self.log_box.verticalScrollBar().maximum())

    def _validate(self):
        if self.combo_road.currentLayer() is None:
            QMessageBox.warning(
                self,
                "Missing Layer",
                "Please select a Streets layer.")
            return False
        if self.combo_urban.currentLayer() is None:
            QMessageBox.warning(
                self,
                "Missing Layer",
                "Please select an Urban Boundary layer.")
            return False
        if self.combo_pop.currentLayer() is None:
            QMessageBox.warning(
                self,
                "Missing Layer",
                "Please select a Gridded Population (Raster) layer.")
            return False
        if not self.city_edit.text().strip():
            QMessageBox.warning(
                self,
                "Missing City Name",
                "Please enter a city name.")
            return False
        if not self.output_edit.text().strip():
            QMessageBox.warning(
                self,
                "Missing Output",
                "Please select an output folder.")
            return False
        if not self.crs_widget.crs().isValid():
            QMessageBox.warning(
                self,
                "Invalid CRS",
                "Please select a valid target CRS.")
            return False
        has_any = any([
            self.combo_pos.currentLayer(),
            self.combo_bus.currentLayer(),
            self.combo_ferry.currentLayer(),
            self.combo_rail.currentLayer(),
        ])
        if not has_any:
            reply = QMessageBox.question(
                self, "No Transport Layers",
                "No Open Public Spaces/Low Capacity Transport Stops (Bus Stops, Light Rail Stops)/Ferry/Rail layers selected. Only urban area and streets will be processed. Continue?",
                QMessageBox.Yes | QMessageBox.No)
            if reply == QMessageBox.No:
                return False
        return True

    def run_analysis(self):
        if not self._validate():
            return
        self.log_box.clear()
        self.progress_bar.setValue(0)
        self.run_btn.setEnabled(False)
        self.cancel_btn.setEnabled(True)
        self.reset_btn.setEnabled(False)

        params = {
            'road_layer': self.combo_road.currentLayer(),
            'pos_layer': self.combo_pos.currentLayer(),
            'bus_layer': self.combo_bus.currentLayer(),
            'ferry_layer': self.combo_ferry.currentLayer(),
            'rail_layer': self.combo_rail.currentLayer(),
            'urban_layer': self.combo_urban.currentLayer(),
            'pop_raster': self.combo_pop.currentLayer(),
            'crs': self.crs_widget.crs(),
            'city_name': self.city_edit.text().strip(),
            'output_dir': self.output_edit.text().strip(),
            'dist_pos': self.spin_pos.value(),
            'dist_bus': self.spin_bus.value(),
            'dist_ferry': self.spin_ferry.value(),
            'dist_rail': self.spin_rail.value(),
        }

        self.worker = SAWorker(params)
        self.worker.log.connect(self._log)
        self.worker.progress.connect(self.progress_bar.setValue)
        self.worker.finished.connect(self._on_finished)
        self.worker.start()

    def cancel_analysis(self):
        if self.worker:
            self.worker.cancel()
            self._log("Cancellation requested...")
        self.cancel_btn.setEnabled(False)

    def _on_finished(self, success, message):
        self.run_btn.setEnabled(True)
        self.cancel_btn.setEnabled(False)
        self.reset_btn.setEnabled(True)
        if success:
            self._log("\nDONE: " + message)
            QMessageBox.information(self, "Complete", message)
        else:
            self._log("\nERROR:\n" + message)
            QMessageBox.critical(self,
                                 "Error",
                                 "Analysis failed. See log for details.\n\n"
                                 "Click 'Reset Log' to clear and run again.\n\n" + message[:500])

    def closeEvent(self, event):
        if self.worker and self.worker.isRunning():
            reply = QMessageBox.question(
                self, "Running",
                "Analysis is still running. Cancel and close?",
                QMessageBox.Yes | QMessageBox.No)
            if reply == QMessageBox.Yes:
                self.worker.cancel()
                self.worker.wait(3000)
                event.accept()
            else:
                event.ignore()
        else:
            event.accept()
