# -*- coding: utf-8 -*-
"""
SDG 11.2.1 and 11.7.1 Statistics Computation Plugin
Author: Data and Statistics Unit, UN-Habitat
Version 2.3 - adds Land Allocated to Streets (LAS) computation
"""

import os
import time
import traceback

PLUGIN_VERSION = "2.3"

# Default street widths (metres) used when a road category has no measured
# width in the user-supplied CSV (or when no CSV is supplied at all).
DEFAULT_ROAD_WIDTHS = {
    'residential': 7.0,
    'motorway': 21.0,
    'primary': 15.0,
    'secondary': 12.0,
    'tertiary': 9.0,
}

# Road-category fields searched (in this order) on the clipped roads layer.
ROAD_CATEGORY_FIELDS = ['fclass', 'highway', 'type']

from qgis.PyQt.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QGridLayout,
    QLabel, QPushButton, QProgressBar, QTextEdit,
    QGroupBox, QTabWidget, QWidget, QFileDialog,
    QLineEdit, QDoubleSpinBox, QMessageBox, QScrollArea, QCheckBox,
    QSplitter
)
from qgis.PyQt.QtCore import Qt, QThread, pyqtSignal
from qgis.PyQt.QtGui import QFont

from qgis.core import (
    QgsProject, QgsVectorLayer, QgsCoordinateReferenceSystem, QgsProperty,
    QgsProcessingContext, QgsFeatureRequest, QgsSpatialIndex, QgsRectangle,
    QgsPointXY, QgsGeometry, QgsFeature, QgsWkbTypes, QgsDistanceArea
)
from qgis.PyQt.QtCore import QUrl
from qgis.gui import (
    QgsMapLayerComboBox, QgsProjectionSelectionWidget, QgsFieldComboBox
)
from qgis.core import QgsMapLayerProxyModel

import processing


# ---------------------------------------------------------------------------
# Fast network service areas
# ---------------------------------------------------------------------------
def math_hypot(x, y):
    return (x * x + y * y) ** 0.5


class FastServiceArea:
    """
    Network service areas with a distance-bounded shortest-path search.

    Equivalent to QGIS 'Service area (from layer)' (shortest path, no
    direction field, topology tolerance 0, INCLUDE_BOUNDS = False) followed
    by 'Convex hull' per start point, but much faster for many start points:

      * the street graph is built ONCE and reused for every mode;
      * each start point is snapped to the nearest street segment using a
        spatial index (QGIS checks every segment for every point);
      * the shortest-path search stops at the distance threshold
        (QGIS computes paths to the whole network for every point).

    Reachable area per start point = convex hull of the snapped start
    point, every street vertex reachable within the threshold, and the
    point where each partially-reachable street segment hits the threshold.
    Streets are joined only where they share an identical vertex, exactly
    like the QGIS network builder with tolerance 0.
    """

    def __init__(self, road_layer, log=None, cancelled=None):
        import math
        self.scale = 1.0
        self._hypot = math.hypot
        self.log = log or (lambda m: None)
        self.cancelled = cancelled or (lambda: False)
        self.xs, self.ys, self.adj, self.segs = [], [], [], []
        self.index = QgsSpatialIndex()
        node_id = {}

        def nid(x, y):
            k = (round(x, 4), round(y, 4))
            i = node_id.get(k)
            if i is None:
                i = len(self.xs)
                node_id[k] = i
                self.xs.append(x)
                self.ys.append(y)
                self.adj.append([])
            return i

        req = QgsFeatureRequest().setNoAttributes()
        for n, f in enumerate(road_layer.getFeatures(req)):
            if n % 20000 == 0 and self.cancelled():
                raise RuntimeError("Cancelled by user.")
            g = f.geometry()
            if g is None or g.isEmpty():
                continue
            parts = g.asMultiPolyline() if g.isMultipart() \
                else [g.asPolyline()]
            for pl in parts:
                for p1, p2 in zip(pl[:-1], pl[1:]):
                    a = nid(p1.x(), p1.y())
                    b = nid(p2.x(), p2.y())
                    if a == b:
                        continue
                    c = self._hypot(p2.x() - p1.x(), p2.y() - p1.y())
                    self.adj[a].append((b, c))
                    self.adj[b].append((a, c))
                    sid = len(self.segs)
                    self.segs.append((a, b, c))
                    self.index.addFeature(sid, QgsRectangle(
                        min(p1.x(), p2.x()), min(p1.y(), p2.y()),
                        max(p1.x(), p2.x()), max(p1.y(), p2.y())))
        self.log("  Street network graph: {:,} nodes, {:,} segments.".format(
            len(self.xs), len(self.segs)))
        self._set_ellipsoid_scale(road_layer)

    def _set_ellipsoid_scale(self, road_layer):
        """QGIS measures network costs on the project ellipsoid (true ground
        metres) - the project ellipsoid, or WGS84 when none is set.
        Projected metres differ slightly (e.g. UTM scale factor 0.9996), so
        derive the local ground/planar ratio at the network centre and
        apply it to the distance threshold, matching QGIS."""
        try:
            if not self.xs:
                return
            ell = QgsProject.instance().ellipsoid()
            if not ell or ell.upper() == 'NONE':
                ell = 'EPSG:7030'  # WGS84, as used by QGIS network analysis
            da = QgsDistanceArea()
            da.setSourceCrs(road_layer.crs(),
                            QgsProject.instance().transformContext())
            da.setEllipsoid(ell)
            if not da.willUseEllipsoid():
                return
            ext = road_layer.extent()
            cx, cy = ext.center().x(), ext.center().y()
            ratios = []
            for dx, dy in ((500, 0), (0, 500), (354, 354)):
                planar = math_hypot(dx, dy)
                ground = da.measureLine(QgsPointXY(cx - dx, cy - dy),
                                        QgsPointXY(cx + dx, cy + dy)) / 2.0
                if ground > 0:
                    ratios.append(ground / planar)
            if ratios:
                r = sum(ratios) / len(ratios)
                if 0.9 < r < 1.1:
                    self.scale = r
                    self.log("  Ellipsoidal distance correction ({}): "
                             "x{:.5f}".format(ell, r))
        except Exception:
            self.scale = 1.0

    # -- snapping ------------------------------------------------------------
    def _seg_closest(self, sid, px, py):
        a, b, c = self.segs[sid]
        ax, ay, bx, by = self.xs[a], self.ys[a], self.xs[b], self.ys[b]
        dx, dy = bx - ax, by - ay
        t = ((px - ax) * dx + (py - ay) * dy) / (c * c)
        t = 0.0 if t < 0 else (1.0 if t > 1 else t)
        cx, cy = ax + t * dx, ay + t * dy
        return self._hypot(px - cx, py - cy), t, cx, cy

    def snap(self, px, py):
        """Exact nearest segment: bbox-nearest gives an upper bound on the
        distance, then every segment within that bound is tested exactly."""
        ids = self.index.nearestNeighbor(QgsPointXY(px, py), 1)
        if not ids:
            return None
        d0 = self._seg_closest(ids[0], px, py)[0]
        cand = self.index.intersects(QgsRectangle(
            px - d0 - 1e-6, py - d0 - 1e-6, px + d0 + 1e-6, py + d0 + 1e-6))
        best = None
        for sid in cand or ids:
            d, t, cx, cy = self._seg_closest(sid, px, py)
            if best is None or d < best[0]:
                best = (d, sid, t, cx, cy)
        return best

    # -- bounded search ------------------------------------------------------
    def reach_points(self, px, py, limit):
        import heapq
        s = self.snap(px, py)
        if s is None:
            return []
        _, sid, t, sx, sy = s
        a, b, c = self.segs[sid]
        xs, ys, adj = self.xs, self.ys, self.adj
        pts = [QgsPointXY(sx, sy)]
        heap = []
        for node, cost in ((a, t * c), (b, (1.0 - t) * c)):
            if cost <= limit:
                heapq.heappush(heap, (cost, node))
            elif cost > 0:
                f = limit / cost
                pts.append(QgsPointXY(sx + (xs[node] - sx) * f,
                                      sy + (ys[node] - sy) * f))
        done = {}
        while heap:
            d, u = heapq.heappop(heap)
            if u in done:
                continue
            done[u] = d
            ux, uy = xs[u], ys[u]
            pts.append(QgsPointXY(ux, uy))
            for v, cst in adj[u]:
                nd = d + cst
                if nd <= limit:
                    if v not in done:
                        heapq.heappush(heap, (nd, v))
                else:
                    f = (limit - d) / cst
                    if f > 0:
                        pts.append(QgsPointXY(ux + (xs[v] - ux) * f,
                                              uy + (ys[v] - uy) * f))
        return pts

    def hull_layer(self, stops_layer, limit, crs, label=''):
        """Memory polygon layer with one convex hull per start point."""
        out = QgsVectorLayer("Polygon?field=src_fid:integer",
                             "sa_hulls_" + label, "memory")
        out.setCrs(crs)
        feats = []
        n_total = stops_layer.featureCount()
        skipped = 0
        req = QgsFeatureRequest().setNoAttributes()
        for i, f in enumerate(stops_layer.getFeatures(req)):
            if i % 250 == 0:
                if self.cancelled():
                    raise RuntimeError("Cancelled by user.")
                if i and i % 1000 == 0:
                    self.log("    [{}] {:,}/{:,} start points...".format(
                        label, i, n_total))
            g = f.geometry()
            if g is None or g.isEmpty():
                continue
            pts = g.asMultiPoint() if g.isMultipart() else [g.asPoint()]
            for pt in pts:
                rp = self.reach_points(pt.x(), pt.y(),
                                       float(limit) / self.scale)
                if len(rp) < 3:
                    skipped += 1
                    continue
                h = QgsGeometry.fromMultiPointXY(rp).convexHull()
                if h.isEmpty() or h.type() != QgsWkbTypes.PolygonGeometry \
                        or h.area() <= 0:
                    skipped += 1
                    continue
                nf = QgsFeature(out.fields())
                nf.setGeometry(h)
                nf.setAttributes([f.id()])
                feats.append(nf)
        out.dataProvider().addFeatures(feats)
        out.updateExtents()
        if skipped:
            self.log("    [{}] {} start point(s) reach no street area "
                     "(isolated / degenerate) - ignored.".format(
                         label, skipped))
        return out


# ---------------------------------------------------------------------------
# Worker
# ---------------------------------------------------------------------------
class SAWorker(QThread):
    log = pyqtSignal(str)
    progress = pyqtSignal(int)
    finished = pyqtSignal(bool, str)

    def __init__(self, params):
        super().__init__()
        self.params = params
        self._cancelled = False

    def cancel(self):
        self._cancelled = True

    def run(self):
        try:
            self._execute()
        except Exception as e:
            self.finished.emit(False, str(e) + '\n' + traceback.format_exc())

    # -----------------------------------------------------------------------
    def _execute(self):
        p = self.params
        out_dir = p['output_dir']
        crs = p['crs']
        city = p['city_name'].strip().replace(' ', '_') or 'city'
        city_label = p['city_name'].strip() or 'city'
        crs_str = "EPSG:{}".format(
            crs.postgisSrid()) if crs.postgisSrid() else crs.toWkt()

        use_mem = p.get('use_memory', True)
        preclip = p.get('preclip', True)
        pos_spacing = float(p.get('pos_spacing', 100) or 100)

        os.makedirs(out_dir, exist_ok=True)
        out_dir = os.path.normpath(out_dir)

        all_files = []
        keep_files = []

        step = [0]
        total = 95

        def tick(msg, n=1):
            step[0] += n
            self.log.emit(msg)
            self.progress.emit(min(int(step[0] / total * 100), 99))
            if self._cancelled:
                raise RuntimeError("Cancelled by user.")

        def shp(name):
            return os.path.join(out_dir, name + ".shp")

        def track(path, keep=False):
            if keep:
                keep_files.append(path)
            else:
                all_files.append(path)
            return path

        def tmp(name):
            """Output target for an intermediate layer: in memory (fast)
            or a temporary shapefile that is deleted at the end."""
            if use_mem:
                return 'TEMPORARY_OUTPUT'
            return track(shp(name))

        def as_layer(src):
            if isinstance(src, QgsVectorLayer):
                return src
            return QgsVectorLayer(src, '', 'ogr')

        def fcount(src):
            lyr = as_layer(src)
            return lyr.featureCount() if lyr and lyr.isValid() else 0

        # Context that skips geometry-validity checks: used only for the
        # fast pre-filter steps that run BEFORE geometries are fixed.
        ctx_nocheck = QgsProcessingContext()
        ctx_nocheck.setProject(QgsProject.instance())
        ctx_nocheck.setInvalidGeometryCheck(QgsFeatureRequest.GeometryNoCheck)

        t_start = time.time()
        t_step = [time.time()]

        def timed(label):
            now = time.time()
            tick("  ({} took {:.1f} s)".format(label, now - t_step[0]), 0)
            t_step[0] = now

        # ---- helpers -------------------------------------------------------
        def fix_geometry(layer_src, tmp_name):
            """Fix invalid geometries before any processing step."""
            r = processing.run("native:fixgeometries", {
                'INPUT': layer_src,
                'METHOD': 1,
                'OUTPUT': tmp(tmp_name)
            })
            return r['OUTPUT']

        def layer_area_km2(lyr_src):
            lyr = as_layer(lyr_src)
            if not lyr.isValid():
                return None
            total_m2 = sum(f.geometry().area() for f in lyr.getFeatures())
            return total_m2 / 1e6

        def delete_all_fields(layer_src, tmp_name):
            lyr = as_layer(layer_src)
            fnames = [f.name() for f in lyr.fields()]
            if not fnames:
                return layer_src
            r = processing.run("native:deletecolumn", {
                'INPUT': layer_src,
                'COLUMN': fnames,
                'OUTPUT': tmp(tmp_name)
            })
            return r['OUTPUT']

        def run_zonal_stats(clean_layer, out_name, keep=True):
            tick("  [ZonalStats] {}...".format(out_name))
            zs_target = shp("ZonalStats_" + out_name) if keep \
                else tmp("ZonalStats_" + out_name)
            zs_out = processing.run("native:zonalstatisticsfb", {
                'INPUT': clean_layer,
                'INPUT_RASTER': p['pop_raster'],
                'RASTER_BAND': 1,
                'COLUMN_PREFIX': 'pop_',
                'STATISTICS': [1],
                'OUTPUT': zs_target
            })['OUTPUT']
            if keep:
                track(zs_target, keep=True)

            lyr = as_layer(zs_out)
            pop_val = None
            if lyr.isValid():
                fnames = [f.name() for f in lyr.fields()]
                tick(
                    "    Fields in {}: {}".format(
                        out_name, ', '.join(fnames)))
                if 'pop_sum' in fnames:
                    for feat in lyr.getFeatures():
                        v = feat['pop_sum']
                        try:
                            fv = float(v)
                            pop_val = (pop_val or 0) + fv
                        except (TypeError, ValueError):
                            pass
                    tick("    pop_sum = {}".format(pop_val))
                else:
                    tick("    WARNING: 'pop_sum' field not found!")
            else:
                tick("    WARNING: zonal stats layer invalid: {}".format(
                    out_name))
            return (zs_target if keep else zs_out), pop_val

        def reproject_and_fix(layer, name):
            tick("  Reprojecting {}...".format(name))
            r = processing.run("native:reprojectlayer", {
                'INPUT': layer, 'TARGET_CRS': crs_str,
                'OPERATION': '', 'OUTPUT': tmp("_tmp_reproj_" + name)
            })
            tick("  Fixing geometries for {}...".format(name))
            return fix_geometry(r['OUTPUT'], "_tmp_fixed_" + name)

        # ---- 1. Urban boundary first ---------------------------------------
        tick("=== STEP 1: Urban boundary - reproject and fix ===")
        urban_r = reproject_and_fix(p['urban_layer'], 'urban_boundary')
        urban_area_km2 = layer_area_km2(urban_r)
        tick("  Urban area: {:.2f} km2".format(urban_area_km2 or 0))

        # ---- 1b. Pre-clip inputs to the urban area + search margin ---------
        buf_cache = {}

        def urban_buffer(dist):
            """Urban boundary buffered by `dist` metres (cached)."""
            dist = float(dist)
            if dist not in buf_cache:
                buf_cache[dist] = processing.run("native:buffer", {
                    'INPUT': urban_r, 'DISTANCE': dist, 'SEGMENTS': 8,
                    'END_CAP_STYLE': 0, 'JOIN_STYLE': 0, 'MITER_LIMIT': 2,
                    'DISSOLVE': True,
                    'OUTPUT': tmp("_tmp_urban_buf_{}".format(int(dist)))
                })['OUTPUT']
            return buf_cache[dist]

        def prefilter(layer, dist, name, clip=False):
            """Keep only features of `layer` within `dist` m of the urban
            boundary. Done on the ORIGINAL layer, before reprojection, so
            country-wide inputs are cut down immediately."""
            if layer is None or not preclip:
                return layer
            n_before = layer.featureCount()
            zone = urban_buffer(dist)
            if clip:
                res = processing.run("native:clip", {
                    'INPUT': layer, 'OVERLAY': zone,
                    'OUTPUT': tmp("_tmp_preclip_" + name)
                }, context=ctx_nocheck)['OUTPUT']
            else:
                res = processing.run("native:extractbylocation", {
                    'INPUT': layer, 'PREDICATE': [0], 'INTERSECT': zone,
                    'OUTPUT': tmp("_tmp_preclip_" + name)
                }, context=ctx_nocheck)['OUTPUT']
            tick("  {}: {:,} -> {:,} features (within {:,.0f} m of urban "
                 "area)".format(name, n_before, fcount(res), dist))
            return res

        pos_in = p['pos_layer']
        bus_in = p['bus_layer']
        ferry_in = p['ferry_layer']
        rail_in = p['rail_layer']
        road_in = p['road_layer']

        if preclip:
            tick("\n=== STEP 1b: Pre-clipping inputs to urban area + search "
                 "margin ===")
            active = []
            if pos_in:
                active.append(p['dist_pos'])
            if bus_in:
                active.append(p['dist_bus'])
            if ferry_in:
                active.append(p['dist_ferry'])
            if rail_in:
                active.append(p['dist_rail'])
            # A stop up to D outside the boundary can route along streets
            # up to D further out, so 2 x D (+ safety) keeps every route
            # that can reach the urban area.
            road_margin = (2 * max(active) + 500) if active else 100
            road_in = prefilter(road_in, road_margin, 'roads', clip=True)
            pos_in = prefilter(pos_in, p['dist_pos'], 'open_spaces')
            bus_in = prefilter(bus_in, p['dist_bus'], 'bus_stops')
            ferry_in = prefilter(ferry_in, p['dist_ferry'], 'ferry_stops')
            rail_in = prefilter(rail_in, p['dist_rail'], 'rail_stops')
            timed("Pre-clip")

            def empty_to_none(src, label):
                if src is not None and fcount(src) == 0:
                    tick("  {}: no features near the urban area - "
                         "treated as not provided.".format(label))
                    return None
                return src
            pos_in = empty_to_none(pos_in, 'Open Public Spaces')
            bus_in = empty_to_none(bus_in, 'Low Capacity Transport Stops')
            ferry_in = empty_to_none(ferry_in, 'Ferry stops')
            rail_in = empty_to_none(rail_in, 'Rail stops')
            if fcount(road_in) == 0:
                raise RuntimeError(
                    "No streets found within the urban area. Check that "
                    "the Streets and Urban Boundary layers overlap.")
        else:
            tick("\n  Pre-clipping disabled - using full input layers.")

        # ---- 1c. Reproject + fix remaining layers ---------------------------
        tick("\n=== STEP 1c: Reprojecting and fixing geometries ===")
        road_r = reproject_and_fix(road_in, 'road_network')
        pos_r = reproject_and_fix(pos_in, 'pos_polygon') if pos_in else None
        bus_r = reproject_and_fix(bus_in, 'bus_stops') if bus_in else None
        ferry_r = reproject_and_fix(
            ferry_in, 'ferry_stops') if ferry_in else None
        rail_r = reproject_and_fix(rail_in, 'rail_stops') if rail_in else None
        timed("Reproject + fix")

        # ---- 2. Open Public Spaces area: clip to urban boundary first ------
        if pos_r:
            tick("  Clipping Open Public Spaces to urban boundary for area "
                 "measurement...")
            pos_area_clipped = processing.run("native:clip", {
                'INPUT': pos_r, 'OVERLAY': urban_r,
                'OUTPUT': tmp("_tmp_pos_clipped_area")
            })['OUTPUT']
            pos_area_km2 = layer_area_km2(pos_area_clipped)
            tick(
                "  Open Public Spaces area (clipped to urban): {:.2f} km2".format(
                    pos_area_km2 or 0))
        else:
            pos_area_km2 = None

        # ---- 3. Open Public Spaces: polygon -> points ----------------------
        pos_pts = None
        if pos_r:
            tick("\n=== STEP 3: Open Public Spaces - Points along geometry "
                 "({:g}m) ===".format(pos_spacing))
            pos_pts_raw = processing.run("native:pointsalonglines", {
                'INPUT': pos_r, 'DISTANCE': pos_spacing,
                'START_OFFSET': 0, 'END_OFFSET': 0,
                'OUTPUT': tmp("_tmp_pos_pts_along_geom")
            })['OUTPUT']
            n_raw = fcount(pos_pts_raw)
            pos_pts = processing.run("native:deleteduplicategeometries", {
                'INPUT': pos_pts_raw,
                'OUTPUT': tmp("_tmp_pos_pts_dedup")
            })['OUTPUT']
            tick("  {:,} points ({:,} duplicates removed).".format(
                fcount(pos_pts), n_raw - fcount(pos_pts)))
        else:
            tick("\n  Open Public Spaces layer not provided - skipping.")

        # ---- 4-6. Pipeline per transport type ------------------------------
        def process_transport(road, stops, dist_m, label):
            if stops is None:
                tick("  [{}] Not provided - skipping.".format(label))
                return None, None

            tick("\n--- {} ({}m, {:,} start points) ---".format(
                label, dist_m, fcount(stops)))

            if use_native_sa:
                tick("  [{}] Service Area -> lines (QGIS native)...".format(
                    label))
                sa_lines = processing.run("native:serviceareafromlayer", {
                    'INPUT': road, 'START_POINTS': stops,
                    'STRATEGY': 0, 'TRAVEL_COST2': dist_m,
                    'INCLUDE_BOUNDS': False,
                    'OUTPUT_LINES': tmp("_tmp_sa_lines_" + label),
                    'OUTPUT': 'TEMPORARY_OUTPUT'
                })['OUTPUT_LINES']

                tick("  [{}] Convex Hull -> polygon...".format(label))
                hull = processing.run("native:convexhull", {
                    'INPUT': sa_lines,
                    'OUTPUT': tmp("_tmp_convexhull_" + label)
                })['OUTPUT']
            else:
                tick("  [{}] Service Area + Convex Hull (fast bounded "
                     "search)...".format(label))
                hull = get_network().hull_layer(
                    as_layer(stops), dist_m, crs, label)
                tick("  [{}] {:,} service area polygons.".format(
                    label, hull.featureCount()))
                if hull.featureCount() == 0:
                    tick("  [{}] WARNING: no reachable street area - "
                         "skipping.".format(label))
                    return None, None

            tick("  [{}] Clip to urban boundary...".format(label))
            clipped = processing.run("native:clip", {
                'INPUT': hull, 'OVERLAY': urban_r,
                'OUTPUT': tmp("_tmp_clipped_" + label)
            })['OUTPUT']

            tick("  [{}] Dissolve...".format(label))
            dissolved_path = shp("SA_{}_dissolved".format(label))
            dissolved = processing.run("native:dissolve", {
                'INPUT': clipped, 'FIELD': [],
                'SEPARATE_DISJOINT': False, 'OUTPUT': dissolved_path
            })['OUTPUT']
            track(dissolved_path, keep=True)
            timed(label + " service area")

            return dissolved_path, dissolved

        use_native_sa = p.get('native_sa', False)
        net_cache = []

        def get_network():
            """Street graph built once, shared by all modes."""
            if not net_cache:
                tick("  Building street network graph (once)...")
                net_cache.append(FastServiceArea(
                    as_layer(road_r), log=lambda m: tick(m, 0),
                    cancelled=lambda: self._cancelled))
            return net_cache[0]

        pos_dp, pos_d = process_transport(
            road_r, pos_pts, p['dist_pos'], 'POS')
        bus_dp, bus_d = process_transport(road_r, bus_r, p['dist_bus'], 'Bus')
        ferry_dp, ferry_d = process_transport(
            road_r, ferry_r, p['dist_ferry'], 'Ferry')
        rail_dp, rail_d = process_transport(
            road_r, rail_r, p['dist_rail'], 'Rail')

        # ---- 7. Zonal Statistics -------------------------------------------
        tick("\n=== STEP 7: Zonal Statistics (prefix='pop_' -> field='pop_sum') ===")

        urban_clean = delete_all_fields(urban_r, "_tmp_urban_clean")
        urban_zs, urban_pop = run_zonal_stats(
            urban_clean, 'urban_boundary', keep=False)

        def zs_if_available(dissolved, label):
            if dissolved is None:
                return None, None
            clean = delete_all_fields(dissolved, "_tmp_clean_" + label)
            return run_zonal_stats(clean, label + "_SA")

        pos_zs, pos_pop = zs_if_available(pos_d, 'POS')
        bus_zs, bus_pop = zs_if_available(bus_d, 'Bus')
        ferry_zs, ferry_pop = zs_if_available(ferry_d, 'Ferry')
        rail_zs, rail_pop = zs_if_available(rail_d, 'Rail')

        # ---- 8. High-Capacity (Ferry + Rail) -------------------------------
        hc_pop = None
        hc_zs = None
        hc_clipped_path = None
        if ferry_dp and rail_dp:
            tick("\n=== STEP 8: High-Capacity Transport (Ferry + Rail) ===")
            merged_hc = processing.run("native:mergevectorlayers", {
                'LAYERS': [ferry_dp, rail_dp], 'CRS': crs_str,
                'OUTPUT': tmp("_tmp_merged_ferry_rail")
            })['OUTPUT']

            hc_diss = processing.run("native:dissolve", {
                'INPUT': merged_hc, 'FIELD': [],
                'SEPARATE_DISJOINT': False,
                'OUTPUT': tmp("_tmp_hc_dissolved")
            })['OUTPUT']

            hc_clipped_path = shp("SA_HighCapacity_dissolved")
            hc_clipped = processing.run("native:clip", {
                'INPUT': hc_diss, 'OVERLAY': urban_r, 'OUTPUT': hc_clipped_path
            })['OUTPUT']
            track(hc_clipped_path, keep=True)

            hc_clean = delete_all_fields(hc_clipped, "_tmp_clean_HighCap")
            hc_zs, hc_pop = run_zonal_stats(hc_clean, 'HighCap_SA')
        elif ferry_dp:
            hc_zs, hc_pop = ferry_zs, ferry_pop
            hc_clipped_path = ferry_dp
        elif rail_dp:
            hc_zs, hc_pop = rail_zs, rail_pop
            hc_clipped_path = rail_dp
        else:
            tick("\n  No ferry or rail layers - skipping High-Capacity SA.")

        # ---- 9. Combined Transport (bus + ferry + rail; POS excluded) ------
        comb_pop = None
        comb_zs = None
        transport_dp = [dp for dp in [bus_dp, ferry_dp, rail_dp] if dp]
        if len(transport_dp) >= 2:
            tick("\n=== STEP 9: Combined Transport SA ({} modes) ===".format(
                len(transport_dp)))
            merged_all = processing.run("native:mergevectorlayers", {
                'LAYERS': transport_dp, 'CRS': crs_str,
                'OUTPUT': tmp("_tmp_merged_all_transport")
            })['OUTPUT']

            comb_diss = processing.run("native:dissolve", {
                'INPUT': merged_all, 'FIELD': [],
                'SEPARATE_DISJOINT': False,
                'OUTPUT': tmp("_tmp_combined_dissolved")
            })['OUTPUT']

            comb_clipped_path = shp("SA_CombinedTransport_dissolved")
            comb_clipped = processing.run("native:clip", {
                'INPUT': comb_diss, 'OVERLAY': urban_r, 'OUTPUT': comb_clipped_path
            })['OUTPUT']
            track(comb_clipped_path, keep=True)

            comb_clean = delete_all_fields(comb_clipped, "_tmp_clean_Combined")
            comb_zs, comb_pop = run_zonal_stats(comb_clean, 'Combined_SA')
        elif bus_dp:
            tick("\n  No high-capacity layers - combined transport = bus only.")
            comb_zs, comb_pop = bus_zs, bus_pop
        elif ferry_dp or rail_dp:
            tick("\n  No bus layer - combined transport = high-capacity only.")
            comb_zs, comb_pop = hc_zs, hc_pop
        else:
            tick("\n  No transport mode layers available - skipping Combined SA.")
        timed("Zonal statistics")

        # ---- 10. Roads: clip -> R_Length -> export CSV ---------------------
        tick("\n=== STEP 10: Roads - clip, R_Length, export CSV ===")

        tick("  Clipping roads to urban boundary...")
        roads_clipped = processing.run("native:clip", {
            'INPUT': road_r, 'OVERLAY': urban_r,
            'OUTPUT': tmp("_tmp_roads_clipped")
        })['OUTPUT']

        tick("  Adding R_Length field...")
        roads_len = processing.run("native:fieldcalculator", {
            'INPUT': roads_clipped,
            'FIELD_NAME': 'R_Length',
            'FIELD_TYPE': 0,
            'FIELD_LENGTH': 20,
            'FIELD_PRECISION': 3,
            'FORMULA': '$length',
            'OUTPUT': tmp("_tmp_roads_with_length")
        })['OUTPUT']

        tick("  Checking for Shape_Length / Shape_Leng fields...")
        fnames = [f.name() for f in as_layer(roads_len).fields()]
        fields_to_drop = [
            fn for fn in fnames if fn in (
                'Shape_Length', 'Shape_Leng')]
        if fields_to_drop:
            tick("  Deleting fields: {}...".format(', '.join(fields_to_drop)))
            roads_final = processing.run("native:deletecolumn", {
                'INPUT': roads_len,
                'COLUMN': fields_to_drop,
                'OUTPUT': tmp("_tmp_roads_clean")
            })['OUTPUT']
        else:
            roads_final = roads_len
            tick("  Shape_Length / Shape_Leng not found - skipping.")

        # ---- 10b. Land Allocated to Streets (LAS) --------------------------
        las_km2, roads_final, las_path = self._compute_las(
            roads_final, urban_r, shp, track, tick, layer_area_km2,
            tmp, as_layer)
        timed("Roads + LAS")

        roads_csv = os.path.join(out_dir, "{}_roads_clipped.csv".format(city))
        processing.run("native:savefeatures", {
            'INPUT': roads_final,
            'OUTPUT': roads_csv,
            'LAYER_NAME': '',
            'DATASOURCE_OPTIONS': '',
            'LAYER_OPTIONS': 'GEOMETRY=AS_WKT'
        })
        tick("  Roads CSV: {}".format(roads_csv))

        # ---- 11. Statistics CSV -------------------------------------------
        tick("\n=== STEP 11: Writing SDG Statistics CSV ===")
        csv_path = os.path.join(
            out_dir, "{}_statistics_11.2.1_and_11.7.1.csv".format(city))
        self._write_csv(csv_path, city_label,
                        urban_area_km2, pos_area_km2, las_km2, urban_pop,
                        pos_pop, bus_pop, hc_pop, comb_pop)
        tick("  Statistics CSV: {}".format(csv_path))

        # ---- 12. Clean up --------------------------------------------------
        tick("\n=== STEP 12: Removing intermediate files ===")
        deleted = 0
        not_removed = []
        for base in all_files:
            if base in keep_files:
                continue
            stem = os.path.splitext(base)[0]
            for ext in ['.shp', '.shx', '.dbf', '.prj', '.cpg',
                        '.qpj', '.qix', '.sbn', '.sbx', '.fix']:
                f = stem + ext
                if os.path.exists(f):
                    try:
                        os.remove(f)
                        deleted += 1
                    except OSError as err:
                        # File may still be locked by QGIS; report it and
                        # carry on - leftover temp files do not affect results.
                        not_removed.append((f, err))
        tick("  Removed {} file components.".format(deleted))
        if not_removed:
            tick("  WARNING: {} intermediate file(s) could not be removed "
                 "(probably locked) - delete them manually:".format(
                     len(not_removed)))
            for f, err in not_removed[:10]:
                tick("    {} ({})".format(os.path.basename(f), err), 0)

        # ---- 13. Load final layers into QGIS -------------------------------
        tick("\n=== STEP 13: Loading results into QGIS ===")
        to_load = [
            (pos_zs, 'SDG 11.7.1 - Open Public Spaces SA'),
            (bus_zs, 'SDG 11.2.1 - Low Capacity Transport Stops (Bus Stops, Light Rail Stops) SA'),
            (ferry_zs, 'SDG 11.2.1 - Ferry SA'),
            (rail_zs, 'SDG 11.2.1 - Rail SA'),
            (hc_zs, 'SDG 11.2.1 - High-Capacity SA'),
            (comb_zs, 'SDG 11.2.1 - Combined Transport SA'),
            (las_path, 'Land Allocated to Streets (LAS)'),
        ]
        for path, name in to_load:
            if path is None:
                continue
            lyr = QgsVectorLayer(path, name, 'ogr')
            if lyr.isValid():
                QgsProject.instance().addMapLayer(lyr)
                tick("  Loaded: {}".format(name))
            else:
                tick("  WARNING: could not load {}".format(name))

        tick("\nTotal processing time: {:.1f} s".format(
            time.time() - t_start), 0)
        self.progress.emit(100)
        self.finished.emit(
            True, "Done!\nLAS       : {:.4f} km2\nStats CSV : {}\n"
            "Roads CSV : {}\nFolder    : {}\nTime      : {:.1f} s".format(
                las_km2 or 0.0, csv_path, roads_csv, out_dir,
                time.time() - t_start))

    # -----------------------------------------------------------------------
    def _compute_las(self, roads_clipped, urban_r, shp, track, tick,
                     layer_area_km2, tmp, as_layer):
        """
        Land Allocated to Streets (LAS).

        1. Join road widths to the clipped roads using the first road
           category field found (fclass -> highway -> type) against
           column 1 of the measured road widths CSV.
        2. Categories without a measured width fall back to the default
           widths (residential 7 m, motorway 21 m, primary 15 m,
           secondary 12 m, tertiary 9 m).
        3. Buffer each road by its width (half-width either side of the
           centre line, so the buffer polygon is exactly one road width
           wide), dissolve, clip to the urban extent and measure area.
           For speed, roads are first merged by width so only one buffer
           per width class is built; the result is the same as buffering
           every segment individually and dissolving.

        Returns (las_km2, roads_layer_for_csv_export, las_shapefile_or_None).
        If no width CSV was supplied AND the roads have none of the category
        fields, LAS = 0.
        """
        p = self.params
        tick("\n=== STEP 10b: Land Allocated to Streets (LAS) ===")

        measured = p.get('road_widths') or {}
        csv_given = bool(p.get('road_widths_provided'))
        if csv_given:
            tick("  Measured road widths CSV: {} categories read.".format(
                len(measured)))
        else:
            tick("  No measured road widths CSV provided.")

        roads_lyr = as_layer(roads_clipped)
        field_map = {f.name().lower(): f.name() for f in roads_lyr.fields()}
        cat_field = None

        # 1. Field chosen by the user in the dialog. Shapefile intermediates
        #    truncate names to 10 characters, so also try the short form.
        chosen = (p.get('road_cat_field') or '').strip()
        if chosen:
            for key in (chosen.lower(), chosen.lower()[:10]):
                if key in field_map:
                    cat_field = field_map[key]
                    break
            if cat_field:
                tick("  Using selected road category field: '{}'".format(
                    chosen))
            else:
                tick("  WARNING: selected field '{}' not found on the "
                     "processed roads - trying fclass / highway / type."
                     .format(chosen))

        # 2. Default fields.
        if cat_field is None:
            for cand in ROAD_CATEGORY_FIELDS:
                if cand in field_map:
                    cat_field = field_map[cand]
                    break

        if cat_field is None:
            tick("  No road category field selected and roads have no "
                 "'fclass', 'highway' or 'type' field - widths cannot be "
                 "joined. Land Allocated to Streets = 0.")
            return 0.0, roads_clipped, None

        tick("  Join field on roads: '{}'".format(cat_field))

        # Lookup: measured widths take priority; defaults fill the gaps.
        lookup = {}
        source = {}
        for k, v in DEFAULT_ROAD_WIDTHS.items():
            lookup[k] = v
            source[k] = 'Default'
        for k, v in measured.items():
            lookup[k] = v
            source[k] = 'Measured'

        # Report what will be matched, so the user can audit the join.
        cats = {}
        req = QgsFeatureRequest().setFlags(QgsFeatureRequest.NoGeometry)
        req.setSubsetOfAttributes([cat_field], roads_lyr.fields())
        for feat in roads_lyr.getFeatures(req):
            val = feat[cat_field]
            if val is None or (hasattr(val, 'isNull') and val.isNull()):
                key = ''
            else:
                key = str(val).strip().lower()
            cats[key] = cats.get(key, 0) + 1
        matched = sorted(c for c in cats if c in lookup)
        unmatched = sorted(c for c in cats if c not in lookup)
        for c in matched:
            tick("    {:<22} {:>6} segments -> {:g} m ({})".format(
                c, cats[c], lookup[c], source[c]), 0)
        if unmatched:
            tick("    No width (excluded from LAS): {}".format(
                ', '.join('{} ({})'.format(c or '<empty>', cats[c])
                          for c in unmatched)), 0)

        if not matched:
            tick("  No road categories matched a width. LAS = 0.")
            return 0.0, roads_clipped, None

        def q(s):
            return "'" + s.replace("'", "''") + "'"

        key_expr = 'lower(trim(to_string("{}")))'.format(
            cat_field.replace('"', '""'))
        width_expr = 'CASE ' + ' '.join(
            'WHEN {} = {} THEN {}'.format(key_expr, q(k), float(w))
            for k, w in lookup.items()) + ' ELSE NULL END'
        src_expr = 'CASE ' + ' '.join(
            'WHEN {} = {} THEN {}'.format(key_expr, q(k), q(source[k]))
            for k in lookup) + " ELSE 'None' END"

        tick("  Attribute join: adding R_Width (m)...")
        roads_w = processing.run("native:fieldcalculator", {
            'INPUT': roads_clipped,
            'FIELD_NAME': 'R_Width',
            'FIELD_TYPE': 0,
            'FIELD_LENGTH': 10,
            'FIELD_PRECISION': 2,
            'FORMULA': width_expr,
            'OUTPUT': tmp("_tmp_roads_with_width")
        })['OUTPUT']

        roads_ws = processing.run("native:fieldcalculator", {
            'INPUT': roads_w,
            'FIELD_NAME': 'W_Source',
            'FIELD_TYPE': 2,
            'FIELD_LENGTH': 10,
            'FIELD_PRECISION': 0,
            'FORMULA': src_expr,
            'OUTPUT': tmp("_tmp_roads_with_width_src")
        })['OUTPUT']

        tick("  Selecting roads with a width...")
        roads_sel = processing.run("native:extractbyexpression", {
            'INPUT': roads_ws,
            'EXPRESSION': '"R_Width" IS NOT NULL AND "R_Width" > 0',
            'OUTPUT': tmp("_tmp_roads_width_only")
        })['OUTPUT']

        tick("  Merging road centre lines by width class...")
        roads_by_w = processing.run("native:dissolve", {
            'INPUT': roads_sel, 'FIELD': ['R_Width'],
            'SEPARATE_DISJOINT': False,
            'OUTPUT': tmp("_tmp_roads_by_width")
        })['OUTPUT']

        tick("  Buffering roads by R_Width (R_Width/2 each side)...")
        roads_buf = processing.run("native:buffer", {
            'INPUT': roads_by_w,
            'DISTANCE': QgsProperty.fromExpression('"R_Width" / 2.0'),
            'SEGMENTS': 5,
            'END_CAP_STYLE': 0,
            'JOIN_STYLE': 0,
            'MITER_LIMIT': 2,
            'DISSOLVE': False,
            'OUTPUT': tmp("_tmp_roads_buffer")
        })['OUTPUT']

        tick("  Dissolving buffered roads...")
        roads_diss = processing.run("native:dissolve", {
            'INPUT': roads_buf, 'FIELD': [],
            'SEPARATE_DISJOINT': False,
            'OUTPUT': tmp("_tmp_roads_buffer_dissolved")
        })['OUTPUT']

        tick("  Clipping dissolved road buffers to urban extent...")
        las_path = shp("LAS_streets_dissolved")
        processing.run("native:clip", {
            'INPUT': roads_diss, 'OVERLAY': urban_r, 'OUTPUT': las_path
        })
        track(las_path, keep=True)

        las_km2 = layer_area_km2(las_path) or 0.0
        tick("  LAS area: {:.4f} km2".format(las_km2))
        return las_km2, roads_ws, las_path

    # -----------------------------------------------------------------------
    def _write_csv(self, path, city_label,
                   urban_area_km2, pos_area_km2, las_km2, urban_pop,
                   pos_pop, bus_pop, hc_pop, comb_pop):
        import csv

        def n(v, d=2):
            if v is None:
                return '-'
            return '{:,.{p}f}'.format(float(v), p=d)

        def pct(part, total, d=2):
            if part is None or total is None or float(total) == 0:
                return '-'
            return '{:,.{p}f}'.format(float(part) / float(total) * 100, p=d)

        las_val = float(las_km2 or 0.0)
        ops_las = float(pos_area_km2 or 0.0) + las_val

        headers = [
            'City',
            'Urban Area (km2)',
            'Open Public Spaces Area (km2)',
            'Land Allocated to Streets (km2)',
            'Open Public Space + Land Allocated to Streets (km2)',
            'Proportion of Urban Area with Open Public Space + Land Allocated to Streets (%)',
            'Total Urban Population',
            'Population with Access to Open Public Spaces',
            'Population with Access to Low Capacity Transport Stops (Bus Stops, Light Rail Stops)',
            'Population with Access to High Capacity Transport (Rail + Ferry)',
            'Population with Access to Combined Public Transport',
            'Percentage Population with Access to Open Public Spaces',
            'Percentage Population with Access to Low Capacity Transport Stops (Bus Stops, Light Rail Stops)',
            'Percentage Population with Access to High Capacity Transport',
            'Percentage Population with Access to Combined Public Transport',
        ]
        row = [
            city_label,
            n(urban_area_km2),
            n(pos_area_km2),
            n(las_val, 4),
            n(ops_las, 4),
            pct(ops_las, urban_area_km2),
            n(urban_pop),
            n(pos_pop),
            n(bus_pop),
            n(hc_pop),
            n(comb_pop),
            pct(pos_pop, urban_pop),
            pct(bus_pop, urban_pop),
            pct(hc_pop, urban_pop),
            pct(comb_pop, urban_pop),
        ]
        with open(path, 'w', newline='', encoding='utf-8') as f:
            writer = csv.writer(f)
            writer.writerow(headers)
            writer.writerow(row)


# ---------------------------------------------------------------------------
# Dialog
# ---------------------------------------------------------------------------
class TransportSADialog(QDialog):

    def __init__(self, iface, parent=None):
        super(TransportSADialog, self).__init__(parent or iface.mainWindow())
        self.iface = iface
        self.worker = None
        self.setWindowTitle("SDG 11.2.1 and 11.7.1 Statistics Computation")
        # Small minimum so the dialog can be dragged down to fit any space;
        # every panel scrolls when there is not enough room.
        self.setMinimumSize(420, 360)
        self.setSizeGripEnabled(True)
        self.setWindowFlags(self.windowFlags()
                            | Qt.WindowMinMaxButtonsHint
                            | Qt.WindowCloseButtonHint)
        self._build_ui()
        # Never narrower than the button row needs.
        self.setMinimumWidth(max(420, self.layout().minimumSize().width()))
        self._fit_to_screen()

    def _fit_to_screen(self):
        """Open at a comfortable size that never exceeds the screen."""
        from qgis.PyQt.QtWidgets import QApplication
        w, h = 700, 820
        # QWidget.screen() exists from Qt 5.14; older Qt uses primaryScreen.
        scr = self.screen() if hasattr(self, 'screen') else None
        if scr is None:
            scr = QApplication.primaryScreen()
        if scr is not None:
            geo = scr.availableGeometry()
            w = min(w, int(geo.width() * 0.9))
            h = min(h, int(geo.height() * 0.85))
        self.resize(max(w, 420), max(h, 360))
        # Settings tabs get ~65% of the space, progress log ~35%.
        self.splitter.setSizes([650, 350])

    @staticmethod
    def _scrollable(widget):
        scroll = QScrollArea()
        scroll.setWidget(widget)
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QScrollArea.NoFrame)
        return scroll

    def _build_ui(self):
        root = QVBoxLayout(self)
        root.setSpacing(8)

        title = QLabel("SDG 11.2.1 and 11.7.1 Statistics Computation")
        title.setAlignment(Qt.AlignCenter)
        f = QFont()
        f.setBold(True)
        f.setPointSize(12)
        title.setFont(f)
        root.addWidget(title)

        sub = QLabel(
            "Pre-clip to Urban Area -> Reproject + Fix Geometries -> Clip Open Public Spaces -> "
            "Boundary Points -> Service Area -> "
            "Convex Hull -> Clip -> Dissolve -> Zonal Stats -> "
            "Road Widths Join -> Buffer -> Dissolve -> Clip (LAS) -> CSV"
            "   |   v" + PLUGIN_VERSION)
        sub.setAlignment(Qt.AlignCenter)
        sub.setStyleSheet("color:#555;font-size:9px;")
        sub.setWordWrap(True)
        root.addWidget(sub)

        tabs = QTabWidget()
        tabs.addTab(self._tab_layers(), "Layers")
        tabs.addTab(self._scrollable(self._tab_distances()), "Distances")
        tabs.addTab(self._scrollable(self._tab_output()), "Output")
        tabs.setMinimumHeight(90)

        pg_box = QGroupBox("Progress")
        pg_lay = QVBoxLayout(pg_box)
        pg_lay.setContentsMargins(6, 6, 6, 6)
        self.progress_bar = QProgressBar()
        self.progress_bar.setRange(0, 100)
        pg_lay.addWidget(self.progress_bar)
        self.log_box = QTextEdit()
        self.log_box.setReadOnly(True)
        self.log_box.setMinimumHeight(40)
        self.log_box.setFont(QFont("Courier New", 9))
        pg_lay.addWidget(self.log_box)
        pg_box.setMinimumHeight(80)

        # Drag the handle between the settings tabs and the progress log
        # to give either one more room.
        self.splitter = QSplitter(Qt.Vertical)
        self.splitter.addWidget(tabs)
        self.splitter.addWidget(pg_box)
        self.splitter.setChildrenCollapsible(False)
        self.splitter.setHandleWidth(8)
        self.splitter.setStyleSheet(
            "QSplitter::handle{background:#e0e0e0;border-radius:3px;}"
            "QSplitter::handle:hover{background:#90caf9;}")
        self.splitter.setStretchFactor(0, 3)
        self.splitter.setStretchFactor(1, 1)
        root.addWidget(self.splitter, 1)

        btn_row = QHBoxLayout()
        self.run_btn = QPushButton("Run Analysis")
        self.run_btn.setStyleSheet(
            "QPushButton{background:#2196F3;color:white;font-weight:bold;"
            "padding:6px 12px;border-radius:4px}"
            "QPushButton:hover{background:#1976D2}"
            "QPushButton:disabled{background:#999}")
        self.run_btn.clicked.connect(self.run_analysis)

        self.cancel_btn = QPushButton("Cancel")
        self.cancel_btn.setEnabled(False)
        self.cancel_btn.setStyleSheet(
            "QPushButton{background:#f44336;color:white;font-weight:bold;"
            "padding:6px 12px;border-radius:4px}"
            "QPushButton:disabled{background:#999}")
        self.cancel_btn.clicked.connect(self.cancel_analysis)

        self.reset_btn = QPushButton("Reset Log")
        self.reset_btn.setStyleSheet(
            "QPushButton{background:#607D8B;color:white;font-weight:bold;"
            "padding:6px 12px;border-radius:4px}"
            "QPushButton:hover{background:#455A64}")
        self.reset_btn.clicked.connect(self._reset_state)

        close_btn = QPushButton("Close")
        close_btn.clicked.connect(self.close)
        btn_row.addWidget(self.run_btn)
        btn_row.addWidget(self.cancel_btn)
        btn_row.addWidget(self.reset_btn)
        btn_row.addStretch()
        btn_row.addWidget(close_btn)
        for b in (self.run_btn, self.cancel_btn, self.reset_btn, close_btn):
            b.setMinimumWidth(b.sizeHint().width())
        root.addLayout(btn_row)

    # -----------------------------------------------------------------------
    def _reset_state(self):
        """Clear log, reset progress bar and button states."""
        # If a worker is still running, don't reset
        if self.worker and self.worker.isRunning():
            QMessageBox.warning(
                self,
                "Running",
                "Cannot reset while analysis is running. Cancel first.")
            return
        self.log_box.clear()
        self.progress_bar.setValue(0)
        self.run_btn.setEnabled(True)
        self.cancel_btn.setEnabled(False)
        self.worker = None

    def showEvent(self, event):
        """Auto-reset when the dialog is shown after being hidden/closed."""
        super().showEvent(event)
        # Only reset if no worker is actively running
        if not (self.worker and self.worker.isRunning()):
            self._reset_state()

    # -----------------------------------------------------------------------
    def _tab_layers(self):
        w = QWidget()
        lay = QVBoxLayout(w)
        lay.setSpacing(4)

        def add_combo(label, note, attr, ftype, required=True):
            display_label = (label + " *") if required else label
            grp = QGroupBox(display_label)
            grp.setStyleSheet(
                "QGroupBox{font-weight:bold;font-size:11px;color:#212121;}")
            g_lay = QVBoxLayout(grp)
            if note:
                lbl = QLabel(note)
                lbl.setStyleSheet(
                    "color:#555;font-size:9px;font-weight:normal;")
                lbl.setWordWrap(True)
                g_lay.addWidget(lbl)
            combo = QgsMapLayerComboBox()
            combo.setFilters(ftype)
            combo.setAllowEmptyLayer(not required)
            if not required:
                combo.setCurrentIndex(0)
            setattr(self, attr, combo)
            g_lay.addWidget(combo)
            lay.addWidget(grp)

        add_combo("Streets",
                  "Street layer used for network routing",
                  'combo_road', QgsMapLayerProxyModel.LineLayer, required=True)

        add_combo(
            "Urban Boundary",
            "Polygon layer defining urban extent",
            'combo_urban',
            QgsMapLayerProxyModel.PolygonLayer,
            required=True)

        add_combo(
            "Gridded Population (Raster)",
            "Gridded population dataset",
            'combo_pop',
            QgsMapLayerProxyModel.RasterLayer,
            required=True)

        add_combo(
            "Open Public Spaces (Polygons)",
            "Polygon layers representing undeveloped or open land that is accessible to the public, "
            "providing recreational areas for residents and enhancing environmental quality. "
            "Examples include parks, gardens, playgrounds, public beaches, riverbanks, and waterfronts",
            'combo_pos',
            QgsMapLayerProxyModel.PolygonLayer,
            required=False)

        add_combo(
            "Low Capacity Transport Stops (Bus Stops, Light Rail Stops)",
            "Point layer of bus stop / light rail stop locations",
            'combo_bus',
            QgsMapLayerProxyModel.PointLayer,
            required=False)

        add_combo(
            "High Capacity Transport Stops (Railway Stops, Metro Stops)",
            "Point layer of railway/metro station locations",
            'combo_rail',
            QgsMapLayerProxyModel.PointLayer,
            required=False)

        add_combo(
            "High Capacity Transport Stops (Ferry Stops)",
            "Point layer of ferry terminal locations",
            'combo_ferry',
            QgsMapLayerProxyModel.PointLayer,
            required=False)

        # ---- Measured road widths (CSV) for LAS ----------------------------
        grp_w = QGroupBox("Measured Road Widths (CSV table)")
        grp_w.setStyleSheet(
            "QGroupBox{font-weight:bold;font-size:11px;color:#212121;}")
        g_w = QVBoxLayout(grp_w)
        lbl_w = QLabel(
            "Used for Land Allocated to Streets. Column 1 = road category "
            "(matched to the Road Category Field selected below), column 2 = "
            "measured road width in metres. If no CSV is given and no road "
            "category field is available, Land Allocated to Streets = 0.")
        lbl_w.setStyleSheet("color:#555;font-size:9px;font-weight:normal;")
        lbl_w.setWordWrap(True)
        g_w.addWidget(lbl_w)
        row_csv = QHBoxLayout()
        self.combo_widths = QgsMapLayerComboBox()
        self.combo_widths.setFilters(QgsMapLayerProxyModel.NoGeometry)
        self.combo_widths.setAllowEmptyLayer(True)
        self.combo_widths.setCurrentIndex(0)
        browse_csv = QPushButton("Browse CSV...")
        browse_csv.clicked.connect(self._browse_widths_csv)
        row_csv.addWidget(self.combo_widths, 1)
        row_csv.addWidget(browse_csv)
        g_w.addLayout(row_csv)
        lay.addWidget(grp_w)

        # ---- Road category field on the Streets layer ----------------------
        grp_f = QGroupBox("Road Category Field (from Streets layer)")
        grp_f.setStyleSheet(
            "QGroupBox{font-weight:bold;font-size:11px;color:#212121;}")
        g_f = QVBoxLayout(grp_f)
        lbl_f = QLabel(
            "Field of the Streets layer holding the road categories, used to "
            "join the road widths. 'fclass', 'highway' or 'type' is selected "
            "automatically when present; otherwise choose the field here. "
            "Leave empty to auto-detect.")
        lbl_f.setStyleSheet("color:#555;font-size:9px;font-weight:normal;")
        lbl_f.setWordWrap(True)
        g_f.addWidget(lbl_f)
        self.combo_cat_field = QgsFieldComboBox()
        self.combo_cat_field.setAllowEmptyFieldName(True)
        g_f.addWidget(self.combo_cat_field)
        lay.addWidget(grp_f)

        self.combo_road.layerChanged.connect(self._on_road_layer_changed)
        self._on_road_layer_changed(self.combo_road.currentLayer())

        grp_crs = QGroupBox(
            "Target Coordinate Reference System (Projected, Meters - e.g. UTM for the urban area) *")
        grp_crs.setStyleSheet("QGroupBox{font-weight:bold;font-size:11px;color:#212121;}")
        g_crs = QVBoxLayout(grp_crs)
        self.crs_widget = QgsProjectionSelectionWidget()
        self.crs_widget.setCrs(QgsCoordinateReferenceSystem("EPSG:32736"))
        g_crs.addWidget(self.crs_widget)
        lay.addWidget(grp_crs)

        lay.addStretch()
        scroll = QScrollArea()
        scroll.setWidget(w)
        scroll.setWidgetResizable(True)
        return scroll

    # -----------------------------------------------------------------------
    def _tab_distances(self):
        w = QWidget()
        lay = QGridLayout(w)
        lay.setSpacing(10)
        lay.setContentsMargins(16, 16, 16, 16)

        header_lbl = QLabel("Network distance threshold for:")
        header_lbl.setStyleSheet("color:#000000;font-weight:bold;font-size:12px;")
        lay.addWidget(header_lbl, 0, 0, 1, 2)

        configs = [
            ("Open Public Spaces", 'spin_pos', 400),
            ("Low Capacity Transport Stops (Bus Stops, Light Rail Stops)", 'spin_bus', 500),
            ("High Capacity Transport Stops (Ferry Stops)", 'spin_ferry', 1000),
            ("High Capacity Transport Stops (Railway Stops, Metro Stops)", 'spin_rail', 1000),
        ]
        for row, (lbl, attr, default) in enumerate(configs, start=1):
            spin = QDoubleSpinBox()
            spin.setRange(1, 50000)
            spin.setValue(default)
            spin.setSuffix(" m")
            spin.setDecimals(0)
            spin.setMinimumWidth(90)
            spin.setMaximumWidth(140)
            setattr(self, attr, spin)
            q = QLabel(lbl)
            q.setWordWrap(True)
            lay.addWidget(q, row, 0)
            lay.addWidget(spin, row, 1)
        lay.setColumnStretch(0, 1)

        r = len(configs) + 1
        sp_lbl = QLabel("Open Public Spaces boundary point spacing:")
        sp_lbl.setStyleSheet("color:#000000;font-weight:bold;font-size:12px;")
        lay.addWidget(sp_lbl, r, 0, 1, 2)
        self.spin_pos_spacing = QDoubleSpinBox()
        self.spin_pos_spacing.setRange(10, 1000)
        self.spin_pos_spacing.setValue(100)
        self.spin_pos_spacing.setSuffix(" m")
        self.spin_pos_spacing.setDecimals(0)
        self.spin_pos_spacing.setMinimumWidth(90)
        self.spin_pos_spacing.setMaximumWidth(140)
        sp_note = QLabel(
            "Start points placed along each open space outline. 100 m is "
            "the standard; larger spacing (e.g. 200 m) is faster for cities "
            "with many large parks but slightly less precise.")
        sp_note.setWordWrap(True)
        sp_note.setStyleSheet("color:#555;font-size:9px;")
        lay.addWidget(sp_note, r + 1, 0)
        lay.addWidget(self.spin_pos_spacing, r + 1, 1)

        perf_lbl = QLabel("Performance:")
        perf_lbl.setStyleSheet("color:#000000;font-weight:bold;font-size:12px;")
        lay.addWidget(perf_lbl, r + 2, 0, 1, 2)
        def check(text, note, checked):
            box = QWidget()
            bl = QVBoxLayout(box)
            bl.setContentsMargins(0, 0, 0, 0)
            bl.setSpacing(1)
            cb = QCheckBox(text)
            cb.setChecked(checked)
            bl.addWidget(cb)
            nl = QLabel(note)
            nl.setWordWrap(True)
            nl.setStyleSheet("color:#555;font-size:9px;margin-left:20px;")
            bl.addWidget(nl)
            return cb, box

        self.chk_preclip, b1 = check(
            "Pre-clip inputs to the urban area",
            "Recommended. Keeps only streets, stops and open spaces within "
            "the search margin of the urban area - much faster with "
            "country/region-wide data.", True)
        self.chk_memory, b2 = check(
            "Keep intermediate layers in memory",
            "Faster. Untick only if the computer runs out of RAM.", True)
        self.chk_native_sa, b3 = check(
            "Use QGIS native Service Area algorithm",
            "For cross-checking only - very slow with many start points. "
            "Default is the fast bounded search (same results).", False)
        for i, b in enumerate((b1, b2, b3)):
            lay.addWidget(b, r + 3 + i, 0, 1, 2)

        lay.setRowStretch(r + 6, 1)
        return w

    # -----------------------------------------------------------------------
    def _tab_output(self):
        w = QWidget()
        lay = QVBoxLayout(w)
        lay.setSpacing(10)
        lay.setContentsMargins(16, 16, 16, 16)

        grp_city = QGroupBox("City Name (Hint: Avoid special characters)")
        g_city = QVBoxLayout(grp_city)
        self.city_edit = QLineEdit()
        self.city_edit.setPlaceholderText("e.g. Mombasa")
        g_city.addWidget(self.city_edit)
        lay.addWidget(grp_city)

        lay.addWidget(QLabel("Output folder:"))
        row_w = QHBoxLayout()
        self.output_edit = QLineEdit()
        self.output_edit.setText(os.path.expanduser("~/transport_sa_output"))
        browse_btn = QPushButton("Browse...")
        browse_btn.clicked.connect(self._browse_output)
        row_w.addWidget(self.output_edit)
        row_w.addWidget(browse_btn)
        lay.addLayout(row_w)

        info = QLabel(
            "Final files retained:\n"
            "  SA_POS_dissolved.shp                Open Public Spaces service area\n"
            "  SA_Bus_dissolved.shp                Low Capacity Transport Stops (Bus Stops, Light Rail Stops) service area\n"
            "  SA_Ferry_dissolved.shp              Ferry service area\n"
            "  SA_Rail_dissolved.shp               Rail service area\n"
            "  SA_HighCapacity_dissolved.shp       High-capacity SA\n"
            "  SA_CombinedTransport_dissolved.shp  Combined SA\n"
            "  ZonalStats_*.shp                    SA + pop_sum field\n"
            "  LAS_streets_dissolved.shp           Land Allocated to Streets\n"
            "  {city}_roads_clipped.csv            Roads with R_Length, R_Width\n"
            "  {city}_statistics_11.2.1_and_11.7.1.csv\n\n"
            "NOTES:\n"
            "  - Geometries are fixed automatically before processing.\n"
            "  - Open Public Spaces area measured after clipping to urban boundary.\n"
            "  - Inputs are pre-clipped to the urban area + search margin and\n"
            "    intermediates kept in memory (see Distances tab to change).\n"
            "  - Combined transport = Low Capacity Transport Stops (Bus Stops, Light Rail Stops) + ferry + rail (Open Public Spaces excluded).\n"
            "  - If no high-capacity, combined transport = Low Capacity Transport Stops (Bus Stops, Light Rail Stops) only.\n"
            "  - LAS: roads buffered by width, dissolved, clipped to urban extent.\n"
            "  - Stats add Land Allocated to Streets (km2), Open Public Space +\n"
            "    Land Allocated to Streets (km2) and its proportion of Urban Area (%).\n"
            "  - Use 'Reset Log' to clear log and re-enable buttons after failure.")
        info.setTextInteractionFlags(Qt.TextSelectableByMouse)
        info.setStyleSheet(
            "background:#f5f5f5;border:1px solid #ddd;padding:10px;"
            "font-family:Courier New;font-size:9px;border-radius:4px;"
        )
        lay.addWidget(info)
        lay.addStretch()
        return w

    # -----------------------------------------------------------------------
    def _browse_output(self):
        folder = QFileDialog.getExistingDirectory(
            self, "Select Output Folder", self.output_edit.text())
        if folder:
            self.output_edit.setText(folder)

    def _on_road_layer_changed(self, layer):
        """Refresh the road category field list for the chosen Streets
        layer and pre-select fclass / highway / type when available."""
        self.combo_cat_field.setLayer(layer)
        self.combo_cat_field.setField('')
        if layer is None:
            return
        names = {f.name().lower(): f.name() for f in layer.fields()}
        for cand in ROAD_CATEGORY_FIELDS:
            if cand in names:
                self.combo_cat_field.setField(names[cand])
                break

    def _browse_widths_csv(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "Select Measured Road Widths CSV", "",
            "CSV files (*.csv *.txt);;All files (*)")
        if not path:
            return
        uri = QUrl.fromLocalFile(path).toString() + \
            "?type=csv&detectTypes=yes&geomType=none"
        name = os.path.splitext(os.path.basename(path))[0]
        lyr = QgsVectorLayer(uri, name, "delimitedtext")
        if not lyr.isValid():
            lyr = QgsVectorLayer(path, name, "ogr")
        if not lyr.isValid():
            QMessageBox.warning(
                self, "Invalid CSV", "Could not read:\n{}".format(path))
            return
        QgsProject.instance().addMapLayer(lyr)
        self.combo_widths.setLayer(lyr)

    def _read_road_widths(self):
        """
        Read the measured road widths table (col 1 = category,
        col 2 = width in m) into {category_lower: width}. Done on the
        main thread so the worker never touches a project layer.
        Returns (dict, provided_flag).
        """
        lyr = self.combo_widths.currentLayer()
        if lyr is None:
            return {}, False
        if lyr.fields().count() < 2:
            QMessageBox.warning(
                self, "Road Widths CSV",
                "The road widths table needs at least two columns "
                "(road category, width). It will be ignored.")
            return {}, False
        widths = {}
        skipped = 0
        for feat in lyr.getFeatures():
            attrs = feat.attributes()
            cat, w = attrs[0], attrs[1]
            if cat is None or (hasattr(cat, 'isNull') and cat.isNull()):
                skipped += 1
                continue
            try:
                w = float(str(w).strip().replace(',', '.'))
            except (TypeError, ValueError):
                skipped += 1
                continue
            key = str(cat).strip().lower()
            if key and w > 0:
                widths[key] = w
            else:
                skipped += 1
        if skipped:
            self._log("Road widths CSV: {} row(s) skipped (empty category "
                      "or non-numeric/zero width).".format(skipped))
        return widths, True

    def _log(self, msg):
        self.log_box.append(msg)
        self.log_box.verticalScrollBar().setValue(
            self.log_box.verticalScrollBar().maximum())

    def _validate(self):
        if self.combo_road.currentLayer() is None:
            QMessageBox.warning(
                self,
                "Missing Layer",
                "Please select a Streets layer.")
            return False
        if self.combo_urban.currentLayer() is None:
            QMessageBox.warning(
                self,
                "Missing Layer",
                "Please select an Urban Boundary layer.")
            return False
        if self.combo_pop.currentLayer() is None:
            QMessageBox.warning(
                self,
                "Missing Layer",
                "Please select a Gridded Population (Raster) layer.")
            return False
        if not self.city_edit.text().strip():
            QMessageBox.warning(
                self,
                "Missing City Name",
                "Please enter a city name.")
            return False
        if not self.output_edit.text().strip():
            QMessageBox.warning(
                self,
                "Missing Output",
                "Please select an output folder.")
            return False
        if not self.crs_widget.crs().isValid():
            QMessageBox.warning(
                self,
                "Invalid CRS",
                "Please select a valid target CRS.")
            return False
        has_any = any([
            self.combo_pos.currentLayer(),
            self.combo_bus.currentLayer(),
            self.combo_ferry.currentLayer(),
            self.combo_rail.currentLayer(),
        ])
        if not has_any:
            reply = QMessageBox.question(
                self, "No Transport Layers",
                "No Open Public Spaces/Low Capacity Transport Stops (Bus Stops, Light Rail Stops)/Ferry/Rail layers selected. Only urban area and streets will be processed. Continue?",
                QMessageBox.Yes | QMessageBox.No)
            if reply == QMessageBox.No:
                return False
        return True

    def run_analysis(self):
        if not self._validate():
            return
        self.log_box.clear()
        self.progress_bar.setValue(0)
        self.run_btn.setEnabled(False)
        self.cancel_btn.setEnabled(True)
        self.reset_btn.setEnabled(False)

        road_widths, widths_provided = self._read_road_widths()

        params = {
            'road_widths': road_widths,
            'road_widths_provided': widths_provided,
            'road_cat_field': self.combo_cat_field.currentField() or '',
            'road_layer': self.combo_road.currentLayer(),
            'pos_layer': self.combo_pos.currentLayer(),
            'bus_layer': self.combo_bus.currentLayer(),
            'ferry_layer': self.combo_ferry.currentLayer(),
            'rail_layer': self.combo_rail.currentLayer(),
            'urban_layer': self.combo_urban.currentLayer(),
            'pop_raster': self.combo_pop.currentLayer(),
            'crs': self.crs_widget.crs(),
            'city_name': self.city_edit.text().strip(),
            'output_dir': self.output_edit.text().strip(),
            'dist_pos': self.spin_pos.value(),
            'dist_bus': self.spin_bus.value(),
            'dist_ferry': self.spin_ferry.value(),
            'dist_rail': self.spin_rail.value(),
            'pos_spacing': self.spin_pos_spacing.value(),
            'preclip': self.chk_preclip.isChecked(),
            'use_memory': self.chk_memory.isChecked(),
            'native_sa': self.chk_native_sa.isChecked(),
        }

        self.worker = SAWorker(params)
        self.worker.log.connect(self._log)
        self.worker.progress.connect(self.progress_bar.setValue)
        self.worker.finished.connect(self._on_finished)
        self.worker.start()

    def cancel_analysis(self):
        if self.worker:
            self.worker.cancel()
            self._log("Cancellation requested...")
        self.cancel_btn.setEnabled(False)

    def _on_finished(self, success, message):
        self.run_btn.setEnabled(True)
        self.cancel_btn.setEnabled(False)
        self.reset_btn.setEnabled(True)
        if success:
            self._log("\nDONE: " + message)
            QMessageBox.information(self, "Complete", message)
        else:
            self._log("\nERROR:\n" + message)
            QMessageBox.critical(self,
                                 "Error",
                                 "Analysis failed. See log for details.\n\n"
                                 "Click 'Reset Log' to clear and run again.\n\n" + message[:500])

    def closeEvent(self, event):
        if self.worker and self.worker.isRunning():
            reply = QMessageBox.question(
                self, "Running",
                "Analysis is still running. Cancel and close?",
                QMessageBox.Yes | QMessageBox.No)
            if reply == QMessageBox.Yes:
                self.worker.cancel()
                self.worker.wait(3000)
                event.accept()
            else:
                event.ignore()
        else:
            event.accept()
