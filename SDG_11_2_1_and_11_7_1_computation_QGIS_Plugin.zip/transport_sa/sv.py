# -*- coding: utf-8 -*-
"""Svenska."""

TEXT = {
    'win_title': 'Beräkning av statistik för SDG 11.2.1 och 11.7.1',
    'subtitle': 'Förklippning till tätortsområdet -> Omprojicering + '
                'geometrikorrigering -> Klippning av öppna offentliga platser -> '
                'Gränspunkter -> Serviceområde -> Konvext hölje -> Klippning -> '
                'Sammanslagning -> Befolkning i upptagningsområden -> Koppling av '
                'gatubredder -> Buffert -> Sammanslagning -> Klippning (mark '
                'avsatt för gator) -> Statistiktabell',
    'language': 'Språk:',
    'tab_layers': 'Lager',
    'tab_distances': 'Avstånd',
    'tab_output': 'Utdata',
    'progress': 'Förlopp',
    'btn_run': 'Kör analys',
    'btn_cancel': 'Avbryt',
    'btn_reset': 'Rensa logg',
    'btn_close': 'Stäng',
    'grp_streets': 'Gator',
    'note_streets': 'Gatulager som används för ruttberäkning i nätverket',
    'grp_urban': 'Tätortsgräns',
    'note_urban': 'Polygonlager som avgränsar tätortsområdet',
    'grp_pop_raster': 'Rutnätsbefolkning (raster)',
    'note_pop_raster': 'Befolkningsdata i rutnät. Ange detta ELLER '
                       'Hushållsbefolkning (punkter) nedan - ett av dem krävs.',
    'grp_hh': 'Hushållsbefolkning (punkter)',
    'note_hh': 'Punktlager med antal invånare per hushåll. Ange detta ELLER '
               'befolkningsrastret - ett av dem krävs. Om båda anges används '
               'hushållspunkterna. Befolkning i varje upptagningsområde = summan '
               'av det valda fältet för punkterna inom området.',
    'lbl_pop_field': 'Fält med total befolkning (per hushållspunkt):',
    'grp_pos': 'Öppna offentliga platser (polygoner)',
    'note_pos': 'Polygonlager med obebyggd eller öppen mark som är tillgänglig '
                'för allmänheten, ger invånarna rekreationsytor och förbättrar '
                'miljökvaliteten. Exempel: parker, trädgårdar, lekplatser, '
                'allmänna stränder, åstränder och strandpromenader',
    'grp_bus': 'Hållplatser för kollektivtrafik med låg kapacitet '
               '(busshållplatser, spårvägshållplatser)',
    'note_bus': 'Punktlager med buss- / spårvägshållplatser',
    'grp_rail': 'Hållplatser för kollektivtrafik med hög kapacitet '
                '(järnvägsstationer, tunnelbanestationer)',
    'note_rail': 'Punktlager med järnvägs- / tunnelbanestationer',
    'grp_ferry': 'Hållplatser för kollektivtrafik med hög kapacitet '
                 '(färjelägen)',
    'note_ferry': 'Punktlager med färjeterminaler',
    'grp_widths': 'Uppmätta gatubredder (CSV-tabell)',
    'note_widths': 'Används för mark avsatt för gator. Kolumn 1 = vägkategori '
                   '(matchas mot fältet för vägkategori som väljs nedan), '
                   'kolumn 2 = uppmätt gatubredd i meter. Om ingen CSV anges och '
                   'inget kategorifält finns blir mark avsatt för gator = 0.',
    'btn_browse_csv': 'Bläddra CSV...',
    'grp_catfield': 'Fält för vägkategori (gatulager)',
    'note_catfield': 'Fält i gatulagret med vägkategorierna, används för att '
                     'koppla gatubredderna. \'fclass\', \'highway\' eller '
                     '\'type\' väljs automatiskt om det finns; annars väljer du '
                     'fältet här. Lämna tomt för automatisk identifiering.',
    'grp_crs': 'Målkoordinatsystem (projicerat, i meter - t.ex. UTM för '
               'tätortsområdet)',
    'dist_header': 'Tröskelvärde för nätverksavstånd för:',
    'dist_pos': 'Öppna offentliga platser',
    'spacing_header': 'Avstånd mellan gränspunkter för öppna offentliga '
                      'platser:',
    'spacing_note': 'Startpunkter längs varje öppen plats kontur. 100 m är '
                    'standard; större avstånd (t.ex. 200 m) går snabbare för '
                    'städer med många stora parker men blir något mindre '
                    'exakt.',
    'perf_header': 'Prestanda:',
    'chk_preclip': 'Förklipp indata till tätortsområdet',
    'note_preclip': 'Rekommenderas. Behåller bara gator, hållplatser och öppna '
                    'platser inom sökmarginalen kring tätortsområdet - mycket '
                    'snabbare med data för hela landet eller regionen.',
    'chk_memory': 'Behåll mellanlager i minnet',
    'note_memory': 'Snabbare. Avmarkera bara om datorn får slut på RAM-minne.',
    'chk_native': 'Använd QGIS inbyggda algoritm för serviceområde',
    'note_native': 'Endast för kontroll - mycket långsamt med många '
                   'startpunkter. Standard är den snabba begränsade sökningen '
                   '(samma resultat).',
    'grp_city': 'Stadens namn (tips: undvik specialtecken)',
    'city_placeholder': 't.ex. Mombasa',
    'lbl_output_folder': 'Utdatamapp:',
    'btn_browse': 'Bläddra...',
    'info_block':
        "Slutliga filer som sparas:\n"
        "  Klippta och sammanslagna upptagningsområden:\n"
        "  SA_POS_dissolved.shp                Öppna offentliga platser\n"
        "  SA_Bus_dissolved.shp                Hållplatser med låg kapacitet\n"
        "  SA_Ferry_dissolved.shp              Färjelägen\n"
        "  SA_Rail_dissolved.shp               Järnvägsstationer\n"
        "  SA_HighCapacity_dissolved.shp       Hög kapacitet (järnväg + färja)\n"
        "  SA_CombinedTransport_dissolved.shp  Kollektivtrafik totalt\n"
        "  Enskilda serviceområden (per hållplats):\n"
        "  SA_Bus_individual.shp / SA_Ferry_individual.shp / SA_Rail_individual.shp\n"
        "  ZonalStats_*.shp                    Upptagningsområde + fältet pop_sum\n"
        "  LAS_streets_dissolved.shp           Mark avsatt för gator\n"
        "  {city}_statistics_11.2.1_and_11.7.1.xlsx\n\n"
        "ANMÄRKNINGAR:\n"
        "  - Geometrier korrigeras automatiskt före bearbetningen.\n"
        "  - Befolkning: hushållspunkter (summan av befolkningsfältet) om de\n"
        "    anges, annars befolkningsrastret.\n"
        "  - Ytan för öppna offentliga platser mäts efter klippning mot tätortsgränsen.\n"
        "  - Indata förklipps till tätortsområdet + sökmarginal och mellanlager\n"
        "    hålls i minnet (se fliken Avstånd).\n"
        "  - Kollektivtrafik totalt = låg kapacitet + färja + järnväg\n"
        "    (öppna offentliga platser ingår inte).\n"
        "  - Mark avsatt för gator: gator buffrade efter bredd, sammanslagna\n"
        "    och klippta mot tätortsområdet.\n"
        "  - Statistiktabellen skrivs på det valda språket.\n"
        "  - Använd ”Rensa logg” för att aktivera knapparna igen efter ett fel.",
    'msg_running_title': 'Körs',
    'msg_cannot_reset': 'Det går inte att rensa medan analysen körs. Avbryt '
                        'först.',
    'msg_missing_layer': 'Lager saknas',
    'msg_select_streets': 'Välj ett gatulager.',
    'msg_select_urban': 'Välj ett lager för tätortsgränsen.',
    'msg_missing_pop_title': 'Befolkningsdata saknas',
    'msg_missing_pop': 'Välj ett lager med rutnätsbefolkning (raster) eller '
                       'hushållsbefolkning (punkter) - ett av dem krävs.',
    'msg_missing_popfield_title': 'Befolkningsfält saknas',
    'msg_missing_popfield': 'Välj fältet med total befolkning för lagret med '
                            'hushållsbefolkning (punkter).',
    'msg_missing_city_title': 'Stadens namn saknas',
    'msg_missing_city': 'Ange stadens namn.',
    'msg_missing_output_title': 'Utdatamapp saknas',
    'msg_missing_output': 'Välj en utdatamapp.',
    'msg_invalid_crs_title': 'Ogiltigt koordinatsystem',
    'msg_invalid_crs': 'Välj ett giltigt målkoordinatsystem.',
    'msg_no_transport_title': 'Inga trafiklager',
    'msg_no_transport': 'Inget lager för öppna offentliga platser / låg '
                        'kapacitet / färja / järnväg har valts. Endast '
                        'tätortsområdet och gatorna bearbetas. Fortsätta?',
    'msg_complete': 'Klart',
    'msg_error': 'Fel',
    'msg_failed': 'Analysen misslyckades. Se loggen för detaljer.\n\n'
                  'Klicka på ”Rensa logg” och kör igen.',
    'msg_close_running': 'Analysen körs fortfarande. Avbryta och stänga?',
    'msg_cancel_requested': 'Avbrott begärt...',
    'dlg_select_output': 'Välj utdatamapp',
    'dlg_select_csv': 'Välj CSV med uppmätta gatubredder',
    'csv_filter': 'CSV-filer (*.csv *.txt);;Alla filer (*)',
    'msg_invalid_csv_title': 'Ogiltig CSV',
    'msg_invalid_csv': 'Kunde inte läsas:',
    'msg_widths_title': 'CSV med gatubredder',
    'msg_widths_cols': 'Tabellen med gatubredder måste ha minst två kolumner '
                       '(vägkategori, bredd). Den ignoreras.',
    'res_done': 'Klart!',
    'res_las': 'Mark avsatt för gator',
    'res_stats': 'Statistiktabell (CSV)',
    'res_excel': 'Statistikarbetsbok (Excel)',
    'res_roads': 'Gatutabell',
    'res_folder': 'Mapp',
    'res_time': 'Tid',
    'h_city': 'Stad',
    'h_urban_area': 'Tätortsyta (km2)',
    'h_pos_area': 'Yta för öppna offentliga platser (km2)',
    'h_las': 'Mark avsatt för gator (km2)',
    'h_ops_las': 'Öppna offentliga platser + mark avsatt för gator (km2)',
    'h_prop_ops_las': 'Andel av tätortsytan med öppna offentliga platser + '
                      'mark avsatt för gator (%)',
    'h_total_pop': 'Total befolkning i tätorten',
    'h_pop_pos': 'Befolkning med tillgång till öppna offentliga platser',
    'h_pop_bus': 'Befolkning med tillgång till hållplatser för kollektivtrafik '
                 'med låg kapacitet (busshållplatser, spårvägshållplatser)',
    'h_pop_hc': 'Befolkning med tillgång till kollektivtrafik med hög '
                'kapacitet (järnväg + färja)',
    'h_pop_comb': 'Befolkning med tillgång till kollektivtrafik totalt',
    'h_pct_pos': 'Andel av befolkningen med tillgång till öppna offentliga '
                 'platser (%)',
    'h_pct_bus': 'Andel av befolkningen med tillgång till hållplatser för '
                 'kollektivtrafik med låg kapacitet (busshållplatser, '
                 'spårvägshållplatser) (%)',
    'h_pct_hc': 'Andel av befolkningen med tillgång till kollektivtrafik med '
                'hög kapacitet (%)',
    'h_pct_comb': 'Andel av befolkningen med tillgång till kollektivtrafik '
                  'totalt (%)',
    'h_pop_source': 'Källa för befolkningsdata',
    'src_household': 'Hushållspunkter',
    'src_raster': 'Befolkningsraster',
    'src_field': 'fält',
}
