# -*- coding: utf-8 -*-
"""
Translated names of the output files (shapefiles and the Excel workbook)
and of the workbook's sheets, one entry per interface language.

Templates:
  sa_dissolved   clipped + dissolved catchment, e.g. SA_{mode}_dissolved
  sa_individual  per-stop service areas,        e.g. SA_{mode}_individual
  sa_clipped     service areas clipped to the urban boundary, not dissolved
  sa_merged      high-capacity / combined: modes merged, not dissolved
  sa_unclipped   high-capacity / combined: dissolved, not yet clipped
  zonal          catchment with pop_sum field,  e.g. ZonalStats_{mode}_SA
  las            Land Allocated to Streets polygon
  stats          the Excel workbook ({city} is the city name)
Mode names fill {mode}. Sheet names must be 31 characters or fewer.
Characters that are not allowed in file names are replaced automatically.
"""

import re

FILE_NAMES = {
    'en': {
        'sa_dissolved': 'SA_{mode}_dissolved',
        'sa_clipped': 'SA_{mode}_clipped',
        'sa_merged': 'SA_{mode}_merged',
        'sa_unclipped': 'SA_{mode}_dissolved_unclipped',
        'sa_individual': 'SA_{mode}_individual',
        'zonal': 'ZonalStats_{mode}_SA',
        'las': 'LAS_streets_dissolved',
        'stats': '{city}_statistics_11.2.1_and_11.7.1',
        'm_pos': 'POS', 'm_bus': 'Bus', 'm_ferry': 'Ferry', 'm_rail': 'Rail',
        'm_hc': 'HighCapacity', 'm_comb': 'CombinedTransport',
        'sheet_stats': 'Statistics', 'sheet_roads': 'Roads',
    },
    'fr': {
        'sa_dissolved': 'ZD_{mode}_fusionnée',
        'sa_clipped': 'ZD_{mode}_découpée',
        'sa_merged': 'ZD_{mode}_assemblée',
        'sa_unclipped': 'ZD_{mode}_fusionnée_non_découpée',
        'sa_individual': 'ZD_{mode}_individuelle',
        'zonal': 'Population_{mode}_ZD',
        'las': 'Superficie_rues_fusionnée',
        'stats': '{city}_statistiques_11.2.1_et_11.7.1',
        'm_pos': 'EspacesPublicsOuverts', 'm_bus': 'FaibleCapacité',
        'm_ferry': 'Ferry', 'm_rail': 'Rail', 'm_hc': 'GrandeCapacité',
        'm_comb': 'TransportsCombinés',
        'sheet_stats': 'Statistiques', 'sheet_roads': 'Rues',
    },
    'es': {
        'sa_dissolved': 'AS_{mode}_disuelta',
        'sa_clipped': 'AS_{mode}_recortada',
        'sa_merged': 'AS_{mode}_combinada',
        'sa_unclipped': 'AS_{mode}_disuelta_sin_recortar',
        'sa_individual': 'AS_{mode}_individual',
        'zonal': 'Población_{mode}_AS',
        'las': 'Superficie_calles_disuelta',
        'stats': '{city}_estadísticas_11.2.1_y_11.7.1',
        'm_pos': 'EspaciosPúblicosAbiertos', 'm_bus': 'BajaCapacidad',
        'm_ferry': 'Ferry', 'm_rail': 'Ferrocarril', 'm_hc': 'AltaCapacidad',
        'm_comb': 'TransporteCombinado',
        'sheet_stats': 'Estadísticas', 'sheet_roads': 'Calles',
    },
    'it': {
        'sa_dissolved': 'AS_{mode}_dissolta',
        'sa_clipped': 'AS_{mode}_ritagliata',
        'sa_merged': 'AS_{mode}_unita',
        'sa_unclipped': 'AS_{mode}_dissolta_non_ritagliata',
        'sa_individual': 'AS_{mode}_individuale',
        'zonal': 'Popolazione_{mode}_AS',
        'las': 'Superficie_strade_dissolta',
        'stats': '{city}_statistiche_11.2.1_e_11.7.1',
        'm_pos': 'SpaziPubbliciAperti', 'm_bus': 'BassaCapacità',
        'm_ferry': 'Traghetto', 'm_rail': 'Ferrovia', 'm_hc': 'AltaCapacità',
        'm_comb': 'TrasportoCombinato',
        'sheet_stats': 'Statistiche', 'sheet_roads': 'Strade',
    },
    'zh': {
        'sa_dissolved': '服务区_{mode}_融合',
        'sa_clipped': '服务区_{mode}_裁剪',
        'sa_merged': '服务区_{mode}_合并',
        'sa_unclipped': '服务区_{mode}_融合_未裁剪',
        'sa_individual': '服务区_{mode}_单站',
        'zonal': '人口_{mode}_服务区',
        'las': '街道用地_融合',
        'stats': '{city}_统计_11.2.1_和_11.7.1',
        'm_pos': '公共开放空间', 'm_bus': '低运量交通', 'm_ferry': '渡轮',
        'm_rail': '铁路', 'm_hc': '大运量交通', 'm_comb': '综合公共交通',
        'sheet_stats': '统计', 'sheet_roads': '道路',
    },
    'ar': {
        'sa_dissolved': 'منطقة_خدمة_{mode}_مدمجة',
        'sa_clipped': 'منطقة_خدمة_{mode}_مقصوصة',
        'sa_merged': 'منطقة_خدمة_{mode}_مجمعة',
        'sa_unclipped': 'منطقة_خدمة_{mode}_مدمجة_غير_مقصوصة',
        'sa_individual': 'منطقة_خدمة_{mode}_فردية',
        'zonal': 'السكان_{mode}',
        'las': 'المساحة_المخصصة_للشوارع',
        'stats': '{city}_إحصاءات_11.2.1_و_11.7.1',
        'm_pos': 'الأماكن_العامة_المفتوحة', 'm_bus': 'النقل_منخفض_السعة',
        'm_ferry': 'العبارات', 'm_rail': 'السكك_الحديدية',
        'm_hc': 'النقل_عالي_السعة', 'm_comb': 'النقل_العام_المجمع',
        'sheet_stats': 'الإحصاءات', 'sheet_roads': 'الطرق',
    },
    'pt': {
        'sa_dissolved': 'AS_{mode}_dissolvida',
        'sa_clipped': 'AS_{mode}_recortada',
        'sa_merged': 'AS_{mode}_combinada',
        'sa_unclipped': 'AS_{mode}_dissolvida_sem_recorte',
        'sa_individual': 'AS_{mode}_individual',
        'zonal': 'População_{mode}_AS',
        'las': 'Área_ruas_dissolvida',
        'stats': '{city}_estatísticas_11.2.1_e_11.7.1',
        'm_pos': 'EspaçosPúblicosAbertos', 'm_bus': 'BaixaCapacidade',
        'm_ferry': 'Ferry', 'm_rail': 'Ferrovia', 'm_hc': 'AltaCapacidade',
        'm_comb': 'TransporteCombinado',
        'sheet_stats': 'Estatísticas', 'sheet_roads': 'Ruas',
    },
    'de': {
        'sa_dissolved': 'EB_{mode}_aufgelöst',
        'sa_clipped': 'EB_{mode}_zugeschnitten',
        'sa_merged': 'EB_{mode}_zusammengeführt',
        'sa_unclipped': 'EB_{mode}_aufgelöst_ungeschnitten',
        'sa_individual': 'EB_{mode}_einzeln',
        'zonal': 'Bevölkerung_{mode}_EB',
        'las': 'Straßenfläche_aufgelöst',
        'stats': '{city}_Statistik_11.2.1_und_11.7.1',
        'm_pos': 'ÖffentlicheFreiflächen', 'm_bus': 'GeringeKapazität',
        'm_ferry': 'Fähre', 'm_rail': 'Bahn', 'm_hc': 'HoheKapazität',
        'm_comb': 'ÖVGesamt',
        'sheet_stats': 'Statistik', 'sheet_roads': 'Straßen',
    },
    'ru': {
        'sa_dissolved': 'ЗО_{mode}_объединённая',
        'sa_clipped': 'ЗО_{mode}_обрезанная',
        'sa_merged': 'ЗО_{mode}_совмещённая',
        'sa_unclipped': 'ЗО_{mode}_объединённая_необрезанная',
        'sa_individual': 'ЗО_{mode}_отдельные',
        'zonal': 'Население_{mode}_ЗО',
        'las': 'Территория_под_улицами',
        'stats': '{city}_статистика_11.2.1_и_11.7.1',
        'm_pos': 'Открытые_пространства', 'm_bus': 'Малая_вместимость',
        'm_ferry': 'Паром', 'm_rail': 'Железная_дорога',
        'm_hc': 'Большая_вместимость', 'm_comb': 'Транспорт_в_целом',
        'sheet_stats': 'Статистика', 'sheet_roads': 'Улицы',
    },
    'ja': {
        'sa_dissolved': 'サービスエリア_{mode}_ディゾルブ',
        'sa_clipped': 'サービスエリア_{mode}_クリップ',
        'sa_merged': 'サービスエリア_{mode}_マージ',
        'sa_unclipped': 'サービスエリア_{mode}_ディゾルブ_未クリップ',
        'sa_individual': 'サービスエリア_{mode}_個別',
        'zonal': '人口_{mode}_圏域',
        'las': '道路用地_ディゾルブ',
        'stats': '{city}_統計_11.2.1_11.7.1',
        'm_pos': '公共オープンスペース', 'm_bus': '低輸送力', 'm_ferry': 'フェリー',
        'm_rail': '鉄道', 'm_hc': '高輸送力', 'm_comb': '公共交通全体',
        'sheet_stats': '統計', 'sheet_roads': '道路',
    },
    'sw': {
        'sa_dissolved': 'EH_{mode}_iliyounganishwa',
        'sa_clipped': 'EH_{mode}_iliyokatwa',
        'sa_merged': 'EH_{mode}_iliyokusanywa',
        'sa_unclipped': 'EH_{mode}_iliyounganishwa_bila_kukatwa',
        'sa_individual': 'EH_{mode}_kila_kituo',
        'zonal': 'IdadiYaWatu_{mode}_EH',
        'las': 'Ardhi_ya_barabara',
        'stats': '{city}_takwimu_11.2.1_na_11.7.1',
        'm_pos': 'MaeneoYaWaziYaUmma', 'm_bus': 'UwezoMdogo',
        'm_ferry': 'Kivuko', 'm_rail': 'Reli', 'm_hc': 'UwezoMkubwa',
        'm_comb': 'UsafiriWaUmmaJumla',
        'sheet_stats': 'Takwimu', 'sheet_roads': 'Barabara',
    },
    'sv': {
        'sa_dissolved': 'SO_{mode}_sammanslagen',
        'sa_clipped': 'SO_{mode}_urklippt',
        'sa_merged': 'SO_{mode}_sammanfogad',
        'sa_unclipped': 'SO_{mode}_sammanslagen_ej_urklippt',
        'sa_individual': 'SO_{mode}_enskilda',
        'zonal': 'Befolkning_{mode}_SO',
        'las': 'Gatumark_sammanslagen',
        'stats': '{city}_statistik_11.2.1_och_11.7.1',
        'm_pos': 'ÖppnaOffentligaPlatser', 'm_bus': 'LågKapacitet',
        'm_ferry': 'Färja', 'm_rail': 'Järnväg', 'm_hc': 'HögKapacitet',
        'm_comb': 'KollektivtrafikTotalt',
        'sheet_stats': 'Statistik', 'sheet_roads': 'Gator',
    },
    'nb': {
        'sa_dissolved': 'SO_{mode}_sammenslått',
        'sa_clipped': 'SO_{mode}_klippet',
        'sa_merged': 'SO_{mode}_sammenføyd',
        'sa_unclipped': 'SO_{mode}_sammenslått_uklippet',
        'sa_individual': 'SO_{mode}_enkeltvis',
        'zonal': 'Befolkning_{mode}_SO',
        'las': 'Gateareal_sammenslått',
        'stats': '{city}_statistikk_11.2.1_og_11.7.1',
        'm_pos': 'ÅpneOffentligeRom', 'm_bus': 'LavKapasitet',
        'm_ferry': 'Ferge', 'm_rail': 'Jernbane', 'm_hc': 'HøyKapasitet',
        'm_comb': 'KollektivSamlet',
        'sheet_stats': 'Statistikk', 'sheet_roads': 'Gater',
    },
    'da': {
        'sa_dissolved': 'SO_{mode}_sammenlagt',
        'sa_clipped': 'SO_{mode}_klippet',
        'sa_merged': 'SO_{mode}_flettet',
        'sa_unclipped': 'SO_{mode}_sammenlagt_uklippet',
        'sa_individual': 'SO_{mode}_individuel',
        'zonal': 'Befolkning_{mode}_SO',
        'las': 'Gadeareal_sammenlagt',
        'stats': '{city}_statistik_11.2.1_og_11.7.1',
        'm_pos': 'ÅbneOffentligeRum', 'm_bus': 'LavKapacitet',
        'm_ferry': 'Færge', 'm_rail': 'Tog', 'm_hc': 'HøjKapacitet',
        'm_comb': 'KollektivSamlet',
        'sheet_stats': 'Statistik', 'sheet_roads': 'Gader',
    },
    'hi': {
        'sa_dissolved': 'सेवा_क्षेत्र_{mode}_विलय',
        'sa_clipped': 'सेवा_क्षेत्र_{mode}_क्लिप',
        'sa_merged': 'सेवा_क्षेत्र_{mode}_संयोजित',
        'sa_unclipped': 'सेवा_क्षेत्र_{mode}_विलय_बिना_क्लिप',
        'sa_individual': 'सेवा_क्षेत्र_{mode}_अलग',
        'zonal': 'जनसंख्या_{mode}',
        'las': 'सड़क_भूमि_विलय',
        'stats': '{city}_सांख्यिकी_11.2.1_और_11.7.1',
        'm_pos': 'सार्वजनिक_खुले_स्थान', 'm_bus': 'कम_क्षमता', 'm_ferry': 'फ़ेरी',
        'm_rail': 'रेल', 'm_hc': 'उच्च_क्षमता', 'm_comb': 'संयुक्त_परिवहन',
        'sheet_stats': 'सांख्यिकी', 'sheet_roads': 'सड़कें',
    },
    'bn': {
        'sa_dissolved': 'সেবা_এলাকা_{mode}_একীভূত',
        'sa_clipped': 'সেবা_এলাকা_{mode}_ক্লিপকৃত',
        'sa_merged': 'সেবা_এলাকা_{mode}_সংযুক্ত',
        'sa_unclipped': 'সেবা_এলাকা_{mode}_একীভূত_ক্লিপবিহীন',
        'sa_individual': 'সেবা_এলাকা_{mode}_পৃথক',
        'zonal': 'জনসংখ্যা_{mode}',
        'las': 'রাস্তার_জমি_একীভূত',
        'stats': '{city}_পরিসংখ্যান_11.2.1_ও_11.7.1',
        'm_pos': 'উন্মুক্ত_জনপরিসর', 'm_bus': 'স্বল্প_ধারণক্ষমতা', 'm_ferry': 'ফেরি',
        'm_rail': 'রেল', 'm_hc': 'উচ্চ_ধারণক্ষমতা', 'm_comb': 'সমন্বিত_পরিবহন',
        'sheet_stats': 'পরিসংখ্যান', 'sheet_roads': 'রাস্তা',
    },
    'ur': {
        'sa_dissolved': 'سروس_ایریا_{mode}_ضم_شدہ',
        'sa_clipped': 'سروس_ایریا_{mode}_کلپ_شدہ',
        'sa_merged': 'سروس_ایریا_{mode}_یکجا',
        'sa_unclipped': 'سروس_ایریا_{mode}_ضم_شدہ_بغیر_کلپ',
        'sa_individual': 'سروس_ایریا_{mode}_انفرادی',
        'zonal': 'آبادی_{mode}',
        'las': 'سڑکوں_کی_زمین',
        'stats': '{city}_اعداد_و_شمار_11.2.1_اور_11.7.1',
        'm_pos': 'عوامی_کھلی_جگہیں', 'm_bus': 'کم_گنجائش', 'm_ferry': 'فیری',
        'm_rail': 'ریل', 'm_hc': 'زیادہ_گنجائش', 'm_comb': 'مجموعی_ٹرانسپورٹ',
        'sheet_stats': 'اعداد و شمار', 'sheet_roads': 'سڑکیں',
    },
    'pa': {
        'sa_dissolved': 'ਸੇਵਾ_ਖੇਤਰ_{mode}_ਰਲੇਵਾਂ',
        'sa_clipped': 'ਸੇਵਾ_ਖੇਤਰ_{mode}_ਕਲਿੱਪ',
        'sa_merged': 'ਸੇਵਾ_ਖੇਤਰ_{mode}_ਜੋੜੇ',
        'sa_unclipped': 'ਸੇਵਾ_ਖੇਤਰ_{mode}_ਰਲੇਵਾਂ_ਬਿਨਾਂ_ਕਲਿੱਪ',
        'sa_individual': 'ਸੇਵਾ_ਖੇਤਰ_{mode}_ਵੱਖਰੇ',
        'zonal': 'ਆਬਾਦੀ_{mode}',
        'las': 'ਸੜਕ_ਜ਼ਮੀਨ_ਰਲੇਵਾਂ',
        'stats': '{city}_ਅੰਕੜੇ_11.2.1_ਅਤੇ_11.7.1',
        'm_pos': 'ਜਨਤਕ_ਖੁੱਲ੍ਹੀਆਂ_ਥਾਵਾਂ', 'm_bus': 'ਘੱਟ_ਸਮਰੱਥਾ', 'm_ferry': 'ਫੈਰੀ',
        'm_rail': 'ਰੇਲ', 'm_hc': 'ਉੱਚ_ਸਮਰੱਥਾ', 'm_comb': 'ਸੰਯੁਕਤ_ਆਵਾਜਾਈ',
        'sheet_stats': 'ਅੰਕੜੇ', 'sheet_roads': 'ਸੜਕਾਂ',
    },
    'mr': {
        'sa_dissolved': 'सेवा_क्षेत्र_{mode}_विलीन',
        'sa_clipped': 'सेवा_क्षेत्र_{mode}_क्लिप',
        'sa_merged': 'सेवा_क्षेत्र_{mode}_एकत्रित',
        'sa_unclipped': 'सेवा_क्षेत्र_{mode}_विलीन_क्लिपविना',
        'sa_individual': 'सेवा_क्षेत्र_{mode}_स्वतंत्र',
        'zonal': 'लोकसंख्या_{mode}',
        'las': 'रस्ता_जमीन_विलीन',
        'stats': '{city}_सांख्यिकी_11.2.1_आणि_11.7.1',
        'm_pos': 'सार्वजनिक_खुल्या_जागा', 'm_bus': 'कमी_क्षमता', 'm_ferry': 'फेरी',
        'm_rail': 'रेल्वे', 'm_hc': 'उच्च_क्षमता', 'm_comb': 'एकत्रित_वाहतूक',
        'sheet_stats': 'सांख्यिकी', 'sheet_roads': 'रस्ते',
    },
    'te': {
        'sa_dissolved': 'సేవా_ప్రాంతం_{mode}_విలీనం',
        'sa_clipped': 'సేవా_ప్రాంతం_{mode}_క్లిప్',
        'sa_merged': 'సేవా_ప్రాంతం_{mode}_కలిపిన',
        'sa_unclipped': 'సేవా_ప్రాంతం_{mode}_విలీనం_క్లిప్_లేని',
        'sa_individual': 'సేవా_ప్రాంతం_{mode}_వేర్వేరు',
        'zonal': 'జనాభా_{mode}',
        'las': 'వీధుల_భూమి_విలీనం',
        'stats': '{city}_గణాంకాలు_11.2.1_మరియు_11.7.1',
        'm_pos': 'బహిరంగ_ప్రజా_స్థలాలు', 'm_bus': 'తక్కువ_సామర్థ్యం',
        'm_ferry': 'ఫెర్రీ', 'm_rail': 'రైలు', 'm_hc': 'అధిక_సామర్థ్యం',
        'm_comb': 'సమ్మిళిత_రవాణా',
        'sheet_stats': 'గణాంకాలు', 'sheet_roads': 'వీధులు',
    },
    'ta': {
        'sa_dissolved': 'சேவைப்பகுதி_{mode}_ஒன்றிணைத்தது',
        'sa_clipped': 'சேவைப்பகுதி_{mode}_வெட்டியது',
        'sa_merged': 'சேவைப்பகுதி_{mode}_சேர்த்தது',
        'sa_unclipped': 'சேவைப்பகுதி_{mode}_ஒன்றிணைத்தது_வெட்டாதது',
        'sa_individual': 'சேவைப்பகுதி_{mode}_தனித்தனி',
        'zonal': 'மக்கள்தொகை_{mode}',
        'las': 'தெரு_நிலம்_ஒன்றிணைத்தது',
        'stats': '{city}_புள்ளிவிவரம்_11.2.1_மற்றும்_11.7.1',
        'm_pos': 'பொது_திறந்தவெளிகள்', 'm_bus': 'குறைந்த_திறன்',
        'm_ferry': 'படகு', 'm_rail': 'ரயில்', 'm_hc': 'உயர்_திறன்',
        'm_comb': 'ஒருங்கிணைந்த_போக்குவரத்து',
        'sheet_stats': 'புள்ளிவிவரம்', 'sheet_roads': 'தெருக்கள்',
    },
    'gu': {
        'sa_dissolved': 'સેવા_વિસ્તાર_{mode}_વિલય',
        'sa_clipped': 'સેવા_વિસ્તાર_{mode}_ક્લિપ',
        'sa_merged': 'સેવા_વિસ્તાર_{mode}_જોડાયેલ',
        'sa_unclipped': 'સેવા_વિસ્તાર_{mode}_વિલય_ક્લિપ_વિના',
        'sa_individual': 'સેવા_વિસ્તાર_{mode}_અલગ',
        'zonal': 'વસ્તી_{mode}',
        'las': 'શેરી_જમીન_વિલય',
        'stats': '{city}_આંકડા_11.2.1_અને_11.7.1',
        'm_pos': 'જાહેર_ખુલ્લી_જગ્યાઓ', 'm_bus': 'ઓછી_ક્ષમતા', 'm_ferry': 'ફેરી',
        'm_rail': 'રેલ', 'm_hc': 'ઉચ્ચ_ક્ષમતા', 'm_comb': 'સંયુક્ત_પરિવહન',
        'sheet_stats': 'આંકડા', 'sheet_roads': 'શેરીઓ',
    },
    'id': {
        'sa_dissolved': 'AL_{mode}_gabungan',
        'sa_clipped': 'AL_{mode}_terpotong',
        'sa_merged': 'AL_{mode}_digabung',
        'sa_unclipped': 'AL_{mode}_gabungan_tanpa_potong',
        'sa_individual': 'AL_{mode}_individual',
        'zonal': 'Penduduk_{mode}_AL',
        'las': 'Lahan_jalan_gabungan',
        'stats': '{city}_statistik_11.2.1_dan_11.7.1',
        'm_pos': 'RuangTerbukaPublik', 'm_bus': 'KapasitasRendah',
        'm_ferry': 'Feri', 'm_rail': 'Kereta', 'm_hc': 'KapasitasTinggi',
        'm_comb': 'AngkutanUmumGabungan',
        'sheet_stats': 'Statistik', 'sheet_roads': 'Jalan',
    },
    'tr': {
        'sa_dissolved': 'HA_{mode}_birleşik',
        'sa_clipped': 'HA_{mode}_kırpılmış',
        'sa_merged': 'HA_{mode}_birleştirilmiş',
        'sa_unclipped': 'HA_{mode}_birleşik_kırpılmamış',
        'sa_individual': 'HA_{mode}_tekil',
        'zonal': 'Nüfus_{mode}_HA',
        'las': 'Sokak_alanı_birleşik',
        'stats': '{city}_istatistik_11.2.1_ve_11.7.1',
        'm_pos': 'AçıkKamusalAlanlar', 'm_bus': 'DüşükKapasite',
        'm_ferry': 'Vapur', 'm_rail': 'Raylı', 'm_hc': 'YüksekKapasite',
        'm_comb': 'ToplamTopluTaşıma',
        'sheet_stats': 'İstatistik', 'sheet_roads': 'Sokaklar',
    },
    'ko': {
        'sa_dissolved': '서비스권_{mode}_디졸브',
        'sa_clipped': '서비스권_{mode}_클립',
        'sa_merged': '서비스권_{mode}_병합',
        'sa_unclipped': '서비스권_{mode}_디졸브_미클립',
        'sa_individual': '서비스권_{mode}_개별',
        'zonal': '인구_{mode}_서비스권',
        'las': '도로용지_디졸브',
        'stats': '{city}_통계_11.2.1_및_11.7.1',
        'm_pos': '공공오픈스페이스', 'm_bus': '저용량', 'm_ferry': '여객선',
        'm_rail': '철도', 'm_hc': '고용량', 'm_comb': '대중교통전체',
        'sheet_stats': '통계', 'sheet_roads': '도로',
    },
    'vi': {
        'sa_dissolved': 'VùngPV_{mode}_hợp_nhất',
        'sa_clipped': 'VùngPV_{mode}_cắt',
        'sa_merged': 'VùngPV_{mode}_gộp',
        'sa_unclipped': 'VùngPV_{mode}_hợp_nhất_chưa_cắt',
        'sa_individual': 'VùngPV_{mode}_riêng',
        'zonal': 'DânSố_{mode}_VùngPV',
        'las': 'Đất_đường_phố_hợp_nhất',
        'stats': '{city}_thống_kê_11.2.1_và_11.7.1',
        'm_pos': 'KhôngGianCôngCộngMở', 'm_bus': 'SứcChứaThấp',
        'm_ferry': 'Phà', 'm_rail': 'ĐườngSắt', 'm_hc': 'SứcChứaCao',
        'm_comb': 'GiaoThôngCôngCộngTổngHợp',
        'sheet_stats': 'Thống kê', 'sheet_roads': 'Đường phố',
    },
    'fa': {
        'sa_dissolved': 'محدوده_خدمات_{mode}_ادغام',
        'sa_clipped': 'محدوده_خدمات_{mode}_برش_خورده',
        'sa_merged': 'محدوده_خدمات_{mode}_ترکیب_شده',
        'sa_unclipped': 'محدوده_خدمات_{mode}_ادغام_بدون_برش',
        'sa_individual': 'محدوده_خدمات_{mode}_جداگانه',
        'zonal': 'جمعیت_{mode}',
        'las': 'زمین_خیابانها_ادغام',
        'stats': '{city}_آمار_11.2.1_و_11.7.1',
        'm_pos': 'فضاهای_باز_عمومی', 'm_bus': 'کم_ظرفیت', 'm_ferry': 'کشتی',
        'm_rail': 'ریلی', 'm_hc': 'پرظرفیت', 'm_comb': 'حمل_ونقل_تجمیعی',
        'sheet_stats': 'آمار', 'sheet_roads': 'خیابانها',
    },
    'th': {
        'sa_dissolved': 'พื้นที่บริการ_{mode}_รวม',
        'sa_clipped': 'พื้นที่บริการ_{mode}_ตัดขอบ',
        'sa_merged': 'พื้นที่บริการ_{mode}_ผนวก',
        'sa_unclipped': 'พื้นที่บริการ_{mode}_รวม_ไม่ตัดขอบ',
        'sa_individual': 'พื้นที่บริการ_{mode}_รายจุด',
        'zonal': 'ประชากร_{mode}',
        'las': 'ที่ดินถนน_รวม',
        'stats': '{city}_สถิติ_11.2.1_และ_11.7.1',
        'm_pos': 'พื้นที่สาธารณะเปิดโล่ง', 'm_bus': 'ความจุต่ำ',
        'm_ferry': 'เรือข้ามฟาก', 'm_rail': 'ราง', 'm_hc': 'ความจุสูง',
        'm_comb': 'ขนส่งสาธารณะรวม',
        'sheet_stats': 'สถิติ', 'sheet_roads': 'ถนน',
    },
    'pl': {
        'sa_dissolved': 'OO_{mode}_scalony',
        'sa_clipped': 'OO_{mode}_przycięty',
        'sa_merged': 'OO_{mode}_połączony',
        'sa_unclipped': 'OO_{mode}_scalony_nieprzycięty',
        'sa_individual': 'OO_{mode}_pojedyncze',
        'zonal': 'Ludność_{mode}_OO',
        'las': 'Teren_ulic_scalony',
        'stats': '{city}_statystyki_11.2.1_i_11.7.1',
        'm_pos': 'OtwartePrzestrzeniePubliczne', 'm_bus': 'MałaPojemność',
        'm_ferry': 'Prom', 'm_rail': 'Kolej', 'm_hc': 'DużaPojemność',
        'm_comb': 'TransportŁącznie',
        'sheet_stats': 'Statystyki', 'sheet_roads': 'Ulice',
    },
    'nl': {
        'sa_dissolved': 'VG_{mode}_samengevoegd',
        'sa_clipped': 'VG_{mode}_geknipt',
        'sa_merged': 'VG_{mode}_gecombineerd',
        'sa_unclipped': 'VG_{mode}_samengevoegd_ongeknipt',
        'sa_individual': 'VG_{mode}_afzonderlijk',
        'zonal': 'Bevolking_{mode}_VG',
        'las': 'Straatgrond_samengevoegd',
        'stats': '{city}_statistieken_11.2.1_en_11.7.1',
        'm_pos': 'OpenOpenbareRuimten', 'm_bus': 'LageCapaciteit',
        'm_ferry': 'Veer', 'm_rail': 'Spoor', 'm_hc': 'HogeCapaciteit',
        'm_comb': 'OVTotaal',
        'sheet_stats': 'Statistieken', 'sheet_roads': 'Straten',
    },
    'uk': {
        'sa_dissolved': 'ЗО_{mode}_обʼєднана',
        'sa_clipped': 'ЗО_{mode}_обрізана',
        'sa_merged': 'ЗО_{mode}_поєднана',
        'sa_unclipped': 'ЗО_{mode}_обʼєднана_необрізана',
        'sa_individual': 'ЗО_{mode}_окремі',
        'zonal': 'Населення_{mode}_ЗО',
        'las': 'Територія_під_вулицями',
        'stats': '{city}_статистика_11.2.1_та_11.7.1',
        'm_pos': 'Відкриті_простори', 'm_bus': 'Мала_місткість',
        'm_ferry': 'Пором', 'm_rail': 'Залізниця', 'm_hc': 'Велика_місткість',
        'm_comb': 'Транспорт_загалом',
        'sheet_stats': 'Статистика', 'sheet_roads': 'Вулиці',
    },
    'am': {
        'sa_dissolved': 'የአገልግሎት_ክልል_{mode}_የተዋሀደ',
        'sa_clipped': 'የአገልግሎት_ክልል_{mode}_የተቆረጠ',
        'sa_merged': 'የአገልግሎት_ክልል_{mode}_የተጣመረ',
        'sa_unclipped': 'የአገልግሎት_ክልል_{mode}_የተዋሀደ_ያልተቆረጠ',
        'sa_individual': 'የአገልግሎት_ክልል_{mode}_ተናጠል',
        'zonal': 'ሕዝብ_{mode}',
        'las': 'የመንገድ_መሬት_የተዋሀደ',
        'stats': '{city}_ስታቲስቲክስ_11.2.1_እና_11.7.1',
        'm_pos': 'የሕዝብ_ክፍት_ቦታዎች', 'm_bus': 'ዝቅተኛ_አቅም', 'm_ferry': 'ጀልባ',
        'm_rail': 'ባቡር', 'm_hc': 'ከፍተኛ_አቅም', 'm_comb': 'የተቀናጀ_ትራንስፖርት',
        'sheet_stats': 'ስታቲስቲክስ', 'sheet_roads': 'መንገዶች',
    },
    'ha': {
        'sa_dissolved': 'YankinHidima_{mode}_hade',
        'sa_clipped': 'YankinHidima_{mode}_yanke',
        'sa_merged': 'YankinHidima_{mode}_hadaddun',
        'sa_unclipped': 'YankinHidima_{mode}_hade_ba_yanke',
        'sa_individual': 'YankinHidima_{mode}_kowace_tasha',
        'zonal': 'YawanJamaa_{mode}',
        'las': 'Kasar_tituna_hade',
        'stats': '{city}_kididdiga_11.2.1_da_11.7.1',
        'm_pos': 'Wuraren_Budaddu', 'm_bus': 'Karamin_Karfi',
        'm_ferry': 'Jirgin_Ruwa', 'm_rail': 'Jirgin_Kasa', 'm_hc': 'Babban_Karfi',
        'm_comb': 'Sufurin_Jamaa',
        'sheet_stats': 'Kididdiga', 'sheet_roads': 'Tituna',
    },
}

# Internal transport labels used by the processing code -> mode keys.
MODE_KEYS = {
    'POS': 'm_pos', 'Bus': 'm_bus', 'Ferry': 'm_ferry', 'Rail': 'm_rail',
    'HighCap': 'm_hc', 'Combined': 'm_comb',
}

_BAD_FILE_CHARS = re.compile(r'[\\/:*?"<>|\x00-\x1f]')
_BAD_SHEET_CHARS = re.compile(r'[\\/:*?\[\]]')


def _get(lang, key):
    return FILE_NAMES.get(lang, {}).get(key) or FILE_NAMES['en'][key]


def safe_file_name(name):
    """Replace characters that Windows / macOS / Linux do not allow."""
    name = _BAD_FILE_CHARS.sub('_', name).replace(' ', '_').strip(' ._')
    return name or 'output'


def mode_name(lang, label):
    return _get(lang, MODE_KEYS.get(label, 'm_pos'))


def file_name(lang, key, label=None, city=''):
    """Translated output file name (no extension)."""
    template = _get(lang, key)
    name = template.format(mode=mode_name(lang, label) if label else '',
                           city=city)
    return safe_file_name(name)


def sheet_name(lang, key):
    name = _BAD_SHEET_CHARS.sub('_', _get(lang, key)).strip("'")
    return name[:31] or 'Sheet1'


def translate_info_file_list(text, lang):
    """Replace the English output file names in the Output-tab note with
    the names used for `lang`, keeping the columns aligned."""
    extra = '  ' + ' / '.join(
        _get(lang, k).format(mode='*') + '.shp'
        for k in ('sa_clipped', 'sa_merged', 'sa_unclipped'))
    lines = text.split('\n')
    for i, ln in enumerate(lines):
        if 'ZonalStats_*.shp' in ln:
            lines.insert(i, extra)
            break
    text = '\n'.join(lines)
    if lang == 'en':
        return text
    mapping = {}
    for label in ('POS', 'Bus', 'Ferry', 'Rail', 'HighCap', 'Combined'):
        mapping[file_name('en', 'sa_dissolved', label) + '.shp'] = \
            file_name(lang, 'sa_dissolved', label) + '.shp'
        mapping[file_name('en', 'sa_individual', label) + '.shp'] = \
            file_name(lang, 'sa_individual', label) + '.shp'
    mapping['ZonalStats_*.shp'] = _get(lang, 'zonal').format(mode='*') + '.shp'
    mapping[file_name('en', 'las') + '.shp'] = file_name(lang, 'las') + '.shp'
    mapping['{city}_statistics_11.2.1_and_11.7.1.xlsx'] = \
        _get(lang, 'stats') + '.xlsx'

    lines = []
    for line in text.split('\n'):
        m = re.match(r'^(  )(\S+\.(?:shp|xlsx))(\s{2,})(.+)$', line)
        if m and m.group(2) in mapping:
            line = '  {}  {}'.format(mapping[m.group(2)], m.group(4))
        else:
            for old, new in mapping.items():
                line = line.replace(old, new)
        lines.append(line)
    return '\n'.join(lines)
