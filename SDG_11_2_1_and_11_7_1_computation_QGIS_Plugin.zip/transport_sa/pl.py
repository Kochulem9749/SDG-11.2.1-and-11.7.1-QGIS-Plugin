# -*- coding: utf-8 -*-
"""Polski."""

TEXT = {
    'win_title': 'Obliczanie statystyk SDG 11.2.1 i 11.7.1',
    'subtitle': 'Wstępne przycięcie do obszaru miejskiego -> Ponowne odwzorowanie + '
                'naprawa geometrii -> Przycięcie otwartych przestrzeni publicznych -> '
                'Punkty granicy -> Obszar obsługi -> Otoczka wypukła -> Przycięcie -> '
                'Scalenie -> Ludność w obszarach obsługi -> Połączenie szerokości ulic '
                '-> Bufor -> Scalenie -> Przycięcie (teren przeznaczony pod ulice) -> '
                'Tabela statystyczna',
    'language': 'Język:',
    'tab_layers': 'Warstwy',
    'tab_distances': 'Odległości',
    'tab_output': 'Wyniki',
    'progress': 'Postęp',
    'btn_run': 'Uruchom analizę',
    'btn_cancel': 'Anuluj',
    'btn_reset': 'Wyczyść dziennik',
    'btn_close': 'Zamknij',
    'grp_streets': 'Ulice',
    'note_streets': 'Warstwa ulic używana do wyznaczania tras w sieci',
    'grp_urban': 'Granica miasta',
    'note_urban': 'Warstwa poligonowa określająca zasięg obszaru miejskiego',
    'grp_pop_raster': 'Ludność w siatce (raster)',
    'note_pop_raster': 'Zbiór danych o ludności w siatce. Podaj go LUB Ludność '
                       'gospodarstw domowych (punkty) poniżej - jedno z nich jest '
                       'wymagane.',
    'grp_hh': 'Ludność gospodarstw domowych (punkty)',
    'note_hh': 'Warstwa punktowa z liczbą osób w gospodarstwach domowych. Podaj ją LUB '
               'raster ludności w siatce - jedno z nich jest wymagane. Jeśli podano '
               'oba, używane są punkty gospodarstw domowych. Ludność każdego obszaru '
               'obsługi = suma wybranego pola dla punktów znajdujących się w jego '
               'wnętrzu.',
    'lbl_pop_field': 'Pole z łączną liczbą ludności (na punkt gospodarstwa '
                     'domowego):',
    'grp_pos': 'Otwarte przestrzenie publiczne (poligony)',
    'note_pos': 'Warstwy poligonowe niezabudowanych lub otwartych terenów dostępnych '
                'publicznie, zapewniających mieszkańcom miejsca rekreacji i '
                'poprawiających jakość środowiska. Przykłady: parki, ogrody, place '
                'zabaw, plaże publiczne, brzegi rzek i nabrzeża',
    'grp_bus': 'Przystanki transportu o małej pojemności (przystanki autobusowe, '
               'tramwajowe)',
    'note_bus': 'Warstwa punktowa lokalizacji przystanków autobusowych / '
                'tramwajowych',
    'grp_rail': 'Przystanki transportu o dużej pojemności (stacje kolejowe, stacje '
                'metra)',
    'note_rail': 'Warstwa punktowa lokalizacji stacji kolejowych / metra',
    'grp_ferry': 'Przystanki transportu o dużej pojemności (przystanie promowe)',
    'note_ferry': 'Warstwa punktowa lokalizacji terminali promowych',
    'grp_widths': 'Zmierzone szerokości ulic (tabela CSV)',
    'note_widths': 'Używane do terenu przeznaczonego pod ulice. Kolumna 1 = kategoria '
                   'drogi (dopasowywana do wybranego poniżej pola kategorii drogi), '
                   'kolumna 2 = zmierzona szerokość w metrach. Jeśli nie podano CSV i '
                   'brak pola kategorii, teren przeznaczony pod ulice = 0.',
    'btn_browse_csv': 'Wybierz CSV...',
    'grp_catfield': 'Pole kategorii drogi (z warstwy ulic)',
    'note_catfield': 'Pole warstwy ulic zawierające kategorie dróg, używane do '
                     'połączenia szerokości. \'fclass\', \'highway\' lub \'type\' '
                     'jest wybierane automatycznie, jeśli istnieje; w przeciwnym '
                     'razie wybierz pole tutaj. Pozostaw puste, aby wykryć '
                     'automatycznie.',
    'grp_crs': 'Docelowy układ współrzędnych (odwzorowany, w metrach - np. strefa '
               'UTM obszaru miejskiego)',
    'dist_header': 'Próg odległości sieciowej dla:',
    'dist_pos': 'Otwarte przestrzenie publiczne',
    'spacing_header': 'Odstęp punktów na granicy otwartych przestrzeni publicznych:',
    'spacing_note': 'Punkty startowe rozmieszczone wzdłuż obrysu każdej otwartej '
                    'przestrzeni. Standardem jest 100 m; większy odstęp (np. 200 m) '
                    'przyspiesza obliczenia w miastach z wieloma dużymi parkami, ale '
                    'nieco obniża dokładność.',
    'perf_header': 'Wydajność:',
    'chk_preclip': 'Wstępnie przytnij dane wejściowe do obszaru miejskiego',
    'note_preclip': 'Zalecane. Zachowuje tylko ulice, przystanki i otwarte przestrzenie '
                    'w marginesie wyszukiwania wokół miasta - znacznie szybciej przy '
                    'danych krajowych lub regionalnych.',
    'chk_memory': 'Przechowuj warstwy pośrednie w pamięci',
    'note_memory': 'Szybciej. Odznacz tylko, gdy komputerowi brakuje pamięci RAM.',
    'chk_native': 'Użyj wbudowanego algorytmu obszaru obsługi QGIS',
    'note_native': 'Tylko do kontroli - bardzo wolne przy wielu punktach startowych. '
                   'Domyślnie używane jest szybkie wyszukiwanie ograniczone (te same '
                   'wyniki).',
    'grp_city': 'Nazwa miasta (wskazówka: unikaj znaków specjalnych)',
    'city_placeholder': 'np. Mombasa',
    'lbl_output_folder': 'Folder wyników:',
    'btn_browse': 'Przeglądaj...',
    'info_block':
        "Zachowywane pliki wynikowe:\n"
        "  Przycięte i scalone obszary obsługi:\n"
        "  SA_POS_dissolved.shp                Otwarte przestrzenie publiczne\n"
        "  SA_Bus_dissolved.shp                Przystanki o małej pojemności\n"
        "  SA_Ferry_dissolved.shp              Przystanie promowe\n"
        "  SA_Rail_dissolved.shp               Stacje kolejowe\n"
        "  SA_HighCapacity_dissolved.shp       Duża pojemność (kolej + prom)\n"
        "  SA_CombinedTransport_dissolved.shp  Transport publiczny łącznie\n"
        "  Pojedyncze obszary obsługi (dla każdego przystanku):\n"
        "  SA_Bus_individual.shp / SA_Ferry_individual.shp / SA_Rail_individual.shp\n"
        "  ZonalStats_*.shp                    Obszar obsługi + pole pop_sum\n"
        "  LAS_streets_dissolved.shp           Teren przeznaczony pod ulice\n"
        "  {city}_statistics_11.2.1_and_11.7.1.xlsx\n\n"
        "UWAGI:\n"
        "  - Geometrie są automatycznie naprawiane przed przetwarzaniem.\n"
        "  - Ludność: punkty gospodarstw domowych (suma pola ludności), jeśli podano,\n"
        "    w przeciwnym razie raster ludności w siatce.\n"
        "  - Powierzchnia otwartych przestrzeni mierzona po przycięciu do granicy miasta.\n"
        "  - Dane są przycinane do obszaru miejskiego + margines wyszukiwania,\n"
        "    a warstwy pośrednie trzymane w pamięci (zob. kartę Odległości).\n"
        "  - Transport łącznie = przystanki o małej pojemności + prom + kolej\n"
        "    (bez otwartych przestrzeni publicznych).\n"
        "  - Teren pod ulice: bufor ulic według szerokości, scalony\n"
        "    i przycięty do zasięgu miasta.\n"
        "  - Tabela statystyczna jest zapisywana w wybranym języku.\n"
        "  - Po błędzie użyj „Wyczyść dziennik”, aby ponownie włączyć przyciski.",
    'msg_running_title': 'W toku',
    'msg_cannot_reset': 'Nie można wyczyścić podczas analizy. Najpierw ją anuluj.',
    'msg_missing_layer': 'Brak warstwy',
    'msg_select_streets': 'Wybierz warstwę ulic.',
    'msg_select_urban': 'Wybierz warstwę granicy miasta.',
    'msg_missing_pop_title': 'Brak danych o ludności',
    'msg_missing_pop': 'Wybierz warstwę ludności w siatce (raster) lub warstwę ludności '
                       'gospodarstw domowych (punkty) - jedna z nich jest wymagana.',
    'msg_missing_popfield_title': 'Brak pola ludności',
    'msg_missing_popfield': 'Wybierz pole z łączną liczbą ludności dla warstwy ludności '
                            'gospodarstw domowych (punkty).',
    'msg_missing_city_title': 'Brak nazwy miasta',
    'msg_missing_city': 'Wpisz nazwę miasta.',
    'msg_missing_output_title': 'Brak folderu wyników',
    'msg_missing_output': 'Wybierz folder wyników.',
    'msg_invalid_crs_title': 'Nieprawidłowy układ współrzędnych',
    'msg_invalid_crs': 'Wybierz prawidłowy docelowy układ współrzędnych.',
    'msg_no_transport_title': 'Brak warstw transportu',
    'msg_no_transport': 'Nie wybrano warstw otwartych przestrzeni publicznych / małej '
                        'pojemności / promów / kolei. Przetworzony zostanie tylko '
                        'obszar miejski i ulice. Kontynuować?',
    'msg_complete': 'Zakończono',
    'msg_error': 'Błąd',
    'msg_failed': 'Analiza nie powiodła się. Szczegóły w dzienniku.\n\n'
                  'Kliknij „Wyczyść dziennik” i uruchom ponownie.',
    'msg_close_running': 'Analiza nadal trwa. Anulować i zamknąć?',
    'msg_cancel_requested': 'Zażądano anulowania...',
    'dlg_select_output': 'Wybierz folder wyników',
    'dlg_select_csv': 'Wybierz CSV ze zmierzonymi szerokościami ulic',
    'csv_filter': 'Pliki CSV (*.csv *.txt);;Wszystkie pliki (*)',
    'msg_invalid_csv_title': 'Nieprawidłowy CSV',
    'msg_invalid_csv': 'Nie można odczytać:',
    'msg_widths_title': 'CSV szerokości ulic',
    'msg_widths_cols': 'Tabela szerokości ulic musi mieć co najmniej dwie kolumny '
                       '(kategoria drogi, szerokość). Zostanie pominięta.',
    'res_done': 'Gotowe!',
    'res_las': 'Teren przeznaczony pod ulice',
    'res_stats': 'Tabela statystyczna (CSV)',
    'res_excel': 'Skoroszyt statystyczny (Excel)',
    'res_roads': 'Tabela ulic',
    'res_folder': 'Folder',
    'res_time': 'Czas',
    'h_city': 'Miasto',
    'h_urban_area': 'Powierzchnia obszaru miejskiego (km2)',
    'h_pos_area': 'Powierzchnia otwartych przestrzeni publicznych (km2)',
    'h_las': 'Teren przeznaczony pod ulice (km2)',
    'h_ops_las': 'Otwarte przestrzenie publiczne + teren przeznaczony pod ulice (km2)',
    'h_prop_ops_las': 'Udział otwartych przestrzeni publicznych + terenu pod ulice w '
                      'powierzchni miasta (%)',
    'h_total_pop': 'Łączna ludność miasta',
    'h_pop_pos': 'Ludność z dostępem do otwartych przestrzeni publicznych',
    'h_pop_bus': 'Ludność z dostępem do przystanków transportu o małej pojemności '
                 '(przystanki autobusowe, tramwajowe)',
    'h_pop_hc': 'Ludność z dostępem do transportu o dużej pojemności (kolej + prom)',
    'h_pop_comb': 'Ludność z dostępem do transportu publicznego łącznie',
    'h_pct_pos': 'Odsetek ludności z dostępem do otwartych przestrzeni publicznych',
    'h_pct_bus': 'Odsetek ludności z dostępem do przystanków transportu o małej '
                 'pojemności (przystanki autobusowe, tramwajowe)',
    'h_pct_hc': 'Odsetek ludności z dostępem do transportu o dużej pojemności',
    'h_pct_comb': 'Odsetek ludności z dostępem do transportu publicznego łącznie',
    'h_pop_source': 'Źródło danych o ludności',
    'src_household': 'Punkty gospodarstw domowych',
    'src_raster': 'Raster w siatce',
    'src_field': 'pole',
}
